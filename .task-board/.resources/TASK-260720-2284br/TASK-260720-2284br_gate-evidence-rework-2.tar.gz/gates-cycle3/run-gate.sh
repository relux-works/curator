#!/bin/zsh
# Durable gate runner: survives harness shell kills.
# Usage: run-gate.sh <name> <command...>
# Writes <name>.log, then <name>.exit containing the real exit code as the
# last action, so a missing .exit file means "still running or killed",
# never "passed".
set -u
G="/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br/gates-cycle3"
name="$1"; shift
cd /Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-1zntv0/worktree || exit 97
rm -f "$G/$name.exit"
"$@" > "$G/$name.log" 2>&1
code=$?
print -r -- "$code" > "$G/$name.exit"
exit $code
