#!/bin/bash
# Final-tree sequential gate driver for TASK-260720-2284br rework cycle 4 (R5).
#
# Evidence protocol (unchanged from the R4 driver):
#   * every gate is a standalone process: no tee, no pipe chain, no subshell that
#     could swallow the status
#   * the real exit code is written to <name>.exit as the LAST action, so a
#     missing .exit means "killed or still running", never "passed"
#   * <name>.seconds records wall clock, <name>.log records combined output
#   * DRIVER-DONE only appears if the driver reached the end
#
# godriver runs as its own invocation with nothing else in flight: its probe
# deadline is wall-clock and it timed out under unrelated machine load in the
# previous cycle.

WT=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-1zntv0/worktree
G=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br/gates-cycle5
LINT=/Users/iv/go/1.25.5/bin/golangci-lint

cd "$WT" || exit 99
rm -f "$G/DRIVER-DONE"
pwd > "$G/PWD.txt"
date +%FT%T > "$G/DRIVER-START"

run() {
  name="$1"; shift
  start=$(date +%s)
  "$@" > "$G/$name.log" 2>&1
  code=$?
  echo "$(( $(date +%s) - start ))" > "$G/$name.seconds"
  echo "$code" > "$G/$name.exit"
}

# R5: the generation binding itself plus the four ABA cases and their control.
R5='TestReadDocumentBindsGenerationToBytesRewrittenInPlace|TestReadDocumentBindsGenerationToBytesReplacedByRename|TestDeclarationGenerationIsContentAddressed|TestDocumentGenerationIsStableWhenUnreadable|TestObservationsRecheckDocumentsAgainstTheParsedBytes|TestProjectManifestABAAroundTheReadRestartsClosure|TestGlobalManifestABAAroundTheReadRestartsClosure|TestSubstitutionsABAAroundTheReadRestartsClosure|TestHybridActivationABAAroundTheReadRestartsClosure|TestByteIdenticalRewriteDuringTheReadDoesNotRestart'
# R4: the one-way declaration revalidation cases this cycle must not regress.
REVALIDATION='TestStableDeclarationInputsCommitWithoutRestarting|TestProjectDeclarationRemovedBeforeHomeLockRestartsAndCommitsNoStaleState|TestProjectDeclarationAddedBeforeHomeLockRestartsAndCommitsTheNewClosure|TestGlobalDeclarationRemovedBeforeHomeLockRestartsAndCommitsNoStaleState|TestGlobalDeclarationAddedBeforeHomeLockRestartsAndCommitsTheNewClosure|TestDevSubstitutionAppearingBeforeHomeLockRestartsClosureResolution'
CONCURRENCY='TestConcurrentProjectInstallsPreserveBothConsumers|TestInstallHelperProcess|TestRecoveryCompletesBeforeAnyNewMutation|TestStaleInstalledGenerationRestartsInsteadOfApplyingTheOldPlan|TestRollbackCannotRestoreOverAnotherProjectsCommittedSharedTargets'
ACTIVATION='TestStableHybridActivationCommitsWithoutRestarting|TestHybridDeclarationRemovedBeforeHomeLockRestartsAndCommitsNoStaleContext|TestHybridDeclarationRetargetedBeforeHomeLockRestartsAndCommitsNoStaleContext|TestHybridDeclarationAddedBeforeHomeLockRestartsAndCommitsTheNewClosure'

# --- format / build ---------------------------------------------------------
run gate-gofmt      gofmt -l .
run gate-diff-check git diff --check
run gate-build      go build ./...
run gate-vet        go vet ./...

# --- focused: this cycle's own fix, then the fixes it must not regress -------
run gate-test-r5           go test ./internal/install -count=1 -run "$R5" -v
run gate-test-revalidation go test ./internal/install -count=1 -run "$REVALIDATION"
run gate-test-loaders      go test ./internal/manifest ./internal/devsub ./internal/scopes -count=1
# The reviewer cycle-2 hybrid and cycle-3 project/global repros, unmodified.
run gate-reviewer-overlays go test -overlay "$G/reviewer-overlay.json" ./internal/install -count=1 -run 'TestReviewerStale' -v

# --- full suites, split only so one log stays readable per scope -------------
run gate-test-install   go test ./internal/install -count=1
run gate-test-atomicity go test ./internal/install/atomicity -count=1
REST=$(go list ./... | grep -v '/internal/install$' | grep -v '/internal/install/atomicity$' | grep -v '/internal/godriver$')
run gate-test-rest      go test $REST -count=1
run gate-test-godriver  go test ./internal/godriver -count=1

# --- race over the changed read/revalidation path ---------------------------
run gate-race-r5           go test -race ./internal/install -count=1 -run "$R5"
run gate-race-revalidation go test -race ./internal/install -count=1 -run "$REVALIDATION"
run gate-race-concurrency  go test -race ./internal/install -count=1 -run "$CONCURRENCY"
run gate-race-activation   go test -race ./internal/install/atomicity -count=1 -run "$ACTIVATION"
run gate-race-loaders      go test -race ./internal/manifest ./internal/devsub ./internal/scopes -count=1

# --- pinned lint ------------------------------------------------------------
"$LINT" --version > "$G/lint-version.log" 2>&1
run gate-lint-repo "$LINT" run ./...

date +%FT%T > "$G/DRIVER-DONE"
