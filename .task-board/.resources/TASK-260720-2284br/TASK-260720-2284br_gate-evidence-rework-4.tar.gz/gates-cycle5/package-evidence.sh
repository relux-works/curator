#!/bin/bash
# Packages the cycle-5 (R5) gate archive: a GATES.md table generated from the
# durable .exit / .seconds files, every gate log, the negative-control diffs and
# logs, the driver itself, and the reviewer-overlay map.
set -u
G=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br/gates-cycle5
N=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br/negative-control-r5
OUT=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br/TASK-260720-2284br_gate-evidence-rework-4.tar.gz

{
  echo "# TASK-260720-2284br rework cycle 4 (R5) gates"
  echo
  echo "Worktree: $(cat "$G/PWD.txt" 2>/dev/null)"
  echo "Driver start: $(cat "$G/DRIVER-START" 2>/dev/null)"
  echo "Driver done:  $(cat "$G/DRIVER-DONE" 2>/dev/null || echo 'NOT REACHED')"
  echo "golangci-lint: $(cat "$G/lint-version.log" 2>/dev/null)"
  echo
  echo "Every exit below is the real status of a standalone process, written to a"
  echo "durable .exit file as that gate's last action. A gate with no .exit file was"
  echo "killed or never finished and is not evidence."
  echo
  printf '| gate | exit | seconds |\n| --- | --- | --- |\n'
  for f in "$G"/gate-*.exit; do
    [ -e "$f" ] || continue
    name=$(basename "$f" .exit)
    printf '| %s | %s | %s |\n' "$name" "$(cat "$f")" "$(cat "$G/$name.seconds" 2>/dev/null)"
  done
  echo
  echo "## Red gate, not claimed green"
  echo
  echo "gate-test-godriver exited $(cat "$G/gate-test-godriver.exit" 2>/dev/null) in the driver run:"
  echo "one subtest, TestBuildStopsBeforeBuildForEveryPreflightRejectionClass/escaped_embed,"
  echo "hit the sibling-owned 15s wall-clock probe deadline (go-v1 process_timeout) with no"
  echo "assertion failure anywhere, on a machine at load average 12+ from unrelated work."
  echo "Isolated rerun of the same tree: exit $(cat "$G/gate-test-godriver-rerun1.exit" 2>/dev/null) in"
  echo "$(grep -o '[0-9.]*s$' "$G/gate-test-godriver-rerun1.log" 2>/dev/null | tail -1)."
  echo "internal/godriver is owned by TASK-260720-6i3cya and is untouched by this task."
  echo
  echo "## Negative control (pre-fix relation restored)"
  echo
  printf '| variant | exit | outcome |\n| --- | --- | --- |\n'
  printf '| digest before the read | %s | 4 install-level ABA cases FAIL committing the transient declaration; in-place binding case FAILS; byte-identical control PASSES |\n' \
    "$(sed 's/exit=//' "$N/negative-control.exit" 2>/dev/null)"
  printf '| digest after the read | %s | rename binding case FAILS; in-place case passes |\n' \
    "$(sed 's/exit=//' "$N/negative-control-digest-after-read.exit" 2>/dev/null)"
} > "$G/GATES.md"

cd /Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br || exit 99
tar -czf "$OUT" \
  gates-cycle5/GATES.md \
  gates-cycle5/PWD.txt gates-cycle5/DRIVER-START gates-cycle5/DRIVER-DONE \
  gates-cycle5/run-gates.sh gates-cycle5/package-evidence.sh \
  gates-cycle5/reviewer-overlay.json gates-cycle5/lint-version.log gates-cycle5/lint-cache-clean.log \
  gates-cycle5/gate-*.log gates-cycle5/gate-*.exit gates-cycle5/gate-*.seconds \
  negative-control-r5/negative-control.diff \
  negative-control-r5/negative-control.log \
  negative-control-r5/negative-control.exit \
  negative-control-r5/negative-control-digest-after-read.diff \
  negative-control-r5/negative-control-digest-after-read.log \
  negative-control-r5/negative-control-digest-after-read.exit
status=$?
echo "tar exit=$status"
shasum -a 256 "$OUT"
