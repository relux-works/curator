package install

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"

	manifestpkg "github.com/relux-works/curator/internal/manifest"
)

func TestReviewerProjectManifestABARestartsClosure(t *testing.T) {
	e := newEnv(t)
	e.skill("skill-a")
	e.skill("skill-b")
	e.declare("skill-a")
	if err := manifestpkg.AddDecl(e.project, "skill-a", "tag", "v1", "", ""); err != nil {
		t.Fatalf("canonicalize initial manifest through its real writer: %v", err)
	}
	originalManifest, err := os.ReadFile(manifestpkg.PathIn(e.project))
	if err != nil {
		t.Fatal(err)
	}

	var hookErr error
	reviewerAfterProjectManifestObserve = func() {
		reviewerAfterProjectManifestObserve = nil
		hookErr = manifestpkg.AddDecl(e.project, "skill-b", "tag", "v1", "", "")
	}
	reviewerAfterProjectManifestLoad = func() {
		reviewerAfterProjectManifestLoad = nil
		if hookErr == nil {
			hookErr = manifestpkg.RemoveDecl(e.project, "skill-b")
		}
	}
	t.Cleanup(func() {
		reviewerAfterProjectManifestObserve = nil
		reviewerAfterProjectManifestLoad = nil
	})

	result := e.install(Options{})
	if hookErr != nil {
		t.Fatalf("exercise the manifest ABA window: %v", hookErr)
	}
	if result.Status != "ok" {
		t.Fatalf("install failed: %+v", result)
	}
	currentManifest, err := os.ReadFile(manifestpkg.PathIn(e.project))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(currentManifest, originalManifest) {
		t.Fatal("exercise did not restore byte-identical manifest A")
	}
	if !hasMessageContaining(result.Messages, "restarting from closure resolution") {
		t.Fatalf("manifest changed A -> B -> A around Load without restarting; messages = %v", result.Messages)
	}
	if _, err := os.Lstat(filepath.Join(e.project, ".agents", "skills", "skill-b")); !os.IsNotExist(err) {
		t.Fatalf("transient skill-b closure committed although current manifest omits it: %v", err)
	}
}
