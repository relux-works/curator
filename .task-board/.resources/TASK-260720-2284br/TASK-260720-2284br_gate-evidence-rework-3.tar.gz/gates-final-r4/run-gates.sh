#!/bin/bash
# Final-tree sequential gate driver for TASK-260720-2284br rework cycle 3 (R4).
#
# Evidence protocol:
#   * every gate is a standalone process: no tee, no pipe chain, no subshell
#     that could swallow the status
#   * the real exit code is written to <name>.exit as the LAST action, so a
#     missing .exit means "killed or still running", never "passed"
#   * <name>.seconds records wall clock, <name>.log records combined output
#   * DRIVER-DONE only appears if the driver reached the end
#
# godriver runs as its own invocation with nothing else in flight: its probe
# deadline is wall-clock and it timed out under load in the earlier combined
# test-rest chunk.

WT=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-1zntv0/worktree
G=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br/gates-final-r4
LINT=/Users/iv/go/1.25.5/bin/golangci-lint

cd "$WT" || exit 99
rm -f "$G/DRIVER-DONE"
pwd > "$G/PWD.txt"

run() {
  name="$1"; shift
  start=$(date +%s)
  "$@" > "$G/$name.log" 2>&1
  code=$?
  echo "$(( $(date +%s) - start ))" > "$G/$name.seconds"
  echo "$code" > "$G/$name.exit"
}

REVALIDATION='TestStableDeclarationInputsCommitWithoutRestarting|TestProjectDeclarationRemovedBeforeHomeLockRestartsAndCommitsNoStaleState|TestProjectDeclarationAddedBeforeHomeLockRestartsAndCommitsTheNewClosure|TestGlobalDeclarationRemovedBeforeHomeLockRestartsAndCommitsNoStaleState|TestGlobalDeclarationAddedBeforeHomeLockRestartsAndCommitsTheNewClosure|TestDevSubstitutionAppearingBeforeHomeLockRestartsClosureResolution'
ACTIVATION='TestStableHybridActivationCommitsWithoutRestarting|TestHybridDeclarationRemovedBeforeHomeLockRestartsAndCommitsNoStaleContext|TestHybridDeclarationRetargetedBeforeHomeLockRestartsAndCommitsNoStaleContext|TestHybridDeclarationAddedBeforeHomeLockRestartsAndCommitsTheNewClosure'
CONCURRENCY='TestConcurrentProjectInstallsPreserveBothConsumers|TestInstallHelperProcess|TestRecoveryCompletesBeforeAnyNewMutation|TestStaleInstalledGenerationRestartsInsteadOfApplyingTheOldPlan|TestRollbackCannotRestoreOverAnotherProjectsCommittedSharedTargets'

# --- format / build ---------------------------------------------------------
run gofmt      gofmt -l .
run diff-check git diff --check
run build      go build ./...
run vet        go vet ./...

# --- focused R4 revalidation first: highest signal, cheapest to lose ---------
run test-revalidation go test -count=1 ./internal/install -run "$REVALIDATION"

# --- full suite in chunks (split only to fit the harness command limit) ------
run test-install   go test -count=1 ./internal/install
run test-atomicity go test -count=1 ./internal/install/atomicity
run test-godriver  go test -count=1 ./internal/godriver
run test-rest      go test -count=1 $(go list ./... | grep -v -E '/internal/install$|/internal/install/atomicity$|/internal/godriver$')

# --- race gates proportionate to the changed paths --------------------------
run race-revalidation go test -race -count=1 ./internal/install -run "$REVALIDATION"
run race-concurrency  go test -race -count=1 ./internal/install -run "$CONCURRENCY"
run race-activation   go test -race -count=1 ./internal/install/atomicity -run "$ACTIVATION"
run race-staging      go test -race -count=1 ./internal/staging ./internal/transaction

# --- pinned repo-wide lint --------------------------------------------------
"$LINT" --version > "$G/lint-version.log" 2>&1
run lint-repo "$LINT" run ./...

echo done > "$G/DRIVER-DONE"
