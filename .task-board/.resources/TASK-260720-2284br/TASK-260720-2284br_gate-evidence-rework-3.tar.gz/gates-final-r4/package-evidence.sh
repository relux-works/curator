#!/bin/bash
# Packages the cycle-3 / R4 final-tree gate archive.
# Includes the completed final-tree gates, the negative control, and the
# reviewer overlay repro. Superseded/killed material is included only under
# clearly named directories so the record shows what was discarded.
set -u

T=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br
OUT="$T/TASK-260720-2284br_gate-evidence-rework-3.tar.gz"

cd "$T" || exit 9

# Machine-readable summary of every final-tree gate.
{
  echo "TASK-260720-2284br rework cycle 3 (R4) — final-tree gate summary"
  echo "worktree: $(cat gates-final-r4/PWD.txt 2>/dev/null)"
  echo "golangci-lint: $(cat gates-final-r4/lint-version.log 2>/dev/null)"
  echo "driver completed: $([ -f gates-final-r4/DRIVER-DONE ] && echo yes || echo NO)"
  echo
  printf '%-22s %6s %10s\n' GATE EXIT SECONDS
  for f in gates-final-r4/*.exit; do
    n=$(basename "$f" .exit)
    printf '%-22s %6s %10s\n' "$n" "$(cat "$f")" "$(cat "gates-final-r4/$n.seconds" 2>/dev/null)"
  done
} > gates-final-r4/SUMMARY.txt

tar -czf "$OUT" \
  gates-final-r4 \
  gates-cycle4/negative-control.log \
  gates-cycle4/negative-control \
  review/global-overlay.json \
  review/stale_global_manifest_test.go \
  2>/dev/null

echo "wrote $OUT"
ls -l "$OUT"
