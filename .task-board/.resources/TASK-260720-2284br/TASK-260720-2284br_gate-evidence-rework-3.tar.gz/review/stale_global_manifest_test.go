package install

import (
	"os"
	"path/filepath"
	"testing"

	manifestpkg "github.com/relux-works/curator/internal/manifest"
)

func TestReviewerStaleGlobalManifestRestartsClosure(t *testing.T) {
	e := newEnv(t)
	e.skill("skill-a")
	e.skill("skill-b")
	if _, err := GlobalInit(e.home); err != nil {
		t.Fatal(err)
	}
	if err := manifestAddGlobal(e, "skill-a"); err != nil {
		t.Fatal(err)
	}
	if err := manifestAddGlobal(e, "skill-b"); err != nil {
		t.Fatal(err)
	}

	changed := false
	result := Global(e.cfg, t.TempDir(), Options{
		Platform: "unix",
		OnStaged: func(Staged) error {
			if changed {
				return nil
			}
			changed = true
			return manifestpkg.RemoveDecl(GlobalRoot(e.home), "skill-b")
		},
	})
	if result.Status != "ok" {
		t.Fatalf("global install failed: %+v", result)
	}
	if !hasMessageContaining(result.Messages, "restarting from closure resolution") {
		t.Fatalf("stale global manifest did not restart closure resolution: messages=%v", result.Messages)
	}
	if _, err := os.Lstat(filepath.Join(GlobalRoot(e.home), "skills", "skill-b")); !os.IsNotExist(err) {
		t.Fatalf("stale global closure installed skill-b after its declaration was removed: %v", err)
	}
}

func TestReviewerStaleProjectManifestRestartsClosure(t *testing.T) {
	e := newEnv(t)
	e.skill("skill-a")
	e.skill("skill-b")
	e.declare("skill-a", "skill-b")

	changed := false
	result := e.install(Options{
		OnStaged: func(Staged) error {
			if changed {
				return nil
			}
			changed = true
			return manifestpkg.RemoveDecl(e.project, "skill-b")
		},
	})
	if result.Status != "ok" {
		t.Fatalf("project install failed: %+v", result)
	}
	if !hasMessageContaining(result.Messages, "restarting from closure resolution") {
		t.Fatalf("stale project manifest did not restart closure resolution: messages=%v", result.Messages)
	}
	if _, err := os.Lstat(filepath.Join(e.project, ".agents", "skills", "skill-b")); !os.IsNotExist(err) {
		t.Fatalf("stale project closure installed skill-b after its declaration was removed: %v", err)
	}
}
