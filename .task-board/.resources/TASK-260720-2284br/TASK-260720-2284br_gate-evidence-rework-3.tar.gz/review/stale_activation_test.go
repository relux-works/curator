package install

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/curator/internal/scopes"
)

func TestReviewerStaleHybridActivationRestarts(t *testing.T) {
	e := newEnv(t)
	e.skill("skill-a")
	e.skill("skill-h")
	e.declare("skill-a")

	writeHybrid := func(names ...string) {
		t.Helper()
		skills := make([]map[string]any, 0, len(names))
		for _, name := range names {
			skills = append(skills, map[string]any{
				"name": name, "tag": "v1", "targets": []string{"test"},
			})
		}
		payload, err := json.MarshalIndent(map[string]any{
			"schema_version": 1,
			"skills":         skills,
		}, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		e.write(e.home, "hybrid/Skillfile.json", string(payload))
	}
	writeHybrid("skill-h")

	changed := false
	result := e.install(Options{OnStaged: func(Staged) error {
		if !changed {
			changed = true
			writeHybrid()
		}
		return nil
	}})
	if result.Status != "ok" {
		t.Fatalf("install failed after activation restart: %+v", result)
	}
	if !hasMessageContaining(result.Messages, "restarting from") {
		t.Fatalf("stale hybrid activation did not restart planning: messages=%v", result.Messages)
	}
	if _, err := os.Lstat(filepath.Join(scopes.HybridSkillsRoot(e.home), "skill-h")); !os.IsNotExist(err) {
		t.Fatalf("stale activation installed skill-h after its declaration was removed: %v", err)
	}
}
