#!/bin/bash
# Packages the cycle-3 / R4 final-tree gate archive.
#
# gates-r4-verify is the first-hand re-run of every gate on the final tree by
# the run that hands off. gates-final-r4 is the earlier 18:22-18:38 run whose
# session was killed before it could package or hand off; it is included as a
# second independent pass, not as the primary evidence.
set -u

T=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-2284br
OUT="$T/TASK-260720-2284br_gate-evidence-rework-3.tar.gz"

cd "$T" || exit 9

# Machine-readable summary of every final-tree gate.
{
  echo "TASK-260720-2284br rework cycle 3 (R4) - final-tree gate summary"
  echo "worktree: $(cat gates-r4-verify/PWD.txt 2>/dev/null)"
  echo "golangci-lint: $(cat gates-r4-verify/lint-version.log 2>/dev/null)"
  echo "started: $(cat gates-r4-verify/STARTED-AT.txt 2>/dev/null)"
  echo "finished: $(cat gates-r4-verify/FINISHED-AT.txt 2>/dev/null)"
  echo "driver completed: $([ -f gates-r4-verify/DRIVER-DONE ] && echo yes || echo NO)"
  echo
  printf '%-22s %6s %10s\n' GATE EXIT SECONDS
  for f in gates-r4-verify/*.exit; do
    n=$(basename "$f" .exit)
    printf '%-22s %6s %10s\n' "$n" "$(cat "$f")" "$(cat "gates-r4-verify/$n.seconds" 2>/dev/null)"
  done
  echo
  echo "negative control (gates-cycle4/negative-control.log): expected-red, exit 1"
  echo "  overlay removes exactly the three observed.observe lines; the five"
  echo "  mutation cases fail and the control still passes."
} > gates-r4-verify/SUMMARY.txt

tar -czf "$OUT" \
  gates-r4-verify \
  gates-final-r4 \
  gates-cycle4/negative-control.log \
  gates-cycle4/negative-control \
  review/global-overlay.json \
  review/stale_global_manifest_test.go \
  review/overlay.json \
  review/stale_activation_test.go \
  2>/dev/null

echo "wrote $OUT"
ls -l "$OUT"
cat gates-r4-verify/SUMMARY.txt
