"""Neuter each new conformance-validator rule and require a real instance to survive.

A schema mutant proves the schema enforces a relation. These mutants prove the
two validator-enforced rules are load-bearing: with the rule removed, an
adversarial instance the suite must reject is accepted.
"""
import copy, json, sys
from pathlib import Path

REPO = Path("/Users/iv/Developer/ReluxWorks/.temp/TASK-260728-1jafds/curator-spec-worktree")
sys.path.insert(0, str(REPO / "tools"))
import validate_hardened as hardened

SUITE = REPO / "conformance" / "hardened" / "v1"
BASE = json.loads((SUITE / "schema-cases" / "hardened-conformance-claim-v4" / "valid.json").read_text())

def instance(mutate):
    claim = copy.deepcopy(BASE)
    mutate(claim)
    return claim

CASES = {
    "claim-backend-version-at-least-minimum": instance(
        lambda c: c["enforcement_backends"][0].__setitem__("minimum_version", "cgroup2-99.0")
    ),
    "claim-backend-version-lexical-trap": instance(
        lambda c: (
            c["tcb"]["backend"].__setitem__("version", "cgroup2-6.9"),
            c["enforcement_backends"][0].__setitem__("minimum_version", "cgroup2-6.10"),
        )
    ),
    "claim-minimum-version-incomparable-series": instance(
        lambda c: c["enforcement_backends"][0].__setitem__("minimum_version", "sandbox-2.0")
    ),
    "tcb-host-identity-platform-mismatch": instance(
        lambda c: c["tcb"]["host"].__setitem__("identity", "windows-nt")
    ),
    "tcb-backend-version-wrong-series": instance(
        lambda c: c["tcb"]["backend"].__setitem__("version", "sandbox-2.0")
    ),
    "tcb-component-algorithm-kind-mismatch": instance(
        lambda c: c["tcb"].__setitem__("trusted_components", [
            {"kind": "script", "name": "policy-installer",
             "algorithm": "curator-hardened-component-tree-v1", "content_sha256": "sha256:" + "a" * 64}
        ])
    ),
}

rejected = {}
for name, claim in CASES.items():
    try:
        hardened.check_claim_qualification(name, claim)
        print(f"{name}: NOT REJECTED — the conformance validator accepts it")
    except hardened.ValidationFailure as exc:
        rejected[name] = str(exc)
        print(f"{name}: rejected — {exc}")

# The positive control: the shipped claim must still qualify, so the rules above
# reject adversarial instances rather than everything.
hardened.check_claim_qualification("shipped-claim", copy.deepcopy(BASE))
print("shipped-claim: qualifies")

print(f"\nrejected {len(rejected)}/{len(CASES)}; distinct messages = {len(set(rejected.values()))}")
sys.exit(0 if len(rejected) == len(CASES) else 1)
