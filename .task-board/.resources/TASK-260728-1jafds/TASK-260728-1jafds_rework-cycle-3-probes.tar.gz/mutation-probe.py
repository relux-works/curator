"""Delete each new rule from the shipped artifacts and require a distinct failure."""
import copy, json, shutil, sys, tempfile
from pathlib import Path

REPO = Path("/Users/iv/Developer/ReluxWorks/.temp/TASK-260728-1jafds/curator-spec-worktree")
sys.path.insert(0, str(REPO / "tools"))
import validate_hardened as hardened

COMMON = ("schemas", "hardened", "v1", "hardened-common.schema.json")
CLAIM = ("schemas", "hardened", "v1", "hardened-conformance-claim-v4.schema.json")


def drop_ref(schema, path, ref):
    """Replace one relation with a vacuous branch.

    Deleting the entry outright can empty an allOf and fail as an invalid
    schema, which would 'detect' the mutation for the wrong reason. Neutering
    the relation in place keeps the document valid, so only the relation itself
    is under test.
    """
    node = schema
    for key in path:
        node = node[key]
    replaced = 0
    for index, item in enumerate(node["allOf"]):
        if item.get("$ref") == ref:
            node["allOf"][index] = {"type": "object"}
            replaced += 1
    assert replaced == 1, f"{ref} was not present exactly once at {path}"


MUTATIONS = {
    "host-identity-to-platform": (
        COMMON,
        lambda s: drop_ref(s, ("$defs", "hardenedTcbRecordV1"), "#/$defs/hardenedHostPlatformRelationV1"),
    ),
    "backend-version-series-to-backend": (
        COMMON,
        lambda s: drop_ref(s, ("$defs", "hardenedTcbRecordV1"), "#/$defs/hardenedBackendVersionSeriesRelationV1"),
    ),
    "component-algorithm-to-kind": (
        COMMON,
        lambda s: drop_ref(s, ("$defs", "hardenedTrustedComponentV1"), "#/$defs/hardenedComponentAlgorithmKindRelationV1"),
    ),
    "host-kind-narrowing": (
        COMMON,
        lambda s: s["$defs"].__setitem__("hardenedHostKindV1", {"enum": ["hypervisor", "operating-system"]}),
    ),
    "host-identity-value-set": (
        COMMON,
        lambda s: s["$defs"].__setitem__(
            "hardenedHostIdentityValueV1", {"$ref": "../../v1/common.schema.json#/$defs/nonEmptyString"}
        ),
    ),
    "backend-version-grammar": (
        COMMON,
        lambda s: s["$defs"].__setitem__(
            "hardenedBackendVersionV1", {"$ref": "../../v1/common.schema.json#/$defs/nonEmptyString"}
        ),
    ),
    "claim-minimum-version-series": (
        CLAIM,
        lambda s: drop_ref(
            s,
            ("properties", "enforcement_backends", "items"),
            "hardened-common.schema.json#/$defs/hardenedMinimumVersionSeriesRelationV1",
        ),
    ),
}

saved = {
    name: getattr(hardened, name)
    for name in ("ROOT", "PORTABLE_SCHEMAS", "HARDENED_SCHEMAS", "PORTABLE_SUITE", "HARDENED_SUITE")
}
failures = {}
for name, (target, mutate) in MUTATIONS.items():
    with tempfile.TemporaryDirectory() as raw:
        root = Path(raw)
        for directory in ("schemas", "conformance", "release"):
            shutil.copytree(REPO / directory, root / directory)
        path = root.joinpath(*target)
        schema = json.loads(path.read_text())
        mutate(schema)
        path.write_text(json.dumps(schema, indent=2) + "\n")
        hardened.ROOT = root
        hardened.PORTABLE_SCHEMAS = root / "schemas" / "v1"
        hardened.HARDENED_SCHEMAS = root / "schemas" / "hardened" / "v1"
        hardened.PORTABLE_SUITE = root / "conformance" / "v1"
        hardened.HARDENED_SUITE = root / "conformance" / "hardened" / "v1"
        try:
            hardened.validate_schema_closed_value_sets()
            hardened.validate_tcb_schema_relations()
            print(f"{name}: NOT DETECTED — the shipped suite accepts the weakened schema")
        except hardened.ValidationFailure as exc:
            failures[name] = str(exc)
            print(f"{name}: detected — {exc}")
        finally:
            for key, value in saved.items():
                setattr(hardened, key, value)

print(f"\ndetected {len(failures)}/{len(MUTATIONS)}; distinct messages = {len(set(failures.values()))}")
sys.exit(0 if len(failures) == len(MUTATIONS) else 1)
