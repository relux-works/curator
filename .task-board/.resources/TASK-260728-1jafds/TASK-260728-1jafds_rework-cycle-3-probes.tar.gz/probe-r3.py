"""Reproduce review cycle 3 probes R3-1 and R3-2 against the shipped candidate."""
import json, sys, copy
from pathlib import Path

ROOT = Path("/Users/iv/Developer/ReluxWorks/.temp/TASK-260728-1jafds/curator-spec-worktree")
sys.path.insert(0, str(ROOT / "tools"))
import validate_hardened as hardened

SUITE = ROOT / "conformance" / "hardened" / "v1"
claim_validator = hardened.validator_for("hardened-conformance-claim-v4.schema.json")
base = json.loads((SUITE / "schema-cases" / "hardened-conformance-claim-v4" / "valid.json").read_text())

def probe(name, doc):
    errs = list(claim_validator.iter_errors(doc))
    try:
        hardened.check_claim_qualification(name, doc)
        semantic = "ACCEPTED"
    except hardened.ValidationFailure as exc:
        semantic = f"rejected: {exc}"
    print(f"{name}: schema errors = {len(errs)}; check_claim_qualification {semantic}")

# R3-2 probe 1: observed backend version far below the declared minimum.
below = copy.deepcopy(base)
below["tcb"]["backend"]["version"] = "0"
below["enforcement_backends"][0]["minimum_version"] = "999999"
probe("backend-below-minimum", below)

# R3-2 probe 2: a linux TCB whose observed host identity is windows.
contradiction = copy.deepcopy(base)
contradiction["tcb"]["host"]["identity"] = "windows"
contradiction["tcb"]["host"]["version"] = "1.0"
probe("host-platform-contradiction", contradiction)

# R3-2 probe 3: both versions well formed and in the right series, so only the
# comparison itself can reject this one.
well_formed_below = copy.deepcopy(base)
well_formed_below["tcb"]["backend"]["version"] = "cgroup2-6.0"
well_formed_below["enforcement_backends"][0]["minimum_version"] = "cgroup2-6.99"
probe("well-formed-below-minimum", well_formed_below)

# R3-2 probe 4: the lexical trap. 6.9 sorts after 6.10 as a string and is below
# it as a version.
lexical = copy.deepcopy(base)
lexical["tcb"]["backend"]["version"] = "cgroup2-6.9"
lexical["enforcement_backends"][0]["minimum_version"] = "cgroup2-6.10"
probe("below-minimum-not-lexical", lexical)

# R3-1: are the two component digest algorithms normatively constructed?
PROTOCOL = (ROOT / "protocol" / "hardened-execution.md").read_text().splitlines()
for algorithm in ("curator-hardened-component-file-v1", "curator-hardened-component-tree-v1"):
    heading = f"##### `{algorithm}`"
    defined = [
        number for number, line in enumerate(PROTOCOL, 1) if line.strip() == heading
    ]
    mentions = [number for number, line in enumerate(PROTOCOL, 1) if algorithm in line]
    print(
        f"{algorithm}: normative construction at protocol/hardened-execution.md"
        f":{defined or 'MISSING'}; mentions = {mentions}"
    )

# R3-1: the fixtures must be reproducible from their own published bytes by an
# implementation that never runs the generator.
vector = json.loads((SUITE / "vectors" / "hardened-identity-separation.json").read_text())
fixtures = vector["component_digest_fixtures"]["fixtures"]
for fixture in fixtures:
    recomputed = hardened.recompute_component_fixture(fixture["name"], fixture)
    status = "reproduced" if recomputed == fixture["expected_sha256"] else "MISMATCH"
    print(f"fixture {fixture['name']}: {status} {recomputed}")
print(f"distinct fixture digests: {len({f['expected_sha256'] for f in fixtures})}/{len(fixtures)}")
