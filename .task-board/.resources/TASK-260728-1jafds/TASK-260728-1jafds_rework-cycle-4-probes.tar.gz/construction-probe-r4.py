"""Break the cycle-4 constructions in the generator and require detection.

The schema and vector mutations are covered by mutation-probe-r4.py. This probe
attacks the layer below them: the Go construction itself, and the phase order it
emits. Each mutation is applied to a scratch copy of the repository, which is
then regenerated and re-validated by both implementations. A mutation nothing
catches would mean the construction is only asserted, not enforced.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/iv/Developer/ReluxWorks/.temp/TASK-260728-1jafds/curator-spec-worktree")
VENV = REPO / ".venv" / "bin" / "python"
MAIN = Path("tools") / "generate-hardened" / "main.go"

MUTATIONS = {
    # The source count keeps a truncated observation list from aliasing a full
    # one. Dropping it here desynchronises Go from the Python recomputation.
    "drop-the-hashed-source-count": (
        MAIN,
        """	var framing [8]byte
	binary.BigEndian.PutUint64(framing[:], uint64(len(sources)))
	digest.Write(framing[:])
	for _, source := range sources {""",
        """	for _, source := range sources {""",
    ),
    # Without per-field framing, two field lists whose byte stream concatenates
    # identically become one input.
    "drop-the-source-field-framing": (
        MAIN,
        """	for _, source := range sources {
		writeFramed(digest, source.name)
		writeFramed(digest, source.value)
	}""",
        """	for _, source := range sources {
		digest.Write([]byte(source.name))
		digest.Write([]byte(source.value))
	}""",
    ),
    # Hashing the observed values as one blob, which is exactly what the
    # boundary-shift fixture exists to catch.
    "hash-only-the-concatenated-source-values": (
        MAIN,
        """	for _, source := range sources {
		writeFramed(digest, source.name)
		writeFramed(digest, source.value)
	}""",
        """	blob := ""
	for _, source := range sources {
		blob += source.value
	}
	writeFramed(digest, blob)""",
    ),
    # Without the observed tuple, one build digest could be published beside any
    # kernel identity or release.
    "drop-the-observed-tuple-from-the-digest": (
        MAIN,
        """	writeFramed(digest, identity)
	writeFramed(digest, version)
	writeFramed(digest, identifier)""",
        """	writeFramed(digest, identifier)""",
    ),
    # The exact aliasing review cycle 4 found: drop the source the two kernels
    # differ in, and they become one trusted computing base again.
    "drop-the-kernel-version-source-macos": (
        MAIN,
        """		source("kern.version", kernelVersion),""",
        """""",
    ),
    # The ordering the finding rejected.
    "reverify-before-the-domain-is-joined": (
        MAIN,
        """		{"domain-teardown", "hardened-supervisor", "hardened_domain_breach_detected", true},
		{"identity-reverification", "manager-parent", "hardened_tcb_identity_invalid", true},""",
        """		{"identity-reverification", "manager-parent", "hardened_tcb_identity_invalid", true},
		{"domain-teardown", "hardened-supervisor", "hardened_domain_breach_detected", true},""",
    ),
    # The narrower obligation the finding rejected: supervisor, worker,
    # snapshot, toolchain only.
    "reverify-only-the-cycle-3-subset": (
        MAIN,
        """	out := []string{"source-snapshot"}
	for _, item := range tcbBoundFields() {
		field := item.(map[string]any)["field"].(string)
		if !constant[field] {
			out = append(out, field)
		}
	}""",
        """	out := []string{"source-snapshot", "supervisor_sha256", "worker_sha256", "toolchain"}
	_ = constant""",
    ),
}


def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
    return result.returncode, (result.stdout + result.stderr).strip()


detected = {}
for name, (target, before, after) in MUTATIONS.items():
    with tempfile.TemporaryDirectory() as raw:
        root = Path(raw) / "repo"
        shutil.copytree(
            REPO, root, ignore=shutil.ignore_patterns(".venv", ".git", ".temp")
        )
        path = root / target
        source = path.read_text(encoding="utf-8")
        if source.count(before) != 1:
            print(f"{name}: PROBE BROKEN — anchor appears {source.count(before)} times")
            continue
        path.write_text(source.replace(before, after), encoding="utf-8")

        stage = None
        code, output = run(["gofmt", "-l", "tools"], root)
        code, output = run(["go", "test", "-count=1", "./tools/..."], root)
        if code != 0:
            stage = "go test"
        else:
            code, output = run(["go", "run", "./tools/generate-hardened", "-root", "."], root)
            if code != 0:
                stage = "generate"
            else:
                code, output = run([str(VENV), "tools/validate_hardened.py"], root)
                if code != 0:
                    stage = "validate_hardened.py"
        if stage is None:
            print(f"{name}: NOT DETECTED — the weakened construction regenerates and validates")
            continue
        first = next(
            (
                line
                for line in output.splitlines()
                if line.strip() and not line.startswith(("ok ", "---", "FAIL\t", "?"))
            ),
            output.splitlines()[0] if output else "",
        )
        detected[name] = f"{stage}: {first.strip()[:160]}"
        print(f"{name}: detected by {detected[name]}")

print(f"\ndetected {len(detected)}/{len(MUTATIONS)}")
sys.exit(0 if len(detected) == len(MUTATIONS) else 1)
