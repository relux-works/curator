"""Reproduce both review-cycle-4 findings against the candidate.

R4-1: the observed-host record could alias materially different kernels.
R4-2: full-TCB stability was neither ordered nor reverified through domain exit.

Every check below is run against the shipped artifacts, not against prose.
"""
import copy
import json
import re
import sys
from pathlib import Path

REPO = Path("/Users/iv/Developer/ReluxWorks/.temp/TASK-260728-1jafds/curator-spec-worktree")
sys.path.insert(0, str(REPO / "tools"))
import validate_hardened as hardened  # noqa: E402

SUITE = hardened.HARDENED_SUITE
RECEIPT_V3 = "hardened-build-receipt-v3.schema.json"
failures = []


def check(name, condition, detail=""):
    print(f"{'PASS' if condition else 'FAIL'}  {name}{(' — ' + detail) if detail else ''}")
    if not condition:
        failures.append(name)


def valid_case(schema):
    index = hardened.load_json(SUITE / "schema-cases" / "index.json")
    case = next(item for item in index if item["schema"] == schema and item["valid"])
    return hardened.load_json(SUITE / "schema-cases" / case["instance"])


print("=" * 78)
print("R4-1  the reviewer's exact probe: tcb.host.build = null")
print("=" * 78)

validator = hardened.validator_for(RECEIPT_V3)
mutant = valid_case(RECEIPT_V3)
mutant["tcb"]["host"]["build"] = None
schema_errors = list(validator.iter_errors(mutant))
check("shipped receipt schema rejects a null kernel build identity",
      len(schema_errors) > 0, f"schema_errors={len(schema_errors)}")

record = valid_case(RECEIPT_V3)["tcb"]
record["host"]["build"] = None
try:
    hardened.check_tcb_record("reviewer probe", record)
    check("check_tcb_record rejects a null kernel build identity", False, "ACCEPTED")
except hardened.ValidationFailure as exc:
    check("check_tcb_record rejects a null kernel build identity", True, str(exc))

# The same probe, one layer weaker: a descriptive string, which is what the
# accepted-cycle-3 record actually carried.
for value in ("25A123", "unknown", ""):
    mutant = valid_case(RECEIPT_V3)
    mutant["tcb"]["host"]["build"] = value
    check(f"schema rejects a bare-string build {value!r}",
          len(list(validator.iter_errors(mutant))) > 0)

print()
print("=" * 78)
print("R4-1  two materially different kernels with one observed tuple")
print("=" * 78)

identity = hardened.load_json(SUITE / "vectors" / "hardened-identity-separation.json")
fixtures = {item["name"]: item for item in identity["host_build_fixtures"]["fixtures"]}
base = fixtures["macos-host-build"]
rebuilt = fixtures["macos-host-build-recompiled-kernel"]

same_tuple = all(
    base[field] == rebuilt[field]
    for field in ("platform", "host_identity", "host_version", "identifier")
)
check("the two kernels agree on platform, release, and build identifier", same_tuple,
      f"{base['host_identity']} {base['host_version']} {base['identifier']}")
differing = [
    left["name"]
    for left, right in zip(base["sources"], rebuilt["sources"])
    if left["value"] != right["value"]
]
check("they differ in a declared build-identity source", bool(differing), ", ".join(differing))
check("their kernel build digests differ",
      base["expected_sha256"] != rebuilt["expected_sha256"])

cases = {item["name"]: item for item in identity["tcb_rotation_cases"]}
rotation = cases["rotate-host-build-source"]
hardened_case = identity["cache_identity"]["hardened"]
check("their trusted-computing-base digests differ",
      rotation["tcb_digest"] != hardened.tcb_digest(hardened_case["tcb"]))
check("their cache keys differ", rotation["cache_key"] != hardened_case["cache_key"],
      f"{rotation['cache_key'][:23]}… vs {hardened_case['cache_key'][:23]}…")
check("nothing a package can see differs between them",
      rotation["package_visible_input_changed"] is False)
for field in ("receipt_rejected_against_base", "marker_rejected_against_base",
              "claim_rejected_against_base"):
    check(f"the rebuilt kernel is {field.replace('_', ' ')}", rotation[field] is True)

print()
print("=" * 78)
print("R4-1  every published build identity recomputed from its own bytes")
print("=" * 78)

for name, fixture in sorted(fixtures.items()):
    recomputed = hardened.recompute_host_build_fixture(name, fixture)
    check(f"{name} reproduces {fixture['expected_sha256'][:23]}…",
          recomputed == fixture["expected_sha256"])

shifted = fixtures["macos-host-build-source-boundary-shift"]
check("the boundary-shift probe carries the base's concatenated source bytes",
      "".join(e["value"] for e in shifted["sources"])
      == "".join(e["value"] for e in base["sources"]))
check("shifting bytes across a source boundary does not reproduce the digest",
      shifted["expected_sha256"] != base["expected_sha256"])

print()
print("=" * 78)
print("R4-1  no observed host in the suite carries an unpublished identity")
print("=" * 78)

published = {fixture["expected_sha256"] for fixture in fixtures.values()}
observed = 0
orphans = []
for label, tcb in hardened.conforming_tcb_records():
    observed += 1
    if tcb["host"]["build"]["content_sha256"] not in published:
        orphans.append(label)
check(f"all {observed} conforming observed hosts trace to a published fixture", not orphans,
      ", ".join(sorted(set(orphans))) or "no orphans")

print()
print("=" * 78)
print("R4-2  domain-teardown precedes identity-reverification, everywhere")
print("=" * 78)

order = hardened.ORDERED_PHASES
check("validator phase list: teardown < reverification < publication",
      order.index("domain-teardown") < order.index("identity-reverification")
      < order.index("publication"),
      " → ".join(order[-3:]))

protocol = hardened.markdown_section(hardened.PROTOCOL_DOCUMENT, "### 7.2 ")
numbered = re.findall(r"^\|\s*(\d+)\s*\|\s*`([a-z0-9-]+)`\s*\|", protocol, re.MULTILINE)
document_order = [name for _, name in numbered]
check("protocol section 7.2 states the same order", document_order == order,
      " → ".join(document_order[-3:]))

manager = hardened.markdown_section(hardened.MANAGER_DOCUMENT, "## 2. ")
mirrored = re.findall(r"^\|\s*`([a-z0-9-]+)`\s*\|", manager, re.MULTILINE)
check("profiles/manager-hardened.md mirrors it exactly", mirrored == order,
      " → ".join(mirrored[-3:]))

profile = hardened.load_json(SUITE / "vectors" / "hardened-execution-profile.json")
vector_order = [item["name"] for item in profile["ordered_phases"]]
check("the executable vector mirrors it exactly", vector_order == order)

invariants = {item["name"]: item for item in profile["ordering_invariants"]}
for name in ("teardown-before-identity-reverification",
             "identity-reverification-before-publication",
             "teardown-before-publication"):
    check(f"ordering invariant {name} is published and holds",
          name in invariants
          and order.index(invariants[name]["earlier"]) < order.index(invariants[name]["later"]))

print()
print("=" * 78)
print("R4-2  re-verification covers the complete record, not a subset")
print("=" * 78)

check_block = profile["identity_reverification"]
expected = sorted(
    (set(hardened.TCB_FIELDS) - hardened.TCB_CONSTANT_FIELDS) | {"source-snapshot"}
)
check("every mutable TCB member and the frozen snapshot are re-verified",
      check_block["reverified_members"] == expected,
      ", ".join(check_block["reverified_members"]))
for member in ("host", "backend", "parent_sha256", "trusted_components",
               "platform", "enforcement_backend"):
    check(f"the cycle-4 omission {member} is re-verified",
          member in check_block["reverified_members"])
check("re-verification runs after the domain is joined",
      check_block["runs_after_phase"] == "domain-teardown"
      and check_block["domain_joined_before_reverification"] is True)
check("re-verification recomputes the complete record",
      check_block["recomputes_complete_tcb_record"] is True
      and check_block["comparison"] == "byte-identical-record-and-digest")
check("a partial or restated re-verification is forbidden",
      check_block["partial_reverification_permitted"] is False
      and check_block["restating_earlier_record_permitted"] is False)

adversarial = hardened.load_json(SUITE / "vectors" / "hardened-adversarial-vectors.json")
reverification = {item["name"]: item for item in adversarial["reverification_cases"]}
omitted = {
    case["omitted_member"] for case in reverification.values() if case["kind"] == "omitted-member"
}
check("every re-verified member has an adversarial omission case",
      sorted(omitted) == expected, f"{len(omitted)} omission cases")
check("the phase-order failure has its own case",
      any(case["kind"] == "phase-order" for case in reverification.values()))
check("the restated-record failure has its own case",
      any(case["kind"] == "restated-record" for case in reverification.values()))
check("no reverification case publishes or writes reusable state",
      all(not case["published"] and not case["cache_entry_written"]
          and not case["marker_updated"] for case in reverification.values()))

print()
print("=" * 78)
print("Preserved: nothing this cycle claims a qualification")
print("=" * 78)

release = hardened.load_json(hardened.ROOT / "release" / "hardened-1.0.0-rc.1.json")
check("qualified_platforms is empty", release["qualified_platforms"] == [])
check("claims_emitted is empty", release["claim_v4"]["claims_emitted"] == [])
check("the portable baseline is unmodified", release["portable_baseline"]["modified"] is False)
check("every platform declaration is unqualified",
      all(item["qualification_status"] == "unqualified"
          for item in profile["platform_declarations"]))
check("adversarial evidence is still pending native validation",
      adversarial["evidence_status"] == "pending-native-validation")

print()
print("=" * 78)
print(f"{'ALL CHECKS PASSED' if not failures else 'FAILURES: ' + ', '.join(failures)}")
print("=" * 78)
sys.exit(1 if failures else 0)
