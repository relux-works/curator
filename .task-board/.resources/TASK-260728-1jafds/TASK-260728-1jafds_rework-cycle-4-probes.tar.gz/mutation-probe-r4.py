"""Neuter each new cycle-4 rule in a sandbox and require a distinct failure.

A rule nothing would notice being removed is decoration. Each mutation below
weakens exactly one shipped artifact and the probe requires the conformance
validator to reject the weakened suite with its own message.
"""
import json
import shutil
import sys
import tempfile
from pathlib import Path

REPO = Path("/Users/iv/Developer/ReluxWorks/.temp/TASK-260728-1jafds/curator-spec-worktree")
sys.path.insert(0, str(REPO / "tools"))
import validate_hardened as hardened  # noqa: E402

COMMON = ("schemas", "hardened", "v1", "hardened-common.schema.json")
PROTOCOL = ("protocol", "hardened-execution.md")
MANAGER = ("profiles", "manager-hardened.md")
PROFILE = ("conformance", "hardened", "v1", "vectors", "hardened-execution-profile.json")
IDENTITY = ("conformance", "hardened", "v1", "vectors", "hardened-identity-separation.json")
ADVERSARIAL = ("conformance", "hardened", "v1", "vectors", "hardened-adversarial-vectors.json")
RECEIPT = (
    "conformance", "hardened", "v1", "schema-cases",
    "hardened-build-receipt-v3", "valid.json",
)


def drop_ref(schema, path, ref):
    """Replace one relation with a vacuous branch, keeping the schema valid."""
    node = schema
    for key in path:
        node = node[key]
    replaced = 0
    for index, item in enumerate(node["allOf"]):
        if item.get("$ref") == ref:
            node["allOf"][index] = {"type": "object"}
            replaced += 1
    assert replaced == 1, f"{ref} was not present exactly once at {path}"


def widen_build(schema):
    schema["$defs"]["hardenedHostIdentityV1"]["properties"]["build"] = {
        "oneOf": [
            {"$ref": "../../v1/common.schema.json#/$defs/nonEmptyString"},
            {"type": "null"},
        ]
    }


MUTATIONS = {
    # R4-1: the shape of the kernel build identity.
    "host-build-is-nullable-again": (COMMON, widen_build),
    "host-build-record-is-open": (
        COMMON,
        lambda s: s["$defs"]["hardenedHostBuildV1"].__setitem__("additionalProperties", True),
    ),
    "host-build-algorithm-unpinned": (
        COMMON,
        lambda s: s["$defs"].__setitem__(
            "hardenedHostBuildAlgorithmV1",
            {"$ref": "../../v1/common.schema.json#/$defs/nonEmptyString"},
        ),
    ),
    "host-build-identifier-to-platform-dropped": (
        COMMON,
        lambda s: drop_ref(
            s,
            ("$defs", "hardenedTcbRecordV1"),
            "#/$defs/hardenedHostBuildIdentifierPlatformRelationV1",
        ),
    ),
    "host-build-identifier-grammar-widened": (
        COMMON,
        lambda s: s["$defs"]["hardenedHostBuildIdentifierPlatformRelationV1"]["allOf"][0]["then"][
            "properties"
        ]["host"]["properties"]["build"]["properties"]["identifier"].__setitem__(
            "pattern", "^.*$"
        ),
    ),
    "host-release-grammar-widened": (
        COMMON,
        lambda s: s["$defs"].__setitem__(
            "hardenedHostVersionV1",
            {"$ref": "../../v1/common.schema.json#/$defs/nonEmptyString"},
        ),
    ),
    # R4-1: the construction and its fixtures.
    "host-build-fixture-lies-about-its-digest": (
        IDENTITY,
        lambda d: d["host_build_fixtures"]["fixtures"][0].__setitem__(
            "expected_sha256", "sha256:" + "0" * 64
        ),
    ),
    "host-build-source-dropped-from-a-fixture": (
        IDENTITY,
        lambda d: _drop_source(d),
    ),
    "host-build-identifier-detached-from-its-source": (
        IDENTITY,
        lambda d: _detach_identifier(d),
    ),
    "host-build-facet-coverage-dropped": (
        IDENTITY,
        lambda d: _drop_facet(d),
    ),
    "host-build-digest-carried-to-another-release": (
        RECEIPT,
        lambda d: d["tcb"]["host"].__setitem__("version", "25.9.0"),
    ),
    # R4-2: the ordering and the completeness of re-verification.
    "reverification-drops-the-observed-host": (
        PROFILE,
        lambda d: d["identity_reverification"].__setitem__(
            "reverified_members",
            [m for m in d["identity_reverification"]["reverified_members"] if m != "host"],
        ),
    ),
    "reverification-admits-a-restated-record": (
        PROFILE,
        lambda d: d["identity_reverification"].__setitem__(
            "restating_earlier_record_permitted", True
        ),
    ),
    "reverification-compares-the-digest-only": (
        PROFILE,
        lambda d: d["identity_reverification"].__setitem__("comparison", "digest-only"),
    ),
    "teardown-before-reverification-invariant-dropped": (
        PROFILE,
        lambda d: d.__setitem__(
            "ordering_invariants",
            [
                item
                for item in d["ordering_invariants"]
                if item["name"] != "teardown-before-identity-reverification"
            ],
        ),
    ),
    "reverification-omission-case-dropped": (
        ADVERSARIAL,
        lambda d: d.__setitem__(
            "reverification_cases",
            [
                case
                for case in d["reverification_cases"]
                if case["omitted_member"] != "trusted_components"
            ],
        ),
    ),
}


def _drop_source(document):
    for fixture in document["host_build_fixtures"]["fixtures"]:
        if fixture["name"] == "macos-host-build":
            fixture["sources"] = fixture["sources"][:2]
            fixture["source_count"] = 2


def _detach_identifier(document):
    for fixture in document["host_build_fixtures"]["fixtures"]:
        if fixture["name"] == "macos-host-build":
            fixture["identifier"] = "25A999"
            fixture["identifier_byte_length"] = len("25A999")


def _drop_facet(document):
    for case in document["tcb_rotation_cases"]:
        if case["name"] == "rotate-host-build-source":
            case["rotated_host_build_aspects"] = []


def run_all():
    """Every check the hardened validator runs, in main() order."""
    for check in (
        hardened.validate_hardened_schemas,
        hardened.validate_schema_closed_value_sets,
        hardened.validate_tcb_schema_relations,
        hardened.validate_identity_separation,
        hardened.validate_identity_binding_chain,
        hardened.validate_claim_qualification_binding,
        hardened.validate_phase_list_documents,
        hardened.validate_host_build_declaration_document,
        hardened.validate_reverification_documents,
    ):
        check()
    profile = hardened.validate_profile_vector()
    hardened.validate_adversarial_vector(profile)


# The normative documents are text, not JSON, so they get their own table.
TEXT_MUTATIONS = {
    "section-6.3-declares-another-source-list": (
        PROTOCOL,
        "`kern.osversion`, `kern.osproductversion`, `kern.version` |",
        "`kern.osversion`, `kern.osproductversion` |",
    ),
    "section-6.3-reads-the-identifier-from-another-source": (
        PROTOCOL,
        "| `macos` | `[0-9]{1,3}` `[A-Z]` `[0-9]{1,6}` optional lowercase letter | `kern.osversion` |",
        "| `macos` | `[0-9]{1,3}` `[A-Z]` `[0-9]{1,6}` optional lowercase letter | `kern.version` |",
    ),
    "protocol-reverification-drops-a-member": (
        PROTOCOL,
        "| `trusted_components` | every component of section 2.3.1",
        "| `some_components` | some components of section 2.3.1",
    ),
    "protocol-reverification-drops-the-subset-prohibition": (
        PROTOCOL,
        "Re-verifying a subset is not re-verification:",
        "Re-verifying part of it is fine:",
    ),
    "manager-reverification-narrows-back-to-four-identities": (
        MANAGER,
        "After the whole domain has been destroyed and joined, observe every trusted identity again",
        "Re-verify the supervisor, worker, source-snapshot, and fingerprinted toolchain identities",
    ),
}

saved = {
    name: getattr(hardened, name)
    for name in ("ROOT", "PORTABLE_SCHEMAS", "HARDENED_SCHEMAS", "PORTABLE_SUITE", "HARDENED_SUITE")
}
failures = {}
for name, (target, mutate) in MUTATIONS.items():
    with tempfile.TemporaryDirectory() as raw:
        root = Path(raw)
        for directory in ("schemas", "conformance", "release"):
            shutil.copytree(REPO / directory, root / directory)
        path = root.joinpath(*target)
        document = json.loads(path.read_text())
        mutate(document)
        path.write_text(json.dumps(document, indent=2) + "\n")
        hardened.ROOT = root
        hardened.PORTABLE_SCHEMAS = root / "schemas" / "v1"
        hardened.HARDENED_SCHEMAS = root / "schemas" / "hardened" / "v1"
        hardened.PORTABLE_SUITE = root / "conformance" / "v1"
        hardened.HARDENED_SUITE = root / "conformance" / "hardened" / "v1"
        try:
            run_all()
            print(f"{name}: NOT DETECTED — the shipped suite accepts the weakened artifact")
        except hardened.ValidationFailure as exc:
            failures[name] = str(exc)
            print(f"{name}: detected — {exc}")
        finally:
            for key, value in saved.items():
                setattr(hardened, key, value)

saved_documents = {
    "PROTOCOL_DOCUMENT": hardened.PROTOCOL_DOCUMENT,
    "MANAGER_DOCUMENT": hardened.MANAGER_DOCUMENT,
}
for name, (target, before, after) in TEXT_MUTATIONS.items():
    with tempfile.TemporaryDirectory() as raw:
        root = Path(raw)
        for directory in ("schemas", "conformance", "release"):
            shutil.copytree(REPO / directory, root / directory)
        for source, attribute in (
            (("protocol", "hardened-execution.md"), "PROTOCOL_DOCUMENT"),
            (("profiles", "manager-hardened.md"), "MANAGER_DOCUMENT"),
        ):
            path = root.joinpath(*source)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(REPO.joinpath(*source).read_text(encoding="utf-8"), encoding="utf-8")
            setattr(hardened, attribute, path)
        path = root.joinpath(*target)
        text = path.read_text(encoding="utf-8")
        if text.count(before) != 1:
            print(f"{name}: PROBE BROKEN — anchor appears {text.count(before)} times")
            continue
        path.write_text(text.replace(before, after), encoding="utf-8")
        hardened.ROOT = root
        hardened.PORTABLE_SCHEMAS = root / "schemas" / "v1"
        hardened.HARDENED_SCHEMAS = root / "schemas" / "hardened" / "v1"
        hardened.PORTABLE_SUITE = root / "conformance" / "v1"
        hardened.HARDENED_SUITE = root / "conformance" / "hardened" / "v1"
        try:
            run_all()
            print(f"{name}: NOT DETECTED — the shipped suite accepts the weakened document")
        except hardened.ValidationFailure as exc:
            failures[name] = str(exc)
            print(f"{name}: detected — {exc}")
        finally:
            for key, value in saved.items():
                setattr(hardened, key, value)
            for key, value in saved_documents.items():
                setattr(hardened, key, value)

total = len(MUTATIONS) + len(TEXT_MUTATIONS)
print(f"\ndetected {len(failures)}/{total}; distinct messages = {len(set(failures.values()))}")
sys.exit(0 if len(failures) == total else 1)
