"""Run adversarial instances against the conformance validator's semantics.

mutation-probe-r4.py weakens the shipped rules. This probe leaves them intact
and attacks with instances an implementation might really emit, requiring the
semantic checks — not only the schemas — to reject each one, with its own
message. The shipped record is the positive control.
"""
import copy
import sys
from pathlib import Path

REPO = Path("/Users/iv/Developer/ReluxWorks/.temp/TASK-260728-1jafds/curator-spec-worktree")
sys.path.insert(0, str(REPO / "tools"))
import validate_hardened as hardened  # noqa: E402

SUITE = hardened.HARDENED_SUITE
RECEIPT_V3 = "hardened-build-receipt-v3.schema.json"
CLAIM_V4 = "hardened-conformance-claim-v4.schema.json"


def valid_case(schema):
    index = hardened.load_json(SUITE / "schema-cases" / "index.json")
    case = next(item for item in index if item["schema"] == schema and item["valid"])
    return hardened.load_json(SUITE / "schema-cases" / case["instance"])


BASE = valid_case(RECEIPT_V3)["tcb"]
LINUX = valid_case(CLAIM_V4)["tcb"]


def mutate(record, path, value):
    out = copy.deepcopy(record)
    node = out
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = value
    return out


def drop(record, path):
    out = copy.deepcopy(record)
    node = out
    for key in path[:-1]:
        node = node[key]
    del node[path[-1]]
    return out


CASES = {
    "null-kernel-build-identity": mutate(BASE, ("host", "build"), None),
    "kernel-build-identity-as-a-description": mutate(BASE, ("host", "build"), "25A123"),
    "kernel-build-identity-without-a-digest": drop(BASE, ("host", "build", "content_sha256")),
    "kernel-build-identity-without-an-identifier": drop(BASE, ("host", "build", "identifier")),
    "kernel-build-identity-under-another-algorithm": mutate(
        BASE, ("host", "build", "algorithm"), "curator-hardened-tcb-v1"
    ),
    "kernel-build-identity-carrying-an-extra-member": {
        **copy.deepcopy(BASE),
        "host": {
            **copy.deepcopy(BASE["host"]),
            "build": {**copy.deepcopy(BASE["host"]["build"]), "sources": ["kern.version"]},
        },
    },
    "kernel-build-digest-that-is-not-a-digest": mutate(
        BASE, ("host", "build", "content_sha256"), "unknown"
    ),
    "darwin-identifier-on-a-linux-base": mutate(LINUX, ("host", "build", "identifier"), "25A123"),
    "linux-identifier-on-a-darwin-base": mutate(
        BASE, ("host", "build", "identifier"), "4f2a1c8e6b90d3574a1e2f8c0b7d69315ae4c2f8"
    ),
    "identifier-with-a-trailing-newline": mutate(
        BASE, ("host", "build", "identifier"), "25A123\n"
    ),
    "release-outside-the-bounded-grammar": mutate(BASE, ("host", "version"), "twenty-five"),
    "release-with-a-trailing-newline": mutate(BASE, ("host", "version"), "25.0.0\n"),
    "release-with-a-leading-zero-component": mutate(BASE, ("host", "version"), "25.00.0"),
}

failures = {}
for name, record in CASES.items():
    try:
        hardened.check_tcb_record(name, record)
        print(f"{name}: ACCEPTED — the conformance validator does not reject it")
    except hardened.ValidationFailure as exc:
        failures[name] = str(exc)
        print(f"{name}: rejected — {exc}")

print()
try:
    hardened.check_tcb_record("positive control", BASE)
    hardened.check_tcb_record("positive control linux", LINUX)
    print("positive control: the shipped records still validate")
    control = True
except hardened.ValidationFailure as exc:
    print(f"positive control: BROKEN — {exc}")
    control = False

print(
    f"\nrejected {len(failures)}/{len(CASES)}; "
    f"distinct messages = {len(set(failures.values()))}; positive control = {control}"
)
sys.exit(0 if len(failures) == len(CASES) and control else 1)
