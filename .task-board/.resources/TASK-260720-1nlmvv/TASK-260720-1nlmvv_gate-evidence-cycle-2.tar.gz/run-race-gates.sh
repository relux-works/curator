#!/bin/zsh
# TASK-260720-1nlmvv cycle-2 continuation: focused race gates.
# Each gate runs as a standalone foreground process inside this script and its
# real exit code is recorded. No pipes, no tee, no shared-cache mutation.

set -u

WT=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-1nlmvv/worktree
OUT=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260720-1nlmvv/gate-logs-cycle-2
SUMMARY="$OUT/race-continuation.log"

cd "$WT" || exit 99

{
  print "### cycle-2 continuation race gates"
  print "host=$(uname -srm)"
  print "go=$(go version)"
  print "start=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  print "disk_avail_start=$(df -g /System/Volumes/Data | tail -1 | awk '{print $4}')Gi"
} >> "$SUMMARY"

run_gate() {
  local name="$1"; shift
  local log="$OUT/race-$name.log"
  local began ended code
  began=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  "$@" > "$log" 2>&1
  code=$?
  ended=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  {
    print "### race: $name"
    print "cmd: $*"
    print "began=$began ended=$ended"
    print "exit=$code"
    print "disk_avail=$(df -g /System/Volumes/Data | tail -1 | awk '{print $4}')Gi"
    print "tail:"
    tail -n 20 "$log"
    print ""
  } >> "$SUMMARY"
  return $code
}

run_gate godriver go test -race -timeout 30m -count=1 ./internal/godriver
godriver_code=$?

run_gate install go test -race -timeout 60m -count=1 ./internal/install
install_code=$?

run_gate cmd-curator go test -race -timeout 60m -count=1 ./cmd/curator
cmd_code=$?

{
  print "### summary"
  print "godriver_exit=$godriver_code"
  print "install_exit=$install_code"
  print "cmd_curator_exit=$cmd_code"
  print "end=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  print "disk_avail_end=$(df -g /System/Volumes/Data | tail -1 | awk '{print $4}')Gi"
} >> "$SUMMARY"

exit $(( godriver_code | install_code | cmd_code ))
