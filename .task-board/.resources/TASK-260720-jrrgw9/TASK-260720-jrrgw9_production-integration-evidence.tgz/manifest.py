import hashlib, os, subprocess, sys
out = sys.argv[1]
paths = subprocess.run(["git","ls-files","--cached","--others","--exclude-standard","-z"],
                       capture_output=True, check=True).stdout.split(b"\0")
paths = sorted(p.decode() for p in paths if p)
def fhash(p):
    h = hashlib.sha256()
    with open(p,"rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()
lines = []
for p in paths:
    if os.path.islink(p):
        lines.append("symlink %s  %s" % (hashlib.sha256(os.readlink(p).encode()).hexdigest(), p))
    elif os.path.isdir(p):
        inner = []
        for root, dirs, files in os.walk(p):
            dirs.sort()
            for name in sorted(files):
                fp = os.path.join(root, name)
                rel = os.path.relpath(fp, p)
                inner.append("%s %s" % (rel, os.readlink(fp) if os.path.islink(fp) else fhash(fp)))
        d = hashlib.sha256("\n".join(inner).encode()).hexdigest()
        lines.append("dir     %s  %s (%d inner)" % (d, p, len(inner)))
    else:
        lines.append("file    %s  %s" % (fhash(p), p))
open(out,"w").write("\n".join(lines) + "\n")
print("entries:", len(lines))
