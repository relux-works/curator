package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ---------------------------------------------------------------------------
// Cycle 3. Two security-contract defects, closed by measurement.
//
// R1 — the contract admitted the compiler macros decision 0008 requires it to
// reject. S42–S44 are the negative measurements that show no argv, environment
// or presentation mechanism suppresses the load while swiftc runs its own jobs,
// and S45 is what a macro-selecting source does once the compile command has
// started. S46–S50 measured cycle 3's answer — the manager executing the plan's
// jobs itself with the channel deleted — and are retired in cycle 4, because
// accepted decision 0008 section 7 admits exactly one compile command. The
// surface is closed in cycle 4 at the source bytes instead; see
// sourceadmission.go and S54–S64.
//
// R2 — unknown flag channels were accepted. S51–S53 close the token grammar.
// ---------------------------------------------------------------------------

// macroSource is the @Observable case the reviewer named. It loads a macro
// implementation from inside the fingerprinted toolchain root, which is exactly
// the load decision 0008 forbids and decision 0011 used to admit.
const macroSource = "import Observation\n@Observable final class Box { var n: Int = 0 }\nlet b = Box()\nb.n = 7\nprint(\"obs \\(b.n)\")\n"

// richSource exercises the parts of the language a package is most likely to
// use, so "the plugin channel is deleted" is shown not to cost ordinary Swift.
const richSource = `import Foundation

struct Item: Codable, Sendable { let name: String; let qty: Int }

func parse(_ s: String) -> [Substring] { s.split(separator: ",") }

let items = [Item(name: "bolt", qty: 3), Item(name: "nut", qty: 9)]
let data = try JSONEncoder().encode(items)
let back = try JSONDecoder().decode([Item].self, from: data)
let total = back.reduce(0) { $0 + $1.qty }
let re = /([a-z]+)-([0-9]+)/
if let m = "widget-42".firstMatch(of: re) { print(m.1, m.2) }
print("total=\(total) parts=\(parse("a,b,c").count)")
`

// pluginPathsIn reads every plugin-channel value out of a plan, in order.
func pluginPathsIn(planOut string) []string {
	var out []string
	lines, err := SplitPlanLines(planOut)
	if err != nil {
		return nil
	}
	for _, l := range lines {
		toks, err := TokenizeJobLine(l)
		if err != nil {
			continue
		}
		for i, t := range toks {
			if IsPluginChannelToken(t) && !strings.Contains(t, "=") && i+1 < len(toks) {
				out = append(out, toks[i+1])
			}
		}
	}
	return out
}

// writeSource drops one source file into its own directory under the harness.
func (h *harness) writeSource(name, body string) (dir, path string) {
	dir = filepath.Join(h.base, name)
	_ = os.MkdirAll(dir, 0o755)
	path = filepath.Join(dir, "main.swift")
	_ = os.WriteFile(path, []byte(body), 0o644)
	return dir, path
}

// planFor runs the graph phase for one source set and returns the record and the
// raw plan.
func (h *harness) planFor(out string, extra, sources []string, dir string) (RunRecord, string) {
	rec, planOut, _ := runFixedRaw(h.tc.Swiftc, h.graphVector(h.presentedSDK(), out, extra, sources), dir, h.cleanEnv())
	return rec, planOut
}

// execPolicy is the plan policy for a one-source job set.
func (h *harness) execPolicy(sources []string, dir string) PlanPolicy {
	p := h.policy(sources)
	p.WorkingDir = dir
	return p
}

func macroAdmissionChecks(h *harness) []Structural {
	tc := h.tc
	var out []Structural
	srcs := h.defaultSources()

	// ---- S42 .. S45: why deletion, and not a check -------------------------
	// Each of these is a NEGATIVE measurement. Together they are the reason the
	// manager cannot leave swiftc to run its own jobs and merely verify what it
	// planned: the load channel is injected unconditionally and cannot be
	// pointed anywhere harmless.

	fakeRD := filepath.Join(h.base, "fake-resource-dir")
	rdRec, rdPlan := h.planFor(filepath.Join(h.stage, "rd"), []string{"-resource-dir", fakeRD}, srcs, h.srcDir)
	rdMoved := 0
	for _, p := range pluginPathsIn(rdPlan) {
		if strings.HasPrefix(p, fakeRD) {
			rdMoved++
		}
	}
	out = append(out, Structural{
		ID:       "S42-resource-dir-does-not-move-the-plugin-paths",
		Title:    "overriding the resource directory does not move the injected plugin search paths",
		Expected: "0 plugin components under the overridden resource directory",
		Observed: fmt.Sprintf("graph exit=%d, %d of %d plugin components under %s", rdRec.Exit, rdMoved, len(pluginPathsIn(rdPlan)), fakeRD),
		Verdict:  verdict(rdRec.Exit == 0 && rdMoved == 0 && len(pluginPathsIn(rdPlan)) > 0),
		ManagerObligation: "The plugin search paths derive from the driver's own executable location, not from " +
			"-resource-dir. Presenting a resource directory the way the SDK is presented would not close the channel.",
		Runs: []RunRecord{rdRec},
	})

	shimTC := filepath.Join(h.base, "tc-presented", "usr", "bin")
	_ = os.MkdirAll(shimTC, 0o755)
	shimSwiftc := filepath.Join(shimTC, "swiftc")
	_ = os.Remove(shimSwiftc)
	_ = os.Symlink(tc.Swiftc, shimSwiftc)
	symRec, symPlan, _ := runFixedRaw(shimSwiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "sym"), nil, srcs), h.srcDir, h.cleanEnv())
	symUnderPresented := 0
	for _, p := range pluginPathsIn(symPlan) {
		if strings.HasPrefix(p, filepath.Join(h.base, "tc-presented")) {
			symUnderPresented++
		}
	}
	out = append(out, Structural{
		ID:       "S43-toolchain-presentation-resolves-back-to-the-real-root",
		Title:    "invoking the driver through a manager-owned symlink does not move the plugin search paths",
		Expected: "0 plugin components under the presented toolchain directory",
		Observed: fmt.Sprintf("graph exit=%d, %d of %d plugin components under the presentation", symRec.Exit, symUnderPresented, len(pluginPathsIn(symPlan))),
		Verdict:  verdict(symRec.Exit == 0 && symUnderPresented == 0 && len(pluginPathsIn(symPlan)) > 0),
		ManagerObligation: "The driver resolves its own executable before deriving anything from it, so the SDK " +
			"presentation of section 2.2 has no toolchain counterpart.",
		Runs: []RunRecord{symRec},
	})

	macroDir, macroPath := h.writeSource("macro-obs", macroSource)
	absentServer := filepath.Join(h.stage, "absent-plugin-server.dylib")
	ovr := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "ovr"),
		[]string{"-Xfrontend", "-Rmacro-loading", "-Xfrontend", "-in-process-plugin-server-path", "-Xfrontend", absentServer},
		[]string{macroPath}), macroDir, h.cleanEnv())
	ovrLoaded := strings.Contains(ovr.Stderr, "loaded macro implementation module")
	out = append(out, Structural{
		ID:       "S44-in-process-server-override-does-not-stop-the-load",
		Title:    "pointing the in-process plugin server at an absent file does not stop a toolchain macro loading",
		Expected: "exit 0 and the macro still loads",
		Observed: fmt.Sprintf("exit %d, macro loaded=%v", ovr.Exit, ovrLoaded),
		Verdict:  verdict(ovr.Exit == 0 && ovrLoaded),
		ManagerObligation: "The implementation is loaded directly rather than through the named server, so no " +
			"server-path override closes the channel.",
		Runs: []RunRecord{ovr},
	})

	// ---- S45: the surface Stage B has to close, measured on the live vector --
	// Cycle 4 restores compile_argv, so this run IS the contract's own compile
	// command. It is exactly why the macro surface must be closed at the source
	// bytes before anything is executed: once this command starts, the load is
	// already unavoidable. S55 is the positive assertion that it never starts.
	retired := RetiredCompile(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "retired"),
		[]string{"-Xfrontend", "-Rmacro-loading"}, []string{macroPath}), macroDir, h.cleanEnv())
	retiredLib := ""
	for _, l := range strings.Split(retired.Stderr, "\n") {
		if strings.Contains(l, "loaded macro implementation module") {
			retiredLib = strings.TrimSpace(l)
			break
		}
	}
	out = append(out, Structural{
		ID:       "S45-a-macro-selecting-source-that-reaches-the-compile-command-loads",
		Title:    "@Observable compiled by the contract's own compile command loads a macro implementation in-process",
		Expected: "exit 0 and a load remark naming a library inside the toolchain root — this is what Stage B must prevent from ever starting",
		Observed: fmt.Sprintf("exit %d, remark=%s", retired.Exit, clipTo(retiredLib, 200)),
		Verdict:  verdict(retired.Exit == 0 && strings.Contains(retiredLib, tc.Root)),
		ManagerObligation: "Under manager-worker-v2 the compile phase is one swiftc command, so the manager cannot " +
			"edit the frontend jobs. The only remaining place to reject the surface is the source bytes, before the " +
			"session starts; expected-red control C13 restores the missing Stage-B rule and reports this admission.",
		Runs: []RunRecord{retired},
	})

	// ---- S46 .. S50 retired in cycle 4 --------------------------------------
	// Those five checks measured a design in which the manager executed the
	// plan's jobs itself with the plugin channel deleted. Accepted decision 0008
	// section 7 closes a manager-worker-v2 session to exactly one compile
	// command, so that design cannot carry this policy label and is retired.
	// StripPluginChannel and ExecutePlan survive only so expected-red control
	// C15 can restore it from this same binary and report the command count it
	// produces. The properties S47 and S49 covered — ordinary Swift still builds,
	// and the session is deterministic — are re-measured under the restored
	// single-compile-command session as S60 and S64, and the property S48
	// covered is replaced by the stronger S55: the macro-selecting source is
	// rejected before any command starts at all.

	return out
}

func allInChannelSet(names []string) bool {
	for _, n := range names {
		if !IsPluginChannelToken(n) {
			return false
		}
	}
	return true
}

// closedGrammarChecks are R2: the token grammar is total over every token, not
// only over path-shaped ones.
func closedGrammarChecks(h *harness) []Structural {
	tc := h.tc
	var out []Structural
	srcs := h.defaultSources()
	pol := h.policy(srcs)

	planRec, planOut := h.planFor(filepath.Join(h.stage, "closed"), nil, srcs, h.srcDir)
	res := VerifyPlan(planOut, pol)
	tokens := 0
	for _, j := range res.Jobs {
		tokens += len(j)
	}
	out = append(out, Structural{
		ID:       "S51-the-live-plan-verifies-under-the-closed-token-grammar",
		Title:    "every token of the emitted plan is claimed by a table, with no unknown-token escape",
		Expected: "0 rejections over the whole token set",
		Observed: fmt.Sprintf("graph exit=%d, %d jobs, %d tokens, buckets %v, rejections=%v", planRec.Exit, len(res.Jobs), tokens, sortedCounts(res.Counts), res.Rejections),
		Verdict:  verdict(planRec.Exit == 0 && res.OK() && tokens > 0),
		ManagerObligation: "Totality is over every token now, not over the tokens the verifier already recognised as " +
			"paths. A token no table claims rejects with build_execution_control_unavailable.",
		Runs: []RunRecord{planRec},
	})

	// The unknown-channel negatives. Each is a single token added to, or
	// substituted into, an otherwise valid plan.
	valid := res.Jobs
	if len(valid) == 0 {
		return out
	}
	base := valid[0]
	rejected, admittedByRetired := 0, 0
	var admittedNames []string
	for _, neg := range closedGrammarNegatives(base, tc, h) {
		line := renderJob(neg.job)
		if !VerifyPlan(line+"\n", pol).OK() {
			rejected++
		} else {
			admittedNames = append(admittedNames, neg.name)
		}
		if VerifyPlanPathShapeOnly(line+"\n", pol).OK() {
			admittedByRetired++
		}
	}
	total := len(closedGrammarNegatives(base, tc, h))
	out = append(out, Structural{
		ID:       "S52-unknown-channel-negatives-all-reject",
		Title:    "unknown flags, joined carriers, pass-through values and stray operands all reject",
		Expected: fmt.Sprintf("%d of %d rejected", total, total),
		Observed: fmt.Sprintf("%d of %d rejected; still admitted: %v; the retired path-shape-only verifier admits %d", rejected, total, admittedNames, admittedByRetired),
		Verdict:  verdict(rejected == total && total > 0),
		ManagerObligation: "Every one of these is a channel a future toolchain could introduce. Adding one to the " +
			"tables is a measured contract change, never a runtime accommodation.",
	})

	out = append(out, Structural{
		ID:       "S53-load-pass-plugin-is-a-live-joined-channel",
		Title:    "the toolchain really does define a joined LLVM pass-plugin load flag",
		Expected: "-load-pass-plugin= present in the driver's own option list",
		Observed: fmt.Sprintf("present=%v", h.helpMentions("-load-pass-plugin=")),
		Verdict:  verdict(h.helpMentions("-load-pass-plugin=")),
		ManagerObligation: "This is not a hypothetical shape. It is a joined flag whose value is a dynamic library " +
			"the compiler loads, and the retired path-shape-only verifier accepted it because the token itself is not " +
			"path-shaped.",
	})

	return out
}

type grammarNegative struct {
	name string
	job  []string
}

// closedGrammarNegatives builds one negative per channel family from a real,
// verified job, so each one differs from an accepted plan by a single token.
func closedGrammarNegatives(base []string, tc *Toolchain, h *harness) []grammarNegative {
	clone := func(extra ...string) []string {
		j := append([]string{}, base...)
		return append(j, extra...)
	}
	evil := filepath.Join(h.base, "evil.dylib")
	_ = os.WriteFile(evil, []byte("x"), 0o644)

	return []grammarNegative{
		{"unknown flag", clone("-new-channel")},
		{"unknown joined flag with an absolute value", clone("-new-channel=" + evil)},
		{"unknown joined flag with a relative value", clone("-new-channel=evil.dylib")},
		{"joined LLVM pass plugin", clone("-load-pass-plugin=" + evil)},
		{"pass-through carrying a plugin load", clone("-Xllvm", "-load-pass-plugin="+evil)},
		{"pass-through carrying a search path", clone("-Xcc", "-I"+h.base)},
		{"pass-through carrying an unrecognised search path", clone("-Xcc", "-isystem"+h.base)},
		{"pass-through with an unmeasured value", clone("-Xllvm", "-some-new-llvm-option")},
		{"opaque value carrying a path", clone("-module-name", evil)},
		{"opaque value carrying a separator", clone("-target-sdk-name", "macosx#evil")},
		{"opaque value that is not the manager's", clone("-swift-version", "5")},
		{"opaque target that is not the manager's", clone("-target", "x86_64-unknown-linux-gnu")},
		{"stray non-path operand", clone("stray-operand")},
		{"response file", clone("@" + evil)},
		{"link-only flag in a frontend job", clone("-O3")},
		{"otherwise valid plan with one extra unknown token", clone("-enable-future-thing")},
	}
}

// renderJob writes a token list back in the measured quoting grammar, so a
// negative goes through the same tokenizer the live plan does.
func renderJob(toks []string) string {
	var parts []string
	for _, t := range toks {
		if t == "" || strings.ContainsAny(t, " '#\\") {
			parts = append(parts, "'"+strings.ReplaceAll(t, "'", `'\''`)+"'")
			continue
		}
		parts = append(parts, t)
	}
	return strings.Join(parts, " ")
}

// helpMentions asks the driver itself whether it defines a flag, so the contract
// never claims a channel exists without the toolchain saying so.
func (h *harness) helpMentions(flag string) bool {
	// runFixedRaw, not runFixed: the option list is far longer than the record
	// excerpt, and a clipped answer would be a false negative.
	_, out, errOut := runFixedRaw(h.tc.Swiftc, []string{"-help-hidden"}, h.srcDir, h.cleanEnv())
	return strings.Contains(out, flag) || strings.Contains(errOut, flag)
}
