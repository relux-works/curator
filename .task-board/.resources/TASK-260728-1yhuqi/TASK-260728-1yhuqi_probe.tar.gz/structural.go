package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type harness struct {
	base     string
	shimDir  string
	shimLog  string
	emptyDir string
	sdkBase  string // manager presentation base: <sdkBase>/present/SDKs/<name>
	srcDir   string
	stage    string
	tmp      string
	tc       *Toolchain
}

func newHarness(base string, tc *Toolchain) (*harness, error) {
	h := &harness{
		base:     base,
		shimDir:  filepath.Join(base, "shims"),
		shimLog:  filepath.Join(base, "shim.log"),
		emptyDir: filepath.Join(base, "empty-path"),
		sdkBase:  filepath.Join(base, "sdk"),
		srcDir:   filepath.Join(base, "src"),
		stage:    filepath.Join(base, "stage"),
		tmp:      filepath.Join(base, "tmp"),
		tc:       tc,
	}
	// The presentation is nested so that the paths the compiler derives from the
	// -sdk argument stay inside a directory the manager owns and keeps empty.
	// Measured: the derived external plugin tree is <sdk>/../../../Developer, so
	// with the SDK at <sdkBase>/present/SDKs/<name> the derivation lands at
	// <sdkBase>/Developer, inside operation-private manager state.
	for _, d := range []string{h.shimDir, h.emptyDir, h.srcDir, h.stage, h.tmp,
		filepath.Join(h.sdkBase, "present", "SDKs"), filepath.Join(base, "home")} {
		if err := os.MkdirAll(d, 0o755); err != nil {
			return nil, err
		}
	}
	// The shim set names every executable a Swift compile could plausibly reach
	// by name. Each records its own name and exits 127.
	names := []string{
		"cc", "clang", "clang++", "ld", "ld64", "ld64.lld", "ld.lld", "lld", "ld-classic",
		"xcrun", "xcode-select", "ar", "libtool", "ranlib", "dsymutil", "codesign",
		"sh", "env", "python3", "strip", "nm", "otool", "install_name_tool", "lipo",
		"swift", "swiftc", "swift-frontend", "swift-driver", "swift-plugin-server",
		"swift-autolink-extract", "sandbox-exec",
	}
	for _, n := range names {
		body := fmt.Sprintf("#!/bin/sh\nprintf '%%s\\t%%s\\n' '%s' \"$*\" >> '%s'\nexit 127\n", n, h.shimLog)
		if err := os.WriteFile(filepath.Join(h.shimDir, n), []byte(body), 0o755); err != nil {
			return nil, err
		}
	}
	if err := os.WriteFile(filepath.Join(h.srcDir, "main.swift"), []byte("import Foundation\nlet v = helperValue()\nprint(\"probe \\(v)\")\n"), 0o644); err != nil {
		return nil, err
	}
	if err := os.WriteFile(filepath.Join(h.srcDir, "helper.swift"), []byte("func helperValue() -> Int { return 42 }\n"), 0o644); err != nil {
		return nil, err
	}
	link := h.presentedSDK()
	_ = os.Remove(link)
	if err := os.Symlink(h.tc.DeclaredSDK, link); err != nil {
		return nil, err
	}
	return h, nil
}

func (h *harness) presentedSDK() string {
	return filepath.Join(h.sdkBase, "present", "SDKs", filepath.Base(h.tc.DeclaredSDK))
}

func (h *harness) poisonedEnv() *Env {
	return &Env{PATH: h.shimDir, HOME: filepath.Join(h.base, "home"), TMP: h.tmp + string(os.PathSeparator)}
}

func (h *harness) cleanEnv() *Env {
	return &Env{PATH: h.emptyDir, HOME: filepath.Join(h.base, "home"), TMP: h.tmp + string(os.PathSeparator)}
}

func (h *harness) resetLog() { _ = os.WriteFile(h.shimLog, nil, 0o644) }

func (h *harness) shimHits() []string {
	b, err := os.ReadFile(h.shimLog)
	if err != nil {
		return nil
	}
	var out []string
	for _, l := range strings.Split(strings.TrimSpace(string(b)), "\n") {
		if l == "" {
			continue
		}
		out = append(out, strings.SplitN(l, "\t", 2)[0])
	}
	sort.Strings(out)
	return out
}

// compileVector is the driver's fixed compile argument vector. The graph vector
// is derived from it by inserting exactly one token, so the two cannot drift.
func (h *harness) compileVector(sdk string, out string, extra []string, sources []string) []string {
	args := []string{
		"-swift-version", "6",
		"-O",
		"-target", h.tc.Triple,
		"-sdk", sdk,
		"-module-name", "Sk_probe",
		"-no-color-diagnostics",
	}
	args = append(args, extra...)
	args = append(args, sources...)
	return append(args, "-o", out)
}

// graphVector is the compile vector with `-###` prepended and nothing else
// changed. Equality-modulo-one-token is asserted by S17 rather than trusted.
func (h *harness) graphVector(sdk string, out string, extra []string, sources []string) []string {
	return append([]string{"-###"}, h.compileVector(sdk, out, extra, sources)...)
}

// policy is what the plan verifier is allowed to trust: resolved roots only.
func (h *harness) policy(sources []string) PlanPolicy {
	resolve := func(p string) string {
		if r, err := filepath.EvalSymlinks(p); err == nil {
			return r
		}
		return p
	}
	root := resolve(h.tc.Root)
	sdk := resolve(h.tc.DeclaredSDK)
	return PlanPolicy{
		ToolchainRoot:      root,
		FingerprintedRoots: []string{root, sdk},
		OperationPrivate:   []string{resolve(h.stage), resolve(h.tmp)},
		Sources:            sources,
		WorkingDir:         h.srcDir,

		// The opaque constants the manager itself chose, so the closed grammar can
		// compare the plan's opaque values against them byte-exactly.
		Triple:       h.tc.Triple,
		SwiftVersion: "6",
		ModuleName:   "Sk_probe",
		// MEASURED pass-through value sets for this platform. An unlisted value
		// rejects: both flags feed a second option parser.
		XllvmValues: []string{"-aarch64-use-tbi"},
		XccValues:   []string{"-fno-color-diagnostics"},
	}
}

func (h *harness) defaultSources() []string {
	return []string{filepath.Join(h.srcDir, "main.swift"), filepath.Join(h.srcDir, "helper.swift")}
}

func verdict(ok bool) string {
	if ok {
		return "match"
	}
	return "divergence"
}

// Structurals runs every structural boundary check. checkPluginClosure is false
// only for expected-red control C6.
func Structurals(h *harness, checkPluginClosure bool) []Structural {
	tc := h.tc
	var out []Structural
	roots := []string{h.policy(nil).ToolchainRoot}
	srcs := h.defaultSources()

	// ---- S1 / S2: the process closure and the control that makes it mean
	// something ------------------------------------------------------------
	h.resetLog()
	pin := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "pinned"), nil, srcs), h.srcDir, h.poisonedEnv())
	pinHits := h.shimHits()

	h.resetLog()
	ctl := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "control"), []string{"-use-ld=lld"}, srcs), h.srcDir, h.poisonedEnv())
	ctlHits := h.shimHits()

	out = append(out, Structural{
		ID:       "S1-path-closure",
		Title:    "the fixed compile vector resolves no executable through PATH",
		Expected: "exit 0 and 0 PATH resolutions",
		Observed: fmt.Sprintf("exit %d, %d PATH resolutions %v", pin.Exit, len(pinHits), pinHits),
		Verdict:  verdict(pin.Exit == 0 && len(pinHits) == 0),
		ManagerObligation: "The manager pins -target and -sdk and passes no linker selection flag. " +
			"Under a PATH of logging shims the whole compile resolves nothing by name.",
		Runs: []RunRecord{pin},
	})
	out = append(out, Structural{
		ID:       "S2-harness-sensitivity",
		Title:    "the same harness catches a PATH resolution when the linker is named instead of defaulted",
		Expected: "at least one PATH resolution",
		Observed: fmt.Sprintf("exit %d, %d PATH resolutions %v", ctl.Exit, len(ctlHits), ctlHits),
		Verdict:  verdict(len(ctlHits) > 0),
		ManagerObligation: "Without a firing control the zero of S1 proves nothing. `-use-ld=lld` is not in the " +
			"driver's vector; it exists here only to prove the shim directory bites.",
		Runs: []RunRecord{ctl},
	})

	// ---- S2b: the required closure is four members, and `swift` is not one --
	var memberDetail []string
	closureInside := true
	for _, p := range []string{tc.Swiftc, tc.Frontend, tc.Clang, tc.Linker} {
		real, in := resolveInside(p, tc.Root)
		if !in {
			closureInside = false
		}
		memberDetail = append(memberDetail, filepath.Base(p)+"->"+strings.TrimPrefix(real, tc.Root))
	}
	swiftReal, swiftIn := resolveInside(tc.Swift, tc.Root)
	out = append(out, Structural{
		ID:       "S2b-required-closure-is-four-members",
		Title:    "the required runtime closure is swiftc, swift-frontend, clang and the linker; `swift` is not a member",
		Expected: "all four required members resolve inside the toolchain root",
		Observed: fmt.Sprintf("required=[%s]; swift present=%v (%s), never invoked by the driver",
			strings.Join(memberDetail, " "), swiftIn, strings.TrimPrefix(swiftReal, tc.Root)),
		Verdict: verdict(closureInside),
		ManagerObligation: "The driver starts swiftc, which starts swift-frontend and clang, and clang starts the linker. " +
			"`swift` is the SwiftPM launcher: it is forbidden from the pipeline, so it is not a required registry member. " +
			"Its bytes are still covered by the root fingerprint, and this probe uses it only as the upstream oracle. " +
			"The member set is platform-determined — Linux adds swift-autolink-extract — so the rule is structural: " +
			"every executable the verified plan names, plus the linker clang resolves, must lie inside the root.",
	})

	// ---- S3 / S4: the job plan under the fail-closed verifier ---------------
	planRec, planOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "plan"), nil, srcs), h.srcDir, h.cleanEnv())
	pol := h.policy(srcs)
	res := VerifyPlan(planOut, pol)
	execs := res.Counts[BucketExecutable]
	plugins := res.Counts[BucketPlugin]
	pluginAbsent := 0
	pluginOutside := 0
	for _, b := range res.Bindings {
		if b.Bucket == BucketPlugin && !b.Present {
			pluginAbsent++
		}
	}
	_, lenientPlugins := LenientPlanScan(planOut)
	for _, p := range distinct(lenientPlugins) {
		if r, err := filepath.EvalSymlinks(p); err == nil && !contained(r, pol.FingerprintedRoots) {
			pluginOutside++
		}
	}
	planOK := res.OK()
	if !checkPluginClosure {
		planOK = true
	}
	out = append(out, Structural{
		ID:       "S3-job-plan-verification-is-total",
		Title:    "every path-shaped token in the job plan is claimed by exactly one bucket and boundary-checked",
		Expected: "0 rejections, at least one executable, and every bucket accounted",
		Observed: fmt.Sprintf("graph exit=%d, %d jobs, buckets %v, rejections=%v",
			planRec.Exit, len(res.Jobs), sortedCounts(res.Counts), res.Rejections),
		Verdict: verdict(planRec.Exit == 0 && planOK && len(res.Jobs) > 0 && execs > 0),
		ManagerObligation: "The graph phase is `swiftc -###` over the exact compile vector. The verifier is a rejection " +
			"engine: a line it cannot tokenize, a flag with no value, a path it cannot resolve, and a path-shaped token no " +
			"bucket claims all reject the operation with build_execution_control_unavailable.",
		Runs: []RunRecord{planRec},
	})

	linkPlan := runFixed(tc.Clang, []string{"-print-prog-name=ld", "-target", tc.Triple}, h.srcDir, h.cleanEnv())
	linkerNamed := strings.TrimSpace(linkPlan.Stdout)
	linkerReal, linkerIn := "", false
	if linkerNamed != "" {
		if r, err := filepath.EvalSymlinks(linkerNamed); err == nil {
			linkerReal, linkerIn = r, contained(r, roots)
		}
	}
	out = append(out, Structural{
		ID:       "S3b-linker-resolution",
		Title:    "the C driver resolves the linker by absolute path inside the toolchain root",
		Expected: "an absolute linker path resolving inside the toolchain root",
		Observed: fmt.Sprintf("linker=%s resolved=%s inside=%v", linkerNamed, linkerReal, linkerIn),
		Verdict:  verdict(linkerIn),
		ManagerObligation: "swiftc plans no link job of its own: it starts clang, and clang starts the linker. The " +
			"manager passes no linker selection flag, so the compiler-relative lookup wins over PATH.",
		Runs: []RunRecord{linkPlan},
	})

	out = append(out, Structural{
		ID:       "S4-plugin-path-closure",
		Title:    "every macro plugin path is inside a fingerprinted root or does not exist",
		Expected: "0 plugin paths that exist outside a fingerprinted root",
		Observed: fmt.Sprintf("%d plugin components verified; %d absent; %d existing outside every fingerprinted root",
			plugins, pluginAbsent, pluginOutside),
		Verdict: verdict(planOK && plugins > 0),
		ManagerObligation: "The external plugin path is derived from the -sdk argument. Presenting the SDK through a " +
			"manager-owned directory makes the derived tree absent, so no plugin server outside the toolchain can load.",
	})

	// The same plan against the declared SDK path, to show what the manager
	// presentation actually removes.
	planReal, planRealOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(tc.DeclaredSDK, filepath.Join(h.stage, "plan-real"), nil, srcs), h.srcDir, h.cleanEnv())
	realOutside := 0
	_, realPlugins := LenientPlanScan(planRealOut)
	for _, p := range distinct(realPlugins) {
		if r, err := filepath.EvalSymlinks(p); err == nil && !contained(r, pol.FingerprintedRoots) {
			realOutside++
		}
	}
	out = append(out, Structural{
		ID:       "S5-declared-sdk-would-open-a-plugin-tree",
		Title:    "the declared SDK path derives a live plugin tree outside the toolchain root",
		Expected: "at least one existing plugin path outside every fingerprinted root",
		Observed: fmt.Sprintf("%d distinct existing plugin paths outside every fingerprinted root", realOutside),
		Verdict:  verdict(realOutside > 0),
		ManagerObligation: "This is the surface the manager presentation removes. Passing the declared SDK path " +
			"directly would put an executable plugin server outside every fingerprinted root into the closure.",
		Runs: []RunRecord{planReal},
	})

	// ---- S6 / S7: macro availability under the manager presentation --------
	extDir := filepath.Join(h.base, "macro-ext")
	_ = os.MkdirAll(extDir, 0o755)
	_ = os.WriteFile(filepath.Join(extDir, "main.swift"),
		[]byte("import Foundation\nstruct Row { var n: Int }\nlet p = #Predicate<Row> { $0.n > 3 }\nprint(p)\n"), 0o644)
	ext := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "ext"), []string{"-Xfrontend", "-Rmacro-loading"},
		[]string{filepath.Join(extDir, "main.swift")}), extDir, h.poisonedEnv())
	out = append(out, Structural{
		ID:       "S6-external-platform-macro-unavailable",
		Title:    "a platform macro whose implementation lives outside the toolchain root cannot load",
		Expected: "non-zero exit naming the missing external macro implementation",
		Observed: fmt.Sprintf("exit %d: %s", ext.Exit, firstErrorLine(ext.Stderr)),
		Verdict:  verdict(ext.Exit != 0 && strings.Contains(ext.Stderr, "external macro implementation type")),
		ManagerObligation: "Source using an external platform macro fails to compile. That is a stated narrowing of " +
			"what this driver builds, not a silent difference in what it links.",
		Runs: []RunRecord{ext},
	})

	intDir := filepath.Join(h.base, "macro-int")
	_ = os.MkdirAll(intDir, 0o755)
	_ = os.WriteFile(filepath.Join(intDir, "main.swift"),
		[]byte("import Observation\n@Observable final class Box { var n: Int = 0 }\nlet b = Box()\nb.n = 7\nprint(\"obs \\(b.n)\")\n"), 0o644)
	h.resetLog()
	in := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "int"), []string{"-Xfrontend", "-Rmacro-loading"},
		[]string{filepath.Join(intDir, "main.swift")}), intDir, h.poisonedEnv())
	inHits := h.shimHits()
	libLine := ""
	for _, l := range strings.Split(in.Stderr, "\n") {
		if strings.Contains(l, "loaded macro implementation module") {
			libLine = strings.TrimSpace(l)
			break
		}
	}
	inRootOnly := libLine != "" && strings.Contains(libLine, tc.Root) && !strings.Contains(libLine, "compiler plugin server")
	out = append(out, Structural{
		ID:       "S7-toolchain-macro-loads-in-process",
		Title:    "a toolchain-supplied macro loads from the toolchain root without a plugin server process",
		Expected: "exit 0, the remark names a shared library inside the toolchain root, no plugin server, 0 PATH resolutions",
		Observed: fmt.Sprintf("exit %d, %d PATH resolutions, remark=%s", in.Exit, len(inHits), clipTo(libLine, 200)),
		Verdict:  verdict(in.Exit == 0 && len(inHits) == 0 && inRootOnly),
		ManagerObligation: "Macros the toolchain itself ships stay available and stay inside the fingerprinted root. " +
			"The manager does not have to reject macro syntax to keep the closure.",
		Runs: []RunRecord{in},
	})

	// ---- S8: the graph phase executes no package code ---------------------
	badDir := filepath.Join(h.base, "bad")
	_ = os.MkdirAll(badDir, 0o755)
	_ = os.WriteFile(filepath.Join(badDir, "main.swift"), []byte("this is not swift @@@ (((\n"), 0o644)
	planBad := runFixed(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "bad"), nil,
		[]string{filepath.Join(badDir, "main.swift")}), badDir, h.cleanEnv())
	planAbsent := runFixed(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "absent"), nil,
		[]string{filepath.Join(badDir, "does-not-exist.swift")}), badDir, h.cleanEnv())
	entries, _ := os.ReadDir(badDir)
	out = append(out, Structural{
		ID:       "S8-graph-phase-executes-no-package-code",
		Title:    "the graph phase plans jobs for unreadable and absent sources without compiling either",
		Expected: "both -### runs exit 0 and the source directory is unchanged",
		Observed: fmt.Sprintf("invalid exit %d, absent exit %d, directory entries %d", planBad.Exit, planAbsent.Exit, len(entries)),
		Verdict:  verdict(planBad.Exit == 0 && planAbsent.Exit == 0 && len(entries) == 1),
		ManagerObligation: "The Swift graph phase reads no package byte as a program. Every rejection the matrix owns " +
			"is decided from snapshot bytes and this job plan, before any compiler child.",
		Runs: []RunRecord{planBad, planAbsent},
	})

	// ---- S9 / S10: SwiftPM's manifest is a program ------------------------
	out = append(out, manifestExecutionChecks(h)...)

	// ---- S11 / S12: representability is not admission ---------------------
	out = append(out, targetChecks(h)...)

	// ---- S13 .. S16: artifact, determinism, inert selector -----------------
	out = append(out, artifactChecks(h, pin)...)

	// ---- S17 .. S25: the rework's own boundaries --------------------------
	out = append(out, vectorEqualityCheck(h)...)
	out = append(out, planRejectionChecks(h, planOut)...)
	out = append(out, moduleNameChecks(h)...)
	out = append(out, responseFileChecks(h)...)
	out = append(out, presentationDerivationChecks(h)...)
	out = append(out, sourceNameChecks(h)...)

	// ---- S26 .. S39: the cycle-2 rework's own boundaries -------------------
	out = append(out, bannerChecks(h)...)
	out = append(out, runtimeAdmissionChecks(h)...)
	out = append(out, serializationChecks(h)...)
	out = append(out, vectorAndLineChecks(h)...)

	// ---- S42 .. S53: the cycle-3 rework's own boundaries -------------------
	out = append(out, macroAdmissionChecks(h)...)
	out = append(out, closedGrammarChecks(h)...)

	// ---- S54 .. S64: the cycle-4 rework's own boundaries -------------------
	// Stage-B source admission, and the restored manager-worker-v2 session
	// cardinality.
	out = append(out, sourceAdmissionChecks(h)...)

	// ---- S65 .. S72: the cycle-5 rework's own boundaries -------------------
	// The permit-time re-binding, exercised inside the one authoritative
	// session rather than in isolation.
	out = append(out, permitBindingChecks(h)...)

	return out
}

// distinct preserves order and drops repeats, so a count of plugin paths
// reports how many trees are involved rather than how many jobs mention them.
func distinct(in []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, s := range in {
		if seen[s] {
			continue
		}
		seen[s] = true
		out = append(out, s)
	}
	return out
}

func sortedCounts(m map[string]int) string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var parts []string
	for _, k := range keys {
		parts = append(parts, fmt.Sprintf("%s=%d", k, m[k]))
	}
	return strings.Join(parts, " ")
}

// vectorEqualityCheck asserts the property the whole graph phase rests on: the
// verified plan is produced by the executed vector.
func vectorEqualityCheck(h *harness) []Structural {
	srcs := h.defaultSources()
	compile := h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "eq"), nil, srcs)
	graph := h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "eq"), nil, srcs)
	ok := len(graph) == len(compile)+1 && graph[0] == "-###"
	diff := ""
	if ok {
		for i := range compile {
			if graph[i+1] != compile[i] {
				ok = false
				diff = fmt.Sprintf("token %d: graph %q vs compile %q", i, graph[i+1], compile[i])
				break
			}
		}
	}
	return []Structural{{
		ID:       "S17-graph-and-compile-vectors-differ-by-one-token",
		Title:    "the graph vector is the compile vector with exactly one token inserted",
		Expected: "token-for-token equality with `-###` as the sole difference, at index 0",
		Observed: fmt.Sprintf("graph=%d tokens compile=%d tokens equal=%v %s", len(graph), len(compile), ok, diff),
		Verdict:  verdict(ok),
		ManagerObligation: "Both vectors are produced from one builder, so they cannot drift. If they could differ by " +
			"anything but `-###`, the verified plan would not be the executed plan and the graph phase would prove nothing.",
	}}
}

// BadPlanVector is one negative parser vector: a plan the verifier MUST reject.
type BadPlanVector struct {
	ID   string
	Plan string
}

// BadPlanVectors enumerates one vector per failure family the reviewer named,
// built from real paths so the containment checks are meaningful rather than
// simulated.
func BadPlanVectors(h *harness) []BadPlanVector {
	tc := h.tc
	srcs := h.defaultSources()
	good := fmt.Sprintf("%s -frontend -c %s -o %s", tc.Frontend, srcs[0], filepath.Join(h.tmp, "o.o"))
	return []BadPlanVector{
		{"relative-executable", "swift-frontend -frontend -c " + srcs[0]},
		{"unmatched-quote", tc.Frontend + " -plugin-path '" + tc.Root},
		{"dangling-backslash", tc.Frontend + " -frontend " + srcs[0] + " \\"},
		{"plugin-flag-without-value", tc.Frontend + " -frontend -plugin-path"},
		{"plugin-flag-empty-value", tc.Frontend + " -frontend -plugin-path="},
		{"external-plugin-path-one-component", tc.Frontend + " -external-plugin-path " + tc.Root},
		{"external-plugin-path-three-components", tc.Frontend + " -external-plugin-path " + tc.Root + "#" + tc.Root + "#" + tc.Root},
		{"hash-in-a-single-path-plugin-flag", tc.Frontend + " -plugin-path " + tc.Root + "#" + tc.Root},
		{"blank-line", good + "\n\n" + good},
		{"tab-inside-a-line", tc.Frontend + "\t-frontend"},
		{"executable-outside-the-toolchain-root", "/bin/sh -frontend"},
		{"new-driver-path-outside-the-root", tc.Frontend + " -new-driver-path /bin/sh"},
		{"search-path-outside-every-root", tc.Frontend + " -L /etc"},
		{"joined-search-path-outside-every-root", tc.Frontend + " -L/etc"},
		{"search-path-that-does-not-exist", tc.Frontend + " -sdk " + filepath.Join(h.base, "no-such-sdk")},
		{"output-outside-operation-private-state", tc.Frontend + " -o /etc/curator-probe-out"},
		{"unclaimed-absolute-positional", tc.Frontend + " -frontend /etc/hosts"},
		{"source-not-in-the-manager-source-set", tc.Frontend + " -primary-file " + filepath.Join(h.base, "not-a-source.swift")},
		{"plugin-path-that-exists-outside-every-root", tc.Frontend + " -plugin-path /etc"},
		{"empty-plan", ""},
	}
}

// LenientlyAdmitted names the vectors the retired parser lets through: it
// returns a token list for a line it cannot classify instead of failing, so a
// malformed plan reads as an acceptable one.
func LenientlyAdmitted(vectors []BadPlanVector) []string {
	var out []string
	for _, b := range vectors {
		execs, _ := LenientPlanScan(b.Plan + "\n")
		// The retired scan produces no rejection at all. It "admits" a vector
		// whenever it finds an executable to run, or finds nothing and says so
		// with the same silence it uses for a well-formed plan.
		if len(execs) > 0 || b.Plan == "" {
			out = append(out, b.ID)
		}
	}
	return out
}

// planRejectionChecks are the negative parser vectors. Each malformed plan MUST
// reject; a valid baseline MUST NOT. The symlink escape and the mutation race
// are exercised against real filesystem state, not simulated.
func planRejectionChecks(h *harness, realPlan string) []Structural {
	tc := h.tc
	srcs := h.defaultSources()
	pol := h.policy(srcs)
	good := fmt.Sprintf("%s -frontend -c %s -o %s", tc.Frontend, srcs[0], filepath.Join(h.tmp, "o.o"))

	baseline := VerifyPlan(good+"\n", pol)
	bad := BadPlanVectors(h)

	rejected := 0
	var admitted []string
	for _, b := range bad {
		if VerifyPlan(b.Plan+"\n", pol).OK() {
			admitted = append(admitted, b.ID)
			continue
		}
		rejected++
	}
	lenientAdmitted := len(LenientlyAdmitted(bad))

	out := []Structural{{
		ID:       "S18-malformed-plans-are-rejected",
		Title:    "every malformed, unknown or out-of-closure plan shape rejects the operation",
		Expected: fmt.Sprintf("the valid baseline verifies and all %d negative vectors reject", len(bad)),
		Observed: fmt.Sprintf("baseline ok=%v (%v); %d/%d negatives rejected; admitted=%v", baseline.OK(), baseline.Rejections, rejected, len(bad), admitted),
		Verdict:  verdict(baseline.OK() && rejected == len(bad)),
		ManagerObligation: "There is no skip and no best-effort recovery. A line the grammar does not cover, a flag " +
			"with no value, an unresolvable path and a path-shaped token no bucket claims are each " +
			"build_execution_control_unavailable before the compile phase.",
	}}

	// Symlink escape: lexically inside, really outside. The escape is built from
	// the resolved root so the lexical comparison is like with like.
	fakeRoot := filepath.Join(h.base, "fakeroot")
	_ = os.MkdirAll(filepath.Join(fakeRoot, "bin"), 0o755)
	resolvedFake, _ := filepath.EvalSymlinks(fakeRoot)
	escape := filepath.Join(resolvedFake, "bin", "ld")
	_ = os.Remove(escape)
	_ = os.Symlink("/bin/sh", escape)
	escPol := PlanPolicy{
		ToolchainRoot:      resolvedFake,
		FingerprintedRoots: []string{resolvedFake},
		OperationPrivate:   pol.OperationPrivate,
		WorkingDir:         h.srcDir,
	}
	escRes := VerifyPlan(escape+" -frontend\n", escPol)
	lexOK := lexicallyContained(escape, []string{resolvedFake})
	out = append(out, Structural{
		ID:       "S19-symlink-escape-is-caught-by-resolved-containment",
		Title:    "a path lexically below a root but symlinked outside it is rejected",
		Expected: "resolved containment rejects; the retired lexical check would have admitted",
		Observed: fmt.Sprintf("resolved verdict rejected=%v (%v); lexical prefix check admits=%v", !escRes.OK(), escRes.Rejections, lexOK),
		Verdict:  verdict(!escRes.OK() && lexOK),
		ManagerObligation: "Containment is computed on the symlink-resolved path of both sides and compared byte-exactly " +
			"on components, so a case variant on a case-insensitive volume also fails closed rather than passing.",
	})

	// Mutation race: a plugin path verified absent that exists at permit time.
	raceDir := filepath.Join(h.base, "race")
	_ = os.RemoveAll(raceDir)
	racePath := filepath.Join(raceDir, "plugins")
	racePlan := fmt.Sprintf("%s -frontend -plugin-path %s\n", tc.Frontend, racePath)
	raceRes := VerifyPlan(racePlan, pol)
	beforeOK := raceRes.OK()
	_ = os.MkdirAll(racePath, 0o755)
	raceFindings := Reverify(raceRes.Bindings)
	out = append(out, Structural{
		ID:       "S20-absent-plugin-path-that-appears-before-the-permit-is-caught",
		Title:    "a plugin path verified absent at graph time and created before the compile permit is rejected",
		Expected: "the plan verifies while the path is absent, and the permit-time re-check reports it",
		Observed: fmt.Sprintf("graph-time ok=%v; permit-time findings=%v", beforeOK, raceFindings),
		Verdict:  verdict(beforeOK && len(raceFindings) > 0),
		ManagerObligation: "Every binding is re-resolved and re-identified immediately before the compile child starts, " +
			"and every absent plugin path must still be absent. This narrows the window; what closes it is the ownership " +
			"requirement on the declaration channels, which admits no other writer to either root or to staging.",
	})

	// A binding whose bytes change between graph and permit.
	swapDir := filepath.Join(h.base, "swap")
	_ = os.MkdirAll(swapDir, 0o755)
	swapTarget := filepath.Join(swapDir, "exe")
	_ = os.WriteFile(swapTarget, []byte("#!/bin/sh\nexit 0\n"), 0o755)
	swapResolved, _ := filepath.EvalSymlinks(swapDir)
	swapPol := PlanPolicy{ToolchainRoot: swapResolved, FingerprintedRoots: []string{swapResolved}, OperationPrivate: pol.OperationPrivate, WorkingDir: h.srcDir}
	swapRes := VerifyPlan(swapTarget+" -frontend\n", swapPol)
	_ = os.WriteFile(swapTarget, []byte("#!/bin/sh\nexit 1\n#changed\n"), 0o755)
	swapFindings := Reverify(swapRes.Bindings)
	out = append(out, Structural{
		ID:       "S21-bound-executable-that-changes-before-the-permit-is-caught",
		Title:    "an executable whose bytes change between the graph phase and the compile permit is rejected",
		Expected: "the plan verifies, and the permit-time re-check reports the identity change",
		Observed: fmt.Sprintf("graph-time ok=%v; permit-time findings=%v", swapRes.OK(), swapFindings),
		Verdict:  verdict(swapRes.OK() && len(swapFindings) > 0),
		ManagerObligation: "The binding records the resolved path and the file identity the graph phase verified. The " +
			"permit re-check requires both to be unchanged before the compile child is allowed to start.",
	})

	// The real plan, under the retired parser, to record what strictness bought.
	strictReal := VerifyPlan(realPlan, pol)
	out = append(out, Structural{
		ID:       "S22-the-real-plan-verifies-under-the-strict-grammar",
		Title:    "the measured Apple 6.3.2 plan is accepted by the same grammar that rejects all twenty negatives",
		Expected: "0 rejections over the real plan",
		Observed: fmt.Sprintf("rejections=%v; lenient scan would have admitted %d/%d negatives", strictReal.Rejections, lenientAdmitted, len(bad)),
		Verdict:  verdict(strictReal.OK()),
		ManagerObligation: "A grammar that rejects everything is not a contract. The same verifier that refuses every " +
			"negative vector accepts the plan the toolchain actually emits, which is what makes the refusals meaningful.",
	})
	return out
}

func moduleNameChecks(h *harness) []Structural {
	// Declared mapping. Every value here is fixed by the derivation, not measured.
	table := map[string]string{
		"tool":    "Sk_tool",
		"my-tool": "Sk_myzhtool",
		"my.tool": "Sk_myzdtool",
		"my_tool": "Sk_myzutool",
		"9.tool":  "Sk_9zdtool",
		"0":       "Sk_0",
		"z":       "Sk_zz",
		"z-z":     "Sk_zzzhzz",
		"zdz":     "Sk_zzdzz",
	}
	var wrong []string
	for k, want := range table {
		got, err := DeriveModuleName(k)
		if err != nil || got != want {
			wrong = append(wrong, fmt.Sprintf("%q -> %q (want %q, err=%v)", k, got, want, err))
		}
	}

	// Totality and injectivity over a generated corpus that covers punctuation,
	// leading digits, the length boundary and the overflow branch.
	alphabet := []string{"a", "z", "0", "9", ".", "-", "_"}
	var corpus []string
	for _, a := range alphabet[:4] { // a valid key starts alphanumeric
		for _, b := range alphabet {
			for _, c := range alphabet {
				corpus = append(corpus, a+b+c)
			}
		}
	}
	for _, n := range []int{29, 30, 31, 32, 60, 61, 62, 63, 64, 65, 200} {
		corpus = append(corpus, "a"+strings.Repeat("z", n-1))
		corpus = append(corpus, "a"+strings.Repeat("b", n-1))
		corpus = append(corpus, "a"+strings.Repeat("-", n-1))
	}
	seen := map[string]string{}
	total, collisions, badShape, badDecode, longBranch := 0, 0, 0, 0, 0
	var collisionDetail []string
	for _, k := range corpus {
		if !ValidCommandKey(k) {
			continue
		}
		total++
		m, err := DeriveModuleName(k)
		if err != nil || !ValidModuleName(m) {
			badShape++
			continue
		}
		if strings.HasPrefix(m, moduleLongTag) {
			longBranch++
		} else if dec, ok := DecodeModuleName(m); !ok || dec != k {
			badDecode++
		}
		if prev, dup := seen[m]; dup && prev != k {
			collisions++
			if len(collisionDetail) < 3 {
				collisionDetail = append(collisionDetail, fmt.Sprintf("%q and %q both -> %q", prev, k, m))
			}
		}
		seen[m] = k
	}

	// The retired rule, restored from the same binary, over the same corpus.
	naiveSeen := map[string]string{}
	naiveCollisions := 0
	for _, k := range corpus {
		if !ValidCommandKey(k) {
			continue
		}
		m := NaiveModuleName(k)
		if prev, dup := naiveSeen[m]; dup && prev != k {
			naiveCollisions++
		}
		naiveSeen[m] = k
	}

	out := []Structural{{
		ID:       "S23-module-name-derivation-is-total-and-collision-free",
		Title:    "every protocol-valid command key derives one valid Swift module name, and no two keys share one",
		Expected: "the declared mapping holds, every corpus key derives a valid name, 0 collisions, every short result decodes back",
		Observed: fmt.Sprintf("declared-mapping-divergences=%v; corpus=%d keys, invalid=%d, collisions=%d %v, undecodable-short=%d, long-branch=%d; the retired replacement rule collides on %d keys",
			wrong, total, badShape, collisions, collisionDetail, badDecode, longBranch, naiveCollisions),
		Verdict: verdict(len(wrong) == 0 && badShape == 0 && collisions == 0 && badDecode == 0 && longBranch > 0 && naiveCollisions > 0),
		ManagerObligation: "The module name is manager-derived from the consuming command key and from nothing else. " +
			"The short branch is injective by construction — the decoder inverts it — and the long branch carries a " +
			"160-bit digest of the whole key. The canonical build input binds the command key alongside the module name, " +
			"so identity does not rest on the derivation being injective at all.",
	}}

	// The reserved prefix must not shadow a module package source can import.
	mods := moduleInventory(h.tc)
	clash := 0
	for _, m := range mods {
		if strings.HasPrefix(m, moduleShortTag) || strings.HasPrefix(m, moduleLongTag) {
			clash++
		}
	}
	out = append(out, Structural{
		ID:       "S24-module-prefix-is-reserved-in-the-measured-closure",
		Title:    "no module in the toolchain root or the platform SDK carries the derivation's reserved prefix",
		Expected: "0 modules named Sk_* or Tk_*",
		Observed: fmt.Sprintf("%d module names inventoried, %d carrying a reserved prefix", len(mods), clash),
		Verdict:  verdict(len(mods) > 0 && clash == 0),
		ManagerObligation: "The prefixes also force the result to start with an uppercase letter, so a derived name can " +
			"never be a Swift keyword and can never be the `Swift` standard-library module — which a bare escape would " +
			"produce for the key `wift`.",
	})
	return out
}

// moduleInventory lists the module and framework names reachable from the two
// fingerprinted roots, bounded in depth so the walk stays cheap.
func moduleInventory(tc *Toolchain) []string {
	seen := map[string]bool{}
	roots := []string{
		filepath.Join(tc.Root, "usr", "lib", "swift"),
		filepath.Join(tc.DeclaredSDK, "usr", "lib", "swift"),
		filepath.Join(tc.DeclaredSDK, "System", "Library", "Frameworks"),
	}
	for _, r := range roots {
		for _, pat := range []string{"*.swiftmodule", "*.framework", "*/*.swiftmodule", "*/*.framework"} {
			matches, _ := filepath.Glob(filepath.Join(r, pat))
			for _, m := range matches {
				b := filepath.Base(m)
				b = strings.TrimSuffix(strings.TrimSuffix(b, ".swiftmodule"), ".framework")
				seen[b] = true
			}
		}
	}
	out := make([]string, 0, len(seen))
	for k := range seen {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

// responseFileChecks close the response-file row: the mechanism is live, and the
// fixed vectors cannot reach it.
func responseFileChecks(h *harness) []Structural {
	tc := h.tc
	rfDir := filepath.Join(h.base, "respfile")
	_ = os.MkdirAll(rfDir, 0o755)
	_ = os.WriteFile(filepath.Join(rfDir, "resp.txt"), []byte("-swift-version\n6\n"), 0o644)
	_ = os.WriteFile(filepath.Join(rfDir, "main.swift"), []byte("print(\"rf\")\n"), 0o644)

	// The mechanism, proven live: an @-leading argument is expanded.
	live, liveOut, _ := runFixedRaw(tc.Swiftc, []string{"-###", "@" + filepath.Join(rfDir, "resp.txt"), "-O",
		"-target", tc.Triple, "-sdk", h.presentedSDK(), "-module-name", "Sk_probe", "-no-color-diagnostics",
		filepath.Join(rfDir, "main.swift"), "-o", filepath.Join(h.stage, "rf")}, rfDir, h.cleanEnv())
	expanded := strings.Contains(liveOut, "-swift-version 6")

	// A source whose name begins with '@' reaches the compiler as an absolute
	// path, so it is compiled, never expanded.
	atDir := filepath.Join(h.base, "atname")
	_ = os.MkdirAll(atDir, 0o755)
	atSrc := filepath.Join(atDir, "@resp.swift")
	_ = os.WriteFile(atSrc, []byte("print(\"at\")\n"), 0o644)
	atRec, atOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "at"), nil, []string{atSrc}), atDir, h.cleanEnv())
	atPol := h.policy([]string{atSrc})
	atPol.WorkingDir = atDir
	atRes := VerifyPlan(atOut, atPol)
	atBuild := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "at-bin"), nil, []string{atSrc}), atDir, h.cleanEnv())

	return []Structural{{
		ID:       "S25-response-files-are-live-and-unreachable",
		Title:    "swiftc honours @file, and no token either vector emits can be read as one",
		Expected: "an @-leading argument is expanded; a source named @resp.swift is compiled as a source path",
		Observed: fmt.Sprintf("response file expanded=%v; @-named source: graph exit=%d plan-rejections=%v source-bucket=%d compile exit=%d",
			expanded, atRec.Exit, atRes.Rejections, atRes.Counts[BucketSource], atBuild.Exit),
		Verdict: verdict(expanded && atRec.Exit == 0 && atRes.OK() && atRes.Counts[BucketSource] > 0 && atBuild.Exit == 0),
		ManagerObligation: "Every source token is the absolute path of a snapshot file, so it begins with the path " +
			"separator and never with '@'. No other vector member begins with '@' either, and neither command shape has a " +
			"flag member a package could use to add one.",
		Runs: []RunRecord{live, atRec, atBuild},
	}}
}

// presentationDerivationChecks measure where the compiler derives its external
// plugin tree when the SDK is presented at the contract's nesting depth.
func presentationDerivationChecks(h *harness) []Structural {
	tc := h.tc
	_, planOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "derive"), nil, h.defaultSources()), h.srcDir, h.cleanEnv())
	_, plugins := LenientPlanScan(planOut)
	sdkBaseResolved, _ := filepath.EvalSymlinks(h.sdkBase)
	derived, insideBase, present := 0, 0, 0
	for _, p := range plugins {
		if strings.HasPrefix(p, h.sdkBase+string(os.PathSeparator)) || strings.HasPrefix(p, sdkBaseResolved+string(os.PathSeparator)) {
			derived++
			insideBase++
			if _, err := os.Lstat(p); err == nil {
				present++
			}
		}
	}
	return []Structural{{
		ID:       "S26-sdk-derived-plugin-tree-stays-in-operation-private-state",
		Title:    "every plugin path derived from the presented SDK lands inside the manager-owned presentation base and is absent",
		Expected: "at least one derived path, all inside the presentation base, none existing",
		Observed: fmt.Sprintf("%d SDK-derived plugin components, %d inside %s, %d existing", derived, insideBase, h.sdkBase, present),
		Verdict:  verdict(derived > 0 && insideBase == derived && present == 0),
		ManagerObligation: "Measured: the derivation is <sdk>/../../../Developer/usr/…. Presenting the SDK at " +
			"<base>/present/SDKs/<name> puts that derivation at <base>/Developer, inside a directory the manager creates " +
			"and keeps empty apart from the presentation chain. The plan verification is still the proof, because a future " +
			"toolchain may derive differently.",
	}}
}

// sourceNameChecks establish, by measurement, why the Stage A source-name rule
// rejects control bytes rather than trusting the parser to cope.
func sourceNameChecks(h *harness) []Structural {
	tc := h.tc
	nlDir := filepath.Join(h.base, "srcname")
	_ = os.MkdirAll(nlDir, 0o755)
	nlSrc := filepath.Join(nlDir, "new\nline.swift")
	_ = os.WriteFile(nlSrc, []byte("func nl() {}\n"), 0o644)
	plain := filepath.Join(nlDir, "main.swift")
	_ = os.WriteFile(plain, []byte("print(\"nl\")\n"), 0o644)

	rec, planOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "nl"), nil, []string{plain, nlSrc}), nlDir, h.cleanEnv())
	physical := len(strings.Split(strings.TrimSuffix(planOut, "\n"), "\n"))
	pol := h.policy([]string{plain, nlSrc})
	pol.WorkingDir = nlDir
	res := VerifyPlan(planOut, pol)

	stageA := ValidSourceRelPath("new\nline.swift")
	quoted := ValidSourceRelPath("has'quote.swift")
	spaced := ValidSourceRelPath("has space.swift")
	at := ValidSourceRelPath("@resp.swift")

	return []Structural{{
		ID:       "S27-a-control-byte-in-a-source-name-breaks-the-plan-grammar",
		Title:    "a source whose name carries a newline splits its job across physical lines, so it is refused at Stage A",
		Expected: "the plan has more physical lines than jobs, the verifier rejects it, and the Stage A rule refuses the name",
		Observed: fmt.Sprintf("graph exit=%d, %d physical lines, verifier rejections=%d, Stage A: newline=%v quote=%v space=%v at=%v",
			rec.Exit, physical, len(res.Rejections), stageA != nil, quoted != nil, spaced != nil, at != nil),
		Verdict: verdict(rec.Exit == 0 && physical > 2 && !res.OK() && stageA != nil && quoted == nil && spaced == nil && at == nil),
		ManagerObligation: "The rule is narrow on purpose: only ASCII control bytes are refused, because only they break " +
			"the line-oriented plan grammar. A quote, a space, a '#' and a leading '@' are all admitted, because the measured " +
			"quoting grammar renders them unambiguously and the verifier round-trips every source token against the manager's " +
			"own list.",
		Runs: []RunRecord{rec},
	}}
}

func manifestExecutionChecks(h *harness) []Structural {
	tc := h.tc
	escape := filepath.Join(h.base, "manifest-escape-marker")
	body := func() string {
		return "// swift-tools-version:6.0\nimport PackageDescription\nimport Foundation\n" +
			"FileHandle.standardError.write(\"PROBE-MANIFEST-EXECUTED\\n\".data(using: .utf8)!)\n" +
			"try? \"x\".write(toFile: \"" + escape + "\", atomically: true, encoding: .utf8)\n" +
			ManifestBody
	}
	mk := func(name string) string {
		dir := filepath.Join(h.base, name, PkgDir)
		_ = os.RemoveAll(filepath.Join(h.base, name))
		_ = os.MkdirAll(filepath.Join(dir, "Sources", "probe"), 0o755)
		_ = os.WriteFile(filepath.Join(dir, "Package.swift"), []byte(body()), 0o644)
		_ = os.WriteFile(filepath.Join(dir, "Sources", "probe", "lib.swift"), []byte(SourceBody), 0o644)
		return dir
	}
	env := func(name string) *Env {
		e := &Env{PATH: h.emptyDir, HOME: filepath.Join(h.base, name, "home"), TMP: filepath.Join(h.base, name, "tmp") + string(os.PathSeparator)}
		_ = os.MkdirAll(e.HOME, 0o755)
		_ = os.MkdirAll(strings.TrimSuffix(e.TMP, string(os.PathSeparator)), 0o755)
		return e
	}

	_ = os.Remove(escape)
	d1 := mk("mf-sandboxed")
	r1 := runFixed(tc.Swift, []string{"package", "--cache-path", filepath.Join(h.base, "mf-sandboxed", "c"), "--scratch-path", filepath.Join(h.base, "mf-sandboxed", "s"), "dump-package"}, d1, env("mf-sandboxed"))
	ranSandboxed := strings.Contains(r1.Stderr, "PROBE-MANIFEST-EXECUTED")
	escapedSandboxed := exists(escape)

	_ = os.Remove(escape)
	d2 := mk("mf-unsandboxed")
	r2 := runFixed(tc.Swift, []string{"package", "--disable-sandbox", "--cache-path", filepath.Join(h.base, "mf-unsandboxed", "c"), "--scratch-path", filepath.Join(h.base, "mf-unsandboxed", "s"), "dump-package"}, d2, env("mf-unsandboxed"))
	ranUnsandboxed := strings.Contains(r2.Stderr, "PROBE-MANIFEST-EXECUTED")
	escapedUnsandboxed := exists(escape)
	_ = os.Remove(escape)

	// tools-version against a manifest whose body is not valid Swift.
	d3 := filepath.Join(h.base, "mf-header-only", PkgDir)
	_ = os.RemoveAll(filepath.Join(h.base, "mf-header-only"))
	_ = os.MkdirAll(filepath.Join(d3, "Sources", "probe"), 0o755)
	_ = os.WriteFile(filepath.Join(d3, "Package.swift"), []byte("// swift-tools-version:6.0\nthis is @@ not swift (((\n"), 0o644)
	_ = os.WriteFile(filepath.Join(d3, "Sources", "probe", "lib.swift"), []byte(SourceBody), 0o644)
	r3 := runFixed(tc.Swift, []string{"package", "--cache-path", filepath.Join(h.base, "mf-header-only", "c"), "--scratch-path", filepath.Join(h.base, "mf-header-only", "s"), "tools-version"}, d3, env("mf-header-only"))
	r4 := runFixed(tc.Swift, []string{"package", "--cache-path", filepath.Join(h.base, "mf-header-only", "c2"), "--scratch-path", filepath.Join(h.base, "mf-header-only", "s2"), "dump-package"}, d3, env("mf-header-only"))

	// A specification only inside a multi-line string literal, to show that
	// upstream's scan reaches manifest body bytes that Curator never reads.
	d5 := filepath.Join(h.base, "mf-in-string", PkgDir)
	_ = os.RemoveAll(filepath.Join(h.base, "mf-in-string"))
	_ = os.MkdirAll(filepath.Join(d5, "Sources", "probe"), 0o755)
	inString := "import PackageDescription\nlet unused = \"\"\"\n// swift-tools-version:9.9\n\"\"\"\n" + ManifestBody
	_ = os.WriteFile(filepath.Join(d5, "Package.swift"), []byte(inString), 0o644)
	_ = os.WriteFile(filepath.Join(d5, "Sources", "probe", "lib.swift"), []byte(SourceBody), 0o644)
	r5 := runFixed(tc.Swift, []string{"package", "--cache-path", filepath.Join(h.base, "mf-in-string", "c"), "--scratch-path", filepath.Join(h.base, "mf-in-string", "s"), "tools-version"}, d5, env("mf-in-string"))

	return []Structural{
		{
			ID:       "S9-manifest-is-a-program",
			Title:    "reading what a SwiftPM package declares executes the manifest",
			Expected: "the manifest's side effect is observed under both sandbox settings, and the filesystem escape lands only with --disable-sandbox",
			Observed: fmt.Sprintf("sandboxed: executed=%v escaped=%v; --disable-sandbox: executed=%v escaped=%v", ranSandboxed, escapedSandboxed, ranUnsandboxed, escapedUnsandboxed),
			Verdict:  verdict(ranSandboxed && !escapedSandboxed && ranUnsandboxed && escapedUnsandboxed),
			ManagerObligation: "No manager command may invoke dump-package, describe, resolve, show-dependencies or build. " +
				"The only containment measured here is a macOS-specific sandbox that one flag removes, which is not a " +
				"guarantee the portable policy provides.",
			Runs: []RunRecord{r1, r2},
		},
		{
			ID:       "S10-tools-version-is-header-only",
			Title:    "the tools-version query answers for a manifest that is not valid Swift",
			Expected: "tools-version exits 0 while dump-package on the same file exits non-zero",
			Observed: fmt.Sprintf("tools-version exit=%d out=%q; dump-package exit=%d", r3.Exit, strings.TrimSpace(r3.Stdout), r4.Exit),
			Verdict:  verdict(r3.Exit == 0 && strings.TrimSpace(r3.Stdout) == "6.0.0" && r4.Exit != 0),
			ManagerObligation: "The bound project metadata is the first line of Package.swift and nothing else. The " +
				"manager reads those bytes itself; this run only establishes that the boundary upstream draws is the same one.",
			Runs: []RunRecord{r3, r4},
		},
		{
			ID:       "S10b-upstream-scans-into-string-literals",
			Title:    "upstream reports a tools version written inside a multi-line string literal",
			Expected: "exit 0 and the value from inside the literal",
			Observed: fmt.Sprintf("tools-version exit=%d out=%q", r5.Exit, strings.TrimSpace(r5.Stdout)),
			Verdict:  verdict(r5.Exit == 0 && strings.TrimSpace(r5.Stdout) == "9.9.0"),
			ManagerObligation: "This is why Curator reads line 1 and stops. A whole-file scan would let arbitrary manifest " +
				"body bytes — including bytes inside a string literal — set the version the manager compares, which is exactly " +
				"the input this driver refuses to accept. The refusal is declared as a member of the security partition F.",
			Runs: []RunRecord{r5},
		},
	}
}

func targetChecks(h *harness) []Structural {
	tc := h.tc
	unserved := "x86_64-unknown-linux-gnu"
	unknown := "not-a-real-triple"

	ti := runFixed(tc.Swiftc, []string{"-print-target-info", "-target", unserved}, h.srcDir, h.cleanEnv())
	tiUnknown := runFixed(tc.Swiftc, []string{"-print-target-info", "-target", unknown}, h.srcDir, h.cleanEnv())
	unservedPathPresent := false
	var ti2 targetInfo
	if ti.Exit == 0 && jsonInto(ti.Stdout, &ti2) {
		for _, p := range ti2.Paths.RuntimeLibraryPaths {
			if isDir(p) {
				unservedPathPresent = true
			}
		}
	}

	// The driver's vector shape with the unserved target substituted for the
	// native one, so the only difference from a real build is the target.
	link, linkOut, _ := runFixedRaw(tc.Swiftc, []string{
		"-swift-version", "6", "-O", "-target", unserved, "-sdk", h.presentedSDK(),
		"-module-name", "Sk_probe", "-no-color-diagnostics", "-v",
		filepath.Join(h.srcDir, "main.swift"), "-o", filepath.Join(h.stage, "unserved"),
	}, h.srcDir, h.cleanEnv())
	compileOnly, compileOnlyOut, _ := runFixedRaw(tc.Swiftc, []string{"-swift-version", "6", "-sdk", h.presentedSDK(), "-target", unserved, "-c", "-v",
		filepath.Join(h.srcDir, "main.swift"), "-o", filepath.Join(h.stage, "unserved.o")}, h.srcDir, h.cleanEnv())
	frontendJobsLinking := strings.Count(linkOut, "swift-frontend -frontend")
	frontendJobsCompileOnly := strings.Count(compileOnlyOut, "swift-frontend -frontend")

	return []Structural{
		{
			ID:       "S11-representability-is-not-admission",
			Title:    "a target the compiler can name is not a target its standard library serves",
			Expected: "-print-target-info exits 0 for the unserved target and names a runtime library directory that does not exist; an unknown triple exits non-zero",
			Observed: fmt.Sprintf("unserved exit=%d runtime dir present=%v; unknown exit=%d", ti.Exit, unservedPathPresent, tiUnknown.Exit),
			Verdict:  verdict(ti.Exit == 0 && !unservedPathPresent && tiUnknown.Exit != 0),
			ManagerObligation: "Admission is a manager-side stat of the runtimeLibraryPaths entry inside the fingerprinted " +
				"root, in Stage A, before source acquisition. -print-target-info is a representability surface and must not be the gate.",
			Runs: []RunRecord{ti, tiUnknown},
		},
		{
			ID:       "S12-unserved-target-fails-before-any-frontend",
			Title:    "under the linking vector the unserved target is refused at job planning, not by a compiler child",
			Expected: "the linking vector spawns 0 frontend jobs; the compile-only vector spawns at least 1",
			Observed: fmt.Sprintf("linking exit=%d frontend jobs=%d (%s); compile-only exit=%d frontend jobs=%d", link.Exit, frontendJobsLinking, firstErrorLine(link.Stdout+"\n"+link.Stderr), compileOnly.Exit, frontendJobsCompileOnly),
			Verdict:  verdict(link.Exit != 0 && frontendJobsLinking == 0 && compileOnly.Exit != 0 && frontendJobsCompileOnly > 0),
			ManagerObligation: "TASK-260729-rhjxtx measured a frontend job for this target with a compile-only vector, and " +
				"that reproduces here. This driver's vector links, and under it the refusal arrives earlier. Both facts are true; " +
				"the vector is what separates them.",
			Runs: []RunRecord{link, compileOnly},
		},
	}
}

func artifactChecks(h *harness, pinned RunRecord) []Structural {
	tc := h.tc
	art := filepath.Join(h.stage, "pinned")
	fileOut := runFixed("/usr/bin/file", []string{art}, h.stage, h.cleanEnv())
	otool := runFixed("/usr/bin/otool", []string{"-L", art}, h.stage, h.cleanEnv())
	sign := runFixed("/usr/bin/codesign", []string{"-dvv", art}, h.stage, h.cleanEnv())
	runArt := runFixed(art, nil, h.stage, h.cleanEnv())

	baseOnly := true
	for _, l := range strings.Split(otool.Stdout, "\n")[1:] {
		l = strings.TrimSpace(l)
		if l == "" {
			continue
		}
		p := strings.SplitN(l, " ", 2)[0]
		if !strings.HasPrefix(p, "/usr/lib/") && !strings.HasPrefix(p, "/System/Library/") {
			baseOnly = false
		}
	}

	// Determinism for a fixed output path.
	same := filepath.Join(h.stage, "determinism")
	srcs := h.defaultSources()
	d1 := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), same, nil, srcs), h.srcDir, h.cleanEnv())
	h1 := sha256File(same)
	d2 := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), same, nil, srcs), h.srcDir, h.cleanEnv())
	h2 := sha256File(same)

	// A different output path, to name the one input that does move the bytes.
	other := filepath.Join(h.stage, "determinism-other-path")
	_ = runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), other, nil, srcs), h.srcDir, h.cleanEnv())
	h3 := sha256File(other)

	// .swift-version next to the sources.
	svDir := filepath.Join(h.base, "swift-version")
	_ = os.MkdirAll(svDir, 0o755)
	copyFile(filepath.Join(h.srcDir, "main.swift"), filepath.Join(svDir, "main.swift"))
	copyFile(filepath.Join(h.srcDir, "helper.swift"), filepath.Join(svDir, "helper.swift"))
	_ = os.WriteFile(filepath.Join(svDir, ".swift-version"), []byte("5.9.9-nonexistent\n"), 0o644)
	sv := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "sv"), nil,
		[]string{filepath.Join(svDir, "main.swift"), filepath.Join(svDir, "helper.swift")}), svDir, h.cleanEnv())

	srcEntries, _ := os.ReadDir(h.srcDir)

	return []Structural{
		{
			ID:       "S13-artifact-class",
			Title:    "the produced file is one native executable depending only on base-installation libraries",
			Expected: "Mach-O executable, dynamic dependencies all under /usr/lib or /System/Library, adhoc linker-signed, runs",
			Observed: fmt.Sprintf("file=%q base-installation-only=%v signed=%v run exit=%d", clipTo(strings.TrimSpace(fileOut.Stdout), 90), baseOnly, strings.Contains(sign.Stderr, "adhoc"), runArt.Exit),
			Verdict:  verdict(pinned.Exit == 0 && baseOnly && runArt.Exit == 0 && strings.Contains(fileOut.Stdout, "Mach-O")),
			ManagerObligation: "The signature is applied by the linker as part of linking. The manager performs no signing " +
				"step, selects no identity and never executes the artifact; this probe runs it only to record that it is a program.",
			Runs: []RunRecord{fileOut, otool, sign},
		},
		{
			ID:       "S14-output-path-is-the-only-moving-input",
			Title:    "two compiles of the same sources to the same path are byte-identical",
			Expected: "identical digests for a fixed output path, and a different digest when only the output path changes",
			Observed: fmt.Sprintf("run1=%s run2=%s other-path=%s", short(h1), short(h2), short(h3)),
			Verdict:  verdict(d1.Exit == 0 && d2.Exit == 0 && h1 != "" && h1 == h2 && h3 != h1),
			ManagerObligation: "Cache identity stays input-keyed. This is not a reproducible-build claim: the output path " +
				"reaches the Mach-O UUID, so a manager that varied its staging path would vary the bytes.",
			Runs: []RunRecord{d1, d2},
		},
		{
			ID:       "S15-swift-version-file-is-inert",
			Title:    "a .swift-version file beside the sources changes nothing for a directly resolved toolchain",
			Expected: "exit 0 with the file present",
			Observed: fmt.Sprintf("exit %d", sv.Exit),
			Verdict:  verdict(sv.Exit == 0),
			ManagerObligation: "The file is honoured by a version manager shim, which decision 0007 forbids resolving " +
				"through. That is what admits it as compared rather than forbidden.",
			Runs: []RunRecord{sv},
		},
		{
			ID:       "S16-compile-writes-nothing-into-the-source-tree",
			Title:    "the compile phase leaves the frozen source directory unchanged",
			Expected: "exactly the two source files remain",
			Observed: fmt.Sprintf("%d entries", len(srcEntries)),
			Verdict:  verdict(len(srcEntries) == 2),
			ManagerObligation: "Every product goes to the operation-private staging path named by -o. No lock file, no " +
				"build directory and no module cache is written beside the sources.",
			Runs: nil,
		},
	}
}

func exists(p string) bool { _, err := os.Stat(p); return err == nil }

func firstErrorLine(s string) string {
	for _, l := range strings.Split(s, "\n") {
		if strings.Contains(l, "error") {
			return clipTo(strings.TrimSpace(l), 160)
		}
	}
	return ""
}

func clipTo(s string, n int) string {
	if len(s) > n {
		return s[:n] + "…"
	}
	return s
}

func short(h string) string {
	if len(h) > 16 {
		return h[:16]
	}
	return h
}

func copyFile(src, dst string) {
	b, err := os.ReadFile(src)
	if err == nil {
		_ = os.WriteFile(dst, b, 0o644)
	}
}
