package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ---------------------------------------------------------------------------
// Cycle 4. Two findings, both about the SHAPE of the session rather than about
// a mechanism that did not work.
//
// F1 — accepted decision 0008 section 7 closes a manager-worker-v2 session to at
// most one graph command and EXACTLY ONE compile command, with the tool
// executables started by the driver's own trusted launcher. Cycle 3 executed the
// plan's 2-3 jobs directly from the manager while still binding
// execution_policy=manager-worker-v2. The session shape is restored here: the
// manager starts exactly two processes, `swiftc -###` and `swiftc`, and swiftc
// starts its own frontend, clang and ld children.
//
// F2 — with compile_argv executed again, the injected plugin channel is back in
// the frontend jobs, so the macro surface must be closed at the only other end:
// the source bytes, before anything is executed at all. That is
// curator-swift-source-admission-v1 in sourceadmission.go.
//
// S54-S64 measure both.
// ---------------------------------------------------------------------------

// BuildOutcome is one whole driver session: Stage-B source admission, then the
// graph command, then plan verification, then the permit-time re-binding, then
// the single compile command. The Commands slice is the exact list of processes
// the MANAGER started, which is what decision 0008 section 7 bounds.
type BuildOutcome struct {
	Admission  SourceAdmission
	Commands   []RunRecord
	Verify     PlanResult
	Plan       string
	Rejected   bool
	Class      string
	Diagnostic string
	Artifact   string

	// Cycle 5. Reverified records that the permit-time re-check actually ran in
	// THIS session, Rebound how many bindings it re-examined, and Permit the
	// findings that withheld the permit. The reviewer's cycle-5 finding was that
	// the mechanism existed and the session did not call it, so the session now
	// reports the call rather than leaving it to be inferred.
	Reverified bool
	Rebound    int
	Permit     []string
}

// ManagerCommands is the cardinality decision 0008 closes: 1 graph + 1 compile.
func (b BuildOutcome) ManagerCommands() int { return len(b.Commands) }

// CompileRan reports whether a compile permit was granted and used.
func (b BuildOutcome) CompileRan() bool { return len(b.Commands) == 2 }

// Stable Swift details beneath build_execution_control_unavailable.
const (
	DiagPlanTokenUnclaimed = "swift_plan_token_unclaimed"
	DiagPermitBinding      = "swift_permit_binding_changed"
)

// sessionSpec parameterises one session. Every field that is not set falls back
// to the contract session, so the adversarial cases differ from the happy path
// by exactly the thing under test and nothing else.
type sessionSpec struct {
	sources []string
	dir     string
	out     string
	extra   []string

	// swiftc overrides the program for BOTH commands. It is set only by the
	// synthetic-toolchain cases, whose whole purpose is a mutable executable
	// binding; the real toolchain is read-only host state.
	swiftc string
	// policy overrides the plan policy, for the same reason.
	policy *PlanPolicy

	// admit is the Stage-B rule; C13 restores the retired one.
	admit func([]string) SourceAdmission

	// mutate runs after plan verification and before the permit-time re-check.
	// This is the adversary: the graph phase has already accepted everything.
	mutate func()

	// observe runs at the same point, after mutate, and reads the outcome
	// without changing it. It exists so a check can measure something AT the
	// permit — the compile command has not started, and nothing it produces has
	// yet touched a binding.
	observe func(BuildOutcome)

	// skipReverify restores the retired cycle-4 session, which went straight
	// from VerifyPlan to compile_argv. Expected-red control C16 uses it.
	skipReverify bool
}

// session is the contract session: the whole pipeline for one source set with a
// pluggable Stage-B rule, so expected-red control C13 can restore the retired
// one. It is runSession with no adversary and no override.
func (h *harness) session(sources []string, dir, out string, extra []string,
	admit func([]string) SourceAdmission) BuildOutcome {
	return h.runSession(sessionSpec{sources: sources, dir: dir, out: out, extra: extra, admit: admit})
}

// runSession is the ONE authoritative session. Its order is normative:
//
//  1. AdmitSources         — Stage B, before any process
//  2. swiftc -###          — manager command 1 of 2, read-only
//  3. VerifyPlan           — the closed grammar over every token
//  4. Reverify + ReverifyAdmittedSources  — the compile permit
//  5. swiftc compile_argv  — manager command 2 of 2
//
// Step 4 is what cycle 5 adds to the session. A finding at step 4 leaves exactly
// ONE manager-started command, no compile child and no artifact.
func (h *harness) runSession(s sessionSpec) BuildOutcome {
	swiftc := s.swiftc
	if swiftc == "" {
		swiftc = h.tc.Swiftc
	}
	admit := s.admit
	if admit == nil {
		admit = AdmitSources
	}
	b := BuildOutcome{Artifact: s.out}

	// Stage B, before anything is executed.
	b.Admission = admit(s.sources)
	if !b.Admission.OK() {
		b.Rejected = true
		b.Class = b.Admission.Class()
		b.Diagnostic = b.Admission.Diagnostic()
		return b
	}

	// Command 1 of 2 — the read-only graph phase.
	graph, planOut, _ := runFixedRaw(swiftc, h.graphVector(h.presentedSDK(), s.out, s.extra, s.sources), s.dir, h.cleanEnv())
	b.Commands = append(b.Commands, graph)
	b.Plan = planOut

	pol := h.policy(s.sources)
	if s.policy != nil {
		pol = *s.policy
		pol.Sources = s.sources
	}
	pol.WorkingDir = s.dir
	b.Verify = VerifyPlan(planOut, pol)
	if graph.Exit != 0 || !b.Verify.OK() {
		b.Rejected = true
		b.Class = "build_execution_control_unavailable"
		b.Diagnostic = DiagPlanTokenUnclaimed
		return b
	}

	// The adversary acts here, with everything already verified.
	if s.mutate != nil {
		s.mutate()
	}
	if s.observe != nil {
		s.observe(b)
	}

	// The compile permit. Every executable, plugin, search, SDK, source and
	// output binding is re-resolved and re-identified, and every admitted source
	// is re-read, immediately before the compile child starts.
	if !s.skipReverify {
		b.Reverified = true
		b.Rebound = len(b.Verify.Bindings) + len(b.Admission.Admitted)
		b.Permit = append(append([]string{}, Reverify(b.Verify.Bindings)...),
			ReverifyAdmittedSources(b.Admission)...)
		if len(b.Permit) > 0 {
			b.Rejected = true
			b.Class = "build_execution_control_unavailable"
			b.Diagnostic = DiagPermitBinding
			return b
		}
	}

	// Command 2 of 2 — the single compile command. swiftc starts its own
	// frontend/clang/ld children; the manager starts nothing else.
	compile := runFixed(swiftc, h.compileVector(h.presentedSDK(), s.out, s.extra, s.sources), s.dir, h.cleanEnv())
	b.Commands = append(b.Commands, compile)
	if compile.Exit != 0 {
		b.Rejected = true
		b.Class = "build_compile_failed"
		b.Diagnostic = firstErrorLine(compile.Stderr)
	}
	return b
}

// macroLoadRemarks counts the frontend's own report of a macro implementation
// being loaded. -Rmacro-loading is an EVIDENCE flag only: it is not a member of
// either contract vector, and it is passed here so the probe can distinguish
// "nothing loaded" from "nothing reported".
const macroLoadRemark = "loaded macro implementation module"

func remarkFlags() []string { return []string{"-Xfrontend", "-Rmacro-loading"} }

func countRemarks(recs ...RunRecord) int {
	n := 0
	for _, r := range recs {
		n += strings.Count(r.Stderr, macroLoadRemark)
	}
	return n
}

// predicateSource is the freestanding-macro half of the surface: `#Predicate`
// needs 0x23 where `@Observable` needs 0x40.
const predicateSource = "import Foundation\nlet ns = [1, 2, 3]\nlet p = #Predicate<Int> { $0 > 1 }\nprint((try? ns.filter { try p.evaluate($0) })?.count ?? -1)\n"

func sourceAdmissionChecks(h *harness) []Structural {
	tc := h.tc
	var out []Structural

	// ---- S54: the rule is a total byte scan over the whole source set -------
	richDir, richPath := h.writeSource("c4-rich", richSource)
	adm := AdmitSources([]string{richPath})
	richBytes, _ := os.ReadFile(richPath)
	out = append(out, Structural{
		ID:       "S54-source-admission-scans-every-byte",
		Title:    "curator-swift-source-admission-v1 reads every byte of every compiled source and admits ordinary Swift",
		Expected: "the whole file scanned and admitted, with no 0x40 and no 0x23 present",
		Observed: fmt.Sprintf("files=%d bytes_scanned=%d file_size=%d at=%d hash=%d admitted=%v",
			adm.Files, adm.BytesScanned, len(richBytes),
			strings.Count(string(richBytes), "@"), strings.Count(string(richBytes), "#"), adm.OK()),
		Verdict: verdict(adm.OK() && adm.BytesScanned == len(richBytes) && len(richBytes) > 0),
		ManagerObligation: "The scan is byte-total: it does not parse Swift, skip comments or skip string literals. " +
			"Foundation, Codable, a bare regex literal, string interpolation, actors and async/await carry neither byte " +
			"and stay admitted.",
	})

	// ---- S55 / S56: both macro spellings are rejected BEFORE any process ----
	obsDir, obsPath := h.writeSource("c4-macro-attached", macroSource)
	obsOut := h.session([]string{obsPath}, obsDir, filepath.Join(h.stage, "c4-obs"), nil, AdmitSources)
	out = append(out, Structural{
		ID:       "S55-attached-macro-source-is-rejected-before-any-command",
		Title:    "@Observable is rejected at Stage B with zero manager-started commands",
		Expected: "rejected, class build_package_code_execution_forbidden, 0 commands started, 0 artifacts",
		Observed: fmt.Sprintf("rejected=%v class=%s diagnostic=%s offset=%d byte=0x%02X commands=%d artifact_exists=%v",
			obsOut.Rejected, obsOut.Class, obsOut.Diagnostic,
			firstRejOffset(obsOut.Admission), firstRejByte(obsOut.Admission),
			obsOut.ManagerCommands(), exists(obsOut.Artifact)),
		Verdict: verdict(obsOut.Rejected && obsOut.Class == "build_package_code_execution_forbidden" &&
			obsOut.Diagnostic == DiagSourceMacroSelctor && obsOut.ManagerCommands() == 0 && !exists(obsOut.Artifact)),
		ManagerObligation: "This is the Stage-B rejection decision 0008 section 7 requires. The graph phase never runs, " +
			"so no compile permit is reachable and no compile child parses the attribute.",
	})

	predDir, predPath := h.writeSource("c4-macro-freestanding", predicateSource)
	predOut := h.session([]string{predPath}, predDir, filepath.Join(h.stage, "c4-pred"), nil, AdmitSources)
	out = append(out, Structural{
		ID:       "S56-freestanding-macro-source-is-rejected-before-any-command",
		Title:    "#Predicate is rejected at Stage B with zero manager-started commands",
		Expected: "rejected on byte 0x23, 0 commands started",
		Observed: fmt.Sprintf("rejected=%v class=%s diagnostic=%s byte=0x%02X commands=%d",
			predOut.Rejected, predOut.Class, predOut.Diagnostic, firstRejByte(predOut.Admission), predOut.ManagerCommands()),
		Verdict: verdict(predOut.Rejected && predOut.Diagnostic == DiagSourceMacroSelctor &&
			firstRejByte(predOut.Admission) == 0x23 && predOut.ManagerCommands() == 0),
		ManagerObligation: "Both macro roles are covered by one rule: an attached macro is spelled with 0x40 and a " +
			"freestanding one with 0x23, and the scan does not care which.",
	})

	// ---- S57: the COMPILER states the sigil requirement -----------------------
	// This is the measurement the rule rests on. It is not the probe asserting
	// the Swift grammar; it is swiftc refusing to expand a macro without '#' and
	// refusing to declare one without '@'.
	noSigilDir, noSigilPath := h.writeSource("c4-no-sigil", "let x = externalMacro(module: \"A\", type: \"B\")\nprint(x)\n")
	noSigil := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-nosigil"), nil, []string{noSigilPath}), noSigilDir, h.cleanEnv())
	noRoleDir, noRolePath := h.writeSource("c4-no-role", "macro stringify<T>(_ v: T) -> (T, String) = "+string23()+"externalMacro(module: \"M\", type: \"S\")\nprint(1)\n")
	noRole := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-norole"), nil, []string{noRolePath}), noRoleDir, h.cleanEnv())
	needsHash := strings.Contains(noSigil.Stderr, "requires leading '#'")
	needsAt := strings.Contains(noRole.Stderr, "'@freestanding' or '@attached'")
	out = append(out, Structural{
		ID:       "S57-the-compiler-requires-the-two-sigils",
		Title:    "swiftc itself states that a macro expansion needs '#' and a macro declaration needs '@'",
		Expected: "both diagnostics present, both compiles non-zero",
		Observed: fmt.Sprintf("no-sigil exit=%d requires-hash=%v; no-role exit=%d requires-at=%v",
			noSigil.Exit, needsHash, noRole.Exit, needsAt),
		Verdict: verdict(noSigil.Exit != 0 && needsHash && noRole.Exit != 0 && needsAt),
		ManagerObligation: "The completeness of the byte rule is measured rather than argued from the grammar: the " +
			"compiler refuses to expand a macro without a leading 0x23 and refuses to declare one without a 0x40 role " +
			"attribute, so no macro reaches the compiler from a source set carrying neither byte.",
		Runs: []RunRecord{noSigil, noRole},
	})

	// ---- S58: no homoglyph, escape or bare-name channel to the sigil --------
	homoDir, homoPath := h.writeSource("c4-homoglyph", "import Observation\n\uFF20Observable final class Box { var n: Int = 0 }\nprint(Box().n)\n")
	homo := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-homo"), nil, []string{homoPath}), homoDir, h.cleanEnv())
	escDir, escPath := h.writeSource("c4-escape", "import Observation\n\\u{40}Observable final class Box { var n: Int = 0 }\nprint(Box().n)\n")
	esc := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-esc"), nil, []string{escPath}), escDir, h.cleanEnv())
	bareDir, barePath := h.writeSource("c4-bare-attr", "import Observation\nObservable final class Box { var n: Int = 0 }\nprint(Box().n)\n")
	bare := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-bare"), nil, []string{barePath}), bareDir, h.cleanEnv())
	homoAdm := AdmitSources([]string{homoPath})
	out = append(out, Structural{
		ID:       "S58-no-alternative-spelling-reaches-the-attribute-grammar",
		Title:    "a fullwidth homoglyph, a Unicode escape and a bare attribute name are all not attributes",
		Expected: "all three fail to compile, and the homoglyph file is admitted by the byte rule because it is not a macro",
		Observed: fmt.Sprintf("homoglyph exit=%d admitted_by_rule=%v; escape exit=%d; bare-name exit=%d",
			homo.Exit, homoAdm.OK(), esc.Exit, bare.Exit),
		Verdict: verdict(homo.Exit != 0 && esc.Exit != 0 && bare.Exit != 0 && homoAdm.OK()),
		ManagerObligation: "The attribute marker is exactly U+0040 and the expansion marker exactly U+0023. The " +
			"homoglyph file is deliberately ADMITTED by the rule and still cannot select a macro, which is the point: the " +
			"rule needs to cover the sigils, not every character that looks like one.",
		Runs: []RunRecord{homo, esc, bare},
	})

	// ---- S59: the encoding rule closes the smuggling channel the scan can't --
	overlongDir := filepath.Join(h.base, "c4-overlong")
	_ = os.MkdirAll(overlongDir, 0o755)
	overlongPath := filepath.Join(overlongDir, "main.swift")
	overlong := append([]byte("import Observation\n"), 0xC1, 0x80)
	overlong = append(overlong, []byte("Observable final class Box { var n: Int = 0 }\nprint(Box().n)\n")...)
	_ = os.WriteFile(overlongPath, overlong, 0o644)
	overAdm := AdmitSources([]string{overlongPath})
	overRun := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-overlong"), nil, []string{overlongPath}), overlongDir, h.cleanEnv())
	hasRawAt := false
	for _, c := range overlong {
		if c == 0x40 {
			hasRawAt = true
		}
	}
	out = append(out, Structural{
		ID:       "S59-encoding-rule-closes-the-overlong-smuggling-channel",
		Title:    "an overlong UTF-8 encoding of U+0040 carries no 0x40 byte and is rejected by the encoding rule",
		Expected: "no raw 0x40 in the file, rejected as encoding, and independently rejected by the compiler",
		Observed: fmt.Sprintf("raw_0x40_present=%v rule=%s diagnostic=%s offset=%d; compiler exit=%d invalid_utf8=%v",
			hasRawAt, firstRejRule(overAdm), overAdm.Diagnostic(), firstRejOffset(overAdm), overRun.Exit,
			strings.Contains(overRun.Stderr, "invalid UTF-8 found in source file")),
		Verdict: verdict(!hasRawAt && !overAdm.OK() && overAdm.Diagnostic() == DiagSourceEncoding &&
			overRun.Exit != 0 && strings.Contains(overRun.Stderr, "invalid UTF-8 found in source file")),
		ManagerObligation: "The selector scan claims `no 0x40 byte implies no U+0040 code point`, which only holds on " +
			"well-formed UTF-8. The encoding rule runs first so the claim is established rather than assumed, and the " +
			"manager does not have to trust the compiler to reject the malformed file.",
		Runs: []RunRecord{overRun},
	})

	// ---- S60: admitted source builds under exactly ONE compile command, and
	//           the injected plugin channel is inert for it --------------------
	richOut := filepath.Join(h.stage, "c4-rich-artifact")
	rich := h.session([]string{richPath}, richDir, richOut, nil, AdmitSources)
	ranArt := runFixed(richOut, nil, richDir, h.cleanEnv())
	// -Rmacro-loading is NOT a member of either contract vector — the closed
	// token grammar would reject the -Xfrontend pass-through that carries it —
	// so the remark measurement is a separate evidence-only compile of the same
	// source to a throwaway path. It reports whether anything was loaded; the
	// contract session above is what is verified.
	richRemarkRun := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), richOut+"-remark-evidence",
		remarkFlags(), []string{richPath}), richDir, h.cleanEnv())
	richRemarks := countRemarks(richRemarkRun)
	planPlugins := len(pluginPathsIn(rich.Plan))
	out = append(out, Structural{
		ID:       "S60-one-compile-command-builds-admitted-swift-with-nothing-loaded",
		Title:    "the admitted source set builds under exactly two manager-started commands and loads no macro implementation",
		Expected: "2 manager commands, plan carries plugin search paths, 0 load remarks, artifact runs",
		Observed: fmt.Sprintf("commands=%d verified=%v plugin components in plan=%d evidence compile exit=%d load remarks=%d artifact exit=%d out=%q",
			rich.ManagerCommands(), rich.Verify.OK(), planPlugins, richRemarkRun.Exit, richRemarks, ranArt.Exit,
			clipTo(strings.TrimSpace(ranArt.Stdout), 60)),
		Verdict: verdict(!rich.Rejected && rich.ManagerCommands() == 2 && rich.Verify.OK() &&
			planPlugins > 0 && richRemarkRun.Exit == 0 && richRemarks == 0 && ranArt.Exit == 0),
		ManagerObligation: "The plugin search paths are still in the plan — the manager cannot remove them without " +
			"executing the jobs itself, which manager-worker-v2 forbids. They are INERT, because nothing in an admitted " +
			"source set can name a macro. Closure and selection are two independent conditions and both are checked.",
		Runs: append(append([]RunRecord{}, rich.Commands...), richRemarkRun, ranArt),
	})

	// ---- S61: importing a macro-bearing module loads nothing ----------------
	impDir, impPath := h.writeSource("c4-import-only",
		"import Observation\nimport Foundation\nlet r = ObservationRegistrar()\nprint(type(of: r))\n")
	imp := h.session([]string{impPath}, impDir, filepath.Join(h.stage, "c4-import"), nil, AdmitSources)
	impRemarkRun := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-import-remark-evidence"),
		remarkFlags(), []string{impPath}), impDir, h.cleanEnv())
	impRemarks := countRemarks(impRemarkRun)
	out = append(out, Structural{
		ID:       "S61-importing-a-macro-bearing-module-loads-nothing",
		Title:    "import Observation without a macro use compiles with 0 load remarks",
		Expected: "admitted, 2 commands, exit 0, 0 load remarks",
		Observed: fmt.Sprintf("admitted=%v commands=%d rejected=%v evidence compile exit=%d load remarks=%d",
			imp.Admission.OK(), imp.ManagerCommands(), imp.Rejected, impRemarkRun.Exit, impRemarks),
		Verdict: verdict(imp.Admission.OK() && !imp.Rejected && imp.ManagerCommands() == 2 &&
			impRemarkRun.Exit == 0 && impRemarks == 0),
		ManagerObligation: "A macro-bearing module is a prebuilt .swiftmodule; its own macro expansion already happened " +
			"in the library build. Importing one is not a selection, so the driver does not have to reject imports to " +
			"close the surface.",
		Runs: append(append([]RunRecord{}, imp.Commands...), impRemarkRun),
	})

	// ---- S62: session cardinality, and what the retired design did ----------
	defSrcs := h.defaultSources()
	defOut := h.session(defSrcs, h.srcDir, filepath.Join(h.stage, "c4-default"), nil, AdmitSources)
	retiredJobs := 0
	if defOut.Verify.OK() {
		retiredJobs = len(StripPluginChannel(defOut.Verify.Jobs).Executed)
	}
	retiredTotal := 1 + retiredJobs
	out = append(out, Structural{
		ID:       "S62-manager-starts-exactly-one-graph-and-one-compile-command",
		Title:    "the session is the manager-worker-v2 shape: one graph command, one compile command, nothing else",
		Expected: "exactly 2 manager-started commands, against the retired design's 1 + plan-job count",
		Observed: fmt.Sprintf("this design: %d commands (%s); retired plan-execution design: 1 graph + %d plan jobs = %d commands",
			defOut.ManagerCommands(), strings.Join(commandNames(defOut.Commands), ", "), retiredJobs, retiredTotal),
		Verdict: verdict(defOut.ManagerCommands() == 2 && !defOut.Rejected && retiredJobs > 1 && retiredTotal > 2),
		ManagerObligation: "Decision 0008 section 7 admits at most one graph command and exactly one compile command, " +
			"with the tool executables started by the driver's own trusted launcher. Executing the plan's jobs from the " +
			"manager changes both the cardinality and the parentage, so it cannot be labelled manager-worker-v2.",
		Runs: defOut.Commands,
	})

	// ---- S63: both compile children are the driver, and the graph token is
	//           in exactly one of them --------------------------------------
	graphArgv := append([]string{tc.Swiftc}, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "c4-eq"), nil, defSrcs)...)
	compileArgv := append([]string{tc.Swiftc}, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c4-eq"), nil, defSrcs)...)
	insertOK := len(graphArgv) == len(compileArgv)+1 && graphArgv[0] == compileArgv[0] && graphArgv[1] == "-###"
	for i := range compileArgv[1:] {
		if graphArgv[i+2] != compileArgv[i+1] {
			insertOK = false
		}
	}
	graphCount, compileCount := 0, 0
	for _, t := range graphArgv {
		if t == "-###" {
			graphCount++
		}
	}
	for _, t := range compileArgv {
		if t == "-###" {
			compileCount++
		}
	}
	sameProgram := len(defOut.Commands) == 2 &&
		defOut.Commands[0].Argv[0] == tc.Swiftc && defOut.Commands[1].Argv[0] == tc.Swiftc
	out = append(out, Structural{
		ID:       "S63-both-commands-are-one-program-differing-by-one-inserted-token",
		Title:    "graph and compile are the same swiftc with -### inserted at index 1 exactly once",
		Expected: "same program, insertion at index 1, exactly once in graph, never in compile",
		Observed: fmt.Sprintf("same_program=%v insertion_ok=%v graph_hashhash=%d compile_hashhash=%d",
			sameProgram, insertOK, graphCount, compileCount),
		Verdict: verdict(sameProgram && insertOK && graphCount == 1 && compileCount == 0),
		ManagerObligation: "Both commands come from one builder, so the plan the manager verifies is the plan the one " +
			"compile command re-derives. Under manager-worker-v2 that is an equality of inputs rather than of processes; " +
			"section 11 of the reference states the residual honestly.",
	})

	// ---- S64: determinism under the single compile command -------------------
	detDir, detPath := h.writeSource("c4-determinism", "let n = 6 * 7\nprint(\"det \\(n)\")\n")
	detOut := filepath.Join(h.stage, "c4-det-artifact")
	var digests []string
	var detRuns []RunRecord
	for pass := 0; pass < 2; pass++ {
		s := h.session([]string{detPath}, detDir, detOut, nil, AdmitSources)
		detRuns = append(detRuns, s.Commands...)
		digests = append(digests, sha256File(detOut))
	}
	out = append(out, Structural{
		ID:       "S64-two-sessions-to-one-output-path-are-byte-identical",
		Title:    "the restored single-compile-command session is deterministic for a fixed output path",
		Expected: "one distinct digest across two full sessions",
		Observed: fmt.Sprintf("%d distinct digests over %d commands", len(distinct(digests)), len(detRuns)),
		Verdict:  verdict(len(digests) == 2 && digests[0] != "" && len(distinct(digests)) == 1 && len(detRuns) == 4),
		ManagerObligation: "Restoring compile_argv does not cost determinism: the per-run intermediate directory swiftc " +
			"creates for itself never reaches the artifact, exactly as S14 measures for the compile command alone.",
		Runs: detRuns,
	})

	return out
}

func commandNames(recs []RunRecord) []string {
	var out []string
	for _, r := range recs {
		if len(r.Argv) == 0 {
			continue
		}
		name := filepath.Base(r.Argv[0])
		if len(r.Argv) > 1 && r.Argv[1] == "-###" {
			name += " -###"
		}
		out = append(out, name)
	}
	return out
}

func firstRejOffset(a SourceAdmission) int {
	if a.OK() {
		return -1
	}
	return a.Rejections[0].Offset
}

func firstRejByte(a SourceAdmission) int {
	if a.OK() {
		return -1
	}
	return a.Rejections[0].Byte
}

func firstRejRule(a SourceAdmission) string {
	if a.OK() {
		return ""
	}
	return a.Rejections[0].Rule
}

// string23 builds a literal "#" without writing one, so that this probe's own
// Go sources stay searchable for stray sigils in the Swift fixtures.
func string23() string { return string(rune(0x23)) }
