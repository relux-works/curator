package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ---------------------------------------------------------------------------
// Cycle 5. One finding, and it is not that a mechanism was missing.
//
// Reference 4.1.4 and decision 0011 section 4 require the manager, immediately
// before starting compile_argv, to re-resolve and re-identify every verified
// binding and to confirm that every plugin path verified absent is still absent.
// The mechanism existed and was exercised in isolation by S20/S21. The SESSION
// went straight from VerifyPlan to compile_argv, so the contract's stronger
// statement — that command 2 received a permit AFTER re-verification — was not
// demonstrated by anything the probe ran.
//
// Two defects came with integrating it, both found by the reviewer reading the
// code rather than by a failing check:
//
//   - a not-yet-created output recorded its operation-private PARENT's identity
//     but kept the absent final path as the thing to re-resolve, so integrating
//     the function unchanged would have rejected every valid happy path;
//   - an absent plugin path treated ANY Lstat error as continued absence, and a
//     permission or I/O error is not evidence of absence.
//
// S65-S72 exercise the repaired permit inside the one authoritative session.
// Every adversarial case acts AFTER plan verification has already succeeded, and
// every one of them asserts the same three things: exactly one manager-started
// command, no compile child, no artifact.
// ---------------------------------------------------------------------------

// permitCtx is what one adversarial case gets to work with: the harness, a dry
// run of the same session, and the exact paths that session used. The mutation
// is chosen from bindings the graph phase really produced, so a case attacks a
// real binding rather than a guessed path.
type permitCtx struct {
	h      *harness
	dry    BuildOutcome
	srcs   []string
	outDir string
	out    string
}

// permitCase is one adversary. prepare returns the mutation applied between
// VerifyPlan and the permit, and the undo that puts shared harness state back —
// a case that creates a plugin path must remove it again, or every later session
// verifies a different world.
//
// expect is the substring one of the findings must carry. Without it a case
// would pass on ANY permit finding, which is how a check ends up proving that
// something went wrong rather than that the right thing was detected.
type permitCase struct {
	id      string
	title   string
	what    string
	expect  string
	prepare func(permitCtx) (mutate func(), undo func())
}

func permitBindingChecks(h *harness) []Structural {
	var out []Structural

	// ---- S65: the happy path reaches two commands only after the permit -----
	//
	// This is the check the cycle-5 reviewer asked for first: not that the
	// session runs two commands, but that the second one is reached THROUGH the
	// re-binding step.
	happyDir := filepath.Join(h.stage, "c5-happy")
	_ = os.RemoveAll(happyDir)
	_ = os.MkdirAll(happyDir, 0o755)
	happyOut := filepath.Join(happyDir, "artifact")
	happy := h.runSession(sessionSpec{sources: h.defaultSources(), dir: h.srcDir, out: happyOut})
	absentPlugins := 0
	for _, b := range happy.Verify.Bindings {
		if b.Bucket == BucketPlugin && !b.Present {
			absentPlugins++
		}
	}
	// The output binding is the one the reviewer said could not survive
	// integration: it is bound while the file does not exist, so the path whose
	// identity was recorded and the raw token must differ.
	parentBound := 0
	for _, b := range happy.Verify.Bindings {
		if b.Bucket == BucketOutput && b.Checked != b.Raw {
			parentBound++
		}
	}
	out = append(out, Structural{
		ID:       "S65-the-compile-permit-is-reached-through-permit-time-rebinding",
		Title:    "the session re-verifies every binding immediately before the single compile command, and only then runs it",
		Expected: "reverify ran over every plan binding and every admitted source, 0 findings, 2 manager commands, artifact produced, at least one absent-output binding re-checked at its parent",
		Observed: fmt.Sprintf("reverified=%v rebound=%d permit_findings=%d plan_bindings=%d admitted_sources=%d absent_plugins=%d parent_bound_outputs=%d commands=%d artifact=%v",
			happy.Reverified, happy.Rebound, len(happy.Permit), len(happy.Verify.Bindings), len(happy.Admission.Admitted),
			absentPlugins, parentBound, happy.ManagerCommands(), exists(happy.Artifact)),
		Verdict: verdict(happy.Reverified && len(happy.Permit) == 0 && !happy.Rejected &&
			happy.ManagerCommands() == 2 && exists(happy.Artifact) &&
			happy.Rebound == len(happy.Verify.Bindings)+len(happy.Admission.Admitted) &&
			len(happy.Admission.Admitted) == len(h.defaultSources()) &&
			absentPlugins > 0 && parentBound > 0),
		ManagerObligation: "Reference 4.1.4 is a step in the session, not a function that exists. The permit re-resolves and " +
			"re-identifies every plan binding, re-reads every Stage-B admitted source, and requires every absent plugin path " +
			"to still be absent. A not-yet-created output is re-checked at the operation-private parent whose identity was " +
			"actually recorded, which is why the ordinary happy path survives the check.",
		Runs: happy.Commands,
	})

	// ---- S66 .. S70: the adversarial cases, all inside the session ----------
	for _, pc := range []permitCase{
		{
			id:     "S66-absent-plugin-path-that-appears-after-graph-withholds-the-permit",
			title:  "a plugin path verified absent at graph time and created before the permit stops the session at one command",
			what:   "an absent plugin path appears",
			expect: "was absent at graph time and exists at permit time",
			prepare: func(c permitCtx) (func(), func()) {
				// Only a manager-owned path is a candidate: the absent plugin
				// paths inside the real toolchain root are host state this task
				// does not create, and never will.
				target := ""
				for _, bd := range c.dry.Verify.Bindings {
					if bd.Bucket == BucketPlugin && !bd.Present && strings.HasPrefix(bd.Raw, c.h.base) {
						target = bd.Raw
						break
					}
				}
				return func() {
						if target != "" {
							_ = os.MkdirAll(target, 0o755)
						}
					}, func() {
						if target != "" {
							_ = os.RemoveAll(target)
						}
					}
			},
		},
		{
			id:     "S67-source-byte-change-after-stage-b-withholds-the-permit",
			title:  "a compiled source whose bytes change after Stage B — introducing '@' — stops the session at one command",
			what:   "an admitted source gains a macro selector after Stage B",
			expect: DiagSourceMacroSelctor,
			prepare: func(c permitCtx) (func(), func()) {
				target := c.srcs[len(c.srcs)-1]
				return func() {
					// The change is deliberately a sigil: this is the byte the
					// Stage-B rule would have rejected and cannot see again on
					// its own once the file has been scanned.
					_ = os.WriteFile(target, []byte("import Observation\n@Observable final class Late { var n = 0 }\n"), 0o644)
				}, func() {}
			},
		},
		{
			id:     "S68-source-replacement-after-graph-withholds-the-permit",
			title:  "a compiled source re-pointed to different bytes after graph verification stops the session at one command",
			what:   "an admitted source is replaced while keeping its path",
			expect: "changed between Stage B and the permit",
			prepare: func(c permitCtx) (func(), func()) {
				target := c.srcs[0]
				return func() {
					// Replaced through a rename, so the path names a different
					// file rather than being written in place: the enumeration
					// and time-of-check/time-of-use shape.
					repl := target + ".replacement"
					_ = os.WriteFile(repl, []byte("import Foundation\nlet v = helperValue()\nprint(\"other \\(v)\")\n"), 0o644)
					_ = os.Rename(repl, target)
				}, func() {}
			},
		},
		{
			id:     "S69-sdk-presentation-repoint-after-graph-withholds-the-permit",
			title:  "re-pointing the presented SDK between graph and permit stops the session at one command",
			what:   "a search/SDK binding resolves somewhere else",
			expect: "at graph time and",
			prepare: func(c permitCtx) (func(), func()) {
				link := c.h.presentedSDK()
				decoy := filepath.Join(c.h.base, "c5-decoy-sdk")
				return func() {
						_ = os.MkdirAll(decoy, 0o755)
						_ = os.Remove(link)
						_ = os.Symlink(decoy, link)
					}, func() {
						c.h.restorePresentedSDK()
					}
			},
		},
		{
			id:     "S70-output-parent-repoint-after-graph-withholds-the-permit",
			title:  "replacing the operation-private parent of the not-yet-created output stops the session at one command",
			what:   "the output's recorded parent is replaced",
			expect: "changed identity between graph and permit",
			prepare: func(c permitCtx) (func(), func()) {
				return func() {
					// Same path, different inode. This is the binding the
					// reviewer said the retired re-check could not express: the
					// artifact does not exist yet, so what was identified is the
					// directory, and that is what has to be re-checked.
					_ = os.RemoveAll(c.outDir)
					_ = os.MkdirAll(c.outDir, 0o755)
				}, func() {}
			},
		},
	} {
		out = append(out, h.permitCaseCheck(pc))
	}

	// ---- S71: an executable binding that changes, inside a session ----------
	out = append(out, h.syntheticExecutableCheck())

	// ---- S72: the retired re-check could not have been integrated -----------
	//
	// Both defects are reported from the SAME bindings the live session
	// produced, so this is a measurement of the two functions' disagreement
	// rather than a restatement of the review.
	cmpDir := filepath.Join(h.stage, "c5-retired-compare")
	_ = os.RemoveAll(cmpDir)
	_ = os.MkdirAll(cmpDir, 0o755)
	// Both functions are called AT the permit, on the same bindings, in the same
	// moment. Measuring after the session would compare them against a world the
	// compile command has already changed — measured: the graph command's own
	// intermediate directory does not survive the compile command, so a
	// post-session re-check finds a difference that has nothing to do with either
	// function.
	var liveFindings, retiredFindings []string
	cmp := h.runSession(sessionSpec{sources: h.defaultSources(), dir: h.srcDir, out: filepath.Join(cmpDir, "artifact"),
		observe: func(b BuildOutcome) {
			liveFindings = Reverify(b.Verify.Bindings)
			retiredFindings = ReverifyRetired(b.Verify.Bindings)
		}})
	// The absent-plugin branch: a path whose state cannot be established at all.
	denied := filepath.Join(h.base, "c5-denied")
	_ = os.RemoveAll(denied)
	_ = os.MkdirAll(filepath.Join(denied, "inner"), 0o755)
	deniedPlugin := filepath.Join(denied, "inner", "plugins")
	absentBinding := []PlanBinding{{Bucket: BucketPlugin, Raw: deniedPlugin, Checked: deniedPlugin, Present: false}}
	_ = os.Chmod(denied, 0o000)
	liveDenied := Reverify(absentBinding)
	retiredDenied := ReverifyRetired(absentBinding)
	_ = os.Chmod(denied, 0o755)
	out = append(out, Structural{
		ID:       "S72-the-retired-permit-check-rejects-the-happy-path-and-admits-an-unknowable-absence",
		Title:    "the two repairs are measured against the retired function on the same bindings",
		Expected: "live 0 findings on the happy path where the retired one reports the absent output; live fails closed on a non-ENOENT plugin error where the retired one reports nothing",
		Observed: fmt.Sprintf("happy path: live=%d retired=%d %q; unreadable absent plugin: live=%d retired=%d",
			len(liveFindings), len(retiredFindings), clipTo(strings.Join(retiredFindings, "; "), 200),
			len(liveDenied), len(retiredDenied)),
		Verdict: verdict(cmp.Reverified && !cmp.Rejected && len(liveFindings) == 0 && len(retiredFindings) > 0 &&
			len(liveDenied) == 1 && len(retiredDenied) == 0),
		ManagerObligation: "A binding records the path whose identity was established, and the permit re-checks that path. An " +
			"absent plugin path is still absent only when the re-check says ENOENT; every other error is a finding, because " +
			"it is not evidence of absence.",
	})

	return out
}

// permitCaseCheck runs one adversarial case: a full contract session whose only
// difference from the happy path is a mutation applied after plan verification.
// Each one asserts the same postcondition, because that is the postcondition the
// contract states.
func (h *harness) permitCaseCheck(pc permitCase) Structural {
	tag := shortID(pc.id)
	srcDir := filepath.Join(h.base, "c5-"+tag)
	_ = os.RemoveAll(srcDir)
	_ = os.MkdirAll(srcDir, 0o755)
	// Each case gets its own copy of the source set and its own output
	// directory, so a mutation is local to the case and the next one starts from
	// an unmodified tree.
	var srcs []string
	for _, s := range h.defaultSources() {
		dst := filepath.Join(srcDir, filepath.Base(s))
		copyFile(s, dst)
		srcs = append(srcs, dst)
	}
	outDir := filepath.Join(h.stage, "c5-"+tag)
	_ = os.RemoveAll(outDir)
	_ = os.MkdirAll(outDir, 0o755)
	out := filepath.Join(outDir, "artifact")

	// Dry run first, so the mutation is chosen from bindings a real graph phase
	// produced. It must reach two commands; a case whose control run is already
	// rejected proves nothing about the permit.
	dry := h.runSession(sessionSpec{sources: srcs, dir: srcDir, out: out})
	mutate, undo := pc.prepare(permitCtx{h: h, dry: dry, srcs: srcs, outDir: outDir, out: out})

	// Reset everything the dry run touched, then measure.
	for i, s := range h.defaultSources() {
		copyFile(s, srcs[i])
	}
	_ = os.RemoveAll(outDir)
	_ = os.MkdirAll(outDir, 0o755)

	got := h.runSession(sessionSpec{sources: srcs, dir: srcDir, out: out, mutate: mutate})
	undo()

	// The case must fire for its OWN reason, not merely produce some finding.
	named := false
	for _, f := range got.Permit {
		if strings.Contains(f, pc.expect) {
			named = true
		}
	}
	ok := !dry.Rejected && dry.ManagerCommands() == 2 &&
		got.Rejected &&
		got.Class == "build_execution_control_unavailable" &&
		got.Diagnostic == DiagPermitBinding &&
		got.Reverified && len(got.Permit) > 0 && named &&
		got.ManagerCommands() == 1 && !got.CompileRan() &&
		!exists(got.Artifact)
	return Structural{
		ID:       pc.id,
		Title:    pc.title,
		Expected: "control run reaches 2 commands; mutated run rejected at the permit with build_execution_control_unavailable / " + DiagPermitBinding + ", a finding carrying " + fmt.Sprintf("%q", pc.expect) + ", exactly 1 manager command, no compile child, no artifact",
		Observed: fmt.Sprintf("control: rejected=%v commands=%d; mutated: rejected=%v class=%s diagnostic=%s findings=%d named_mechanism=%v commands=%d compile_ran=%v artifact_exists=%v findings=%q",
			dry.Rejected, dry.ManagerCommands(), got.Rejected, got.Class, got.Diagnostic, len(got.Permit), named,
			got.ManagerCommands(), got.CompileRan(), exists(got.Artifact), clipTo(strings.Join(got.Permit, " | "), 400)),
		Verdict: verdict(ok),
		ManagerObligation: "The mutation lands AFTER the closed grammar has accepted every token of the plan, which is the " +
			"only window the graph phase leaves open. The permit is the check that closes it: " + pc.what + ", the re-binding " +
			"reports it, and the compile command is never started.",
		Runs: got.Commands,
	}
}

// syntheticExecutableCheck is the executable-binding case. The plan's real
// executables live in the toolchain root, which is read-only host state this
// task does not mutate, so the case runs a whole session against a SYNTHETIC
// toolchain the manager owns: a `swiftc` that emits a fixed plan under `-###`
// and writes its output otherwise, plus the executables that plan names.
//
// Nothing about the synthetic root is a claim about Swift. It exists so the
// session's own permit step can be exercised against an executable binding that
// is writable, and the plan it emits is verified by the same closed grammar and
// the same bucket rules as the real one.
func (h *harness) syntheticExecutableCheck() Structural {
	root := filepath.Join(h.base, "c5-synthetic-toolchain")
	_ = os.RemoveAll(root)
	_ = os.MkdirAll(filepath.Join(root, "lib"), 0o755)
	srcDir := filepath.Join(h.base, "c5-synthetic-src")
	_ = os.RemoveAll(srcDir)
	_ = os.MkdirAll(srcDir, 0o755)
	src := filepath.Join(srcDir, "main.swift")
	_ = os.WriteFile(src, []byte("let n = 1\nprint(n)\n"), 0o644)

	frontend := filepath.Join(root, "swift-frontend")
	linker := filepath.Join(root, "ld")
	for _, p := range []string{frontend, linker} {
		_ = os.WriteFile(p, []byte("#!/bin/sh\nexit 0\n"), 0o755)
	}
	absentPlugin := filepath.Join(root, "plugins")
	outDir := filepath.Join(h.stage, "c5-synth")
	_ = os.RemoveAll(outDir)
	_ = os.MkdirAll(outDir, 0o755)
	obj := filepath.Join(outDir, "synth.o")
	out := filepath.Join(outDir, "artifact")

	// A two-job plan in the same physical-line, single-quote grammar the real
	// driver emits. Every token is claimed by the closed grammar of 4.1.2.
	plan := fmt.Sprintf("%s -frontend -c -plugin-path %s -I %s %s -o %s\n%s -O3 %s -o %s\n",
		frontend, absentPlugin, filepath.Join(root, "lib"), src, obj, linker, obj, out)
	planFile := filepath.Join(root, "plan.txt")
	_ = os.WriteFile(planFile, []byte(plan), 0o644)

	// The shim uses shell builtins only. The session runs its children with an
	// EMPTY PATH — that is the contract — so a `cat` or a `chmod` in here would
	// not resolve, and the plan would arrive empty.
	shim := filepath.Join(root, "swiftc")
	_ = os.WriteFile(shim, []byte("#!/bin/sh\nplan='"+plan+"'\ngraph=0\nout=\nprev=\nfor a in \"$@\"; do\n"+
		"  [ \"$a\" = '-###' ] && graph=1\n  [ \"$prev\" = '-o' ] && out=$a\n  prev=$a\ndone\n"+
		"if [ \"$graph\" = 1 ]; then printf '%s' \"$plan\"; exit 0; fi\n"+
		"[ -n \"$out\" ] && printf 'synthetic\\n' > \"$out\"\nexit 0\n"), 0o755)

	resolvedRoot, err := filepath.EvalSymlinks(root)
	if err != nil {
		resolvedRoot = root
	}
	base := h.policy(nil)
	pol := PlanPolicy{
		ToolchainRoot:      resolvedRoot,
		FingerprintedRoots: []string{resolvedRoot},
		OperationPrivate:   base.OperationPrivate,
		Triple:             base.Triple,
		SwiftVersion:       base.SwiftVersion,
		ModuleName:         base.ModuleName,
		XllvmValues:        base.XllvmValues,
		XccValues:          base.XccValues,
	}

	// Control run: no mutation, so the synthetic session must reach two commands
	// and produce its artifact. Without it the adversarial run proves nothing.
	clean := h.runSession(sessionSpec{sources: []string{src}, dir: srcDir, out: out, swiftc: shim, policy: &pol})
	cleanArtifact := exists(out)
	_ = os.Remove(out)
	_ = os.Remove(obj)

	got := h.runSession(sessionSpec{sources: []string{src}, dir: srcDir, out: out, swiftc: shim, policy: &pol,
		mutate: func() {
			// The bound executable keeps its path and changes its bytes.
			_ = os.WriteFile(frontend, []byte("#!/bin/sh\nexit 1\n# replaced after the graph phase\n"), 0o755)
		}})

	execBindings := 0
	for _, b := range clean.Verify.Bindings {
		if b.Bucket == BucketExecutable {
			execBindings++
		}
	}
	ok := !clean.Rejected && clean.ManagerCommands() == 2 && cleanArtifact && execBindings == 2 &&
		got.Rejected && got.Class == "build_execution_control_unavailable" &&
		got.Diagnostic == DiagPermitBinding && got.Reverified && len(got.Permit) > 0 &&
		got.ManagerCommands() == 1 && !exists(out)
	return Structural{
		ID:       "S71-executable-binding-that-changes-after-graph-withholds-the-permit",
		Title:    "an executable whose bytes change between the graph phase and the permit stops the session at one command",
		Expected: "the unmutated synthetic session reaches 2 commands and an artifact over 2 executable bindings; the mutated one is rejected at the permit with 1 command and no artifact",
		Observed: fmt.Sprintf("control: rejected=%v commands=%d executable_bindings=%d artifact=%v; mutated: rejected=%v class=%s diagnostic=%s findings=%d commands=%d artifact=%v first=%q",
			clean.Rejected, clean.ManagerCommands(), execBindings, cleanArtifact,
			got.Rejected, got.Class, got.Diagnostic, len(got.Permit), got.ManagerCommands(), exists(out),
			clipTo(firstOf(got.Permit), 160)),
		Verdict: verdict(ok),
		ManagerObligation: "The real toolchain root is read-only host state, so the executable binding is exercised against " +
			"a manager-owned synthetic root. The synthetic plan is verified by the same closed grammar and the same bucket " +
			"rules as the real one; only the executables behind it are writable. The claim is about the SESSION's permit " +
			"step, not about Swift.",
		Runs: append(append([]RunRecord{}, clean.Commands...), got.Commands...),
	}
}

// restorePresentedSDK puts the manager's SDK presentation back after a case that
// re-pointed it, so a later check measures the contract rather than the damage.
func (h *harness) restorePresentedSDK() {
	link := h.presentedSDK()
	if real, err := filepath.EvalSymlinks(link); err == nil && real == h.resolvedDeclaredSDK() {
		return
	}
	_ = os.Remove(link)
	_ = os.Symlink(h.tc.DeclaredSDK, link)
}

func (h *harness) resolvedDeclaredSDK() string {
	if r, err := filepath.EvalSymlinks(h.tc.DeclaredSDK); err == nil {
		return r
	}
	return h.tc.DeclaredSDK
}

// shortID turns S66-absent-plugin-… into s66, so a case's scratch directory is
// named after the check that owns it.
func shortID(id string) string {
	if i := strings.Index(id, "-"); i > 0 {
		return strings.ToLower(id[:i])
	}
	return strings.ToLower(id)
}

func firstOf(in []string) string {
	if len(in) == 0 {
		return ""
	}
	return in[0]
}
