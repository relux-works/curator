package main

import (
	"strings"
	"testing"
)

// The banner grammar is total: every input yields exactly one of a Banner or a
// BannerReject, never both and never neither.
func TestParseCompilerBannerIsTotal(t *testing.T) {
	inputs := []string{
		"", "x", "Apple Swift version ", "Apple Swift version 6.3.2 (x)",
		strings.Repeat("A", 4096), "\x00", "Apple Swift version 6.3.2 x",
		"Apple Swift version 6.3.2 ()", "Apple Swift version 6.3.2 (x))",
	}
	for _, v := range BannerVectors("Apple Swift version 6.3.2 (swiftlang-6.3.2.1.108 clang-2100.1.1.101)") {
		inputs = append(inputs, v.Value)
	}
	for _, in := range inputs {
		b, rej := ParseCompilerBanner(in)
		if (b == nil) == (rej == nil) {
			t.Fatalf("not total for %q: banner=%v reject=%v", in, b, rej)
		}
	}
}

func TestBannerVectorsMatchDeclaredOutcome(t *testing.T) {
	for _, v := range BannerVectors("Apple Swift version 6.3.2 (swiftlang-6.3.2.1.108 clang-2100.1.1.101)") {
		b, rej := ParseCompilerBanner(v.Value)
		if v.Accept {
			if rej != nil {
				t.Errorf("%s (%s): expected acceptance, got %s", v.ID, v.Note, rej.Code)
			}
			continue
		}
		if rej == nil {
			t.Errorf("%s (%s): expected rejection %s, got acceptance of %q", v.ID, v.Note, v.Code, b.Normalized)
			continue
		}
		if rej.Code != v.Code {
			t.Errorf("%s (%s): expected code %s, got %s (%s)", v.ID, v.Note, v.Code, rej.Code, rej.Detail)
		}
	}
}

// The whole value must reconstruct from the parsed components: a parser that
// leaves a suffix unexamined cannot satisfy this.
func TestBannerReconstructs(t *testing.T) {
	raw := "Apple Swift version 6.3.2 (swiftlang-6.3.2.1.108 clang-2100.1.1.101)"
	b, rej := ParseCompilerBanner(raw)
	if rej != nil {
		t.Fatalf("unexpected rejection: %s", rej)
	}
	rebuilt := bannerPrefix + b.Normalized + " (" + b.Suffix + ")"
	if rebuilt != raw {
		t.Fatalf("reconstruction %q != raw %q", rebuilt, raw)
	}
	if b.Normalized != "6.3.2" {
		t.Fatalf("normalized = %q", b.Normalized)
	}
}

// The retired parser must be strictly looser, or control C10 cannot fire.
func TestRetiredPrefixParserIsStrictlyLooser(t *testing.T) {
	looser := 0
	for _, v := range BannerVectors("Apple Swift version 6.3.2 (x)") {
		if v.Accept {
			continue
		}
		if _, ok := NaiveCompilerVersionPrefixOnly(v.Value); ok {
			looser++
		}
	}
	if looser == 0 {
		t.Fatal("the retired parser admits nothing the grammar rejects; C10 would not fire")
	}
	// It must never be TIGHTER: anything the grammar accepts, the retired
	// parser also accepted, so no accepted host regresses.
	for _, v := range BannerVectors("Apple Swift version 6.3.2 (x)") {
		if !v.Accept {
			continue
		}
		if _, ok := NaiveCompilerVersionPrefixOnly(v.Value); !ok {
			t.Errorf("%s: grammar accepts but the retired parser did not; the narrowing claim is wrong", v.ID)
		}
	}
}
