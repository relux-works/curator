package main

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"
)

// Toolchain is a directly resolved Swift toolchain root. It is never resolved
// through PATH, xcrun, xcode-select, DEVELOPER_DIR or a version manager: the
// probe is given a root or it finds candidate roots by their fixed layout and
// reports which one it took.
type Toolchain struct {
	Root         string
	PlatformRoot string
	DeclaredSDK  string

	Swiftc   string
	Swift    string
	Frontend string
	Clang    string
	Linker   string

	CompilerVersion string
	CompilerTag     string
	Normalized      string
	CompilerMM      string
	Triple          string
	Unversioned     string
	RuntimePaths    []string
	StdlibPresent   bool

	// BannerSuffix is the parenthesised body the whole-value grammar consumed.
	// Recording it is how the fixture proves the suffix was examined rather
	// than skipped.
	BannerSuffix string
	// Admission is the P2 verdict. It is computed from an ACTUAL
	// `-print-target-info -target <target.triple>` run, and Stage A green is
	// gated on it.
	Admission RuntimeAdmission
}

// baseInstallPrefixes is the closed, per-platform, registry-declared
// base-installation prefix set of runtime.go rule R2.7. macOS is measured;
// every other platform is empty until a native probe supplies it, which fails
// closed rather than admitting an unmeasured prefix.
func baseInstallPrefixes(goos string) []string {
	switch goos {
	case "darwin":
		return []string{"/usr/lib/swift"}
	default:
		return nil
	}
}

type targetInfo struct {
	CompilerVersion  string `json:"compilerVersion"`
	SwiftCompilerTag string `json:"swiftCompilerTag"`
	Target           struct {
		Triple            string `json:"triple"`
		UnversionedTriple string `json:"unversionedTriple"`
	} `json:"target"`
	Paths struct {
		RuntimeLibraryPaths []string `json:"runtimeLibraryPaths"`
	} `json:"paths"`
}

// ResolveToolchain locates a toolchain root and its platform root. Both are
// declaration inputs in the real contract; here they are probe inputs.
func ResolveToolchain(root, platform string) (*Toolchain, error) {
	if root == "" {
		var err error
		root, platform, err = discover()
		if err != nil {
			return nil, err
		}
	}
	tc := &Toolchain{Root: root, PlatformRoot: platform}
	tc.Swiftc = filepath.Join(root, "usr", "bin", "swiftc")
	tc.Swift = filepath.Join(root, "usr", "bin", "swift")
	tc.Frontend = filepath.Join(root, "usr", "bin", "swift-frontend")
	tc.Clang = filepath.Join(root, "usr", "bin", "clang")
	tc.Linker = filepath.Join(root, "usr", "bin", "ld")
	for _, p := range []string{tc.Swiftc, tc.Swift, tc.Frontend, tc.Clang, tc.Linker} {
		if !isRegularExecutable(p) {
			return nil, fmt.Errorf("toolchain root %s does not carry %s", root, p)
		}
	}
	if platform != "" {
		tc.DeclaredSDK = filepath.Join(platform, "SDKs", "MacOSX.sdk")
		if !isDir(tc.DeclaredSDK) {
			return nil, fmt.Errorf("platform root %s does not carry SDKs/MacOSX.sdk", platform)
		}
	}
	if err := tc.readTargetInfo(); err != nil {
		return nil, err
	}
	return tc, nil
}

func discover() (root, platform string, err error) {
	apps, _ := filepath.Glob("/Applications/Xcode*.app")
	sort.Strings(apps)
	for i := len(apps) - 1; i >= 0; i-- {
		dev := filepath.Join(apps[i], "Contents", "Developer")
		r := filepath.Join(dev, "Toolchains", "XcodeDefault.xctoolchain")
		p := filepath.Join(dev, "Platforms", "MacOSX.platform", "Developer")
		if isRegularExecutable(filepath.Join(r, "usr", "bin", "swiftc")) && isDir(filepath.Join(p, "SDKs", "MacOSX.sdk")) {
			return r, p, nil
		}
	}
	return "", "", fmt.Errorf("no directly resolvable Swift toolchain root was found; nothing was installed, downloaded or activated")
}

// readTargetInfo runs BOTH declared probes. P1 supplies the identity scalars;
// P2 supplies the runtime-library closure for the exact triple the compile
// vector will pass, and its verdict is the native-target admission gate.
func (t *Toolchain) readTargetInfo() error {
	// --- P1 -----------------------------------------------------------------
	ti, rec, p1Raw, err := readTargetInfoFor(t.Swiftc, "", nil)
	if err != nil {
		return err
	}
	_ = rec
	t.CompilerVersion = ti.CompilerVersion
	t.CompilerTag = ti.SwiftCompilerTag
	t.Triple = ti.Target.Triple
	t.Unversioned = ti.Target.UnversionedTriple
	t.RuntimePaths = ti.Paths.RuntimeLibraryPaths

	b, brej := ParseCompilerBanner(ti.CompilerVersion)
	if brej != nil {
		return fmt.Errorf("compilerVersion %q does not match the whole-value normalization grammar (%s)",
			ti.CompilerVersion, brej.String())
	}
	t.Normalized = b.Normalized
	t.BannerSuffix = b.Suffix
	v := mustParse(b.Normalized)
	t.CompilerMM = fmt.Sprintf("%d.%d", v.major, v.minor)

	// --- P2, for the EXACT compile triple ------------------------------------
	ti2, rec2, p2Raw, err2 := readTargetInfoFor(t.Swiftc, t.Triple, nil)
	if err2 != nil {
		return err2
	}

	roots := []RootRecord{{Role: RoleSwiftToolchain, Ordinal: 0, Resolved: resolveOr(t.Root)}}
	if t.DeclaredSDK != "" {
		roots = append(roots, RootRecord{Role: RolePlatformSDK, Ordinal: 0, Resolved: resolveOr(t.DeclaredSDK)})
	}
	pol := RuntimePolicy{Roots: roots, BaseInstallPrefixes: baseInstallPrefixes(runtime.GOOS)}
	t.Admission = AdmitRuntimeLibraryPaths(t.Triple, ti2.Paths.RuntimeLibraryPaths, pol)
	t.Admission.Probe = rec2
	t.Admission.P1EqualsP2 = canonicalJSON(p1Raw) == canonicalJSON(p2Raw)
	if !t.Admission.OK() {
		return fmt.Errorf("native target %s is not admitted: %s", t.Triple, strings.Join(t.Admission.Rejections, "; "))
	}
	// StdlibPresent is now the P2 verdict rather than an incidental observation.
	t.StdlibPresent = t.Admission.InClosure > 0
	return nil
}

func resolveOr(p string) string {
	if r, err := filepath.EvalSymlinks(p); err == nil {
		return r
	}
	return p
}

// canonicalJSON re-encodes a document so two probe outputs are compared on
// structure rather than on incidental whitespace.
func canonicalJSON(s string) string {
	var v any
	if err := json.Unmarshal([]byte(s), &v); err != nil {
		return "\x00invalid:" + s
	}
	b, err := json.Marshal(v)
	if err != nil {
		return "\x00unmarshalable"
	}
	return string(b)
}

// ---------------------------------------------------------------------------
// Execution
// ---------------------------------------------------------------------------

// Env is the operation-private environment: nothing is inherited.
type Env struct {
	PATH  string
	HOME  string
	TMP   string
	Extra []string
}

func (e Env) slice() []string {
	out := []string{
		"PATH=" + e.PATH,
		"HOME=" + e.HOME,
		"TMPDIR=" + e.TMP,
		"LC_ALL=C",
		"LANG=C",
	}
	return append(out, e.Extra...)
}

// runFixed records a bounded excerpt for the fixture. Callers that must parse
// the whole output — the job plan in particular — use runFixedRaw, because a
// clipped path is a corrupted path.
func runFixed(bin string, args []string, dir string, env *Env) RunRecord {
	rec, _, _ := runFixedRaw(bin, args, dir, env)
	return rec
}

func runFixedRaw(bin string, args []string, dir string, env *Env) (RunRecord, string, string) {
	cmd := exec.Command(bin, args...)
	cmd.Dir = dir
	if env == nil {
		env = &Env{PATH: os.TempDir() + "/curator-probe-empty", HOME: os.TempDir(), TMP: os.TempDir() + "/"}
		_ = os.MkdirAll(env.PATH, 0o755)
	}
	cmd.Env = env.slice()
	var out, errb strings.Builder
	cmd.Stdout = &out
	cmd.Stderr = &errb
	done := make(chan error, 1)
	if err := cmd.Start(); err != nil {
		return RunRecord{Argv: append([]string{bin}, args...), Dir: dir, EnvDelta: env.slice(), Exit: -1, Stderr: err.Error()}, "", err.Error()
	}
	go func() { done <- cmd.Wait() }()
	select {
	case <-done:
	case <-time.After(180 * time.Second):
		_ = cmd.Process.Kill()
		<-done
	}
	code := cmd.ProcessState.ExitCode()
	return RunRecord{
		Argv:     append([]string{bin}, args...),
		Dir:      dir,
		EnvDelta: env.slice(),
		Exit:     code,
		Stdout:   clip(out.String()),
		Stderr:   clip(errb.String()),
	}, out.String(), errb.String()
}

func clip(s string) string {
	if len(s) > 4000 {
		return s[:4000] + "…"
	}
	return s
}

// isRegularExecutable resolves symlinks deliberately: the measured toolchain
// ships `swiftc` and `swift` as symlinks to the single `swift-frontend` binary,
// which dispatches on argv[0]. What the contract cares about is that the
// resolved target is a regular executable inside the same fingerprinted root,
// which resolveInside checks.
func isRegularExecutable(p string) bool {
	fi, err := os.Stat(p)
	if err != nil || !fi.Mode().IsRegular() {
		return false
	}
	return fi.Mode().Perm()&0o111 != 0
}

// resolveInside reports the fully resolved path of p and whether it stays
// inside root.
func resolveInside(p, root string) (string, bool) {
	real, err := filepath.EvalSymlinks(p)
	if err != nil {
		return "", false
	}
	rr, err := filepath.EvalSymlinks(root)
	if err != nil {
		rr = root
	}
	return real, strings.HasPrefix(real, strings.TrimSuffix(rr, "/")+"/")
}

func isDir(p string) bool {
	fi, err := os.Stat(p)
	return err == nil && fi.IsDir()
}
