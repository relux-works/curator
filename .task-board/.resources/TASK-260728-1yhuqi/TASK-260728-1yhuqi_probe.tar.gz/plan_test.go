package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// The tokenizer implements the measured quoting grammar. Every expectation here
// was produced by running `swiftc -###` over a path carrying the character in
// question; none of it is inferred.
func TestTokenizeJobLineMatchesTheMeasuredQuotingGrammar(t *testing.T) {
	for _, tc := range []struct {
		name string
		line string
		want []string
	}{
		{"plain", "/a/b -c /d/e", []string{"/a/b", "-c", "/d/e"}},
		{"quoted composite", "/a/b -external-plugin-path '/p/d#/p/s'", []string{"/a/b", "-external-plugin-path", "/p/d#/p/s"}},
		{"space in a path", "/a/b '/d/has space.swift'", []string{"/a/b", "/d/has space.swift"}},
		{"embedded single quote", `/a/b '/d/has'\''quote.swift'`, []string{"/a/b", "/d/has'quote.swift"}},
		{"backslash inside quotes", `/a/b '/d/back\slash.swift'`, []string{"/a/b", `/d/back\slash.swift`}},
		{"runs of spaces", "/a/b   -c", []string{"/a/b", "-c"}},
		{"empty quoted token", "/a/b ''", []string{"/a/b", ""}},
	} {
		got, err := TokenizeJobLine(tc.line)
		if err != nil {
			t.Errorf("%s: unexpected error %v", tc.name, err)
			continue
		}
		if len(got) != len(tc.want) {
			t.Errorf("%s: got %#v want %#v", tc.name, got, tc.want)
			continue
		}
		for i := range got {
			if got[i] != tc.want[i] {
				t.Errorf("%s: token %d = %q want %q", tc.name, i, got[i], tc.want[i])
			}
		}
	}
}

// The tokenizer never recovers. Each of these is an error, not a shorter token
// list, because a shorter token list is how a malformed plan reads as a clean
// one.
func TestTokenizeJobLineFailsClosed(t *testing.T) {
	for _, bad := range []string{
		"/a/b '/unterminated",
		`/a/b /trailing\`,
		"/a/b\t-c",
		"/a/b \x00",
		"/a/b \x7f",
	} {
		if _, err := TokenizeJobLine(bad); err == nil {
			t.Errorf("TokenizeJobLine(%q) accepted", bad)
		}
	}
}

func testPolicy(t *testing.T) (PlanPolicy, string) {
	t.Helper()
	base := t.TempDir()
	root := filepath.Join(base, "root")
	sdk := filepath.Join(base, "sdk")
	priv := filepath.Join(base, "priv")
	src := filepath.Join(base, "src")
	for _, d := range []string{filepath.Join(root, "bin"), filepath.Join(sdk, "usr"), priv, src} {
		if err := os.MkdirAll(d, 0o755); err != nil {
			t.Fatal(err)
		}
	}
	if err := os.WriteFile(filepath.Join(root, "bin", "frontend"), []byte("#!/bin/sh\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "main.swift"), []byte("x\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	resolve := func(p string) string {
		r, err := filepath.EvalSymlinks(p)
		if err != nil {
			t.Fatal(err)
		}
		return r
	}
	return PlanPolicy{
		ToolchainRoot:      resolve(root),
		FingerprintedRoots: []string{resolve(root), resolve(sdk)},
		OperationPrivate:   []string{resolve(priv)},
		Sources:            []string{filepath.Join(src, "main.swift")},
		WorkingDir:         src,
	}, base
}

func TestVerifyPlanAcceptsAWellFormedPlan(t *testing.T) {
	pol, base := testPolicy(t)
	line := strings.Join([]string{
		filepath.Join(base, "root", "bin", "frontend"),
		"-frontend", "-c",
		"-primary-file", pol.Sources[0],
		"-sdk", filepath.Join(base, "sdk"),
		"-L", filepath.Join(base, "root"),
		"-plugin-path", filepath.Join(base, "root", "plugins"),
		"-external-plugin-path", "'" + filepath.Join(base, "root", "p") + "#" + filepath.Join(base, "root", "s") + "'",
		"-o", filepath.Join(base, "priv", "out.o"),
	}, " ")
	res := VerifyPlan(line+"\n", pol)
	if !res.OK() {
		t.Fatalf("well-formed plan rejected: %v", res.Rejections)
	}
	if res.Counts[BucketExecutable] != 1 || res.Counts[BucketSource] != 1 || res.Counts[BucketOutput] != 1 {
		t.Fatalf("bucket counts wrong: %v", res.Counts)
	}
	if res.Counts[BucketPlugin] != 3 {
		t.Fatalf("expected one -plugin-path and both -external-plugin-path components: %v", res.Counts)
	}
}

// One vector per failure family the reviewer named. Every one must reject.
func TestVerifyPlanRejectsEveryMalformedFamily(t *testing.T) {
	pol, base := testPolicy(t)
	exe := filepath.Join(base, "root", "bin", "frontend")
	for _, tc := range []struct{ name, plan string }{
		{"relative executable", "frontend -frontend"},
		{"unknown wrapper line", "sh -c " + exe},
		{"executable outside the root", "/bin/sh -frontend"},
		{"executable that does not exist", filepath.Join(base, "root", "bin", "absent") + " -frontend"},
		{"unmatched quote", exe + " -plugin-path '/x"},
		{"dangling backslash", exe + ` -frontend \`},
		{"plugin flag with no value", exe + " -plugin-path"},
		{"plugin flag with an empty value", exe + " -plugin-path="},
		{"external plugin path with one component", exe + " -external-plugin-path " + filepath.Join(base, "root", "p")},
		{"external plugin path with three components", exe + " -external-plugin-path a#b#c"},
		{"hash in a single-path plugin flag", exe + " -plugin-path " + filepath.Join(base, "root", "a") + "#" + filepath.Join(base, "root", "b")},
		{"plugin path existing outside every root", exe + " -plugin-path /etc"},
		{"search path outside every root", exe + " -L /etc"},
		{"joined search path outside every root", exe + " -L/etc"},
		{"search path that does not exist", exe + " -sdk " + filepath.Join(base, "absent-sdk")},
		{"source not in the manager set", exe + " -primary-file " + filepath.Join(base, "src", "other.swift")},
		{"output outside operation-private state", exe + " -o /etc/x"},
		{"unclaimed absolute positional", exe + " /etc/hosts"},
		{"blank line", exe + " -frontend\n\n" + exe + " -frontend"},
		{"empty plan", ""},
		{"control byte", exe + "\t-frontend"},
		{"new-driver-path outside the root", exe + " -new-driver-path /bin/sh"},
	} {
		if VerifyPlan(tc.plan+"\n", pol).OK() {
			t.Errorf("%s: accepted %q", tc.name, clipTo(tc.plan, 90))
		}
	}
}

// A plugin path that does not exist is admitted; the same path existing outside
// every fingerprinted root is not. That asymmetry is the whole plugin rule.
func TestVerifyPlanAdmitsAnAbsentPluginPathAndRejectsAPresentOutsideOne(t *testing.T) {
	pol, base := testPolicy(t)
	exe := filepath.Join(base, "root", "bin", "frontend")
	absent := filepath.Join(base, "nowhere", "plugins")
	if !VerifyPlan(exe+" -plugin-path "+absent+"\n", pol).OK() {
		t.Fatal("an absent plugin path must be admitted")
	}
	if err := os.MkdirAll(absent, 0o755); err != nil {
		t.Fatal(err)
	}
	if VerifyPlan(exe+" -plugin-path "+absent+"\n", pol).OK() {
		t.Fatal("a plugin path existing outside every fingerprinted root must be rejected")
	}
}

// A dangling symlink exists as an entry and resolves nowhere. It is neither
// inside a root nor absent, so it rejects.
func TestVerifyPlanRejectsADanglingSymlink(t *testing.T) {
	pol, base := testPolicy(t)
	exe := filepath.Join(base, "root", "bin", "frontend")
	dangling := filepath.Join(base, "dangling")
	if err := os.Symlink(filepath.Join(base, "no-such-target"), dangling); err != nil {
		t.Fatal(err)
	}
	if VerifyPlan(exe+" -plugin-path "+dangling+"\n", pol).OK() {
		t.Fatal("a dangling symlink must reject")
	}
}

// Containment is resolved, so a path lexically below the root but symlinked out
// of it is rejected — and the retired lexical check would have taken it.
func TestVerifyPlanRejectsASymlinkEscape(t *testing.T) {
	pol, _ := testPolicy(t)
	// Built from the resolved root, so the lexical check below is comparing like
	// with like and the control really is about the symlink rather than about
	// an unresolved temp-directory prefix.
	escape := filepath.Join(pol.ToolchainRoot, "bin", "escaped")
	if err := os.Symlink("/bin/sh", escape); err != nil {
		t.Fatal(err)
	}
	if VerifyPlan(escape+" -frontend\n", pol).OK() {
		t.Fatal("a symlink escape must reject")
	}
	if !lexicallyContained(escape, []string{pol.ToolchainRoot}) {
		t.Fatal("the retired lexical check is supposed to admit this; the control depends on it")
	}
}

func TestReverifyCatchesAppearanceAndIdentityChange(t *testing.T) {
	pol, base := testPolicy(t)
	exe := filepath.Join(base, "root", "bin", "frontend")

	// An absent plugin path that appears before the permit.
	absent := filepath.Join(base, "later", "plugins")
	res := VerifyPlan(exe+" -plugin-path "+absent+"\n", pol)
	if !res.OK() {
		t.Fatalf("setup: %v", res.Rejections)
	}
	if len(Reverify(res.Bindings)) != 0 {
		t.Fatal("nothing changed yet")
	}
	if err := os.MkdirAll(absent, 0o755); err != nil {
		t.Fatal(err)
	}
	if len(Reverify(res.Bindings)) == 0 {
		t.Fatal("an absent plugin path that appeared must be reported")
	}

	// A bound executable whose bytes change before the permit.
	res2 := VerifyPlan(exe+" -frontend\n", pol)
	if !res2.OK() {
		t.Fatalf("setup: %v", res2.Rejections)
	}
	if err := os.WriteFile(exe, []byte("#!/bin/sh\n# changed\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	if len(Reverify(res2.Bindings)) == 0 {
		t.Fatal("a bound executable that changed identity must be reported")
	}
}

func TestValidSourceRelPathRejectsOnlyControlBytes(t *testing.T) {
	for _, ok := range []string{"a.swift", "has space.swift", "has'quote.swift", "@resp.swift", "has#hash.swift", `back\slash.swift`, "dir/a.swift"} {
		if err := ValidSourceRelPath(ok); err != nil {
			t.Errorf("ValidSourceRelPath(%q) = %v, want nil", ok, err)
		}
	}
	for _, bad := range []string{"", "new\nline.swift", "tab\tname.swift", "nul\x00.swift", "del\x7f.swift"} {
		if err := ValidSourceRelPath(bad); err == nil {
			t.Errorf("ValidSourceRelPath(%q) accepted", bad)
		}
	}
}

func TestIsPathShapedCoversTheWindowsForms(t *testing.T) {
	for _, yes := range []string{"/a", `C:\a`, `c:/a`, `\\server\share`} {
		if !isPathShaped(yes) {
			t.Errorf("isPathShaped(%q) = false", yes)
		}
	}
	for _, no := range []string{"-O", "arm64-apple-macosx26.0", "6", "", "a/b"} {
		if isPathShaped(no) {
			t.Errorf("isPathShaped(%q) = true", no)
		}
	}
}
