package main

import (
	"fmt"
	"strings"
)

// Closure measures — rather than asserts — that outcomes outside the recognised
// set produce no verdict.
//
// Three kinds of check are run, and the third is labelled as constructed
// because it has to be: a fail-closed property is a claim about outcomes no
// host has emitted yet, so the only honest way to check it is to take text
// upstream did emit and change it the way a later release would.
//
// Each row records which laundering direction a wrong answer would have taken:
// direction A is a fabricated verdict that agrees with an isolated-accepted
// value, direction B one that agrees with an isolated-rejected value.
func Closure(tc *Toolchain, results []CaseResult) []ClosureCheck {
	var out []ClosureCheck

	type measured struct {
		id         string
		raw        string
		exit       int
		stdout     string
		stderr     string
		class      Class
		namesValue bool
		norm       string
	}
	var pool []measured
	var excluded []string
	add := func(id, raw string, rec RunRecord, obs Observation) {
		norm, _ := predictNormalized(raw)
		// An outcome may only be cross-fed if it names the value under test.
		// An exit-0 acceptance names nothing; the missing-specifier and
		// absent-header diagnostics name nothing either. Feeding those to a
		// classifier under another value would test the classifier against text
		// that was never about a value, which is not a laundering check.
		names := raw != "" && obs.Matched != "" && strings.Contains(obs.Matched, raw)
		if !names {
			excluded = append(excluded, fmt.Sprintf("%s (%s names no value under test)", id, obs.Class))
			return
		}
		pool = append(pool, measured{id, raw, rec.Exit, rec.Stdout, rec.Stderr, obs.Class, names, norm})
	}
	for _, r := range results {
		if r.Status != "run" || len(r.Runs) < 2 {
			continue
		}
		raw := rawVersionOf(r.Case.Manifest + ManifestBody)
		add(r.Case.ID+"/isolated", raw, r.Runs[0], r.Isolated)
		add(r.Case.ID+"/corroborating", raw, r.Runs[1], r.Corroborating)
	}

	direction := func(c Class) string {
		if c == ClassAccepted {
			return "A"
		}
		return "B"
	}

	// 1. measured, unrelated: a real command, a real non-zero exit, nothing in
	//    it about the value under test.
	unrelated := []struct {
		id   string
		rec  RunRecord
		want Class
	}{
		{"unrelated/print-target-info-unknown-triple", runFixed(tc.Swiftc, []string{"-print-target-info", "-target", "not-a-real-triple"}, "", nil), ClassAccepted},
		{"unrelated/swiftc-unknown-flag", runFixed(tc.Swiftc, []string{"--curator-not-a-flag"}, "", nil), ClassGrammar},
	}
	for _, u := range unrelated {
		for _, raw := range []string{"6.0", "notaversion"} {
			obs := recognise(isolatedExpectations(raw, PkgDir, tc.Normalized, tc.CompilerMM), u.rec.Exit, u.rec.Stdout, u.rec.Stderr, "", modeExact)
			out = append(out, ClosureCheck{
				ID:        fmt.Sprintf("%s@%s", u.id, raw),
				Direction: direction(u.want),
				Kind:      "measured, unrelated",
				Yielded:   obs.Class,
				NoVerdict: obs.Class == ClassUnknown,
				Detail:    clipTo(firstNonEmptyLine(u.rec.Stdout+"\n"+u.rec.Stderr), 120),
			})
		}
	}

	// 2. measured: every measured value-bearing outcome classified against every
	//    other case's value.
	pairs := 0
	for _, m := range pool {
		for _, other := range pool {
			// Two raw values that normalize to the same string denote the same
			// outcome, so feeding one under the other is not a cross-feed.
			if m.raw == other.raw || (m.norm != "" && m.norm == other.norm) {
				continue
			}
			pairs++
			obs := recognise(isolatedExpectations(other.raw, PkgDir, tc.Normalized, tc.CompilerMM), m.exit, m.stdout, m.stderr, "", modeExact)
			obs2 := recognise(corroboratingExpectations(other.raw, PkgDir, tc.Normalized, tc.CompilerMM), m.exit, m.stdout, m.stderr, "", modeExact)
			for _, o := range []Observation{obs, obs2} {
				if o.Class != ClassUnknown {
					out = append(out, ClosureCheck{
						ID:        fmt.Sprintf("crossfeed/%s-under-%q", m.id, other.raw),
						Direction: direction(m.class),
						Kind:      "measured",
						Yielded:   o.Class,
						NoVerdict: false,
						Detail:    "a measured outcome answered for a value it does not name",
					})
				}
			}
		}
	}
	// Record the aggregate so a green run still reports the work it did, and
	// name every outcome the cross-feed deliberately left out.
	out = append(out, ClosureCheck{
		ID:        fmt.Sprintf("crossfeed/summary-%d-pairs", pairs),
		Direction: "A+B",
		Kind:      "measured",
		Yielded:   ClassUnknown,
		NoVerdict: true,
		Detail: fmt.Sprintf("%d value-bearing outcomes cross-fed over %d pairs; %d outcomes excluded because they name no value: %s",
			len(pool), pairs, len(excluded), clipTo(strings.Join(excluded, ", "), 600)),
	})

	// 3. measured, extended (constructed): a measured recognised diagnostic with
	//    the structural change a later release makes to a message.
	for _, m := range pool {
		if m.class == ClassUnknown || m.stderr == "" {
			continue
		}
		line := firstNonEmptyLine(m.stderr)
		if line == "" {
			continue
		}
		mutations := map[string]string{
			"tail-appended": line + ": unrelated failure",
			"wrapper-ahead": "swift-package: " + line,
			"embedded":      "note: while reading the manifest, " + line + " (see documentation)",
		}
		for name, mutated := range mutations {
			obs := recognise(isolatedExpectations(m.raw, PkgDir, tc.Normalized, tc.CompilerMM), 1, "", mutated, "", modeExact)
			out = append(out, ClosureCheck{
				ID:        fmt.Sprintf("extended/%s/%s", m.id, name),
				Direction: direction(m.class),
				Kind:      "measured, extended (constructed)",
				Yielded:   obs.Class,
				NoVerdict: obs.Class == ClassUnknown,
				Detail:    clipTo(mutated, 120),
			})
		}
	}
	return out
}

func firstNonEmptyLine(s string) string {
	for _, l := range strings.Split(s, "\n") {
		if strings.TrimSpace(l) != "" {
			return strings.TrimSpace(l)
		}
	}
	return ""
}
