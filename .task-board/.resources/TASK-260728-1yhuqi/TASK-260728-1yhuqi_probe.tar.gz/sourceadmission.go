package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"sort"
)

// ---------------------------------------------------------------------------
// curator-swift-source-admission-v1 — Stage B, before the graph phase.
//
// Cycle 4, finding 2. Decision 0008 section 7 requires the pre-compile matrix to
// reject every package-selected compiler macro BEFORE the compile phase, under
// build_package_code_execution_forbidden. Cycle 3 removed the macro LOAD but let
// macro-selecting source pass verification, receive a compile permit and fail
// inside a compile child. That is a runtime allowance, which the same section
// forbids.
//
// Cycle 4 rejects the selection instead of the load, at the only place that is
// both manager-owned and total: the raw bytes of the admitted source set.
//
//	A source file is admitted only if it is well-formed UTF-8, carries no NUL,
//	and contains NEITHER the byte 0x40 ('@') NOR the byte 0x23 ('#').
//
// The rule is deliberately over-rejecting. It does not parse Swift, does not
// normalize, does not skip comments or string literals, and does not depend on
// any package-supplied artifact. It is a byte scan, so it is total over every
// possible file and cannot be argued around.
//
// Why those two bytes are the complete macro-selection surface — MEASURED on
// Apple Swift 6.3.2 / macOS 26.5 arm64, not argued from the grammar alone:
//
//	N1  `externalMacro(module:"A",type:"B")` without the sigil:
//	    "error: expansion of macro 'externalMacro(module:type:)' requires
//	     leading '#'"                          -> freestanding use needs 0x23
//	N6  `macro stringify … = #externalMacro(…)` with no role attribute:
//	    "error: macro 'stringify' must declare its applicable roles via
//	     '@freestanding' or '@attached'"       -> declaring one needs 0x40
//	N3  `Observable final class Box {}` — an attached macro attribute without
//	    '@' is not an attribute at all; it is a parse error.
//	N4  `\u{40}Observable` — a Unicode escape outside a literal is not syntax;
//	    parse error. There is no escape channel to the sigil.
//	S2  '＠' U+FF20 (fullwidth) is an identifier character, not an attribute
//	    marker; parse error. There is no homoglyph channel.
//	S1  an overlong UTF-8 encoding of U+0040 (0xC1 0x80) is rejected by the
//	    compiler with "invalid UTF-8 found in source file" — and is rejected
//	    HERE by the encoding rule, so the byte scan does not have to trust the
//	    compiler for that case.
//	N5  importing a macro-bearing module without using a macro loads nothing.
//	M1  the whole admitted rich-Swift source set compiles under one swiftc
//	    command with 0 macro-load remarks, with the plugin search paths present.
//
// Encoding is checked before the selector scan, and that order is normative: the
// scan's claim is "no 0x40 byte implies no U+0040 code point", which only holds
// on a well-formed UTF-8 file. A malformed file is rejected rather than scanned.
// ---------------------------------------------------------------------------

// Stable per-surface diagnostics beneath build_package_code_execution_forbidden.
const (
	DiagSourceUnreadable   = "swift_source_unreadable"
	DiagSourceEncoding     = "swift_source_encoding_forbidden"
	DiagSourceMacroSelctor = "swift_source_macro_selector_forbidden"
)

// SourceRejection names one rejected file, the rule it failed, and the byte
// offset that failed it. The offset makes the diagnostic reproducible.
type SourceRejection struct {
	Path       string `json:"path"`
	Rule       string `json:"rule"`
	Diagnostic string `json:"diagnostic"`
	Offset     int    `json:"offset"`
	Byte       int    `json:"byte"`
	Detail     string `json:"detail"`
}

// AdmittedSource is the binding Stage B leaves behind for one admitted file: the
// exact bytes the rule scanned, named by their digest.
//
// Cycle 5. The plan's own source binding records file identity (size, mode,
// mtime), which a writer that restores the metadata can preserve across a
// content change. Stage B already reads every byte, so the digest costs nothing
// and makes the permit-time re-check answer the question that actually matters:
// are these the bytes the rule admitted?
type AdmittedSource struct {
	Path   string `json:"path"`
	Size   int    `json:"size"`
	Digest string `json:"digest"`
}

// SourceAdmission is the whole Stage-B verdict over the compiled source set.
type SourceAdmission struct {
	Files        int               `json:"files"`
	BytesScanned int               `json:"bytes_scanned"`
	Admitted     []AdmittedSource  `json:"admitted,omitempty"`
	Rejections   []SourceRejection `json:"rejections"`
}

// OK reports whether the graph phase may start. Nothing is executed for a
// source set that is not admitted: no graph command, no compile command.
func (a SourceAdmission) OK() bool { return len(a.Rejections) == 0 }

// Class is the shared semantic class every rejection in this rule reports.
func (a SourceAdmission) Class() string {
	if a.OK() {
		return ""
	}
	return "build_package_code_execution_forbidden"
}

// Diagnostic is the first rejection's per-surface diagnostic, in path order.
func (a SourceAdmission) Diagnostic() string {
	if a.OK() {
		return ""
	}
	return a.Rejections[0].Diagnostic
}

// AdmitSources applies curator-swift-source-admission-v1 to the whole compiled
// source set. It is total: every input yields either an admission or a named
// rejection, and it reports EVERY rejected file rather than the first, so the
// verdict does not depend on iteration order. Rejections are sorted by path so
// the diagnostic is deterministic.
func AdmitSources(paths []string) SourceAdmission {
	a := SourceAdmission{Files: len(paths)}
	for _, p := range paths {
		b, err := os.ReadFile(p)
		if err != nil {
			a.Rejections = append(a.Rejections, SourceRejection{
				Path: p, Rule: "A1", Diagnostic: DiagSourceUnreadable, Offset: -1, Byte: -1,
				Detail: err.Error(),
			})
			continue
		}
		a.BytesScanned += len(b)
		if r, bad := admitBytes(p, b); bad {
			a.Rejections = append(a.Rejections, r)
			continue
		}
		a.Admitted = append(a.Admitted, AdmittedSource{Path: p, Size: len(b), Digest: digestBytes(b)})
	}
	sort.Slice(a.Rejections, func(i, j int) bool {
		if a.Rejections[i].Path != a.Rejections[j].Path {
			return a.Rejections[i].Path < a.Rejections[j].Path
		}
		return a.Rejections[i].Offset < a.Rejections[j].Offset
	})
	return a
}

// admitBytes is the whole rule for one file: encoding first, then the selector
// scan. Both passes read every byte; neither skips a comment or a literal.
func admitBytes(path string, b []byte) (SourceRejection, bool) {
	if off, why, ok := utf8Defect(b); !ok {
		return SourceRejection{
			Path: path, Rule: "A2", Diagnostic: DiagSourceEncoding, Offset: off, Byte: int(b[off]),
			Detail: why,
		}, true
	}
	for i, c := range b {
		if c == 0x40 || c == 0x23 {
			return SourceRejection{
				Path: path, Rule: "A3", Diagnostic: DiagSourceMacroSelctor, Offset: i, Byte: int(c),
				Detail: fmt.Sprintf("byte 0x%02X (%q) at offset %d selects the Swift macro surface", c, string(rune(c)), i),
			}, true
		}
	}
	return SourceRejection{}, false
}

// utf8Defect validates RFC 3629 well-formed UTF-8 by hand rather than through
// the standard library, so each defect class is named in the evidence rather
// than collapsed into one boolean. NUL is rejected too: it is valid UTF-8, the
// compiler only WARNS about it ("nul character embedded in middle of file"), and
// no admitted source needs one, so admitting it would leave a byte that hides
// content from a line-oriented reader while the compiler carries on.
//
// A cross-check against utf8.Valid is asserted in the tests.
func utf8Defect(b []byte) (int, string, bool) {
	for i := 0; i < len(b); {
		c := b[i]
		switch {
		case c == 0x00:
			return i, "NUL byte", false
		case c < 0x80:
			i++
		case c < 0xC2:
			// 0x80-0xBF is a continuation byte with no lead; 0xC0 and 0xC1 can
			// only ever begin an overlong two-byte form. This is the case that
			// stops an overlong encoding of U+0040 reaching the selector scan.
			if c < 0xC0 {
				return i, "continuation byte without a lead byte", false
			}
			return i, "overlong two-byte form (0xC0/0xC1 lead)", false
		case c < 0xE0:
			if !cont(b, i+1, 1) {
				return i, "truncated two-byte sequence", false
			}
			i += 2
		case c < 0xF0:
			if !cont(b, i+1, 2) {
				return i, "truncated three-byte sequence", false
			}
			if c == 0xE0 && b[i+1] < 0xA0 {
				return i, "overlong three-byte form", false
			}
			if c == 0xED && b[i+1] >= 0xA0 {
				return i, "UTF-16 surrogate half", false
			}
			i += 3
		case c < 0xF5:
			if !cont(b, i+1, 3) {
				return i, "truncated four-byte sequence", false
			}
			if c == 0xF0 && b[i+1] < 0x90 {
				return i, "overlong four-byte form", false
			}
			if c == 0xF4 && b[i+1] >= 0x90 {
				return i, "code point above U+10FFFF", false
			}
			i += 4
		default:
			return i, "lead byte above 0xF4", false
		}
	}
	return -1, "", true
}

func cont(b []byte, from, n int) bool {
	if from+n > len(b) {
		return false
	}
	for k := 0; k < n; k++ {
		if b[from+k]&0xC0 != 0x80 {
			return false
		}
	}
	return true
}

func digestBytes(b []byte) string {
	sum := sha256.Sum256(b)
	return hex.EncodeToString(sum[:])
}

// ReverifyAdmittedSources is the Stage-B half of the permit-time re-check. It
// runs immediately before the single compile command, alongside Reverify over
// the plan bindings, and re-reads every admitted source from the same path.
//
// It reports three distinguishable outcomes, because they mean different things
// to a reader of the evidence:
//
//   - the file can no longer be read — fail closed;
//   - the bytes changed — the compile child would read something Stage B never
//     scanned, whether or not the change introduces a sigil;
//   - the bytes changed AND the new bytes fail the rule — the same finding, with
//     the rule, offset and byte named, which is the concrete `@`/`#` case.
//
// Identity is deliberately not the test here: a writer that restores size, mode
// and mtime keeps identity while changing content. The digest does not care.
func ReverifyAdmittedSources(a SourceAdmission) []string {
	var findings []string
	for _, s := range a.Admitted {
		b, err := os.ReadFile(s.Path)
		if err != nil {
			findings = append(findings, fmt.Sprintf("admitted source %q can no longer be read at permit time: %v", s.Path, err))
			continue
		}
		d := digestBytes(b)
		if d == s.Digest && len(b) == s.Size {
			continue
		}
		detail := ""
		if r, bad := admitBytes(s.Path, b); bad {
			detail = fmt.Sprintf(" and no longer satisfies curator-swift-source-admission-v1 (%s, %s, byte 0x%02X at offset %d)",
				r.Rule, r.Diagnostic, r.Byte, r.Offset)
		}
		findings = append(findings, fmt.Sprintf(
			"admitted source %q changed between Stage B and the permit: %d bytes/%s became %d bytes/%s%s",
			s.Path, s.Size, clipTo(s.Digest, 16), len(b), clipTo(d, 16), detail))
	}
	return findings
}

// AdmitSourcesRetired is the retired Stage B: no source admission at all, which
// is what cycle 3 shipped. It is retained only so expected-red control C13 can
// restore it from the same binary and report the macro-selecting source it lets
// through to a compile permit.
func AdmitSourcesRetired(paths []string) SourceAdmission {
	return SourceAdmission{Files: len(paths)}
}
