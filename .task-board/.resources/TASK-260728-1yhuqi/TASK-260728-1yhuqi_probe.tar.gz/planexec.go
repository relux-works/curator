package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ---------------------------------------------------------------------------
// curator-swift-plan-execution-v1: the manager executes the plan it verified,
// with the macro/plugin load channel deleted.
//
// Why deletion rather than a check. MEASURED on Apple Swift 6.3.2, macOS 26.5
// arm64, four ways:
//
//   - `-resource-dir <manager-owned>` does NOT move the injected plugin search
//     paths; they stay at <toolchain>/usr/lib/swift/host/plugins;
//   - invoking swiftc through a manager-owned symlink resolves back to the real
//     toolchain root, so presenting the toolchain the way the SDK is presented
//     does not move them either;
//   - overriding -in-process-plugin-server-path to an absent file does not stop
//     the load, because the implementation is dlopen'd directly;
//   - neither swiftc nor swift-frontend has any flag that disables implicit
//     plugin-path injection.
//
// So while swiftc executes its own jobs, a source-selected toolchain macro load
// cannot be prevented by argv, environment or presentation. The decisive
// positive measurement is that the channel is entirely flag-driven: the same
// frontend job with NO plugin flag rejects `@Observable` with `plugin for module
// 'ObservationMacros' not found` and loads nothing, and with `-plugin-path` it
// loads it.
//
// The manager therefore executes the verified plan job by job, deleting exactly
// the closed plugin-flag set, and asserts that nothing else changed.
// ---------------------------------------------------------------------------

// PlanDeletion records one deleted plugin channel: which job, which token index
// in the verified job, the flag, and the value it carried.
type PlanDeletion struct {
	Job   int    `json:"job"`
	Index int    `json:"index"`
	Flag  string `json:"flag"`
	Value string `json:"value,omitempty"`
	Width int    `json:"width"`
}

// PlanExecution is the executable form of a verified plan.
type PlanExecution struct {
	Verified   [][]string     `json:"verified_jobs"`
	Executed   [][]string     `json:"executed_jobs"`
	Deletions  []PlanDeletion `json:"deletions"`
	Assertions []string       `json:"assertion_failures"`
}

// OK reports whether the compile permit may be granted.
func (e PlanExecution) OK() bool { return len(e.Assertions) == 0 }

// StripPluginChannel derives the executed job set from the verified one and
// asserts the four properties that make the derivation mechanical.
func StripPluginChannel(jobs [][]string) PlanExecution {
	e := PlanExecution{Verified: jobs}
	for n, j := range jobs {
		var out []string
		for i := 0; i < len(j); i++ {
			t := j[i]
			if IsPluginChannelToken(t) {
				// A separated spelling consumes its value; a joined one does not.
				width := 1
				val := ""
				if !strings.Contains(t, "=") && i+1 < len(j) {
					width, val = 2, j[i+1]
				} else if k := strings.Index(t, "="); k > 0 {
					val = t[k+1:]
				}
				e.Deletions = append(e.Deletions, PlanDeletion{Job: n, Index: i, Flag: flagNameOf(t), Value: val, Width: width})
				i += width - 1
				continue
			}
			out = append(out, t)
		}
		e.Executed = append(e.Executed, out)
	}
	e.Assertions = assertExecutionDerivation(e)
	return e
}

// assertExecutionDerivation is E1–E4. Each is asserted mechanically rather than
// argued: "we only removed plugin flags" is a claim, and a check is a check.
func assertExecutionDerivation(e PlanExecution) []string {
	var bad []string

	// E1 — same job count, same order.
	if len(e.Executed) != len(e.Verified) {
		bad = append(bad, fmt.Sprintf("E1: %d executed jobs for %d verified jobs", len(e.Executed), len(e.Verified)))
		return bad
	}

	// E2 — every executed job is its verified job with exactly the recorded
	// deletions removed, reconstructed independently of the loop that built it.
	del := map[int]map[int]bool{}
	for _, d := range e.Deletions {
		if del[d.Job] == nil {
			del[d.Job] = map[int]bool{}
		}
		for k := 0; k < d.Width; k++ {
			del[d.Job][d.Index+k] = true
		}
	}
	for n := range e.Verified {
		var want []string
		for i, t := range e.Verified[n] {
			if del[n][i] {
				continue
			}
			want = append(want, t)
		}
		if len(want) != len(e.Executed[n]) {
			bad = append(bad, fmt.Sprintf("E2: job %d executes %d tokens, deletion-reconstruction gives %d", n+1, len(e.Executed[n]), len(want)))
			continue
		}
		for i := range want {
			if want[i] != e.Executed[n][i] {
				bad = append(bad, fmt.Sprintf("E2: job %d token %d is %q, deletion-reconstruction gives %q", n+1, i, e.Executed[n][i], want[i]))
				break
			}
		}
		if len(e.Executed[n]) == 0 {
			bad = append(bad, fmt.Sprintf("E2: job %d executes an empty argv", n+1))
		} else if e.Executed[n][0] != e.Verified[n][0] {
			bad = append(bad, fmt.Sprintf("E2: job %d executes %q, verified %q", n+1, e.Executed[n][0], e.Verified[n][0]))
		}
	}

	// E3 — no executed token opens a plugin channel, in either spelling.
	for n, j := range e.Executed {
		for i, t := range j {
			if IsPluginChannelToken(t) {
				bad = append(bad, fmt.Sprintf("E3: job %d token %d %q survives into the executed argv", n+1, i, t))
			}
		}
	}

	// E4 — the graph token never reaches an executed job.
	for n, j := range e.Executed {
		for _, t := range j {
			if t == "-###" {
				bad = append(bad, fmt.Sprintf("E4: job %d executes a graph vector", n+1))
			}
		}
	}
	return bad
}

// ExecutePlan runs the executed job set in plan order, sequentially, stopping at
// the first non-zero exit. The manager creates each job's output parent, because
// the plan names a temporary directory that swiftc would otherwise have created
// for itself.
func ExecutePlan(e PlanExecution, dir string, env *Env) []RunRecord {
	var out []RunRecord
	if !e.OK() {
		return out
	}
	for _, j := range e.Executed {
		for i, t := range j {
			if t == "-o" && i+1 < len(j) {
				_ = os.MkdirAll(filepath.Dir(j[i+1]), 0o755)
			}
		}
	}
	for _, j := range e.Executed {
		rec := runFixed(j[0], j[1:], dir, env)
		out = append(out, rec)
		if rec.Exit != 0 {
			break
		}
	}
	return out
}

// PlanExecutionFailed reports the first non-zero exit and its first error line.
func PlanExecutionFailed(runs []RunRecord) (bool, int, string) {
	for _, r := range runs {
		if r.Exit != 0 {
			return true, r.Exit, firstErrorLine(r.Stderr)
		}
	}
	return false, 0, ""
}

// RetiredCompile is the retired policy: hand the compile vector to swiftc and
// let it spawn its own jobs, plugin channel intact. It is retained only so
// expected-red control C13 can restore it from the same binary and report the
// toolchain macro it admits.
func RetiredCompile(swiftc string, args []string, dir string, env *Env) RunRecord {
	return runFixed(swiftc, args, dir, env)
}
