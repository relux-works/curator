package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func testRuntimePolicy(t *testing.T) (RuntimePolicy, string, string) {
	t.Helper()
	base := t.TempDir()
	real, err := filepath.EvalSymlinks(base)
	if err != nil {
		t.Fatal(err)
	}
	root := filepath.Join(real, "toolchain")
	sdk := filepath.Join(real, "sdk")
	basePrefix := filepath.Join(real, "os-runtime")
	for _, d := range []string{
		filepath.Join(root, "usr", "lib", "swift", "macosx"),
		filepath.Join(sdk, "usr", "lib", "swift"),
		basePrefix,
	} {
		if err := os.MkdirAll(d, 0o755); err != nil {
			t.Fatal(err)
		}
	}
	return RuntimePolicy{
		Roots: []RootRecord{
			{Role: RoleSwiftToolchain, Ordinal: 0, Resolved: root},
			{Role: RolePlatformSDK, Ordinal: 0, Resolved: sdk},
		},
		BaseInstallPrefixes: []string{basePrefix},
	}, root, basePrefix
}

func TestRuntimeAdmissionAcceptsTheMeasuredShape(t *testing.T) {
	pol, root, basePrefix := testRuntimePolicy(t)
	// The measured macOS shape: one in-closure stdlib plus the OS runtime.
	a := AdmitRuntimeLibraryPaths("arm64-apple-macosx26.0",
		[]string{filepath.Join(root, "usr", "lib", "swift", "macosx"), basePrefix}, pol)
	if !a.OK() {
		t.Fatalf("the measured shape was rejected: %v", a.Rejections)
	}
	if a.InClosure != 1 || a.BaseInstall != 1 {
		t.Fatalf("in-closure=%d base=%d", a.InClosure, a.BaseInstall)
	}
	if len(a.Members) != 2 {
		t.Fatalf("members=%v", a.Members)
	}
	if a.Members[0].Relpath != "." && a.Members[1].Relpath != "." {
		t.Fatalf("the base prefix itself must serialize as \".\": %v", a.Members)
	}
}

func TestRuntimeAdmissionRejections(t *testing.T) {
	pol, root, basePrefix := testRuntimePolicy(t)
	tmp := t.TempDir()
	real, _ := filepath.EvalSymlinks(tmp)
	aFile := filepath.Join(real, "file")
	_ = os.WriteFile(aFile, []byte("x"), 0o644)
	dangling := filepath.Join(real, "dangling")
	_ = os.Symlink(filepath.Join(real, "nothing"), dangling)
	outside := filepath.Join(real, "outside")
	_ = os.MkdirAll(outside, 0o755)

	inRoot := filepath.Join(root, "usr", "lib", "swift", "macosx")

	cases := []struct {
		name  string
		paths []string
		pol   RuntimePolicy
		want  string
	}{
		{"empty", nil, pol, "empty"},
		{"relative", []string{"usr/lib/swift"}, pol, "not absolute"},
		{"absent in-root", []string{filepath.Join(root, "usr", "lib", "swift", "linux")}, pol, "does not exist"},
		// A dangling symlink is deliberately a DIFFERENT rejection from an
		// absent entry: it exists and resolves nowhere, so it is neither
		// "inside a root" nor "absent".
		{"dangling", []string{dangling}, pol, "does not resolve"},
		{"regular file", []string{aFile}, pol, "not a directory"},
		{"out of closure", []string{outside}, pol, "outside every fingerprinted root"},
		{"base only", []string{basePrefix}, pol, "no runtimeLibraryPaths entry"},
		{"empty string", []string{""}, pol, "not absolute"},
	}
	for _, c := range cases {
		a := AdmitRuntimeLibraryPaths("t", c.paths, c.pol)
		if a.OK() {
			t.Errorf("%s: admitted", c.name)
			continue
		}
		if !strings.Contains(strings.Join(a.Rejections, "; "), c.want) {
			t.Errorf("%s: rejections %v do not mention %q", c.name, a.Rejections, c.want)
		}
	}

	// R2.7: a base prefix inside a fingerprinted root would launder class A.
	nested := pol
	nested.BaseInstallPrefixes = []string{filepath.Join(root, "usr", "lib", "swift")}
	a := AdmitRuntimeLibraryPaths("t", []string{inRoot}, nested)
	if a.OK() {
		t.Error("a base prefix nested inside a fingerprinted root was admitted")
	}
}

// The retired rule must admit shapes the closed rule rejects, or C11 cannot
// fire.
func TestRetiredRuntimeRuleIsStrictlyLooser(t *testing.T) {
	pol, root, basePrefix := testRuntimePolicy(t)
	looser := 0
	for _, p := range [][]string{nil, {basePrefix}, {"/definitely/not/here"}} {
		if NaiveRuntimeAdmission(p, root) && !AdmitRuntimeLibraryPaths("t", p, pol).OK() {
			looser++
		}
	}
	if looser == 0 {
		t.Fatal("the retired rule admits nothing the closed rule rejects; C11 would not fire")
	}
}

func TestCanonicalRelpath(t *testing.T) {
	root := "/a/b"
	cases := []struct {
		member, want string
		ok           bool
	}{
		{"/a/b", ".", true},
		{"/a/b/usr/bin/ld", "usr/bin/ld", true},
		{"/a/b/usr/bin/link.exe", "usr/bin/link.exe", true},
		{"/a/b/", ".", true},
		{"/a/bc/x", "", false},
		{"/a", "", false},
		{"/A/B/usr", "", false},
	}
	for _, c := range cases {
		got, err := CanonicalRelpath(root, c.member)
		if c.ok != (err == nil) {
			t.Errorf("%q: ok=%v err=%v", c.member, c.ok, err)
			continue
		}
		if c.ok && got != c.want {
			t.Errorf("%q: got %q want %q", c.member, got, c.want)
		}
	}
}

func TestSerializeMembersOrderAndDuplicates(t *testing.T) {
	in := []ClosureMember{
		{Role: "platform-sdk[1]", Relpath: "usr/lib/b"},
		{Role: "swift-toolchain", Relpath: "usr/bin/swiftc"},
		{Role: "platform-sdk[0]", Relpath: "usr/lib/a"},
		{Role: "platform-sdk[0]", Relpath: "usr/lib/a"},
		{Role: "swift-toolchain", Relpath: "usr/bin/clang"},
	}
	got := SerializeMembers(in)
	want := []string{
		"platform-sdk[0]/usr/lib/a",
		"platform-sdk[1]/usr/lib/b",
		"swift-toolchain/usr/bin/clang",
		"swift-toolchain/usr/bin/swiftc",
	}
	if len(got) != len(want) {
		t.Fatalf("got %d members, want %d: %v", len(got), len(want), got)
	}
	for i := range want {
		if got[i].Role+"/"+got[i].Relpath != want[i] {
			t.Errorf("position %d: got %s/%s want %s", i, got[i].Role, got[i].Relpath, want[i])
		}
	}
}

func TestRoleTokenIsStableUnderCardinality(t *testing.T) {
	// Under one-or-more cardinality the FIRST root is already bracketed, so
	// declaring a second root later cannot change the first root's identity.
	if RoleToken(RolePlatformSDK, 0, true) != "platform-sdk[0]" {
		t.Fatal("one-or-more must bracket even a single root")
	}
	if RoleToken(RolePlatformSDK, 0, false) != "platform-sdk" {
		t.Fatal("exactly-one must not bracket")
	}
	if RoleToken(RolePlatformSDK, 0, true) == RoleToken(RolePlatformSDK, 0, false) {
		t.Fatal("the two cardinalities must not share a token")
	}
}
