package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// The cycle-5 repairs, unit level. The integrated proof is S65-S72; these tests
// pin the two binding-model defects the reviewer found by reading the code, so a
// later edit cannot quietly reintroduce either one.

func absentOutputPolicy(t *testing.T) (PlanPolicy, string) {
	t.Helper()
	dir := t.TempDir()
	priv := filepath.Join(dir, "private")
	if err := os.MkdirAll(priv, 0o755); err != nil {
		t.Fatal(err)
	}
	root := filepath.Join(dir, "root")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	exe := filepath.Join(root, "swift-frontend")
	if err := os.WriteFile(exe, []byte("#!/bin/sh\nexit 0\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	resolvedRoot, _ := filepath.EvalSymlinks(root)
	resolvedPriv, _ := filepath.EvalSymlinks(priv)
	return PlanPolicy{
		ToolchainRoot:      resolvedRoot,
		FingerprintedRoots: []string{resolvedRoot},
		OperationPrivate:   []string{resolvedPriv},
	}, dir
}

func TestAbsentOutputBindsAndRechecksItsParent(t *testing.T) {
	pol, dir := absentOutputPolicy(t)
	exe := filepath.Join(dir, "root", "swift-frontend")
	out := filepath.Join(dir, "private", "not-created-yet.o")
	res := VerifyPlan(exe+" -frontend -o "+out+"\n", pol)
	if !res.OK() {
		t.Fatalf("expected the plan to verify, got %v", res.Rejections)
	}
	var ob *PlanBinding
	for i := range res.Bindings {
		if res.Bindings[i].Bucket == BucketOutput {
			ob = &res.Bindings[i]
		}
	}
	if ob == nil {
		t.Fatal("no output binding recorded")
	}
	if ob.Raw != out {
		t.Fatalf("raw should stay the plan token, got %q", ob.Raw)
	}
	if want := filepath.Dir(out); ob.Checked != want {
		t.Fatalf("an absent output must be checked at its parent: got %q want %q", ob.Checked, want)
	}
	// The whole point: the happy path survives, because the output is correctly
	// still absent when the permit is granted.
	if f := Reverify(res.Bindings); len(f) != 0 {
		t.Fatalf("live re-check rejected a valid absent output: %v", f)
	}
	// And the retired one does not, which is why it could not be integrated.
	if f := ReverifyRetired(res.Bindings); len(f) == 0 {
		t.Fatal("the retired re-check was expected to reject the valid absent output")
	}
}

func TestAbsentOutputParentReplacementIsCaught(t *testing.T) {
	pol, dir := absentOutputPolicy(t)
	exe := filepath.Join(dir, "root", "swift-frontend")
	sub := filepath.Join(dir, "private", "sub")
	if err := os.MkdirAll(sub, 0o755); err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(sub, "artifact")
	res := VerifyPlan(exe+" -frontend -o "+out+"\n", pol)
	if !res.OK() {
		t.Fatalf("expected the plan to verify, got %v", res.Rejections)
	}
	if err := os.RemoveAll(sub); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(sub, 0o755); err != nil {
		t.Fatal(err)
	}
	f := Reverify(res.Bindings)
	if len(f) == 0 {
		t.Fatal("replacing the recorded output parent must be a permit finding")
	}
}

func TestAbsentPluginFailsClosedOnNonENOENT(t *testing.T) {
	dir := t.TempDir()
	outer := filepath.Join(dir, "outer")
	if err := os.MkdirAll(filepath.Join(outer, "inner"), 0o755); err != nil {
		t.Fatal(err)
	}
	p := filepath.Join(outer, "inner", "plugins")
	b := []PlanBinding{{Bucket: BucketPlugin, Raw: p, Checked: p, Present: false}}

	if f := Reverify(b); len(f) != 0 {
		t.Fatalf("an absent plugin path must re-check clean while it is absent: %v", f)
	}
	if err := os.Chmod(outer, 0o000); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chmod(outer, 0o755) }()

	f := Reverify(b)
	if len(f) != 1 || !strings.Contains(f[0], "cannot be re-checked") {
		t.Fatalf("a non-ENOENT error is not evidence of absence, got %v", f)
	}
	if rf := ReverifyRetired(b); len(rf) != 0 {
		t.Fatalf("the retired branch was expected to treat the error as absence, got %v", rf)
	}
}

func TestAdmittedSourcesAreBoundByDigest(t *testing.T) {
	dir := t.TempDir()
	good := filepath.Join(dir, "a.swift")
	if err := os.WriteFile(good, []byte("let n = 1\nprint(n)\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	bad := filepath.Join(dir, "b.swift")
	if err := os.WriteFile(bad, []byte("let s = \"x\"\nprint(s)\n"+string(rune(0x23))+"if true\n#endif\n"), 0o644); err != nil {
		t.Fatal(err)
	}

	a := AdmitSources([]string{good})
	if !a.OK() || len(a.Admitted) != 1 || a.Admitted[0].Digest == "" {
		t.Fatalf("an admitted source must carry a digest binding: %+v", a)
	}
	if f := ReverifyAdmittedSources(a); len(f) != 0 {
		t.Fatalf("an unchanged source must re-check clean: %v", f)
	}

	// A rejected file leaves no binding: nothing was admitted, so nothing is
	// re-checked.
	r := AdmitSources([]string{bad})
	if r.OK() || len(r.Admitted) != 0 {
		t.Fatalf("a rejected source must not be bound: %+v", r)
	}
}

func TestAdmittedSourceChangeIsCaughtEvenWithIdentityRestored(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "a.swift")
	original := []byte("let n = 1\nlet m = 2\nprint(n + m)\n")
	if err := os.WriteFile(p, original, 0o644); err != nil {
		t.Fatal(err)
	}
	a := AdmitSources([]string{p})
	if !a.OK() {
		t.Fatalf("expected admission, got %+v", a.Rejections)
	}
	fi, err := os.Stat(p)
	if err != nil {
		t.Fatal(err)
	}

	// One byte is overwritten in place, so size cannot change; mtime is restored
	// afterwards. The byte that changes is a macro selector.
	changed := append([]byte{}, original...)
	changed[0] = 0x40
	if err := os.WriteFile(p, changed, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(p, fi.ModTime(), fi.ModTime()); err != nil {
		t.Fatal(err)
	}
	if identityOf(mustStat(t, p)) != identityOf(fi) {
		t.Fatal("the fixture failed to restore file identity; the test would prove nothing")
	}

	f := ReverifyAdmittedSources(a)
	if len(f) != 1 {
		t.Fatalf("a content change with identity restored must be a finding, got %v", f)
	}
	if !strings.Contains(f[0], DiagSourceMacroSelctor) {
		t.Fatalf("the finding must name the rule the new bytes fail: %q", f[0])
	}
}

func TestAdmittedSourceThatDisappearsFailsClosed(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "a.swift")
	if err := os.WriteFile(p, []byte("let n = 1\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	a := AdmitSources([]string{p})
	if err := os.Remove(p); err != nil {
		t.Fatal(err)
	}
	f := ReverifyAdmittedSources(a)
	if len(f) != 1 || !strings.Contains(f[0], "can no longer be read") {
		t.Fatalf("a vanished admitted source must fail closed, got %v", f)
	}
}

func mustStat(t *testing.T, p string) os.FileInfo {
	t.Helper()
	fi, err := os.Stat(p)
	if err != nil {
		t.Fatal(err)
	}
	return fi
}
