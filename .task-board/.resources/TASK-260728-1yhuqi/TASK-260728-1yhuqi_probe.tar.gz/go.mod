module swiftboundaryprobe

go 1.23
