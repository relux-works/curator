package main

import (
	"fmt"
	"sort"
	"strings"
)

// ---------------------------------------------------------------------------
// The CLOSED per-job flag and operand grammar.
//
// Cycle 2's verifier was total only over tokens it already recognised as
// path-shaped. That left three live holes, all of them measured on Apple Swift
// 6.3.2:
//
//   - an unknown flag beginning with `-` reached the end of the dispatch chain
//     and was accepted without a verdict;
//   - a joined `-flag=value` carrier was never split, so its value was never
//     path-shaped and never checked — `-load-pass-plugin=<path>` is a real one,
//     it exists in this toolchain, and it loads an LLVM pass plugin;
//   - `-Xllvm` and `-Xcc` carry their value into a second option parser, so
//     `-Xllvm -load-pass-plugin=/x.dylib` and `-Xcc -I/x` smuggle a path
//     through a token that is not itself path-shaped.
//
// This grammar is total over EVERY token, not over path-shaped tokens. A token
// is admitted only by being named in a table below; anything else rejects. A
// future toolchain emitting a new token therefore fails closed and requires a
// measured contract update before it can be allowlisted.
// ---------------------------------------------------------------------------

// Value classes. The five path buckets are unchanged and still checked by
// checkBucket; the opaque classes are new and exist so an opaque token cannot
// become an unchecked value carrier.
const (
	classSource     = "source"
	classSearch     = "search"
	classPlugin     = "plugin"
	classExecutable = "executable"
	classOutput     = "output"

	classTriple       = "opaque-triple"
	classSwiftVersion = "opaque-swift-version"
	classModuleName   = "opaque-module-name"
	classSDKVersion   = "opaque-sdk-version"
	classSDKName      = "opaque-sdk-name"
	classXllvm        = "opaque-xllvm"
	classXcc          = "opaque-xcc"
)

// planCommonValued are value-carrying flags admitted in every job kind. Each one
// lands in a path bucket that is boundary-checked, so admitting them in both job
// kinds adds no capability beyond the bucket rule itself.
var planCommonValued = map[string]string{
	"-sdk":          classSearch,
	"-isysroot":     classSearch,
	"--sysroot":     classSearch,
	"-resource-dir": classSearch,
	"-I":            classSearch,
	"-L":            classSearch,
	"-F":            classSearch,

	"-o":               classOutput,
	"-new-driver-path": classExecutable,
	"-primary-file":    classSource,

	"-plugin-path":                   classPlugin,
	"-external-plugin-path":          classPlugin,
	"-in-process-plugin-server-path": classPlugin,
	"-load-plugin-library":           classPlugin,
	"-load-plugin-executable":        classPlugin,
	"-load-resolved-plugin":          classPlugin,
	"-cas-plugin-path":               classPlugin,
}

// planFrontendValued and planLinkValued are the opaque-value flags MEASURED in
// each job kind of the driver's own plan on macOS arm64, Apple Swift 6.3.2.
var planFrontendValued = map[string]string{
	"-target":             classTriple,
	"-swift-version":      classSwiftVersion,
	"-module-name":        classModuleName,
	"-target-sdk-version": classSDKVersion,
	"-target-sdk-name":    classSDKName,
	"-Xllvm":              classXllvm,
	"-Xcc":                classXcc,
}

var planLinkValued = map[string]string{}

// planFrontendNullary and planLinkNullary are the MEASURED no-value flags.
var planFrontendNullary = map[string]bool{
	"-frontend":                         true,
	"-c":                                true,
	"-enable-objc-interop":              true,
	"-stack-check":                      true,
	"-no-color-diagnostics":             true,
	"-O":                                true,
	"-empty-abi-descriptor":             true,
	"-no-auto-bridging-header-chaining": true,
	"-disable-clang-spi":                true,
	"-enable-default-cmo":               true,
}

var planLinkNullary = map[string]bool{
	"-O3": true,
}

// planJoinedValued are the joined spellings admitted anywhere. `--target=` is
// MEASURED in the link job; the three short search spellings are covered so a
// future toolchain cannot smuggle a path through one.
var planJoinedValued = map[string]string{
	"--target=": classTriple,
	"-I":        classSearch,
	"-L":        classSearch,
	"-F":        classSearch,
}

// Job kinds are read off the plan, never off a file name: a job is a frontend
// job exactly when its first argument is `-frontend`.
const (
	jobFrontend = "frontend"
	jobLink     = "link"
)

func jobKind(toks []string) string {
	if len(toks) > 1 && toks[1] == "-frontend" {
		return jobFrontend
	}
	return jobLink
}

// PluginChannelFlags is the closed set of tokens that make a compiler macro or
// plugin implementation loadable. The manager DELETES every one of them from the
// plan before the compile permit; section 4.2 of the reference document states
// the construction and the assertions that hold it.
//
// `-load-pass-plugin=` is joined-only and is listed separately because it takes
// no separated spelling.
var PluginChannelFlags = []string{
	"-plugin-path",
	"-external-plugin-path",
	"-in-process-plugin-server-path",
	"-load-plugin-library",
	"-load-plugin-executable",
	"-load-resolved-plugin",
	"-cas-plugin-path",
	"-cas-plugin-option",
}

// PluginChannelJoinedPrefixes are the joined-only plugin channels.
var PluginChannelJoinedPrefixes = []string{"-load-pass-plugin="}

// IsPluginChannelToken reports whether a token opens a plugin/macro load channel
// in either spelling.
func IsPluginChannelToken(t string) bool {
	for _, f := range PluginChannelFlags {
		if t == f || strings.HasPrefix(t, f+"=") {
			return true
		}
	}
	for _, p := range PluginChannelJoinedPrefixes {
		if strings.HasPrefix(t, p) {
			return true
		}
	}
	return false
}

func matchesCharset(v string, allow func(byte) bool) bool {
	if v == "" {
		return false
	}
	for i := 0; i < len(v); i++ {
		if !allow(v[i]) {
			return false
		}
	}
	return true
}

func isTripleByte(c byte) bool {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '.' || c == '_' || c == '-'
}

func isVersionByte(c byte) bool { return c >= '0' && c <= '9' || c == '.' }

// checkOpaque is the rule that closes the opaque value carrier. An opaque value
// may not be path-shaped, may not carry a path or plugin separator, must match
// its class charset, and — where the manager itself chose the value — must equal
// what the manager chose, byte for byte.
func checkOpaque(res *PlanResult, pol PlanPolicy, class, flag, v string, lineNo int) {
	reject := func(format string, a ...any) {
		res.Rejections = append(res.Rejections, fmt.Sprintf(format, a...))
	}
	if isPathShaped(v) {
		reject("line %d: %s value %q is path-shaped; this flag carries no path", lineNo, flag, v)
		return
	}
	for _, sep := range []string{"/", `\`, "#"} {
		if strings.Contains(v, sep) {
			reject("line %d: %s value %q embeds %q, which this flag does not define", lineNo, flag, v, sep)
			return
		}
	}
	switch class {
	case classTriple:
		if !matchesCharset(v, isTripleByte) {
			reject("line %d: %s value %q is not a target triple", lineNo, flag, v)
			return
		}
		if pol.Triple != "" && v != pol.Triple {
			reject("line %d: %s value %q is not the manager's target %q", lineNo, flag, v, pol.Triple)
		}
	case classSwiftVersion:
		if pol.SwiftVersion != "" && v != pol.SwiftVersion {
			reject("line %d: %s value %q is not the manager's language version %q", lineNo, flag, v, pol.SwiftVersion)
		}
	case classModuleName:
		if !validModuleName(v) {
			reject("line %d: %s value %q is not a curator-swift-module-v1 name", lineNo, flag, v)
			return
		}
		if pol.ModuleName != "" && v != pol.ModuleName {
			reject("line %d: %s value %q is not the manager's module %q", lineNo, flag, v, pol.ModuleName)
		}
	case classSDKVersion:
		if !matchesCharset(v, isVersionByte) {
			reject("line %d: %s value %q is not a dotted version", lineNo, flag, v)
		}
	case classSDKName:
		if !matchesCharset(v, isTripleByte) {
			reject("line %d: %s value %q is not an SDK name", lineNo, flag, v)
		}
	case classXllvm:
		if !inSet(v, pol.XllvmValues) {
			reject("line %d: -Xllvm value %q is not in the measured allow-set %v; a pass-through value is a second option parser and is never admitted unmeasured", lineNo, v, pol.XllvmValues)
		}
	case classXcc:
		if !inSet(v, pol.XccValues) {
			reject("line %d: -Xcc value %q is not in the measured allow-set %v; a pass-through value is a second option parser and is never admitted unmeasured", lineNo, v, pol.XccValues)
		}
	default:
		reject("line %d: %s has no value rule", lineNo, flag)
	}
}

func inSet(v string, set []string) bool {
	for _, s := range set {
		if s == v {
			return true
		}
	}
	return false
}

// validModuleName is the section 3.2 shape, checked here so a plan cannot carry
// a module name the manager could not have derived.
func validModuleName(v string) bool {
	if v == "" || len(v) > 64 {
		return false
	}
	c := v[0]
	if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '_') {
		return false
	}
	for i := 1; i < len(v); i++ {
		c := v[i]
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_') {
			return false
		}
	}
	return true
}

// VerifyPlan is the whole graph-to-permit gate, and it is total over EVERY token
// of every job line. A token is admitted only by a table above; a token no table
// claims is a rejection, whether or not it looks like a path.
func VerifyPlan(planOut string, pol PlanPolicy) PlanResult {
	res := PlanResult{Counts: map[string]int{}}
	reject := func(format string, a ...any) {
		res.Rejections = append(res.Rejections, fmt.Sprintf(format, a...))
	}

	sources := map[string]bool{}
	for _, s := range pol.Sources {
		sources[s] = true
	}
	check := func(bucket, flag, raw string, lineNo int) {
		checkBucket(&res, pol, sources, bucket, flag, raw, lineNo)
	}

	lines, lerr := SplitPlanLines(planOut)
	if lerr != nil {
		reject("the job plan does not satisfy the physical-line grammar: %v", lerr)
		return res
	}

	for li, line := range lines {
		lineNo := li + 1
		toks, err := TokenizeJobLine(line)
		if err != nil {
			reject("line %d does not parse: %v", lineNo, err)
			continue
		}
		if len(toks) == 0 {
			reject("line %d tokenized to nothing", lineNo)
			continue
		}
		res.Jobs = append(res.Jobs, toks)
		check(BucketExecutable, "", toks[0], lineNo)

		kind := jobKind(toks)
		nullary, valued := planFrontendNullary, planFrontendValued
		if kind == jobLink {
			nullary, valued = planLinkNullary, planLinkValued
		}

		for i := 1; i < len(toks); i++ {
			t := toks[i]

			// A response file is an argument the compiler expands into more
			// arguments. It is rejected first, ahead of every other rule, so no
			// later rule can be reached by expansion.
			if strings.HasPrefix(t, "@") {
				reject("line %d: token %q is a response file", lineNo, t)
				continue
			}
			if t == "" {
				reject("line %d: empty token at position %d", lineNo, i)
				continue
			}

			if nullary[t] {
				continue
			}

			// Separated `-flag value` and joined `-flag=value` for every valued
			// flag admitted in this job kind.
			if class, ok := lookupValued(t, valued, planCommonValued); ok {
				v, next, verr := valueOf(toks, i, t, valued, planCommonValued)
				if verr != nil {
					reject("line %d: %v", lineNo, verr)
					continue
				}
				i = next
				dispatchValue(&res, pol, check, class, flagNameOf(t), v, lineNo)
				continue
			}

			// Joined-only spellings, longest prefix first so `--target=` is not
			// read as a bare `-`.
			if prefix, class, v, ok := lookupJoined(t); ok {
				if v == "" {
					reject("line %d: joined flag %q has an empty value", lineNo, prefix)
					continue
				}
				dispatchValue(&res, pol, check, class, prefix, v, lineNo)
				continue
			}

			// Positional operands. A frontend job takes compiled sources; a link
			// job takes intermediates inside operation-private state.
			if !strings.HasPrefix(t, "-") {
				if kind == jobFrontend {
					check(BucketSource, "", t, lineNo)
				} else {
					check(BucketOutput, "", t, lineNo)
				}
				continue
			}

			reject("line %d: token %q is not admitted by the %s job grammar; an unknown token is a rejection, never a skip", lineNo, t, kind)
		}
	}
	sort.SliceStable(res.Bindings, func(a, b int) bool { return res.Bindings[a].Bucket < res.Bindings[b].Bucket })
	return res
}

func flagNameOf(t string) string {
	if i := strings.Index(t, "="); i > 0 {
		return t[:i]
	}
	return t
}

func lookupValued(t string, tables ...map[string]string) (string, bool) {
	name := flagNameOf(t)
	for _, tbl := range tables {
		if c, ok := tbl[name]; ok {
			return c, true
		}
	}
	return "", false
}

func valueOf(toks []string, i int, t string, tables ...map[string]string) (string, int, error) {
	name := flagNameOf(t)
	if strings.HasPrefix(t, name+"=") {
		v := strings.TrimPrefix(t, name+"=")
		if v == "" {
			return "", i, fmt.Errorf("flag %s has an empty value", name)
		}
		return v, i, nil
	}
	if t != name {
		return "", i, fmt.Errorf("flag %s has a joined form this grammar does not define", t)
	}
	if i+1 >= len(toks) {
		return "", i, fmt.Errorf("flag %s has no value", name)
	}
	if toks[i+1] == "" {
		return "", i, fmt.Errorf("flag %s has an empty value", name)
	}
	return toks[i+1], i + 1, nil
}

func lookupJoined(t string) (prefix, class, value string, ok bool) {
	best := ""
	for p := range planJoinedValued {
		if strings.HasPrefix(t, p) && len(t) > len(p) && len(p) > len(best) {
			best = p
		}
	}
	if best == "" {
		return "", "", "", false
	}
	return best, planJoinedValued[best], t[len(best):], true
}

// dispatchValue routes one flag value to its bucket rule or to the opaque rule.
func dispatchValue(res *PlanResult, pol PlanPolicy, check func(bucket, flag, raw string, lineNo int), class, flag, v string, lineNo int) {
	switch class {
	case classPlugin:
		for _, part := range pluginComponents(flag, v, lineNo, func(format string, a ...any) {
			res.Rejections = append(res.Rejections, fmt.Sprintf(format, a...))
		}) {
			check(BucketPlugin, flag, part, lineNo)
		}
	case classSearch:
		check(BucketSearch, flag, v, lineNo)
	case classSource:
		check(BucketSource, flag, v, lineNo)
	case classOutput:
		check(BucketOutput, flag, v, lineNo)
	case classExecutable:
		check(BucketExecutable, flag, v, lineNo)
	default:
		checkOpaque(res, pol, class, flag, v, lineNo)
	}
}
