package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"unicode/utf8"
)

// write drops one byte sequence into a temp file and returns its path, so the
// vectors below can be raw bytes rather than Go strings where that matters.
func writeBytes(t *testing.T, b []byte) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "main.swift")
	if err := os.WriteFile(p, b, 0o644); err != nil {
		t.Fatal(err)
	}
	return p
}

// SA01–SA20: the admitted half. Every one of these is Swift a package may
// plausibly want, and every one carries neither 0x40 nor 0x23.
func TestSourceAdmissionAdmits(t *testing.T) {
	cases := []struct{ id, body string }{
		{"SA01 empty file", ""},
		{"SA02 top-level print", "print(\"hello\")\n"},
		{"SA03 import Foundation", "import Foundation\nprint(Date().timeIntervalSince1970 > 0)\n"},
		{"SA04 Codable struct", "struct I: Codable { let n: Int }\n"},
		{"SA05 Sendable conformance", "struct I: Sendable { let n: Int }\n"},
		{"SA06 actor and async", "actor A { func f() async -> Int { 1 } }\n"},
		{"SA07 generics and where", "func f<T: Equatable>(_ a: T, _ b: T) -> Bool where T: Hashable { a == b }\n"},
		{"SA08 bare regex literal", "let r = /[a-z]+/\n"},
		{"SA09 string interpolation", "let n = 1\nlet s = \"n=\\(n)\"\nprint(s)\n"},
		{"SA10 multiline string", "let s = \"\"\"\na\nb\n\"\"\"\nprint(s)\n"},
		{"SA11 unicode identifier", "let café = 1\nprint(café)\n"},
		{"SA12 emoji in a literal", "print(\"ok ✅\")\n"},
		{"SA13 comment without a sigil", "// ordinary comment\nprint(1)\n"},
		{"SA14 nested block comment", "/* a /* b */ c */\nprint(1)\n"},
		{"SA15 operators", "infix operator <=>: ComparisonPrecedence\n"},
		{"SA16 protocol and extension", "protocol P {}\nextension Int: P {}\n"},
		{"SA17 result builder call site", "let xs = [1, 2, 3].map { $0 * 2 }\nprint(xs)\n"},
		{"SA18 throwing and defer", "func f() throws { defer { print(1) } }\n"},
		{"SA19 fullwidth homoglyph of the sigil", "let \uFF20name = 1\nprint(\uFF20name)\n"},
		{"SA20 high bytes throughout", "let s = \"ÆØÅ — ЖЗИ — 日本語\"\nprint(s)\n"},
	}
	for _, c := range cases {
		a := AdmitSources([]string{writeBytes(t, []byte(c.body))})
		if !a.OK() {
			t.Errorf("%s: expected admission, rejected as %s (%s)", c.id, a.Diagnostic(), a.Rejections[0].Detail)
		}
		if a.BytesScanned != len(c.body) {
			t.Errorf("%s: scanned %d of %d bytes", c.id, a.BytesScanned, len(c.body))
		}
	}
}

// SR01–SR22: the rejected half. The first four are the macro surface itself;
// the rest are the deliberate collateral, listed so that "over-rejecting" is a
// measured inventory rather than a word in a document.
func TestSourceAdmissionRejects(t *testing.T) {
	at, hash := "\x40", "\x23"
	cases := []struct {
		id, body, wantDiag string
		wantByte           int
	}{
		{"SR01 attached macro", "import Observation\n" + at + "Observable final class B {}\n", DiagSourceMacroSelctor, 0x40},
		{"SR02 freestanding expression macro", "let p = " + hash + "Predicate<Int> { $0 > 1 }\n", DiagSourceMacroSelctor, 0x23},
		{"SR03 macro declaration role", at + "freestanding(expression) macro m()\n", DiagSourceMacroSelctor, 0x40},
		{"SR04 externalMacro body", "macro m() = " + hash + "externalMacro(module: \"M\", type: \"T\")\n", DiagSourceMacroSelctor, 0x23},
		{"SR05 @main", at + "main struct App { static func main() {} }\n", DiagSourceMacroSelctor, 0x40},
		{"SR06 @available", at + "available(macOS 13, *) func f() {}\n", DiagSourceMacroSelctor, 0x40},
		{"SR07 @escaping", "func f(_ c: " + at + "escaping () -> Void) {}\n", DiagSourceMacroSelctor, 0x40},
		{"SR08 @inlinable", at + "inlinable public func f() {}\n", DiagSourceMacroSelctor, 0x40},
		{"SR09 @Sendable closure attribute", "let c: " + at + "Sendable () -> Void = {}\n", DiagSourceMacroSelctor, 0x40},
		{"SR10 @_cdecl", at + "_cdecl(\"e\") func e() {}\n", DiagSourceMacroSelctor, 0x40},
		{"SR11 @_silgen_name", at + "_silgen_name(\"s\") func s()\n", DiagSourceMacroSelctor, 0x40},
		{"SR12 property wrapper use", at + "State var n = 0\n", DiagSourceMacroSelctor, 0x40},
		{"SR13 #if conditional compilation", hash + "if os(macOS)\nlet a = 1\n" + hash + "endif\n", DiagSourceMacroSelctor, 0x23},
		{"SR14 #available", "if " + hash + "available(macOS 13, *) {}\n", DiagSourceMacroSelctor, 0x23},
		{"SR15 #file magic literal", "print(" + hash + "file)\n", DiagSourceMacroSelctor, 0x23},
		{"SR16 #selector", "let s = " + hash + "selector(NSObject.description)\n", DiagSourceMacroSelctor, 0x23},
		{"SR17 raw string literal", "let s = " + hash + "\"a\\b\"" + hash + "\n", DiagSourceMacroSelctor, 0x23},
		{"SR18 extended regex literal", "let r = " + hash + "/[a-z]+/" + hash + "\n", DiagSourceMacroSelctor, 0x23},
		{"SR19 sigil inside a string literal", "let e = \"user" + at + "example.com\"\n", DiagSourceMacroSelctor, 0x40},
		{"SR20 sigil inside a line comment", "// see issue " + hash + "42\nprint(1)\n", DiagSourceMacroSelctor, 0x23},
		{"SR21 sigil inside a block comment", "/* " + at + "Observable */\nprint(1)\n", DiagSourceMacroSelctor, 0x40},
		{"SR22 sigil as the only byte", at, DiagSourceMacroSelctor, 0x40},
	}
	for _, c := range cases {
		a := AdmitSources([]string{writeBytes(t, []byte(c.body))})
		if a.OK() {
			t.Errorf("%s: expected rejection, admitted", c.id)
			continue
		}
		if a.Diagnostic() != c.wantDiag {
			t.Errorf("%s: diagnostic %s, want %s", c.id, a.Diagnostic(), c.wantDiag)
		}
		if a.Rejections[0].Byte != c.wantByte {
			t.Errorf("%s: byte 0x%02X, want 0x%02X", c.id, a.Rejections[0].Byte, c.wantByte)
		}
		if a.Class() != "build_package_code_execution_forbidden" {
			t.Errorf("%s: class %s", c.id, a.Class())
		}
	}
}

// SE01–SE10: the encoding rule. It runs first, because the selector scan's claim
// — "no 0x40 byte implies no U+0040 code point" — only holds on well-formed
// UTF-8. Each of these carries NO raw 0x40 and NO raw 0x23, so the selector scan
// alone would admit every one of them.
func TestSourceAdmissionEncoding(t *testing.T) {
	cases := []struct {
		id   string
		body []byte
		want string
	}{
		{"SE01 overlong two-byte U+0040", []byte{0xC1, 0x80, 'O'}, "overlong two-byte"},
		{"SE02 overlong two-byte via 0xC0", []byte{0xC0, 0xA3, 'x'}, "overlong two-byte"},
		{"SE03 overlong three-byte", []byte{0xE0, 0x81, 0x80}, "overlong three-byte"},
		{"SE04 overlong four-byte", []byte{0xF0, 0x80, 0x80, 0x80}, "overlong four-byte"},
		{"SE05 surrogate half", []byte{0xED, 0xA0, 0x80}, "surrogate"},
		{"SE06 above U+10FFFF", []byte{0xF4, 0x90, 0x80, 0x80}, "above U+10FFFF"},
		{"SE07 lead byte above 0xF4", []byte{0xF5, 0x80, 0x80, 0x80}, "above 0xF4"},
		{"SE08 stray continuation", []byte{'a', 0x80, 'b'}, "continuation byte without a lead"},
		{"SE09 truncated sequence at EOF", []byte{'a', 0xE2, 0x82}, "truncated three-byte"},
		{"SE10 NUL", []byte{'a', 0x00, 'b'}, "NUL"},
	}
	for _, c := range cases {
		for _, b := range c.body {
			if b == 0x40 || b == 0x23 {
				t.Fatalf("%s: vector carries a raw sigil byte, so it does not test the encoding rule", c.id)
			}
		}
		a := AdmitSources([]string{writeBytes(t, c.body)})
		if a.OK() {
			t.Errorf("%s: expected rejection, admitted", c.id)
			continue
		}
		if a.Diagnostic() != DiagSourceEncoding {
			t.Errorf("%s: diagnostic %s, want %s", c.id, a.Diagnostic(), DiagSourceEncoding)
		}
		if got := a.Rejections[0].Detail; !strings.Contains(got, c.want) {
			t.Errorf("%s: detail %q does not name %q", c.id, got, c.want)
		}
	}
}

// The hand-written validator must agree with the standard library on every
// byte sequence that does not contain NUL. NUL is the one deliberate
// divergence: it is valid UTF-8 and this rule rejects it anyway.
func TestUTF8ValidatorAgreesWithTheStandardLibrary(t *testing.T) {
	var seqs [][]byte
	for a := 0; a < 256; a++ {
		seqs = append(seqs, []byte{byte(a)})
		for b := 0; b < 256; b++ {
			seqs = append(seqs, []byte{byte(a), byte(b)})
		}
	}
	seqs = append(seqs,
		[]byte("ordinary ascii"), []byte("日本語"), []byte("ÆØÅ"), []byte("\U0001F600"),
		[]byte{0xF4, 0x8F, 0xBF, 0xBF}, []byte{0xF0, 0x90, 0x80, 0x80},
	)
	for _, s := range seqs {
		hasNUL := false
		for _, c := range s {
			if c == 0x00 {
				hasNUL = true
			}
		}
		if hasNUL {
			continue
		}
		_, why, ok := utf8Defect(s)
		if want := utf8.Valid(s); ok != want {
			t.Fatalf("%v: utf8Defect ok=%v (%s), utf8.Valid=%v", s, ok, why, want)
		}
	}
}

// Totality: every input produces exactly one verdict, and a rejection always
// names a rule, a diagnostic and a class.
func TestSourceAdmissionIsTotal(t *testing.T) {
	var bodies [][]byte
	for a := 0; a < 256; a++ {
		bodies = append(bodies, []byte{byte(a)})
		bodies = append(bodies, []byte{'l', 'e', 't', ' ', byte(a), '\n'})
	}
	for _, b := range bodies {
		a := AdmitSources([]string{writeBytes(t, b)})
		if a.OK() {
			if a.Class() != "" || a.Diagnostic() != "" {
				t.Fatalf("%v: admitted but carries a class/diagnostic", b)
			}
			continue
		}
		r := a.Rejections[0]
		if r.Rule == "" || r.Diagnostic == "" || a.Class() != "build_package_code_execution_forbidden" {
			t.Fatalf("%v: rejection is not fully named: %+v", b, r)
		}
	}
}

// An unreadable member of the source set is a rejection, not a skipped file.
func TestSourceAdmissionRejectsUnreadable(t *testing.T) {
	a := AdmitSources([]string{filepath.Join(t.TempDir(), "absent.swift")})
	if a.OK() || a.Diagnostic() != DiagSourceUnreadable {
		t.Fatalf("absent source: OK=%v diagnostic=%s", a.OK(), a.Diagnostic())
	}
}

// Every rejected file is reported, in path order, so a multi-file source set
// produces one deterministic diagnostic rather than whichever file was read
// first.
func TestSourceAdmissionReportsEveryFileInPathOrder(t *testing.T) {
	dir := t.TempDir()
	for _, n := range []string{"c.swift", "a.swift", "b.swift"} {
		if err := os.WriteFile(filepath.Join(dir, n), []byte("\x40x\n"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	a := AdmitSources([]string{
		filepath.Join(dir, "c.swift"), filepath.Join(dir, "a.swift"), filepath.Join(dir, "b.swift"),
	})
	if len(a.Rejections) != 3 {
		t.Fatalf("rejections = %d, want 3", len(a.Rejections))
	}
	for i, want := range []string{"a.swift", "b.swift", "c.swift"} {
		if filepath.Base(a.Rejections[i].Path) != want {
			t.Fatalf("rejection %d is %s, want %s", i, filepath.Base(a.Rejections[i].Path), want)
		}
	}
}

// The retired Stage B is what control C13 restores: it admits everything.
func TestRetiredStageBAdmitsMacroSource(t *testing.T) {
	p := writeBytes(t, []byte(macroSource))
	if AdmitSources([]string{p}).OK() {
		t.Fatal("the live rule admitted macro-selecting source")
	}
	if !AdmitSourcesRetired([]string{p}).OK() {
		t.Fatal("the retired rule rejected something; control C13 would not fire")
	}
}
