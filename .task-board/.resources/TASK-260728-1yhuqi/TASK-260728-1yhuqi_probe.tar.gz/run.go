package main

import (
	"os"
	"path/filepath"
	"strings"
)

// PkgDir is the fixed package directory name. Upstream renders it inside every
// `swift build` diagnostic, so it is a probe-fixed constant of the prediction.
const PkgDir = "probe-pkg"

// rawVersionOf returns the version text exactly as upstream quotes it back. It
// models upstream, which scans the whole manifest, and is therefore deliberately
// wider than Curator's line-1-only classifier. Nothing in the manager reads it.
func rawVersionOf(manifest string) string {
	if raw, _, ok := headerVersion(FirstLine(manifest)); ok {
		return strings.TrimSpace(raw)
	}
	raw, _ := upstreamScanForHeader(manifest)
	return raw
}

func materialize(base string, c Case, compilerFull string) (string, error) {
	dir := filepath.Join(base, c.ID, PkgDir)
	if err := os.RemoveAll(filepath.Join(base, c.ID)); err != nil {
		return "", err
	}
	if err := os.MkdirAll(filepath.Join(dir, "Sources", "probe"), 0o755); err != nil {
		return "", err
	}
	if err := os.WriteFile(filepath.Join(dir, "Package.swift"), []byte(c.Manifest+ManifestBody), 0o644); err != nil {
		return "", err
	}
	if err := os.WriteFile(filepath.Join(dir, "Sources", "probe", "lib.swift"), []byte(SourceBody), 0o644); err != nil {
		return "", err
	}
	return dir, nil
}

// RunCase executes one case: Curator's classifier, then the isolated upstream
// command, then the corroborating one.
func RunCase(tc *Toolchain, base string, c Case, mode recogniseMode, isolatedIsBuild bool) CaseResult {
	res := CaseResult{Case: c, Status: "run"}
	dir, err := materialize(base, c, tc.Normalized)
	if err != nil {
		res.Status = "not_run"
		res.Reason = err.Error()
		return res
	}
	manifest := c.Manifest + ManifestBody
	res.Curator = CuratorClassify(manifest, tc.Normalized)

	raw := rawVersionOf(manifest)
	env := &Env{
		PATH: filepath.Join(base, "empty-path"),
		HOME: filepath.Join(base, c.ID, "home"),
		TMP:  filepath.Join(base, c.ID, "tmp") + string(os.PathSeparator),
	}
	_ = os.MkdirAll(env.PATH, 0o755)
	_ = os.MkdirAll(env.HOME, 0o755)
	_ = os.MkdirAll(strings.TrimSuffix(env.TMP, string(os.PathSeparator)), 0o755)
	cache := filepath.Join(base, c.ID, "cache")
	scratchI := filepath.Join(base, c.ID, "scratch-isolated")
	scratchC := filepath.Join(base, c.ID, "scratch-corroborating")

	isolatedArgs := []string{"package", "--cache-path", cache, "--scratch-path", scratchI, "tools-version"}
	if isolatedIsBuild {
		// Control C4 only: the wrong isolated command folds the host gate in.
		isolatedArgs = []string{"build", "--cache-path", cache, "--scratch-path", scratchI}
	}
	r1 := runFixed(tc.Swift, isolatedArgs, dir, env)
	res.Runs = append(res.Runs, r1)
	if isolatedIsBuild {
		res.Isolated = recognise(corroboratingExpectations(raw, PkgDir, tc.Normalized, tc.CompilerMM), r1.Exit, r1.Stdout, r1.Stderr, ClassAccepted, mode)
	} else {
		res.Isolated = recognise(isolatedExpectations(raw, PkgDir, tc.Normalized, tc.CompilerMM), r1.Exit, r1.Stdout, r1.Stderr, "", mode)
		if res.Isolated.Class == ClassUnknown && r1.Exit == 0 {
			// The accepted outcome of the isolated command is its normalized
			// stdout line, which the expectation set already carries; reaching
			// here means the output was outside the closed set.
			res.Isolated.Class = ClassUnknown
		}
	}

	r2 := runFixed(tc.Swift, []string{"build", "--cache-path", cache, "--scratch-path", scratchC}, dir, env)
	res.Runs = append(res.Runs, r2)
	res.Corroborating = recognise(corroboratingExpectations(raw, PkgDir, tc.Normalized, tc.CompilerMM), r2.Exit, r2.Stdout, r2.Stderr, ClassAccepted, mode)

	res.Agreed = agrees(res.Isolated.Class, res.Corroborating.Class)
	res.Matched = res.Curator == c.Curator &&
		res.Isolated.Class == c.Isolated &&
		res.Corroborating.Class == c.Corroborating
	return res
}

// agrees states when the isolated and the corroborating commands are consistent.
// They answer different questions: the isolated one reports representability,
// the corroborating one adds the floor and the host gate. Agreement therefore
// means "the corroborating outcome is reachable from the isolated one", not
// equality.
func agrees(isolated, corroborating Class) bool {
	if isolated == corroborating {
		return true
	}
	if isolated == ClassAccepted {
		switch corroborating {
		case ClassAccepted, ClassFloor, ClassHostGate:
			return true
		}
	}
	return false
}

// CheckAlignment asserts P1 (no widening) and P2 (no narrowing) outside the
// security partition F.
func CheckAlignment(results []CaseResult) (Alignment, []string) {
	a := Alignment{P1NoWidening: true, P2NoNarrowing: true}
	inF := 0
	var findings []string
	for _, r := range results {
		if r.Status != "run" {
			continue
		}
		if r.Case.SecurityPartition {
			inF++
			continue
		}
		curatorRepresentable := r.Curator == ClassAccepted || r.Curator == ClassFloor || r.Curator == ClassHostGate
		upstreamRepresentable := r.Isolated.Class == ClassAccepted
		if curatorRepresentable && !upstreamRepresentable {
			a.P1NoWidening = false
			findings = append(findings, "P1 widened at "+r.Case.ID)
		}
		if upstreamRepresentable && !curatorRepresentable {
			a.P2NoNarrowing = false
			findings = append(findings, "P2 narrowed at "+r.Case.ID)
		}
	}
	a.SecurityPartitionEmpty = inF == 0
	return a, findings
}
