package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ---------------------------------------------------------------------------
// Structural checks added by review cycle 2, one group per reviewer blocker.
//
//	S28 .. S30   R1  the whole-value compiler-banner grammar
//	S31 .. S34   R2  the executed P2 probe and the runtime-library admission
//	S35 .. S37   R3  canonical role-relative serialization and root ordinals
//	S38 .. S41   R4  the exact vector relation and the physical-line grammar
// ---------------------------------------------------------------------------

// bannerVector is one positive or negative whole-value banner vector.
type bannerVector struct {
	ID     string
	Value  string
	Accept bool
	// Code is the expected rejection code; empty for a positive.
	Code string
	Note string
}

// BannerVectors is the conformance table for the section 1.2 grammar. Every
// negative names the exact rule it violates.
func BannerVectors(measured string) []bannerVector {
	return []bannerVector{
		// --- positives -------------------------------------------------------
		{"BV01", measured, true, "", "the measured banner on this host"},
		{"BV02", "Apple Swift version 0.0.0 (x)", true, "", "the minimal admitted form: zero components, one-byte suffix"},
		{"BV03", "Apple Swift version 999999999.0.1 (swiftlang-1 clang-2)", true, "", "nine-digit component, the maximum"},
		{"BV04", "Apple Swift version 6.3.2 (a b c d/e-f_g.h+i,j:k;l)", true, "", "the suffix admits every printable ASCII byte except parentheses"},

		// --- negatives: prefix ----------------------------------------------
		{"BV05", "Swift version 6.1 (swift-6.1-RELEASE)", false, "banner_prefix", "the open-source banner is not admitted without its own measurement"},
		{"BV06", " Apple Swift version 6.3.2 (x)", false, "banner_prefix", "a leading space is not part of the prefix"},
		{"BV07", "apple swift version 6.3.2 (x)", false, "banner_prefix", "the prefix is byte-exact, not case-insensitive"},
		{"BV08", "Apple Swift version  6.3.2 (x)", false, "banner_version_component", "two spaces after the prefix put an empty major component in front"},

		// --- negatives: suffix and trailing bytes ----------------------------
		{"BV09", "Apple Swift version 6.3.2 x", false, "banner_parens", "the exact value the retired prefix-only parser accepted"},
		{"BV10", "Apple Swift version 6.3.2 ()", false, "banner_suffix_empty", "an empty suffix is rejected; this is where the two documented regexes disagreed"},
		{"BV11", "Apple Swift version 6.3.2 (x) ", false, "banner_trailing", "one trailing space after the suffix"},
		{"BV12", "Apple Swift version 6.3.2 (x)y", false, "banner_trailing", "a trailing byte after the closing paren"},
		{"BV13", "Apple Swift version 6.3.2", false, "banner_parens", "no suffix at all"},
		{"BV14", "Apple Swift version 6.3.2 (a (b) c)", false, "banner_parens", "nested parentheses are not admitted; sbyte excludes both"},
		{"BV15", "Apple Swift version 6.3.2 x)", false, "banner_parens", "a closing paren with no opening one"},
		{"BV16", "Apple Swift version 6.3.2(x)", false, "banner_separator", "the '(' must be preceded by exactly one SP"},
		{"BV17", "Apple Swift version 6.3.2 (" + strings.Repeat("x", bannerSuffixMaxBytes+1) + ")", false, "banner_suffix_too_long", "the suffix bound"},

		// --- negatives: version shape ----------------------------------------
		{"BV18", "Apple Swift version 6.3 (x)", false, "banner_version_shape", "two components"},
		{"BV19", "Apple Swift version 6.3.2.1 (x)", false, "banner_version_shape", "four components"},
		{"BV20", "Apple Swift version 6.03.2 (x)", false, "banner_version_component", "a leading zero has a second spelling and is rejected"},
		{"BV21", "Apple Swift version 6.3.2b (x)", false, "banner_version_component", "a prerelease marker is not admitted"},
		{"BV22", "Apple Swift version 6..2 (x)", false, "banner_version_component", "an empty minor component"},
		{"BV23", "Apple Swift version 1234567890.0.0 (x)", false, "banner_version_component", "ten digits exceeds the component bound"},

		// --- negatives: byte class -------------------------------------------
		{"BV24", "Apple Swift version 6.3.2 (x)\n", false, "banner_byte", "a trailing LF"},
		{"BV25", "Apple Swift version 6.3.2 (x)\r", false, "banner_byte", "a trailing CR"},
		{"BV26", "Apple Swift version 6.3.2 (x\ny)", false, "banner_byte", "an embedded LF inside the suffix"},
		{"BV27", "Apple Swift version 6.3.2 (x\x00y)", false, "banner_byte", "an embedded NUL"},
		{"BV28", "Apple Swift version 6.3.2 (x\ty)", false, "banner_byte", "an embedded TAB"},
		{"BV29", "Apple Swift version 6.3.2 (x\x7fy)", false, "banner_byte", "an embedded DEL"},
		{"BV30", "Apple Swift version 6.3.2 (café)", false, "banner_byte", "a non-ASCII byte; the value is ASCII-only so it is its own canonical form"},
		{"BV31", "", false, "banner_empty", "the empty value"},
		{"BV32", "Apple Swift version 6.3.2 (" + strings.Repeat("y", bannerMaxBytes) + ")", false, "banner_too_long", "the whole-value bound is checked before any scan"},
	}
}

func bannerChecks(h *harness) []Structural {
	tc := h.tc
	vs := BannerVectors(tc.CompilerVersion)

	// S28 — the grammar is total and every vector lands where it is declared.
	var wrong []string
	pos, neg := 0, 0
	for _, v := range vs {
		b, rej := ParseCompilerBanner(v.Value)
		if (b == nil) == (rej == nil) {
			wrong = append(wrong, v.ID+": neither total nor exclusive")
			continue
		}
		if v.Accept {
			pos++
			if rej != nil {
				wrong = append(wrong, fmt.Sprintf("%s should be accepted, rejected %s", v.ID, rej.Code))
			}
			continue
		}
		neg++
		switch {
		case rej == nil:
			wrong = append(wrong, fmt.Sprintf("%s should be rejected as %s, accepted", v.ID, v.Code))
		case rej.Code != v.Code:
			wrong = append(wrong, fmt.Sprintf("%s rejected as %s, declared %s", v.ID, rej.Code, v.Code))
		}
	}
	out := []Structural{{
		ID:       "S28-compiler-banner-whole-value-grammar",
		Title:    "one whole-value banner grammar, total over every vector, with the declared rejection code",
		Expected: fmt.Sprintf("%d positives accepted, %d negatives rejected with the exact code", pos, neg),
		Observed: fmt.Sprintf("%d vectors, %d mismatches %s", len(vs), len(wrong), clipTo(strings.Join(wrong, "; "), 400)),
		Verdict:  verdict(len(wrong) == 0),
		ManagerObligation: "Decision 0011 section 11, reference section 1.2, the registry `normalization` field and this " +
			"parser state one grammar. The parser consumes the WHOLE value: there is no prefix match and no unexamined suffix.",
	}}

	// S29 — the live banner is consumed entirely, suffix included.
	b, rej := ParseCompilerBanner(tc.CompilerVersion)
	rebuilt := ""
	if b != nil {
		rebuilt = fmt.Sprintf("%s%d.%d.%d (%s)", bannerPrefix, b.Major, b.Minor, b.Patch, b.Suffix)
	}
	out = append(out, Structural{
		ID:       "S29-live-banner-consumed-whole",
		Title:    "the measured banner reconstructs byte-for-byte from the parsed components",
		Expected: "reconstruction equals the raw value, so no byte went unexamined",
		Observed: fmt.Sprintf("raw=%q len=%d rebuilt-equal=%v suffix=%q rej=%s",
			tc.CompilerVersion, len(tc.CompilerVersion), rebuilt == tc.CompilerVersion, tc.BannerSuffix, rej.String()),
		Verdict: verdict(rej == nil && rebuilt == tc.CompilerVersion && tc.BannerSuffix != ""),
		ManagerObligation: "Recording the suffix is how the fixture proves it was parsed rather than skipped. A parser that " +
			"stops at the first space cannot reconstruct the value.",
	})

	// S30 — the retired parser and the grammar genuinely disagree, so the
	// change is load-bearing rather than cosmetic.
	var admitted []string
	for _, v := range vs {
		if v.Accept {
			continue
		}
		if _, ok := NaiveCompilerVersionPrefixOnly(v.Value); ok {
			admitted = append(admitted, v.ID)
		}
	}
	out = append(out, Structural{
		ID:       "S30-retired-prefix-parser-is-strictly-looser",
		Title:    "the retired prefix-only parser admits values the whole-value grammar rejects",
		Expected: "at least one negative vector admitted by the retired parser",
		Observed: fmt.Sprintf("%d of %d negatives admitted: %s", len(admitted), len(vs)-pos, strings.Join(admitted, ", ")),
		Verdict:  verdict(len(admitted) > 0),
		ManagerObligation: "This is the evidence that the cycle-2 narrowing closes a real hole. Control C10 restores the " +
			"retired parser and fails on exactly this set.",
	})
	return out
}

// ---------------------------------------------------------------------------
// R2 — the executed P2 probe and the runtime-library admission
// ---------------------------------------------------------------------------

func runtimeAdmissionChecks(h *harness) []Structural {
	tc := h.tc
	a := tc.Admission
	roots := []RootRecord{
		{Role: RoleSwiftToolchain, Ordinal: 0, Resolved: resolveOr(tc.Root)},
		{Role: RolePlatformSDK, Ordinal: 0, Resolved: resolveOr(tc.DeclaredSDK)},
	}
	pol := RuntimePolicy{Roots: roots, BaseInstallPrefixes: baseInstallPrefixes("darwin")}

	// S31 — P2 was actually run, for the exact compile triple.
	ranP2 := len(a.Probe.Argv) > 0 &&
		containsAll(a.Probe.Argv, []string{"-print-target-info", "-target", tc.Triple}) &&
		a.Probe.Exit == 0
	out := []Structural{{
		ID:       "S31-p2-executed-for-the-compile-triple",
		Title:    "probe P2 runs with the exact triple the compile vector passes",
		Expected: fmt.Sprintf("argv carries -print-target-info -target %s and exits 0", tc.Triple),
		Observed: fmt.Sprintf("argv=%v exit=%d", a.Probe.Argv, a.Probe.Exit),
		Verdict:  verdict(ranP2),
		ManagerObligation: "The admission is defined on the triple the compile uses. Reading P1 and assuming P2 agrees " +
			"is an assumption about a host, not a contract.",
		Runs: []RunRecord{a.Probe},
	}}

	// S32 — the admission classified every entry and found an in-closure stdlib.
	var cls []string
	for _, e := range a.Entries {
		cls = append(cls, fmt.Sprintf("%s=%s", e.Class, e.Relpath))
	}
	out = append(out, Structural{
		ID:       "S32-runtime-library-admission",
		Title:    "every runtimeLibraryPaths entry resolves to a directory in a declared class, with at least one in-closure",
		Expected: "0 rejections, in-closure >= 1, every entry classified",
		Observed: fmt.Sprintf("entries=%d in-closure=%d base-installation=%d rejections=%d %v; p1==p2=%v",
			len(a.Entries), a.InClosure, a.BaseInstall, len(a.Rejections), cls, a.P1EqualsP2),
		Verdict: verdict(a.OK() && a.InClosure > 0 && len(a.Entries) == len(a.Raw)),
		ManagerObligation: "MEASURED: this host returns an OS base-installation entry (/usr/lib/swift) outside every " +
			"fingerprinted root, so a naive in-root-only rule would reject the measured host. The closed set is " +
			"in-closure, declared base-installation, or reject.",
	})

	// S33 — the negatives. Each one is a real filesystem state, not a fiction.
	type rvec struct {
		id    string
		paths []string
		pol   RuntimePolicy
		why   string
	}
	tmp := filepath.Join(h.base, "rt")
	_ = os.MkdirAll(tmp, 0o755)
	afile := filepath.Join(tmp, "a-file")
	_ = os.WriteFile(afile, []byte("x"), 0o644)
	dangling := filepath.Join(tmp, "dangling")
	_ = os.Remove(dangling)
	_ = os.Symlink(filepath.Join(tmp, "nothing-here"), dangling)
	outside := filepath.Join(tmp, "outside-dir")
	_ = os.MkdirAll(outside, 0o755)
	escape := filepath.Join(tmp, "escape")
	_ = os.Remove(escape)
	_ = os.Symlink(outside, escape)

	inClosure := ""
	for _, e := range a.Entries {
		if e.Class == RuntimeClassInClosure {
			inClosure = e.Raw
		}
	}
	badPolNested := RuntimePolicy{Roots: roots, BaseInstallPrefixes: []string{filepath.Join(tc.Root, "usr", "lib", "swift")}}

	vecs := []rvec{
		{"RV01", nil, pol, "an empty list leaves the standard-library closure unbounded"},
		{"RV02", []string{"usr/lib/swift/macosx"}, pol, "a relative entry"},
		{"RV03", []string{filepath.Join(tc.Root, "usr", "lib", "swift", "no-such-target")}, pol, "an absent in-root entry — the unserved-target case"},
		{"RV04", []string{dangling}, pol, "a dangling symlink is neither present nor absent"},
		{"RV05", []string{afile}, pol, "an entry that resolves to a regular file"},
		{"RV06", []string{outside}, pol, "an existing directory outside every root and every base prefix"},
		{"RV07", []string{escape}, pol, "a symlink that is lexically nowhere but resolves outside every root"},
		{"RV08", []string{"/usr/lib/swift"}, pol, "base-installation only: no in-closure standard library"},
		{"RV09", []string{inClosure}, badPolNested, "a base prefix declared inside a fingerprinted root would launder class A"},
		{"RV10", []string{""}, pol, "an empty entry"},
	}
	var admittedNeg []string
	for _, v := range vecs {
		if AdmitRuntimeLibraryPaths(tc.Triple, v.paths, v.pol).OK() {
			admittedNeg = append(admittedNeg, v.id)
		}
	}
	out = append(out, Structural{
		ID:       "S33-runtime-admission-negatives-all-reject",
		Title:    "every runtime-library negative vector rejects",
		Expected: fmt.Sprintf("all %d vectors rejected", len(vecs)),
		Observed: fmt.Sprintf("%d admitted: %v", len(admittedNeg), admittedNeg),
		Verdict:  verdict(len(admittedNeg) == 0),
		ManagerObligation: "Empty, relative, absent, dangling, non-directory, out-of-closure, symlink-escaping and " +
			"base-installation-only lists are all Stage A failures with build_toolchain_platform_unsupported.",
	})

	// S34 — the base-installation class contributes nothing to the job plan.
	// This is what keeps the escape hatch narrow: it is an admission-surface
	// fact about where the runtime could live, never a path handed to a child.
	_, planOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "rtplan"), nil, h.defaultSources()), h.srcDir, h.cleanEnv())
	baseHits := 0
	var baseTokens []string
	if lines, err := SplitPlanLines(planOut); err == nil {
		for _, l := range lines {
			toks, terr := TokenizeJobLine(l)
			if terr != nil {
				continue
			}
			for _, t := range toks {
				for _, b := range pol.BaseInstallPrefixes {
					if t == b || strings.HasPrefix(t, b+"/") {
						baseHits++
						baseTokens = append(baseTokens, t)
					}
				}
			}
		}
	}
	out = append(out, Structural{
		ID:       "S34-base-installation-absent-from-the-plan",
		Title:    "no declared base-installation prefix appears as a token in the verified job plan",
		Expected: "0 tokens under any base-installation prefix",
		Observed: fmt.Sprintf("%d tokens %v (prefixes %v)", baseHits, distinct(baseTokens), pol.BaseInstallPrefixes),
		Verdict:  verdict(baseHits == 0),
		ManagerObligation: "The class-B escape hatch admits a probe-reported directory, not a compiler input. Section 4.1's " +
			"plan verification stays total and admits no base-installation path in any bucket.",
	})
	return out
}

func containsAll(hay []string, needles []string) bool {
	for _, n := range needles {
		found := false
		for _, h := range hay {
			if h == n {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

// ---------------------------------------------------------------------------
// R3 — canonical role-relative serialization
// ---------------------------------------------------------------------------

func serializationChecks(h *harness) []Structural {
	tc := h.tc
	root := resolveOr(tc.Root)

	// S35 — the real members serialize to portable relpaths, through the same
	// code a Windows implementation would run.
	//
	// Both projections are recorded, because they are different facts and both
	// enter identity:
	//
	//	invoked   the relpath as SPELLED — what the manager or the plan names.
	//	          On this host that is four members.
	//	resolved  the relpath the spelling RESOLVES to — what actually executes.
	//	          MEASURED: swiftc is a symlink to swift-frontend, so the four
	//	          spellings collapse to three distinct files.
	//
	// Binding only `resolved` would lose the fact that the driver invokes
	// `usr/bin/swiftc`; binding only `invoked` would let a re-pointed symlink
	// keep one identity while executing other bytes.
	type m struct{ label, path string }
	members := []m{
		{"launcher", tc.Swiftc}, {"frontend", tc.Frontend},
		{"c-driver", tc.Clang}, {"linker", tc.Linker},
	}
	var got []string
	var invoked, resolved []ClosureMember
	ok := true
	for _, mm := range members {
		invRel, ierr := CanonicalRelpath(root, mm.path)
		real, in := resolveInside(mm.path, tc.Root)
		if !in || ierr != nil {
			ok = false
			got = append(got, mm.label+"=<outside or unserializable>")
			continue
		}
		rel, err := CanonicalRelpath(root, real)
		if err != nil {
			ok = false
			got = append(got, mm.label+"=<"+err.Error()+">")
			continue
		}
		if strings.ContainsAny(rel, `\`) || strings.HasPrefix(rel, "/") ||
			strings.ContainsAny(invRel, `\`) || strings.HasPrefix(invRel, "/") {
			ok = false
		}
		invoked = append(invoked, ClosureMember{Role: RoleSwiftToolchain, Relpath: invRel})
		resolved = append(resolved, ClosureMember{Role: RoleSwiftToolchain, Relpath: rel})
		got = append(got, fmt.Sprintf("%s invoked=%s resolved=%s", mm.label, invRel, rel))
	}
	invoked = SerializeMembers(invoked)
	resolved = SerializeMembers(resolved)
	// MEASURED: 4 spellings, 3 distinct files. Asserting the inequality is what
	// keeps "two of them are one file" a measurement rather than a sentence.
	if len(invoked) != 4 || len(resolved) != 3 {
		ok = false
	}
	got = append(got, fmt.Sprintf("| distinct invoked=%d distinct resolved=%d", len(invoked), len(resolved)))
	out := []Structural{{
		ID:       "S35-canonical-role-relative-serialization",
		Title:    "every closure member serializes to a portable role-relative path with U+002F separators",
		Expected: "no absolute path, no volume prefix, no native separator, no . or .. component; 4 invoked, 3 resolved",
		Observed: strings.Join(got, " "),
		Verdict:  verdict(ok),
		ManagerObligation: "Identity may not name a filesystem path. The same function serializes `usr/bin/ld` on macOS " +
			"and whatever P3 resolves on Windows, so the Windows linker member needs no new semantics.",
	}}

	// S36 — the serialization negatives.
	outside := filepath.Dir(root)
	negs := []struct{ id, root, member, why string }{
		{"SV01", root, outside, "an ancestor is not inside the root"},
		{"SV02", root, root + "-sibling", "a lexical prefix that is not a component prefix"},
		{"SV03", root, strings.ToUpper(root), "a case variant fails closed on a case-insensitive volume"},
		// Built by concatenation, not filepath.Join: Join would lexically clean
		// the ".." away and the vector would test nothing. A resolved path never
		// carries "..", so this is the defensive arm of the rule.
		{"SV04", root, root + "/usr/../usr/bin", "an unresolved .. component"},
		{"SV05", "", root, "an empty root"},
		{"SV06", root, "", "an empty member"},
	}
	var accepted []string
	for _, n := range negs {
		if _, err := CanonicalRelpath(n.root, n.member); err == nil {
			accepted = append(accepted, n.id)
		}
	}
	// The identity case must still work.
	self, selfErr := CanonicalRelpath(root, root)
	out = append(out, Structural{
		ID:       "S36-serialization-negatives-and-self",
		Title:    "the serializer rejects non-containment and renders a root as exactly \".\"",
		Expected: fmt.Sprintf("all %d negatives rejected; root-relative-to-itself is \".\"", len(negs)),
		Observed: fmt.Sprintf("%d accepted %v; self=%q err=%v", len(accepted), accepted, self, selfErr),
		Verdict:  verdict(len(accepted) == 0 && selfErr == nil && self == "."),
		ManagerObligation: "Containment is compared component-wise and byte-exactly, so a case variant or a sibling " +
			"whose name shares a prefix cannot serialize as a member.",
	})

	// S37 — ordinal role tokens: the one-or-more case a Windows platform-sdk
	// declaration lands in. The bracketed token is used even for a single root
	// under one-or-more cardinality, so adding a second root later cannot
	// silently change the identity of the first.
	single := RoleToken(RolePlatformSDK, 0, false)
	multi0 := RoleToken(RolePlatformSDK, 0, true)
	multi1 := RoleToken(RolePlatformSDK, 1, true)
	dedup := SerializeMembers([]ClosureMember{
		{Role: multi1, Relpath: "usr/lib/b"},
		{Role: multi0, Relpath: "usr/lib/a"},
		{Role: RoleSwiftToolchain, Relpath: "usr/bin/swiftc"},
		{Role: multi0, Relpath: "usr/lib/a"},
	})
	var order []string
	for _, d := range dedup {
		order = append(order, d.Role+"/"+d.Relpath)
	}
	wantOrder := []string{
		RolePlatformSDK + "[0]/usr/lib/a",
		RolePlatformSDK + "[1]/usr/lib/b",
		RoleSwiftToolchain + "/usr/bin/swiftc",
	}
	out = append(out, Structural{
		ID:       "S37-root-ordinals-order-and-duplicates",
		Title:    "one-or-more roles carry an ordinal token; members sort by (role, relpath) and duplicates collapse",
		Expected: fmt.Sprintf("exactly-one=%q one-or-more=[%q,%q]; ordered %v", RolePlatformSDK, multi0, multi1, wantOrder),
		Observed: fmt.Sprintf("single=%q multi=[%q,%q]; ordered %v (from 4 inputs)", single, multi0, multi1, order),
		Verdict:  verdict(single == RolePlatformSDK && multi0 == RolePlatformSDK+"[0]" && multi1 == RolePlatformSDK+"[1]" && equalStrings(order, wantOrder)),
		ManagerObligation: "Windows declares one-or-more platform-sdk roots. The ordinal token, the declaration order and " +
			"the duplicate rule are fixed here so the admission task mints a schema rather than inventing one.",
	})
	return out
}

func equalStrings(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// ---------------------------------------------------------------------------
// R4 — the exact vector relation and the physical-line grammar
// ---------------------------------------------------------------------------

func vectorAndLineChecks(h *harness) []Structural {
	tc := h.tc
	srcs := h.defaultSources()
	compile := h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "eq2"), nil, srcs)
	graph := h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "eq2"), nil, srcs)
	rel := CheckVectorRelation(tc.Swiftc, compile, graph)

	out := []Structural{{
		ID:       "S38-exact-vector-relation",
		Title:    "graph_args = [\"-###\"] ++ compile_args, and the insertion is at graph_argv index 1, exactly once",
		Expected: "len+1, element-wise equality, one occurrence at complete-argv index 1, zero in compile_argv",
		Observed: fmt.Sprintf("graph_args=%d compile_args=%d insertion_index=%d occurrences=%d findings=%v",
			rel.GraphLen, rel.CompileLen, rel.InsertionIndex, rel.GraphOccurrence, rel.Findings),
		Verdict: verdict(rel.OK),
		ManagerObligation: "Stated as an insertion rather than \"one differing token at index 0\": read as complete argv the " +
			"program occupies index 0 and `-###` is inserted after it. Both vectors come from one builder.",
	}}

	// S39 — negatives for the vector relation.
	negs := []struct {
		id       string
		prog     string
		comp, gr []string
		why      string
	}{
		{"VV01", tc.Swiftc, compile, compile, "no insertion at all"},
		{"VV02", tc.Swiftc, compile, append([]string{"-###", "-###"}, compile...), "inserted twice"},
		{"VV03", tc.Swiftc, compile, append(append([]string{}, compile...), "-###"), "appended instead of inserted"},
		{"VV04", tc.Swiftc, append([]string{"-###"}, compile...), append([]string{"-###", "-###"}, compile...), "the compile vector carries it too"},
		{"VV05", tc.Swiftc, compile, append([]string{"-###", "-Onone"}, compile[1:]...), "a second token changed under cover of the insertion"},
	}
	var passed []string
	for _, n := range negs {
		if CheckVectorRelation(n.prog, n.comp, n.gr).OK {
			passed = append(passed, n.id)
		}
	}
	out = append(out, Structural{
		ID:       "S39-vector-relation-negatives",
		Title:    "a drifted, doubled, appended or co-mutated vector pair is rejected",
		Expected: fmt.Sprintf("all %d negatives rejected", len(negs)),
		Observed: fmt.Sprintf("%d accepted %v", len(passed), passed),
		Verdict:  verdict(len(passed) == 0),
		ManagerObligation: "If the pair could differ by anything but the single insertion, the verified plan would not be " +
			"the executed plan and the graph phase would prove nothing.",
	})

	// S40 — the live plan satisfies the physical-line grammar, measured.
	_, planOut, planErr := runFixedRaw(tc.Swiftc, graph, h.srcDir, h.cleanEnv())
	lines, lerr := SplitPlanLines(planOut)
	crCount := strings.Count(planOut, "\r")
	lastLF := len(planOut) > 0 && planOut[len(planOut)-1] == '\n'
	maxLine := 0
	for _, l := range lines {
		if len(l) > maxLine {
			maxLine = len(l)
		}
	}
	out = append(out, Structural{
		ID:       "S40-physical-line-grammar-live",
		Title:    "the emitted plan is LF-terminated, carries no CR and no other control byte, and every line is non-empty",
		Expected: "final byte LF, 0 CR, lines parse, stderr empty",
		Observed: fmt.Sprintf("bytes=%d final-LF=%v CR=%d lines=%d longest=%d err=%v stderr-bytes=%d",
			len(planOut), lastLF, crCount, len(lines), maxLine, lerr, len(planErr)),
		Verdict: verdict(lerr == nil && crCount == 0 && lastLF && len(lines) > 0 && len(planErr) == 0),
		ManagerObligation: "LF is the only terminator on every platform and the terminal LF is mandatory. A Windows " +
			"implementation reads the child's stdout as a binary stream so no CRLF translation can occur.",
	})

	// S41 — the line-grammar negatives, including the CR family that the
	// retired splitter silently normalized.
	body := "/bin/true -x"
	lnegs := []struct{ id, plan, why string }{
		{"LV01", "", "the empty plan"},
		{"LV02", body, "no terminal LF; the read is truncated"},
		{"LV03", body + "\r\n", "CRLF"},
		{"LV04", body + "\r" + "\n", "a bare CR before the terminator"},
		{"LV05", "a\rb\n", "a bare CR mid-line"},
		{"LV06", body + "\n\n", "a blank line"},
		{"LV07", "\n" + body + "\n", "a leading blank line"},
		{"LV08", body + "\n\n" + body + "\n", "a blank line between jobs"},
		{"LV09", "a\x00b\n", "an embedded NUL"},
		{"LV10", "a\tb\n", "an embedded TAB"},
		{"LV11", "a\x7fb\n", "an embedded DEL"},
		{"LV12", strings.Repeat("x", planMaxLineBytes+1) + "\n", "a line past the line bound"},
	}
	var lAdmitted, lNaiveAdmitted []string
	for _, n := range lnegs {
		if _, err := SplitPlanLines(n.plan); err == nil {
			lAdmitted = append(lAdmitted, n.id)
		}
		if _, err := NaiveSplitPlanLines(n.plan); err == nil {
			lNaiveAdmitted = append(lNaiveAdmitted, n.id)
		}
	}
	out = append(out, Structural{
		ID:       "S41-physical-line-grammar-negatives",
		Title:    "every malformed physical-line family rejects, and the retired splitter admitted several of them",
		Expected: fmt.Sprintf("all %d rejected by the strict grammar; the retired splitter admits at least one", len(lnegs)),
		Observed: fmt.Sprintf("strict admitted %d %v; retired admitted %d %v",
			len(lAdmitted), lAdmitted, len(lNaiveAdmitted), lNaiveAdmitted),
		Verdict: verdict(len(lAdmitted) == 0 && len(lNaiveAdmitted) > 0),
		ManagerObligation: "The reference grammar rejects every control byte and the verifier no longer strips a trailing " +
			"CR, so the documented rule and the implementation are the same rule. Control C12 restores the retired splitter.",
	})
	return out
}
