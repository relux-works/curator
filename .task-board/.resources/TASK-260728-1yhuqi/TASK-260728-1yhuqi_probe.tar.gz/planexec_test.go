package main

import "testing"

func TestStripPluginChannelRemovesExactlyTheChannel(t *testing.T) {
	jobs := [][]string{{
		"/root/bin/swift-frontend", "-frontend", "-c",
		"-external-plugin-path", "/a#/b",
		"-in-process-plugin-server-path", "/c.dylib",
		"-plugin-path", "/d",
		"-load-pass-plugin=/e.dylib",
		"-sdk", "/sdk",
		"-o", "/priv/out.o",
	}}
	e := StripPluginChannel(jobs)
	if !e.OK() {
		t.Fatalf("assertions failed on a well-formed deletion: %v", e.Assertions)
	}
	if len(e.Deletions) != 4 {
		t.Fatalf("expected 4 deletions, got %d: %+v", len(e.Deletions), e.Deletions)
	}
	want := []string{"/root/bin/swift-frontend", "-frontend", "-c", "-sdk", "/sdk", "-o", "/priv/out.o"}
	if len(e.Executed[0]) != len(want) {
		t.Fatalf("executed argv %v, want %v", e.Executed[0], want)
	}
	for i := range want {
		if e.Executed[0][i] != want[i] {
			t.Fatalf("token %d = %q, want %q", i, e.Executed[0][i], want[i])
		}
	}
}

func TestStripPluginChannelKeepsJobCountAndOrder(t *testing.T) {
	jobs := [][]string{
		{"/root/a", "-frontend", "-plugin-path", "/p"},
		{"/root/b", "/priv/x.o", "-o", "/priv/bin"},
	}
	e := StripPluginChannel(jobs)
	if !e.OK() {
		t.Fatalf("assertions failed: %v", e.Assertions)
	}
	if len(e.Executed) != 2 || e.Executed[0][0] != "/root/a" || e.Executed[1][0] != "/root/b" {
		t.Fatalf("job order or executables changed: %v", e.Executed)
	}
}

// E3 and E4 are assertions rather than arguments, so a derivation that left a
// channel or a graph token behind has to be reported.
func TestExecutionAssertionsCatchASurvivingChannel(t *testing.T) {
	e := PlanExecution{
		Verified: [][]string{{"/root/a", "-frontend", "-plugin-path", "/p"}},
		Executed: [][]string{{"/root/a", "-frontend", "-plugin-path", "/p"}},
	}
	if bad := assertExecutionDerivation(e); len(bad) == 0 {
		t.Fatal("a surviving plugin channel must be reported")
	}
	e2 := PlanExecution{
		Verified: [][]string{{"/root/a", "-###", "-frontend"}},
		Executed: [][]string{{"/root/a", "-###", "-frontend"}},
	}
	if bad := assertExecutionDerivation(e2); len(bad) == 0 {
		t.Fatal("a graph token in an executed job must be reported")
	}
}

// E2 reconstructs the executed argv from the deletion record. A derivation that
// removed a token it did not record has to fail that reconstruction.
func TestExecutionAssertionsCatchAnUnrecordedRemoval(t *testing.T) {
	e := PlanExecution{
		Verified:  [][]string{{"/root/a", "-frontend", "-sdk", "/sdk"}},
		Executed:  [][]string{{"/root/a", "-frontend"}},
		Deletions: nil,
	}
	if bad := assertExecutionDerivation(e); len(bad) == 0 {
		t.Fatal("an unrecorded removal must fail the reconstruction")
	}
}

func TestExecutionAssertionsCatchADroppedJob(t *testing.T) {
	e := PlanExecution{
		Verified: [][]string{{"/root/a"}, {"/root/b"}},
		Executed: [][]string{{"/root/a"}},
	}
	if bad := assertExecutionDerivation(e); len(bad) == 0 {
		t.Fatal("a dropped job must be reported")
	}
}
