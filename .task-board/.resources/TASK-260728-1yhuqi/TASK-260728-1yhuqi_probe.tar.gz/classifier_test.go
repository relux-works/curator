package main

import (
	"strings"
	"testing"
)

const compiler = "6.3.2"

func TestCuratorClassifyCanonical(t *testing.T) {
	for _, tc := range []struct {
		header string
		want   Class
	}{
		{"// swift-tools-version:6.0\n", ClassAccepted},
		{"// swift-tools-version: 6.0\n", ClassAccepted},
		{"// swift-tools-version:6.3.2\n", ClassAccepted},
		{"// swift-tools-version:6.0\r\n", ClassAccepted},
		{"// swift-tools-version:4.0\n", ClassAccepted},
		{"// swift-tools-version:3.1\n", ClassFloor},
		{"// swift-tools-version:1.0\n", ClassFloor},
		{"// swift-tools-version:99.0\n", ClassHostGate},
		{"// swift-tools-version:6.3.3\n", ClassHostGate},
		{"// swift-tools-version:6\n", ClassGrammar},
		{"// swift-tools-version:6.0.0.0\n", ClassGrammar},
		{"// swift-tools-version:notaversion\n", ClassGrammar},
		{"// swift-tools-version:\n", ClassNoSpecifier},
		{"", ClassNoHeader},
		{"\ufeff// swift-tools-version:6.0\n", ClassNoHeader},
	} {
		if got := CuratorClassify(tc.header+ManifestBody, compiler); got != tc.want {
			t.Errorf("CuratorClassify(%q) = %s, want %s", tc.header, got, tc.want)
		}
	}
}

// The security partition is the set of headers upstream represents and Curator
// refuses. A member that carries its specification ON line 1 must classify as
// rejected-non-canonical-header, never as a grammar rejection: calling it a
// grammar error would claim upstream refuses it too.
func TestSecurityPartitionOnLineOneIsNonCanonicalNotGrammar(t *testing.T) {
	for _, header := range []string{
		"//swift-tools-version:6.0\n",
		"// SWIFT-TOOLS-VERSION:6.0\n",
		"// swift-tools-version:06.0\n",
		"// swift-tools-version:6.0-beta\n",
		"// swift-tools-version:6.0+build\n",
		"//   swift-tools-version:  6.0\n",
	} {
		if got := CuratorClassify(header+ManifestBody, compiler); got != ClassNonCanonical {
			t.Errorf("CuratorClassify(%q) = %s, want %s", header, got, ClassNonCanonical)
		}
	}
}

// The classifier's input is exactly line 1. A specification below it is not a
// non-canonical header, because Curator never looked: it is an absent one. No
// byte after the first LF may change the verdict.
func TestClassifierReadsLineOneAndNothingElse(t *testing.T) {
	for _, manifest := range []string{
		"import Foundation\n// swift-tools-version:6.0\n",
		"import PackageDescription\nlet u = \"\"\"\n// swift-tools-version:6.0\n\"\"\"\n",
		"// not a specification\n// swift-tools-version:6.0\n",
		"\n// swift-tools-version:6.0\n",
	} {
		if got := CuratorClassify(manifest+ManifestBody, compiler); got != ClassNoHeader {
			t.Errorf("CuratorClassify(%q) = %s, want %s", manifest, got, ClassNoHeader)
		}
	}
	// Line 1 decides; every byte after the first LF is irrelevant to the verdict.
	base := "// swift-tools-version:6.0\n"
	want := CuratorClassify(base+ManifestBody, compiler)
	for _, tail := range []string{
		"// swift-tools-version:99.0\n",
		"// swift-tools-version:1.0\n",
		"// swift-tools-version:notaversion\n",
		strings.Repeat("garbage \x00\xff\n", 20),
	} {
		if got := CuratorClassify(base+tail+ManifestBody, compiler); got != want {
			t.Errorf("a byte after line 1 changed the verdict: got %s want %s for tail %q", got, want, clipTo(tail, 40))
		}
	}
}

func TestCaseTableAgreesWithClassifier(t *testing.T) {
	for _, c := range Cases(compiler) {
		got := CuratorClassify(c.Manifest+ManifestBody, compiler)
		if got != c.Curator {
			t.Errorf("case %s: classifier says %s, table declares %s", c.ID, got, c.Curator)
		}
		if c.SecurityPartition && c.Isolated != ClassAccepted {
			t.Errorf("case %s: a security-partition member must be representable upstream, declared %s", c.ID, c.Isolated)
		}
		// No member of F may be called a grammar rejection: that would assert
		// upstream refuses it too.
		if c.SecurityPartition && c.Curator == ClassGrammar {
			t.Errorf("case %s: a security-partition member must not classify as a grammar rejection", c.ID)
		}
	}
}

func TestParseStrictRejectsLeadingZerosAndSuffixes(t *testing.T) {
	for _, bad := range []string{"06.0", "6.0-beta", "6.0+build", "6", "6.0.0.0", "", "6.", ".6", "a.b", "6.0.01"} {
		if _, ok := parseStrict(bad); ok {
			t.Errorf("parseStrict(%q) accepted", bad)
		}
	}
	for _, good := range []string{"6.0", "6.0.0", "0.1", "99.0", "6.3.2"} {
		if _, ok := parseStrict(good); !ok {
			t.Errorf("parseStrict(%q) rejected", good)
		}
	}
}

func TestPredictNormalizedMatchesMeasuredUpstream(t *testing.T) {
	for in, want := range map[string]string{
		"6.0": "6.0.0", "6.3.2": "6.3.2", "06.0": "6.0.0",
		"6.0-beta": "6.0.0", "6.0+build": "6.0.0", "99.0": "99.0.0", "1.0": "1.0.0",
	} {
		got, ok := predictNormalized(in)
		if !ok || got != want {
			t.Errorf("predictNormalized(%q) = %q,%v want %q", in, got, ok, want)
		}
	}
	for _, bad := range []string{"6", "notaversion", "", "6.0.0.0"} {
		if _, ok := predictNormalized(bad); ok {
			t.Errorf("predictNormalized(%q) accepted", bad)
		}
	}
}

func TestRecognitionIsWholeLineExact(t *testing.T) {
	exp := isolatedExpectations("6.0", PkgDir, compiler, "6.3")
	line := exp[1].line // the grammar diagnostic
	if got := recognise(exp, 1, "", line, "", modeExact); got.Class != ClassGrammar {
		t.Fatalf("exact line not recognised: %s", got.Class)
	}
	for _, mutated := range []string{
		line + ": unrelated failure",
		"swift-package: " + line,
		"note: while reading the manifest, " + line + " (see documentation)",
		strings.Replace(line, "'6.0'", "'6.1'", 1),
	} {
		if got := recognise(exp, 1, "", mutated, "", modeExact); got.Class != ClassUnknown {
			t.Errorf("mutated line yielded %s, want unknown: %q", got.Class, clipTo(mutated, 80))
		}
	}
}

func TestRecognitionRejectsConflictingMatches(t *testing.T) {
	exp := isolatedExpectations("6.0", PkgDir, compiler, "6.3")
	var grammar, missing string
	for _, e := range exp {
		switch e.class {
		case ClassGrammar:
			grammar = e.line
		case ClassNoSpecifier:
			missing = e.line
		}
	}
	both := grammar + "\n" + missing
	if got := recognise(exp, 1, "", both, "", modeExact); got.Class != ClassUnknown {
		t.Errorf("two classes in one output yielded %s, want unknown", got.Class)
	}
}

func TestNormalizeCompilerVersion(t *testing.T) {
	got, ok := NormalizeCompilerVersion("Apple Swift version 6.3.2 (swiftlang-6.3.2.1.108 clang-2100.1.1.101)")
	if !ok || got != "6.3.2" {
		t.Fatalf("got %q,%v", got, ok)
	}
	// The open-source banner is deliberately not covered: no host in this task
	// carried one, and an unmeasured rule is not a rule.
	if _, ok := NormalizeCompilerVersion("Swift version 6.1 (swift-6.1-RELEASE)"); ok {
		t.Fatal("open-source banner must not be accepted by the declared rule")
	}
}

func TestContainedRequiresAPathBoundaryAndAdmitsTheRootItself(t *testing.T) {
	if contained("/root-evil/bin/ld", []string{"/root"}) {
		t.Fatal("a shared prefix is not containment")
	}
	if !contained("/root/bin/ld", []string{"/root"}) {
		t.Fatal("a real child must be inside")
	}
	if !contained("/root", []string{"/root"}) {
		t.Fatal("the root itself must be inside; --sysroot names it directly")
	}
	if contained("/ROOT/bin/ld", []string{"/root"}) {
		t.Fatal("comparison is byte-exact, so a case variant must fail closed")
	}
}

func TestAgreesTreatsRepresentabilityAsWeakerThanTheBuild(t *testing.T) {
	if !agrees(ClassAccepted, ClassHostGate) || !agrees(ClassAccepted, ClassFloor) {
		t.Fatal("the corroborating command may add the host gate and the floor")
	}
	if agrees(ClassGrammar, ClassAccepted) {
		t.Fatal("a grammar rejection cannot become an acceptance")
	}
}

func TestAlignmentIgnoresTheSecurityPartitionOnly(t *testing.T) {
	results := []CaseResult{
		{Case: Case{ID: "f", SecurityPartition: true}, Status: "run", Curator: ClassNonCanonical,
			Isolated: Observation{Class: ClassAccepted}},
		{Case: Case{ID: "ok"}, Status: "run", Curator: ClassAccepted,
			Isolated: Observation{Class: ClassAccepted}},
	}
	a, findings := CheckAlignment(results)
	if !a.P1NoWidening || !a.P2NoNarrowing || len(findings) != 0 {
		t.Fatalf("clean set reported %+v %v", a, findings)
	}
	results[1].Curator = ClassNonCanonical
	a, findings = CheckAlignment(results)
	if a.P2NoNarrowing || len(findings) == 0 {
		t.Fatal("a narrowing outside F must be reported")
	}
}

// rawVersionOf models UPSTREAM, which scans the whole file. It is deliberately
// wider than the classifier; nothing in the manager reads it.
func TestRawVersionOfModelsUpstreamNotCurator(t *testing.T) {
	for manifest, want := range map[string]string{
		"// swift-tools-version:6.0\n":                    "6.0",
		"//   swift-tools-version:  6.0\n":                "6.0",
		"import Foundation\n// swift-tools-version:5.9\n": "5.9",
		"// swift-tools-version:\n":                       "",
		"":                                                "",
	} {
		if got := rawVersionOf(manifest); got != want {
			t.Errorf("rawVersionOf(%q) = %q want %q", manifest, got, want)
		}
	}
	// Line 1 wins for upstream too when it carries a specification. Measured:
	// upstream reports 6.0.0 for a manifest whose line 2 says 99.0.
	if got := rawVersionOf("// swift-tools-version:6.0\n// swift-tools-version:99.0\n"); got != "6.0" {
		t.Errorf("upstream model took the later specification: %q", got)
	}
}
