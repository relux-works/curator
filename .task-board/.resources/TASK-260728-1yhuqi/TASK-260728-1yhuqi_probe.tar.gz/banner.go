package main

import (
	"fmt"
	"strings"
)

// ---------------------------------------------------------------------------
// `swift.printTargetInfo.compilerVersion` — one whole-value, byte-exact grammar.
//
// This is the single normative rule. Decision 0011 section 11, reference
// section 1.2, the registry `normalization` field and this parser all state the
// same grammar, and the parser consumes the ENTIRE value: there is no prefix
// match, no "first numeric token" shortcut, and no unexamined suffix.
//
//	banner    := prefix version " (" suffix ")"
//	prefix    := %s"Apple Swift version "          ; exactly 20 bytes, one SP
//	version   := num "." num "." num
//	num       := "0" / ( %x31-39 *8( %x30-39 ) )   ; no leading zero, <= 9 digits
//	suffix    := 1*200( sbyte )
//	sbyte     := %x20-27 / %x2A-7E                 ; printable ASCII, no ( or )
//
// Whole-value length is bounded at bannerMaxBytes. Every byte of the value must
// lie in %x20-7E: that single rule rejects CR, LF, NUL, every other C0 control,
// DEL, and every non-ASCII byte (so a UTF-8 continuation byte can never reach
// the version, and the value is its own canonical form).
//
// Excluding "(" and ")" from `sbyte` is what makes the grammar unambiguous
// without balanced-paren parsing: the value carries exactly one "(" and exactly
// one ")", and the ")" is the final byte.
//
// Measured on this host, len 68:
//	Apple Swift version 6.3.2 (swiftlang-6.3.2.1.108 clang-2100.1.1.101)
//
// A value that does not match leaves the version UNDETERMINED and fails Stage A
// with build_toolchain_version_undetermined. It is never guessed, never
// truncated, and never taken from a second surface. Widening the grammar — for
// the open-source banner, for a prerelease marker, for a parenthesised suffix —
// is a measurement obligation on the host that emits it, not a regex edit.
// ---------------------------------------------------------------------------

const (
	bannerPrefix         = "Apple Swift version "
	bannerMaxBytes       = 255
	bannerSuffixMaxBytes = 200
	bannerNumMaxDigits   = 9
)

// BannerReject is a typed rejection. Code is the stable reason token that the
// conformance vectors assert on; Detail is human-facing.
type BannerReject struct {
	Code   string `json:"code"`
	Detail string `json:"detail"`
}

func (b *BannerReject) String() string {
	if b == nil {
		return ""
	}
	return b.Code + ": " + b.Detail
}

// Banner is the accepted decomposition of a matched value.
type Banner struct {
	// Raw is the whole input, byte for byte.
	Raw string
	// Major, Minor, Patch are the three decimal components.
	Major, Minor, Patch uint32
	// Normalized is "<major>.<minor>.<patch>".
	Normalized string
	// Suffix is the parenthesised body, without the parentheses.
	Suffix string
}

// ParseCompilerBanner is TOTAL: every input either yields a Banner or a typed
// BannerReject. It never returns both nil.
func ParseCompilerBanner(s string) (*Banner, *BannerReject) {
	// 1. Length. Checked first so an adversarial multi-megabyte value costs a
	//    length comparison rather than a scan.
	if len(s) == 0 {
		return nil, &BannerReject{"banner_empty", "the compilerVersion value is empty"}
	}
	if len(s) > bannerMaxBytes {
		return nil, &BannerReject{"banner_too_long",
			fmt.Sprintf("the value is %d bytes; the grammar admits at most %d", len(s), bannerMaxBytes)}
	}

	// 2. Byte class over the WHOLE value. This is the rule that rejects CR, LF,
	//    NUL, every other control byte, DEL and every non-ASCII byte.
	for i := 0; i < len(s); i++ {
		if c := s[i]; c < 0x20 || c > 0x7e {
			return nil, &BannerReject{"banner_byte",
				fmt.Sprintf("byte 0x%02x at offset %d is outside %%x20-7E", c, i)}
		}
	}

	// 3. Exact prefix.
	if !strings.HasPrefix(s, bannerPrefix) {
		return nil, &BannerReject{"banner_prefix",
			fmt.Sprintf("the value does not begin with the exact %d-byte prefix %q", len(bannerPrefix), bannerPrefix)}
	}
	rest := s[len(bannerPrefix):]

	// 4. Exactly one "(" and one ")", and the ")" is the last byte. Because
	//    sbyte excludes both, any other count is malformed rather than nested.
	if n := strings.Count(rest, "("); n != 1 {
		return nil, &BannerReject{"banner_parens",
			fmt.Sprintf("the value carries %d '(' bytes; the grammar admits exactly 1", n)}
	}
	if n := strings.Count(rest, ")"); n != 1 {
		return nil, &BannerReject{"banner_parens",
			fmt.Sprintf("the value carries %d ')' bytes; the grammar admits exactly 1", n)}
	}
	if rest[len(rest)-1] != ')' {
		return nil, &BannerReject{"banner_trailing",
			"the value does not end with ')'; the grammar admits no trailing bytes after the suffix"}
	}
	open := strings.IndexByte(rest, '(')
	if open < 2 || rest[open-1] != ' ' {
		return nil, &BannerReject{"banner_separator",
			"the '(' is not preceded by exactly one SP following the version"}
	}

	verPart := rest[:open-1]
	suffix := rest[open+1 : len(rest)-1]

	// 5. Version: exactly three components.
	comps := strings.Split(verPart, ".")
	if len(comps) != 3 {
		return nil, &BannerReject{"banner_version_shape",
			fmt.Sprintf("the version %q has %d dot-separated components; the grammar admits exactly 3", verPart, len(comps))}
	}
	var vals [3]uint32
	for i, c := range comps {
		v, rej := parseBannerNum(c, i)
		if rej != nil {
			return nil, rej
		}
		vals[i] = v
	}

	// 6. Suffix: non-empty, bounded, and inside the sbyte class. The byte-class
	//    sweep in step 2 already excluded controls and non-ASCII, so only the
	//    parentheses remain — and step 4 already proved there are none here.
	if len(suffix) == 0 {
		return nil, &BannerReject{"banner_suffix_empty",
			"the parenthesised suffix is empty; the grammar requires at least one byte"}
	}
	if len(suffix) > bannerSuffixMaxBytes {
		return nil, &BannerReject{"banner_suffix_too_long",
			fmt.Sprintf("the suffix is %d bytes; the grammar admits at most %d", len(suffix), bannerSuffixMaxBytes)}
	}

	return &Banner{
		Raw: s, Major: vals[0], Minor: vals[1], Patch: vals[2],
		Normalized: fmt.Sprintf("%d.%d.%d", vals[0], vals[1], vals[2]),
		Suffix:     suffix,
	}, nil
}

func parseBannerNum(c string, idx int) (uint32, *BannerReject) {
	pos := [3]string{"major", "minor", "patch"}[idx]
	if c == "" {
		return 0, &BannerReject{"banner_version_component",
			fmt.Sprintf("the %s component is empty", pos)}
	}
	if len(c) > bannerNumMaxDigits {
		return 0, &BannerReject{"banner_version_component",
			fmt.Sprintf("the %s component is %d digits; the grammar admits at most %d", pos, len(c), bannerNumMaxDigits)}
	}
	for i := 0; i < len(c); i++ {
		if c[i] < '0' || c[i] > '9' {
			return 0, &BannerReject{"banner_version_component",
				fmt.Sprintf("the %s component %q carries a non-digit byte 0x%02x", pos, c, c[i])}
		}
	}
	if len(c) > 1 && c[0] == '0' {
		return 0, &BannerReject{"banner_version_component",
			fmt.Sprintf("the %s component %q has a leading zero; the grammar admits one canonical spelling", pos, c)}
	}
	var v uint32
	for i := 0; i < len(c); i++ {
		v = v*10 + uint32(c[i]-'0')
	}
	return v, nil
}

// NormalizeCompilerVersion is the manager-facing entry point. It consumes the
// whole value through ParseCompilerBanner; there is no second, looser path.
func NormalizeCompilerVersion(s string) (string, bool) {
	b, rej := ParseCompilerBanner(s)
	if rej != nil {
		return "", false
	}
	return b.Normalized, true
}

// NaiveCompilerVersionPrefixOnly is the RETIRED parser: match the prefix, take
// the numeric token before the first space, and never look at the rest. It is
// retained only so expected-red control C10 can restore it from this same
// binary and report the values it admits that the whole-value grammar rejects.
func NaiveCompilerVersionPrefixOnly(s string) (string, bool) {
	if !strings.HasPrefix(s, bannerPrefix) {
		return "", false
	}
	rest := strings.TrimPrefix(s, bannerPrefix)
	i := strings.IndexByte(rest, ' ')
	if i < 0 {
		return "", false
	}
	v, ok := parseStrict(rest[:i])
	if !ok {
		return "", false
	}
	return fmt.Sprintf("%d.%d.%d", v.major, v.minor, v.patch), true
}
