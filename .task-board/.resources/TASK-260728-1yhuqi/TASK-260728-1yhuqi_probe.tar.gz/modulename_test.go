package main

import (
	"strings"
	"testing"
)

// The declared mapping. These are the values the conformance vectors carry, so
// a change here is a contract change.
func TestDeriveModuleNameDeclaredMapping(t *testing.T) {
	for key, want := range map[string]string{
		"tool":      "Sk_tool",
		"my-tool":   "Sk_myzhtool",
		"my.tool":   "Sk_myzdtool",
		"my_tool":   "Sk_myzutool",
		"9.tool":    "Sk_9zdtool",
		"0":         "Sk_0",
		"z":         "Sk_zz",
		"z-z":       "Sk_zzzhzz",
		"zdz":       "Sk_zzdzz",
		"a.b-c_d.e": "Sk_azdbzhczudzde",
	} {
		got, err := DeriveModuleName(key)
		if err != nil {
			t.Errorf("DeriveModuleName(%q) errored: %v", key, err)
			continue
		}
		if got != want {
			t.Errorf("DeriveModuleName(%q) = %q want %q", key, got, want)
		}
	}
}

// The reviewer's collision: a replacement rule merges these two, the derivation
// must not.
func TestPunctuationDoesNotCollide(t *testing.T) {
	a, _ := DeriveModuleName("my-tool")
	b, _ := DeriveModuleName("my.tool")
	c, _ := DeriveModuleName("my_tool")
	if a == b || a == c || b == c {
		t.Fatalf("collision: %q %q %q", a, b, c)
	}
	if NaiveModuleName("my-tool") != NaiveModuleName("my.tool") {
		t.Fatal("the retired rule is supposed to collide here; control C9 depends on it")
	}
}

func TestDeriveModuleNameIsTotalValidAndInjective(t *testing.T) {
	alphabet := []string{"a", "z", "Z", "0", "9", ".", "-", "_"}
	var corpus []string
	for _, a := range []string{"a", "z", "Z", "0", "9"} {
		for _, b := range alphabet {
			for _, c := range alphabet {
				corpus = append(corpus, a+b+c)
			}
		}
	}
	for _, n := range []int{1, 2, 29, 30, 31, 32, 60, 61, 62, 63, 64, 65, 128, 512} {
		for _, fill := range []string{"z", "b", "-", ".", "_"} {
			corpus = append(corpus, "a"+strings.Repeat(fill, n-1))
		}
	}
	seen := map[string]string{}
	long := 0
	for _, key := range corpus {
		if !ValidCommandKey(key) {
			t.Fatalf("corpus key %q is outside the protocol grammar", key)
		}
		m, err := DeriveModuleName(key)
		if err != nil {
			t.Fatalf("DeriveModuleName(%q) errored: %v", key, err)
		}
		if !ValidModuleName(m) {
			t.Fatalf("DeriveModuleName(%q) = %q, outside the module grammar", key, m)
		}
		if prev, dup := seen[m]; dup && prev != key {
			t.Fatalf("collision: %q and %q both derive %q", prev, key, m)
		}
		seen[m] = key
		if strings.HasPrefix(m, moduleLongTag) {
			long++
			continue
		}
		back, ok := DecodeModuleName(m)
		if !ok || back != key {
			t.Fatalf("short branch is not invertible: %q -> %q -> %q,%v", key, m, back, ok)
		}
	}
	if long == 0 {
		t.Fatal("the corpus never reached the overflow branch")
	}
}

// The length boundary is exact: 61 escaped bytes still fit the short branch,
// 62 do not.
func TestDeriveModuleNameLengthBoundary(t *testing.T) {
	short := strings.Repeat("a", moduleShortMax)
	m, err := DeriveModuleName(short)
	if err != nil || len(m) != ModuleNameMax || !strings.HasPrefix(m, moduleShortTag) {
		t.Fatalf("boundary key: %q %v", m, err)
	}
	over := strings.Repeat("a", moduleShortMax+1)
	m2, err := DeriveModuleName(over)
	if err != nil || len(m2) != ModuleNameMax || !strings.HasPrefix(m2, moduleLongTag) {
		t.Fatalf("overflow key: %q (%d) %v", m2, len(m2), err)
	}
	// Escape expansion counts against the same bound: each `-a` costs three
	// bytes, so a 41-byte key lands exactly on 61 and still fits the short
	// branch, while one more pair overflows.
	esc := "a" + strings.Repeat("-a", 20)
	m3, err := DeriveModuleName(esc)
	if err != nil || !strings.HasPrefix(m3, moduleShortTag) || len(m3) != ModuleNameMax {
		t.Fatalf("escape-expanded key at the boundary: %q (%d) %v", m3, len(m3), err)
	}
	m4, err := DeriveModuleName(esc + "-a")
	if err != nil || !strings.HasPrefix(m4, moduleLongTag) || !ValidModuleName(m4) {
		t.Fatalf("escape-expanded key past the boundary: %q %v", m4, err)
	}
}

func TestDeriveModuleNameRejectsNonProtocolKeys(t *testing.T) {
	for _, bad := range []string{"", ".tool", "-tool", "_tool", "tool name", "tool/name", "tóol", "tool\n"} {
		if _, err := DeriveModuleName(bad); err == nil {
			t.Errorf("DeriveModuleName(%q) accepted a key outside the protocol grammar", bad)
		}
	}
}

// A bare escape without the tag would map the key `wift` onto the standard
// library's module name. The tag is what prevents it, and the prefix is
// reserved, so the derivation can never shadow a module source can import.
func TestDerivedNamesCannotShadowSwiftOrAKeyword(t *testing.T) {
	m, err := DeriveModuleName("wift")
	if err != nil || m == "Swift" {
		t.Fatalf("DeriveModuleName(\"wift\") = %q, %v", m, err)
	}
	for _, keyword := range []string{"class", "import", "default", "func", "let", "var", "Swift", "Foundation"} {
		for _, key := range []string{keyword, strings.ToLower(keyword)} {
			if !ValidCommandKey(key) {
				continue
			}
			got, err := DeriveModuleName(key)
			if err != nil {
				t.Fatal(err)
			}
			if got == keyword {
				t.Fatalf("DeriveModuleName(%q) produced the reserved name %q", key, got)
			}
		}
	}
}
