package main

import (
	"fmt"
	"runtime"
	"sort"
	"strings"
)

// ---------------------------------------------------------------------------
// curator-swift-relpath-v1 — one canonical, platform-neutral serialization for
// every closure member that enters identity.
//
// Identity may not name a filesystem path (decision 0007 section 3.2), so every
// member is serialized as a (role, relpath) pair: the role names one declared
// root, and the relpath locates the member inside it. This file is the whole
// rule, and it is written so that the macOS constants (`usr/bin/ld`) and an
// unmeasured Windows linker (`usr/bin/link.exe`, or wherever P3 resolves it)
// serialize through the SAME code path. Nothing here is macOS-specific.
//
// Rules, all mandatory:
//
//  1. Both root and member are FULLY RESOLVED before serialization — POSIX
//     symlinks via realpath(3), Windows reparse points/junctions/symlinks via
//     the final path (GetFinalPathNameByHandle). A relpath is never computed
//     from an unresolved argument, because that is exactly the lexical
//     containment expected-red control C8 exists to reject.
//  2. The member must equal the root or lie strictly under it, compared
//     COMPONENT-WISE and BYTE-EXACTLY. A case variant on a case-insensitive
//     volume fails closed rather than matching.
//  3. The separator in the serialized form is always U+002F, on every platform.
//     A native separator never appears in identity.
//  4. No volume prefix, no drive letter, no UNC prefix, no leading separator,
//     no trailing separator.
//  5. No empty component, no "." component, no ".." component; no component may
//     contain a separator byte or NUL. A Windows final component keeps its
//     extension verbatim (`swiftc.exe`, not `swiftc`).
//  6. The member equal to its own root serializes as exactly ".".
//  7. Case is taken from the RESOLVED path as the filesystem reports it, never
//     from the spelling in an argument or a job plan. On a case-insensitive
//     volume the resolved path is the on-disk spelling, so the serialization is
//     deterministic for a given tree.
//
// Ordering and duplicates for a member SET are in SerializeMembers below.
// ---------------------------------------------------------------------------

// ClosureMember is one serialized closure member.
type ClosureMember struct {
	Role    string `json:"role"`
	Relpath string `json:"relpath"`
	// Identity is the (device, inode) pair on POSIX and the
	// (volume serial, file index) pair on Windows. It is evidence for
	// permit-time re-verification and is NOT part of the portable identity.
	Identity string `json:"identity,omitempty"`
	// Resolved is the local absolute path. Recorded in the fixture as evidence,
	// never in identity.
	Resolved string `json:"resolved,omitempty"`
}

// volumePrefixLen reports the length of a platform volume prefix that must be
// stripped before component splitting. On POSIX it is always 0; the Windows
// arms are written out so the rule is implementable rather than inferred.
func volumePrefixLen(p string) int {
	if runtime.GOOS != "windows" {
		return 0
	}
	// \\?\C:\ and \\?\UNC\server\share\ extended forms, \\server\share, C:\
	switch {
	case strings.HasPrefix(p, `\\?\UNC\`):
		return len(`\\?\UNC\`)
	case strings.HasPrefix(p, `\\?\`):
		return len(`\\?\`) + 2 // drive letter and colon
	case strings.HasPrefix(p, `\\`):
		return 2
	case len(p) >= 2 && p[1] == ':':
		return 2
	}
	return 0
}

func isSep(c byte) bool {
	if c == '/' {
		return true
	}
	return runtime.GOOS == "windows" && c == '\\'
}

// splitComponents splits a resolved absolute path into its components, dropping
// the volume prefix and every empty run of separators. It is byte-exact: no
// case folding, no Unicode normalization.
func splitComponents(p string) []string {
	p = p[volumePrefixLen(p):]
	var out []string
	cur := strings.Builder{}
	for i := 0; i < len(p); i++ {
		if isSep(p[i]) {
			if cur.Len() > 0 {
				out = append(out, cur.String())
				cur.Reset()
			}
			continue
		}
		cur.WriteByte(p[i])
	}
	if cur.Len() > 0 {
		out = append(out, cur.String())
	}
	return out
}

// CanonicalRelpath serializes resolvedMember relative to resolvedRoot. Both
// arguments MUST already be fully resolved. It is total: every input yields a
// relpath or a typed error.
func CanonicalRelpath(resolvedRoot, resolvedMember string) (string, error) {
	if resolvedRoot == "" || resolvedMember == "" {
		return "", fmt.Errorf("relpath: root and member must both be non-empty resolved paths")
	}
	rc := splitComponents(resolvedRoot)
	mc := splitComponents(resolvedMember)
	if len(mc) < len(rc) {
		return "", fmt.Errorf("relpath: %q is not inside %q", resolvedMember, resolvedRoot)
	}
	for i := range rc {
		if rc[i] != mc[i] {
			return "", fmt.Errorf("relpath: component %d differs byte-exactly (%q vs %q); %q is not inside %q",
				i, rc[i], mc[i], resolvedMember, resolvedRoot)
		}
	}
	tail := mc[len(rc):]
	if len(tail) == 0 {
		return ".", nil
	}
	for _, c := range tail {
		switch {
		case c == "":
			return "", fmt.Errorf("relpath: empty component")
		case c == "." || c == "..":
			return "", fmt.Errorf("relpath: %q component is not admitted", c)
		}
		for i := 0; i < len(c); i++ {
			if c[i] == 0x00 || c[i] == '/' || c[i] == '\\' {
				return "", fmt.Errorf("relpath: component %q carries a separator or NUL byte", c)
			}
		}
	}
	return strings.Join(tail, "/"), nil
}

// SerializeMembers is the canonical ORDER and DUPLICATE rule for a member set.
//
//   - Two members with the same (role, relpath) are ONE member. Deduplication
//     happens after serialization, so two spellings that resolve to the same
//     file collapse exactly when their canonical relpaths are equal.
//   - The set is sorted by role byte order, then relpath byte order. Sorting is
//     over the serialized bytes, never over the local absolute path, so the
//     order does not depend on where the roots happen to live.
//   - The result is the ordered list that enters the identity digest.
func SerializeMembers(in []ClosureMember) []ClosureMember {
	seen := map[string]bool{}
	var out []ClosureMember
	for _, m := range in {
		k := m.Role + "\x00" + m.Relpath
		if seen[k] {
			continue
		}
		seen[k] = true
		out = append(out, m)
	}
	sort.SliceStable(out, func(a, b int) bool {
		if out[a].Role != out[b].Role {
			return out[a].Role < out[b].Role
		}
		return out[a].Relpath < out[b].Relpath
	})
	return out
}

// RootRecord is one declared root in the ordered closure. Ordinal exists so a
// platform that declares MORE THAN ONE root in a role — the Windows
// `platform-sdk` case — has a defined role token, order and digest position
// without inventing them at implementation time.
type RootRecord struct {
	Role    string `json:"role"`
	Ordinal int    `json:"ordinal"`
	// TreeSHA256 is the per-root digest. Recorded here as evidence only; the
	// probe does not re-walk 3.3 GiB per structural check.
	TreeSHA256 string `json:"tree_sha256,omitempty"`
	Resolved   string `json:"resolved,omitempty"`
}

// RoleToken is the token that appears in identity for a root record.
//
//	cardinality "exactly-one"  -> the bare role, e.g. "swift-toolchain"
//	cardinality "one-or-more"  -> "<role>[<ordinal>]", e.g. "platform-sdk[0]"
//
// The bracketed form is used WHENEVER the platform's registry cardinality for
// that role is one-or-more, even when exactly one root happens to be declared.
// Otherwise a Windows host that declared one SDK today and two tomorrow would
// change the identity of the FIRST root, which is a silent cache collision.
func RoleToken(role string, ordinal int, oneOrMore bool) string {
	if !oneOrMore {
		return role
	}
	return fmt.Sprintf("%s[%d]", role, ordinal)
}
