package main

// Fixture is the emitted evidence document. Its shape follows the
// rust-boundary-fixture-v1 layout of TASK-260728-12pnm1 so the two language
// contracts can be read side by side.
type Fixture struct {
	FixtureVersion string          `json:"fixture_version"`
	Task           string          `json:"task"`
	Host           Host            `json:"host"`
	Toolchain      ToolchainRecord `json:"toolchain"`
	Cases          []CaseResult    `json:"cases"`
	HostGateCases  []CaseResult    `json:"host_gate_cases"`
	Alignment      Alignment       `json:"alignment"`
	Closure        []ClosureCheck  `json:"closure"`
	Controls       []ControlResult `json:"controls"`
	Structural     []Structural    `json:"structural"`
	Summary        Summary         `json:"summary"`
}

type Host struct {
	OperatingSystem string `json:"operating_system"`
	Architecture    string `json:"architecture"`
	ProbeGoVersion  string `json:"probe_go_version"`
}

// ToolchainRecord carries only what the contract needs to reproduce a run. No
// value here is a platform claim.
type ToolchainRecord struct {
	Available bool `json:"available"`
	// Reason is set only when Available is false.
	Reason string `json:"reason,omitempty"`

	Root          string   `json:"root"`
	SwiftcPath    string   `json:"swiftc_path"`
	SwiftPath     string   `json:"swift_path"`
	FrontendPath  string   `json:"frontend_path"`
	ClangPath     string   `json:"clang_path"`
	LinkerPath    string   `json:"linker_path"`
	PlatformRoot  string   `json:"platform_root"`
	DeclaredSDK   string   `json:"declared_sdk"`
	PresentedSDK  string   `json:"presented_sdk"`
	CompilerVer   string   `json:"compiler_version"`
	CompilerTag   string   `json:"compiler_tag"`
	Normalized    string   `json:"normalized_version"`
	Triple        string   `json:"target_triple"`
	Unversioned   string   `json:"target_unversioned_triple"`
	RuntimePaths  []string `json:"runtime_library_paths"`
	StdlibPresent bool     `json:"stdlib_present"`

	// BannerSuffix is the parenthesised body the whole-value grammar consumed.
	BannerSuffix string `json:"compiler_version_suffix"`
	// Admission is the executed P2 verdict for the exact compile triple.
	Admission RuntimeAdmission `json:"native_target_admission"`
}

// Class is one outcome of the swift-tools-version classifier. It is an outcome,
// never a lead and never a family.
type Class string

const (
	ClassAccepted     Class = "accepted"
	ClassNoHeader     Class = "rejected-absent-header"
	ClassNoSpecifier  Class = "rejected-missing-specifier"
	ClassGrammar      Class = "rejected-grammar"
	ClassFloor        Class = "rejected-unsupported-floor"
	ClassHostGate     Class = "host-gate"
	ClassNonCanonical Class = "rejected-non-canonical-header"
	ClassUnknown      Class = "unknown"
)

// Case is one declared expectation about one manifest header.
type Case struct {
	ID string `json:"id"`
	// Manifest is the exact byte prefix written ahead of the fixed manifest body.
	Manifest string `json:"manifest_prefix"`
	// Display renders control characters so the fixture stays readable.
	Display string `json:"display"`
	// Curator is the class Curator's own classifier must produce.
	Curator Class `json:"curator_expected"`
	// Isolated is the class the isolated upstream command must produce.
	Isolated Class `json:"isolated_expected"`
	// Corroborating is the class the corroborating upstream command must produce.
	Corroborating Class `json:"corroborating_expected"`
	// SecurityPartition marks a value Curator refuses for a stated security
	// reason even though upstream represents it. P2 is checked outside F.
	SecurityPartition bool `json:"security_partition"`
	// HostGate marks a case whose corroborating outcome depends on the runner.
	HostGate bool   `json:"host_gate"`
	Note     string `json:"note,omitempty"`
}

type Observation struct {
	Class    Class  `json:"class"`
	Exit     int    `json:"exit"`
	Matched  string `json:"matched_line,omitempty"`
	Stream   string `json:"matched_stream,omitempty"`
	Excerpt  string `json:"excerpt"`
	Recognis bool   `json:"recognised"`
}

type CaseResult struct {
	Case          Case        `json:"case"`
	Status        string      `json:"status"`
	Reason        string      `json:"reason,omitempty"`
	Curator       Class       `json:"curator"`
	Isolated      Observation `json:"isolated"`
	Corroborating Observation `json:"corroborating"`
	Agreed        bool        `json:"agreed"`
	Matched       bool        `json:"matched_expectation"`
	Runs          []RunRecord `json:"runs"`
}

type RunRecord struct {
	Argv     []string `json:"argv"`
	Dir      string   `json:"dir"`
	EnvDelta []string `json:"env_delta"`
	Exit     int      `json:"exit"`
	Stdout   string   `json:"stdout"`
	Stderr   string   `json:"stderr"`
}

type Alignment struct {
	SecurityPartitionEmpty bool `json:"security_partition_empty"`
	P1NoWidening           bool `json:"p1_no_widening"`
	P2NoNarrowing          bool `json:"p2_no_narrowing"`
}

type ClosureCheck struct {
	ID        string `json:"id"`
	Direction string `json:"direction"`
	Kind      string `json:"kind"`
	Yielded   Class  `json:"yielded"`
	NoVerdict bool   `json:"no_verdict"`
	Detail    string `json:"detail"`
}

type ControlResult struct {
	ID       string `json:"id"`
	Guards   string `json:"guards"`
	Failed   bool   `json:"failed"`
	Findings int    `json:"findings"`
	Detail   string `json:"detail"`
}

type Structural struct {
	ID                string      `json:"id"`
	Title             string      `json:"title"`
	Expected          string      `json:"expected"`
	Observed          string      `json:"observed"`
	Verdict           string      `json:"verdict"`
	ManagerObligation string      `json:"manager_obligation"`
	Runs              []RunRecord `json:"runs"`
}

type Summary struct {
	Cases                   int  `json:"cases"`
	Matched                 int  `json:"matched"`
	Divergences             int  `json:"divergences"`
	NotRun                  int  `json:"not_run"`
	ClosureChecks           int  `json:"closure_checks"`
	ClosureFailures         int  `json:"closure_failures"`
	ControlsTotal           int  `json:"controls_total"`
	ControlsFailingRequired int  `json:"controls_failing_as_required"`
	StructuralTotal         int  `json:"structural_total"`
	StructuralDivergences   int  `json:"structural_divergences"`
	NativeAdmissionOK       bool `json:"native_target_admission_ok"`
	Green                   bool `json:"green"`
}
