package main

import (
	"fmt"
	"strings"
)

// ---------------------------------------------------------------------------
// The physical-line grammar of the `swiftc -###` job plan.
//
// This is the layer BELOW the token grammar, and it is stated separately
// because it is the layer a Windows implementation would otherwise have to
// guess at. It is total: a plan either splits into lines or is rejected.
//
//	plan        := 1*line-record
//	line-record := line LF                 ; the TERMINAL LF IS MANDATORY
//	line        := 1*lbyte                 ; non-empty
//	lbyte       := %x20-7E / %x80-FF       ; no C0 control, no CR, no DEL
//
// The decisions this fixes, each of which was previously ambiguous:
//
//	LF            0x0A is the ONLY line terminator, on every platform.
//	terminal LF   MEASURED: the plan's final byte is 0x0A. It is therefore
//	              REQUIRED, not optional. A plan whose final byte is not LF is a
//	              truncated read and rejects. This removes the "LF?" ambiguity:
//	              there is exactly one trailing empty element after splitting on
//	              LF, and it is dropped; a second one means a blank line.
//	bare CR       0x0D is REJECTED ANYWHERE, on every platform. It is never
//	              stripped, never normalized, never tolerated at end of line.
//	              The retired TrimSuffix("\r") behaviour is control C12.
//	CRLF          consequently rejected. A Windows implementation MUST read the
//	              child's stdout as a BINARY stream with no newline translation
//	              (`_setmode(_O_BINARY)` / CreateProcess pipe read, never a text
//	              mode CRT handle). If a Windows toolchain is ever measured to
//	              emit CRLF, that is a measurement that extends this grammar,
//	              not a runtime fallback.
//	control bytes every byte < 0x20 other than the LF terminator, and 0x7F, is
//	              rejected. This is the same class TokenizeJobLine rejects, so
//	              the two layers cannot disagree.
//	high bytes    0x80-0xFF are ADMITTED inside a line and compared BYTE-EXACTLY.
//	              The plan is not required to be valid UTF-8: a POSIX path is a
//	              byte string, and every path token is compared against the
//	              manager's own byte set rather than decoded.
//	blank line    rejected. There is no whitespace-only line either: a line of
//	              spaces is non-empty under this grammar and then fails the
//	              token grammar's "first token must be an absolute path" rule.
//	bounds        the whole plan, each line, and the line count are bounded, so
//	              an adversarial plan cannot be an unbounded read.
//
// MEASURED on Apple Swift 6.3.2 / macOS 26.5 arm64 for the driver's own
// vector: 4670 bytes, final byte 0x0A, 3 LF, 0 CR, 0 other control bytes, 0
// non-ASCII bytes, longest line 1940 bytes, 3 job lines.
// ---------------------------------------------------------------------------

const (
	planMaxBytes     = 8 << 20 // 8 MiB
	planMaxLineBytes = 1 << 16 // 64 KiB
	planMaxLines     = 4096
)

// SplitPlanLines is total over byte strings: it returns the ordered job lines or
// a typed error. It strips nothing.
func SplitPlanLines(plan string) ([]string, error) {
	if len(plan) == 0 {
		return nil, fmt.Errorf("the job plan is empty")
	}
	if len(plan) > planMaxBytes {
		return nil, fmt.Errorf("the job plan is %d bytes; the grammar admits at most %d", len(plan), planMaxBytes)
	}
	for i := 0; i < len(plan); i++ {
		c := plan[i]
		if c == '\n' {
			continue
		}
		if c == '\r' {
			return nil, fmt.Errorf("bare CR at offset %d; LF is the only line terminator and CR is never stripped", i)
		}
		if c < 0x20 || c == 0x7f {
			return nil, fmt.Errorf("control byte 0x%02x at offset %d", c, i)
		}
	}
	if plan[len(plan)-1] != '\n' {
		return nil, fmt.Errorf("the job plan does not end with LF; the final line is unterminated and the read is truncated")
	}
	parts := strings.Split(plan, "\n")
	// Exactly one trailing empty element, produced by the mandatory final LF.
	parts = parts[:len(parts)-1]
	if len(parts) == 0 {
		return nil, fmt.Errorf("the job plan carries no line")
	}
	if len(parts) > planMaxLines {
		return nil, fmt.Errorf("the job plan carries %d lines; the grammar admits at most %d", len(parts), planMaxLines)
	}
	for i, l := range parts {
		if l == "" {
			return nil, fmt.Errorf("line %d is empty; the grammar admits no blank line", i+1)
		}
		if len(l) > planMaxLineBytes {
			return nil, fmt.Errorf("line %d is %d bytes; the grammar admits at most %d", i+1, len(l), planMaxLineBytes)
		}
	}
	return parts, nil
}

// NaiveSplitPlanLines is the RETIRED rule: optional terminal LF, and one
// trailing CR silently removed from every line. Retained only so expected-red
// control C12 can restore it from this same binary and report what it admits.
func NaiveSplitPlanLines(plan string) ([]string, error) {
	lines := strings.Split(plan, "\n")
	if n := len(lines); n > 0 && lines[n-1] == "" {
		lines = lines[:n-1]
	}
	if len(lines) == 0 {
		return nil, fmt.Errorf("the job plan is empty")
	}
	out := make([]string, 0, len(lines))
	for _, l := range lines {
		out = append(out, strings.TrimSuffix(l, "\r"))
	}
	return out, nil
}

// ---------------------------------------------------------------------------
// The exact relationship between the two argument vectors.
//
// Stated as code because the prose form ("they differ in exactly one token, at
// index 0") is ambiguous when read as complete argv: the difference is an
// INSERTION after the program, not a changed token at index 0.
//
//	program      := the resolved absolute swiftc inside the swift-toolchain root
//	compile_args := the driver's fixed argument list
//	graph_args   := ["-###"] ++ compile_args
//	compile_argv := [program] ++ compile_args
//	graph_argv   := [program] ++ graph_args
//
// So, mechanically:
//
//	len(graph_args) == len(compile_args) + 1
//	graph_args[0]   == "-###"
//	graph_args[i+1] == compile_args[i]   for every i, byte-exact
//	graph_argv[1]   == "-###"            the insertion point, in complete argv
//	count(graph_argv,   "-###") == 1     exactly once, nowhere else
//	count(compile_argv, "-###") == 0     never in the executed vector
//	graph_argv[0]   == compile_argv[0] == program
//
// `-###` cannot collide with any other token: sources are absolute paths, the
// module name matches ^[A-Za-z_][A-Za-z0-9_]{0,63}$, and every remaining token
// is a manager-owned constant or a manager-derived path. The uniqueness
// assertion is made anyway, because "cannot collide" is an argument and the
// assertion is a check.
// ---------------------------------------------------------------------------

const graphOnlyToken = "-###"

// VectorRelation is the verdict of comparing the two vectors.
type VectorRelation struct {
	OK              bool     `json:"ok"`
	Findings        []string `json:"findings,omitempty"`
	GraphLen        int      `json:"graph_args_len"`
	CompileLen      int      `json:"compile_args_len"`
	InsertionIndex  int      `json:"insertion_index_in_graph_argv"`
	GraphOccurrence int      `json:"graph_argv_occurrences"`
}

// CheckVectorRelation asserts every property above over complete argv.
func CheckVectorRelation(program string, compileArgs, graphArgs []string) VectorRelation {
	v := VectorRelation{GraphLen: len(graphArgs), CompileLen: len(compileArgs), InsertionIndex: -1}
	add := func(f string, a ...any) { v.Findings = append(v.Findings, fmt.Sprintf(f, a...)) }

	if len(graphArgs) != len(compileArgs)+1 {
		add("graph_args has %d tokens; the rule requires exactly len(compile_args)+1 = %d", len(graphArgs), len(compileArgs)+1)
	}
	if len(graphArgs) == 0 || graphArgs[0] != graphOnlyToken {
		add("graph_args[0] is not %q", graphOnlyToken)
	}
	n := len(compileArgs)
	if len(graphArgs)-1 < n {
		n = len(graphArgs) - 1
	}
	for i := 0; i < n; i++ {
		if graphArgs[i+1] != compileArgs[i] {
			add("graph_args[%d]=%q differs from compile_args[%d]=%q", i+1, graphArgs[i+1], i, compileArgs[i])
		}
	}

	graphArgv := append([]string{program}, graphArgs...)
	compileArgv := append([]string{program}, compileArgs...)
	for i, t := range graphArgv {
		if t == graphOnlyToken {
			v.GraphOccurrence++
			if v.InsertionIndex < 0 {
				v.InsertionIndex = i
			}
		}
	}
	if v.GraphOccurrence != 1 {
		add("%q occurs %d times in graph_argv; the rule requires exactly 1", graphOnlyToken, v.GraphOccurrence)
	}
	if v.InsertionIndex != 1 {
		add("%q is at graph_argv index %d; the rule requires index 1, immediately after the program", graphOnlyToken, v.InsertionIndex)
	}
	for _, t := range compileArgv {
		if t == graphOnlyToken {
			add("%q appears in compile_argv; the executed vector must never carry it", graphOnlyToken)
		}
	}
	if graphArgv[0] != compileArgv[0] {
		add("the two vectors do not share one program")
	}
	v.OK = len(v.Findings) == 0
	return v
}
