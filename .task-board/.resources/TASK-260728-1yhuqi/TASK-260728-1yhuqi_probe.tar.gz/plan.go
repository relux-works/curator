package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// ---------------------------------------------------------------------------
// The `swiftc -###` job-plan grammar, and the fail-closed verifier the manager
// runs over it between the graph phase and the compile permit.
//
// Everything here is a rejection engine. There is no "skip", no "ignore" and no
// best-effort recovery: a line the grammar does not cover, a flag whose value is
// missing, a path that resolves outside every declared root, and a path-shaped
// token that no bucket claims are all rejections of the operation with
// build_execution_control_unavailable.
//
// Measured on Apple Swift 6.3.2, macOS 26.5 arm64:
//   - the plan is written to stdout, one job per line, stderr empty;
//   - tokens are separated by one ASCII space;
//   - a token containing a space or a '#' is wrapped in single quotes;
//   - an embedded single quote is rendered '\'' — close, backslash-escaped
//     quote outside the quoted run, reopen;
//   - a backslash inside a quoted run is literal;
//   - a source file name containing a newline splits the job across physical
//     lines, which is why the source-name rule below rejects control bytes
//     before the graph phase rather than after it.
// ---------------------------------------------------------------------------

// planExecutableFlags carry an executable the compiler may start. Their value
// MUST resolve inside the swift-toolchain root.
var planExecutableFlags = []string{"-new-driver-path"}

// planPluginFlags carry a macro implementation the frontend may load. Their
// value MUST resolve inside a fingerprinted root, or MUST NOT exist.
var planPluginFlags = []string{
	"-plugin-path",
	"-external-plugin-path",
	"-in-process-plugin-server-path",
	"-load-plugin-library",
	"-load-plugin-executable",
	"-load-resolved-plugin",
}

// planSearchFlags carry a directory or SDK the compiler and linker read. Their
// value MUST resolve inside a fingerprinted root.
var planSearchFlags = []string{"-sdk", "-isysroot", "--sysroot", "-resource-dir", "-I", "-F", "-L"}

// planSourceFlags carry a compiled source unit. Their value MUST be a member of
// the manager's own ordered source set, byte for byte.
var planSourceFlags = []string{"-primary-file"}

// planOutputFlags carry a file the job writes. Their value MUST lie inside
// operation-private manager state.
var planOutputFlags = []string{"-o"}

// joinedSearchPrefixes are the short search flags that admit a joined spelling
// (`-I/path`). The measured plan uses the separated spelling; the joined one is
// covered so a future toolchain cannot smuggle a path past the token scan.
var joinedSearchPrefixes = []string{"-I", "-L", "-F"}

// Buckets. Every path-shaped token in a plan must land in exactly one.
const (
	BucketExecutable = "executable"
	BucketPlugin     = "plugin"
	BucketSearch     = "search"
	BucketSource     = "source"
	BucketOutput     = "output"
)

// PlanPolicy is everything the verifier is allowed to trust. Every path in it
// has already been resolved by the manager; the verifier resolves nothing on
// the strength of a plan byte.
type PlanPolicy struct {
	// ToolchainRoot is the resolved swift-toolchain root.
	ToolchainRoot string
	// FingerprintedRoots is the resolved ordered closure: toolchain, then SDK.
	FingerprintedRoots []string
	// OperationPrivate is the resolved set of manager-owned operation-private
	// trees: the staging root and the operation TMPDIR.
	OperationPrivate []string
	// Sources is the manager's own ordered compiled source set, absolute.
	Sources []string
	// WorkingDir is the child working directory, used only to reject a relative
	// token that names an existing entry.
	WorkingDir string

	// The four opaque constants the manager itself put in the compile vector. The
	// closed grammar compares a plan's opaque values against these byte-exactly,
	// so an opaque token is a constant the manager already chose rather than a
	// value carrier the package could reach.
	Triple       string
	SwiftVersion string
	ModuleName   string

	// XllvmValues and XccValues are the per-platform MEASURED value allow-sets for
	// the two pass-through flags. Both carry values into another option parser, so
	// an unlisted value rejects rather than passing through: `-Xllvm
	// -load-pass-plugin=<path>` and `-Xcc -I<path>` are live channels.
	XllvmValues []string
	XccValues   []string
}

// PlanBinding records one verified path and the identity it was verified at, so
// the permit-time re-check can prove the same bytes are still there.
//
// Raw and Checked are two different things and cycle 5 separates them. Raw is
// the token the plan carried. Checked is the path whose identity was ACTUALLY
// resolved and recorded, which for an output that does not exist yet is its
// operation-private parent, not the absent file. The permit-time re-check runs
// against Checked; running it against Raw would reject the ordinary happy path,
// because the output is correctly still absent when the permit is granted.
type PlanBinding struct {
	Bucket   string `json:"bucket"`
	Flag     string `json:"flag,omitempty"`
	Raw      string `json:"raw"`
	Checked  string `json:"checked,omitempty"`
	Resolved string `json:"resolved,omitempty"`
	Present  bool   `json:"present"`
	Identity string `json:"identity,omitempty"`

	info os.FileInfo
}

// checkedPath is the path the permit-time re-check re-resolves. It is Checked
// whenever the binding recorded one; the fallback keeps the retired
// path-shape-only verifier's bindings usable by the same function.
func (b PlanBinding) checkedPath() string {
	if b.Checked != "" {
		return b.Checked
	}
	return b.Raw
}

// PlanResult is the verdict. OK is true only when Rejections is empty.
type PlanResult struct {
	Jobs       [][]string     `json:"jobs"`
	Bindings   []PlanBinding  `json:"bindings"`
	Rejections []string       `json:"rejections"`
	Counts     map[string]int `json:"counts"`
}

// OK reports whether the plan may be executed.
func (r PlanResult) OK() bool { return len(r.Rejections) == 0 }

// TokenizeJobLine implements the measured quoting grammar. It never recovers:
// a line that ends inside a quoted run, ends with a dangling backslash, or
// carries an ASCII control byte is an error, not a shorter token list.
func TokenizeJobLine(line string) ([]string, error) {
	var out []string
	var cur strings.Builder
	started := false
	inQuote := false
	for i := 0; i < len(line); i++ {
		c := line[i]
		if c < 0x20 || c == 0x7f {
			return nil, fmt.Errorf("control byte 0x%02x at offset %d", c, i)
		}
		switch {
		case inQuote && c == '\'':
			inQuote = false
		case inQuote:
			cur.WriteByte(c)
		case c == '\'':
			inQuote = true
			started = true
		case c == '\\':
			i++
			if i >= len(line) {
				return nil, fmt.Errorf("line ends with a dangling backslash")
			}
			if line[i] < 0x20 || line[i] == 0x7f {
				return nil, fmt.Errorf("control byte 0x%02x escaped at offset %d", line[i], i)
			}
			cur.WriteByte(line[i])
			started = true
		case c == ' ':
			if started {
				out = append(out, cur.String())
				cur.Reset()
				started = false
			}
		default:
			cur.WriteByte(c)
			started = true
		}
	}
	if inQuote {
		return nil, fmt.Errorf("line ends inside a quoted run")
	}
	if started {
		out = append(out, cur.String())
	}
	return out, nil
}

// ValidSourceRelPath is the Stage A rule that keeps the plan grammar
// line-oriented. Measured: a source whose name carries a newline splits its job
// across physical lines, so the rejection has to happen before the graph phase,
// not after it.
func ValidSourceRelPath(rel string) error {
	if rel == "" {
		return fmt.Errorf("empty relative source path")
	}
	for i := 0; i < len(rel); i++ {
		if c := rel[i]; c < 0x20 || c == 0x7f {
			return fmt.Errorf("control byte 0x%02x at offset %d", c, i)
		}
	}
	return nil
}

func isPathShaped(t string) bool {
	if strings.HasPrefix(t, "/") {
		return true
	}
	// Windows drive-absolute and UNC forms, recognised so the same verifier can
	// be implemented there without loosening.
	if len(t) >= 3 && t[1] == ':' && (t[2] == '\\' || t[2] == '/') {
		c := t[0]
		return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
	}
	return strings.HasPrefix(t, `\\`)
}

func flagValue(toks []string, i int, names []string) (flag, value string, next int, ok bool, err error) {
	t := toks[i]
	for _, n := range names {
		if t == n {
			if i+1 >= len(toks) {
				return n, "", i, false, fmt.Errorf("flag %s has no value", n)
			}
			if toks[i+1] == "" {
				return n, "", i, false, fmt.Errorf("flag %s has an empty value", n)
			}
			return n, toks[i+1], i + 1, true, nil
		}
		if strings.HasPrefix(t, n+"=") {
			v := strings.TrimPrefix(t, n+"=")
			if v == "" {
				return n, "", i, false, fmt.Errorf("flag %s has an empty value", n)
			}
			return n, v, i, true, nil
		}
	}
	return "", "", i, false, nil
}

func resolveEntry(p string) (resolved string, present bool, info os.FileInfo, err error) {
	li, lerr := os.Lstat(p)
	if lerr != nil {
		if os.IsNotExist(lerr) {
			return "", false, nil, nil
		}
		return "", false, nil, lerr
	}
	// A dangling symlink is an entry that exists and resolves nowhere. It is
	// neither "inside a root" nor "absent", so it is a rejection.
	real, rerr := filepath.EvalSymlinks(p)
	if rerr != nil {
		return "", true, li, fmt.Errorf("%s exists but does not resolve: %v", p, rerr)
	}
	fi, serr := os.Stat(real)
	if serr != nil {
		return "", true, li, serr
	}
	return real, true, fi, nil
}

// contained is resolved containment, not a lexical prefix. Both sides are
// symlink-resolved before the comparison, and the comparison is byte-exact on
// path components, so a case variant on a case-insensitive volume fails closed
// rather than passing.
func contained(resolved string, roots []string) bool {
	for _, r := range roots {
		if r == "" {
			continue
		}
		r = strings.TrimSuffix(r, string(filepath.Separator))
		if resolved == r || strings.HasPrefix(resolved, r+string(filepath.Separator)) {
			return true
		}
	}
	return false
}

// lexicallyContained is the retired check. It is retained only so expected-red
// control C8 can restore it from the same binary and report the symlink escape
// it admits.
func lexicallyContained(p string, roots []string) bool {
	for _, r := range roots {
		if r == "" {
			continue
		}
		r = strings.TrimSuffix(r, string(filepath.Separator))
		if p == r || strings.HasPrefix(p, r+string(filepath.Separator)) {
			return true
		}
	}
	return false
}

func identityOf(fi os.FileInfo) string {
	if fi == nil {
		return "absent"
	}
	return fmt.Sprintf("size=%d mode=%v mtime=%d", fi.Size(), fi.Mode(), fi.ModTime().UnixNano())
}

// VerifyPlanPathShapeOnly is the RETIRED cycle-2 verifier. It is total only over
// tokens it already recognises as path-shaped, so an unknown flag, a joined
// `-flag=value` carrier and an opaque value carrying a path all pass without a
// verdict. It is retained solely so expected-red control C14 can restore it from
// the same binary and report how many of the closed-grammar negatives it admits.
// The live gate is VerifyPlan in planclosed.go.
func VerifyPlanPathShapeOnly(planOut string, pol PlanPolicy) PlanResult {
	res := PlanResult{Counts: map[string]int{}}
	reject := func(format string, a ...any) {
		res.Rejections = append(res.Rejections, fmt.Sprintf(format, a...))
	}
	bind := func(b PlanBinding) {
		res.Bindings = append(res.Bindings, b)
		res.Counts[b.Bucket]++
	}

	sources := map[string]bool{}
	for _, s := range pol.Sources {
		sources[s] = true
	}

	lines, lerr := SplitPlanLines(planOut)
	if lerr != nil {
		reject("the job plan does not satisfy the physical-line grammar: %v", lerr)
		return res
	}

	// checkOne applies one bucket's rule and records the binding.
	checkOne := func(bucket, flag, raw string, lineNo int) {
		checkBucket(&res, pol, sources, bucket, flag, raw, lineNo)
	}

	for li, line := range lines {
		lineNo := li + 1
		// No CR is stripped and no line is trimmed. SplitPlanLines already
		// rejected every control byte, including CR, so a line that reaches
		// here is exactly the bytes the compiler emitted between two LFs.
		toks, err := TokenizeJobLine(line)
		if err != nil {
			reject("line %d does not parse: %v", lineNo, err)
			continue
		}
		if len(toks) == 0 {
			reject("line %d tokenized to nothing", lineNo)
			continue
		}
		res.Jobs = append(res.Jobs, toks)
		checkOne(BucketExecutable, "", toks[0], lineNo)

		for i := 1; i < len(toks); i++ {
			t := toks[i]

			if flag, value, next, ok, ferr := flagValue(toks, i, planExecutableFlags); ferr != nil {
				reject("line %d: %v", lineNo, ferr)
				continue
			} else if ok {
				checkOne(BucketExecutable, flag, value, lineNo)
				i = next
				continue
			}
			if flag, value, next, ok, ferr := flagValue(toks, i, planPluginFlags); ferr != nil {
				reject("line %d: %v", lineNo, ferr)
				continue
			} else if ok {
				for _, part := range pluginComponents(flag, value, lineNo, reject) {
					checkOne(BucketPlugin, flag, part, lineNo)
				}
				i = next
				continue
			}
			if flag, value, next, ok, ferr := flagValue(toks, i, planSearchFlags); ferr != nil {
				reject("line %d: %v", lineNo, ferr)
				continue
			} else if ok {
				checkOne(BucketSearch, flag, value, lineNo)
				i = next
				continue
			}
			if flag, value, next, ok, ferr := flagValue(toks, i, planSourceFlags); ferr != nil {
				reject("line %d: %v", lineNo, ferr)
				continue
			} else if ok {
				checkOne(BucketSource, flag, value, lineNo)
				i = next
				continue
			}
			if flag, value, next, ok, ferr := flagValue(toks, i, planOutputFlags); ferr != nil {
				reject("line %d: %v", lineNo, ferr)
				continue
			} else if ok {
				checkOne(BucketOutput, flag, value, lineNo)
				i = next
				continue
			}
			if joined, value, ok := joinedSearch(t); ok {
				checkOne(BucketSearch, joined, value, lineNo)
				continue
			}

			if isPathShaped(t) {
				// A positional absolute path is either a compiled source unit or
				// an intermediate the job writes or reads inside operation-private
				// state. Anything else has no bucket and rejects.
				if sources[t] {
					bind(PlanBinding{Bucket: BucketSource, Raw: t, Resolved: t, Present: true})
					continue
				}
				resolved, present, _, rerr := resolveEntry(t)
				if rerr == nil && !present {
					resolved, present, _, rerr = resolveEntry(filepath.Dir(t))
				}
				if rerr == nil && present && contained(resolved, pol.OperationPrivate) {
					bind(PlanBinding{Bucket: BucketOutput, Raw: t, Resolved: resolved, Present: true})
					continue
				}
				reject("line %d: positional path %q is neither a source-set member nor operation-private state", lineNo, t)
				continue
			}

			// A relative token that names an existing entry under the child
			// working directory is a path the bucket scan would have missed.
			if pol.WorkingDir != "" && !strings.HasPrefix(t, "-") && t != "" {
				if _, err := os.Lstat(filepath.Join(pol.WorkingDir, t)); err == nil {
					reject("line %d: token %q names an existing entry relative to the working directory", lineNo, t)
				}
			}
		}
	}
	sort.SliceStable(res.Bindings, func(a, b int) bool { return res.Bindings[a].Bucket < res.Bindings[b].Bucket })
	return res
}

func labelOf(flag, bucket string) string {
	if flag == "" {
		return bucket
	}
	return flag
}

func joinedSearch(t string) (flag, value string, ok bool) {
	for _, p := range joinedSearchPrefixes {
		if len(t) > len(p) && strings.HasPrefix(t, p) {
			v := t[len(p):]
			if isPathShaped(v) {
				return p, v, true
			}
		}
	}
	return "", "", false
}

// pluginComponents splits a plugin flag value into the paths it introduces.
// `-external-plugin-path` carries exactly `<dir>#<server>`; every other plugin
// flag carries exactly one path. Any other shape rejects.
func pluginComponents(flag, value string, lineNo int, reject func(string, ...any)) []string {
	if flag != "-external-plugin-path" {
		if strings.Contains(value, "#") {
			reject("line %d: %s value %q carries a '#' separator the flag does not define", lineNo, flag, value)
			return nil
		}
		return []string{value}
	}
	parts := strings.Split(value, "#")
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		reject("line %d: -external-plugin-path value %q is not exactly <dir>#<server>", lineNo, value)
		return nil
	}
	return parts
}

// Reverify is the permit-time re-check. It runs immediately before the compile
// child starts and requires every binding to be exactly what the graph phase
// verified: the same resolution, the same file identity, and an absent plugin
// path still absent.
//
// This narrows the window rather than removing it. What actually closes the race
// is the ownership requirement the declaration channels already impose — both
// fingerprinted roots are manager-distribution or owner-protected manager-owned
// state, and the staging tree is operation-private — so no other principal is
// admitted as a writer in the first place. The re-check is the defence that does
// not depend on that assumption holding.
//
// Cycle 5 repairs two things the reviewer found while integrating this into the
// session:
//
//   - it re-checks the path whose identity was recorded (checkedPath), not the
//     raw token. An output that does not exist yet recorded its operation-private
//     PARENT; re-resolving the still-absent file would fail the happy path.
//   - an absent plugin path stays absent only on ENOENT. A permission error, an
//     I/O error, a dangling symlink or any other Lstat failure is not evidence of
//     continued absence, so it is a finding rather than a `continue`.
func Reverify(bindings []PlanBinding) []string {
	var findings []string
	for _, b := range bindings {
		p := b.checkedPath()
		if b.Bucket == BucketPlugin && !b.Present {
			_, err := os.Lstat(p)
			switch {
			case err == nil:
				findings = append(findings, fmt.Sprintf("plugin path %q was absent at graph time and exists at permit time", p))
			case !os.IsNotExist(err):
				// Fail closed: this is not proof of absence.
				findings = append(findings, fmt.Sprintf("plugin path %q was absent at graph time and cannot be re-checked: %v", p, err))
			}
			continue
		}
		if b.info == nil {
			continue
		}
		real, err := filepath.EvalSymlinks(p)
		if err != nil {
			findings = append(findings, fmt.Sprintf("%s %q no longer resolves: %v", b.Bucket, p, err))
			continue
		}
		if real != b.Resolved {
			findings = append(findings, fmt.Sprintf("%s %q resolved to %q at graph time and %q at permit time", b.Bucket, p, b.Resolved, real))
			continue
		}
		fi, err := os.Stat(real)
		if err != nil {
			findings = append(findings, fmt.Sprintf("%s %q disappeared: %v", b.Bucket, p, err))
			continue
		}
		if !os.SameFile(fi, b.info) || identityOf(fi) != b.Identity {
			findings = append(findings, fmt.Sprintf("%s %q changed identity between graph and permit", b.Bucket, p))
		}
	}
	return findings
}

// ReverifyRetired is the retired permit-time re-check, kept only so expected-red
// control C17 can restore it from the same binary: it re-resolves the raw token
// and treats any Lstat error on an absent plugin path as continued absence. The
// first defect rejects a valid absent output; the second admits a plugin path
// whose state can no longer be established.
func ReverifyRetired(bindings []PlanBinding) []string {
	var findings []string
	for _, b := range bindings {
		if b.Bucket == BucketPlugin && !b.Present {
			if _, err := os.Lstat(b.Raw); err == nil {
				findings = append(findings, fmt.Sprintf("plugin path %q was absent at graph time and exists at permit time", b.Raw))
			}
			continue
		}
		if b.info == nil {
			continue
		}
		real, err := filepath.EvalSymlinks(b.Raw)
		if err != nil {
			findings = append(findings, fmt.Sprintf("%s %q no longer resolves: %v", b.Bucket, b.Raw, err))
			continue
		}
		if real != b.Resolved {
			findings = append(findings, fmt.Sprintf("%s %q resolved to %q at graph time and %q at permit time", b.Bucket, b.Raw, b.Resolved, real))
			continue
		}
		fi, err := os.Stat(real)
		if err != nil {
			findings = append(findings, fmt.Sprintf("%s %q disappeared: %v", b.Bucket, b.Raw, err))
			continue
		}
		if !os.SameFile(fi, b.info) || identityOf(fi) != b.Identity {
			findings = append(findings, fmt.Sprintf("%s %q changed identity between graph and permit", b.Bucket, b.Raw))
		}
	}
	return findings
}

// LenientPlanScan is the retired parser. It is retained only so expected-red
// control C7 can restore it from the same binary: it silently ignores a line
// whose first token is not absolute, a flag with no value, and any shape it does
// not recognise, which is exactly the behaviour that made a malformed plan look
// acceptable.
func LenientPlanScan(planOut string) (execs, plugins []string) {
	for _, line := range strings.Split(planOut, "\n") {
		toks, err := TokenizeJobLine(strings.TrimSpace(line))
		if err != nil {
			continue
		}
		if len(toks) > 0 && strings.HasPrefix(toks[0], "/") {
			execs = append(execs, toks[0])
		}
		for i, t := range toks {
			for _, f := range planPluginFlags {
				if t != f || i+1 >= len(toks) {
					continue
				}
				for _, part := range strings.Split(toks[i+1], "#") {
					if part != "" {
						plugins = append(plugins, part)
					}
				}
			}
		}
	}
	return execs, plugins
}

// checkBucket applies one bucket's rule to one path and records the binding it
// verified. It is the single implementation both the live closed-grammar
// verifier and the retired path-shape-only one call, so the two can never
// disagree about what a bucket means.
func checkBucket(res *PlanResult, pol PlanPolicy, sources map[string]bool, bucket, flag, raw string, lineNo int) {
	reject := func(format string, a ...any) {
		res.Rejections = append(res.Rejections, fmt.Sprintf(format, a...))
	}
	bind := func(b PlanBinding) {
		res.Bindings = append(res.Bindings, b)
		res.Counts[b.Bucket]++
	}
	if !isPathShaped(raw) {
		reject("line %d: %s value %q is not an absolute path", lineNo, labelOf(flag, bucket), raw)
		return
	}
	resolved, present, info, err := resolveEntry(raw)
	if err != nil {
		reject("line %d: %s value %q could not be resolved: %v", lineNo, labelOf(flag, bucket), raw, err)
		return
	}
	// checked is the path whose identity this function actually established. It
	// is the raw token everywhere except a not-yet-created output, where the
	// operation-private PARENT is what was resolved and identified. Recording it
	// is what makes the permit-time re-check re-examine the same thing.
	checked := raw
	switch bucket {
	case BucketExecutable:
		if !present {
			reject("line %d: executable %q does not exist", lineNo, raw)
			return
		}
		if !contained(resolved, []string{pol.ToolchainRoot}) {
			reject("line %d: executable %q resolves to %q, outside the swift-toolchain root", lineNo, raw, resolved)
			return
		}
		if !info.Mode().IsRegular() || info.Mode().Perm()&0o111 == 0 {
			reject("line %d: executable %q resolves to a non-executable entry", lineNo, raw)
			return
		}
	case BucketPlugin:
		if present && !contained(resolved, pol.FingerprintedRoots) {
			reject("line %d: plugin path %q exists and resolves to %q, outside every fingerprinted root", lineNo, raw, resolved)
			return
		}
	case BucketSearch:
		if !present {
			reject("line %d: search path %q does not exist", lineNo, raw)
			return
		}
		if !contained(resolved, pol.FingerprintedRoots) {
			reject("line %d: search path %q resolves to %q, outside every fingerprinted root", lineNo, raw, resolved)
			return
		}
	case BucketSource:
		if !sources[raw] {
			reject("line %d: source token %q is not a member of the manager's own source set", lineNo, raw)
			return
		}
	case BucketOutput:
		// An output need not exist yet; its parent must be operation-private.
		// When it does not exist, the parent is both what is verified and what
		// the permit-time re-check must re-examine, so `checked` moves with it.
		if !present {
			checked = filepath.Dir(raw)
			var perr error
			resolved, present, info, perr = resolveEntry(checked)
			if perr != nil || !present {
				reject("line %d: output %q has no resolvable operation-private parent", lineNo, raw)
				return
			}
		}
		if !contained(resolved, pol.OperationPrivate) {
			reject("line %d: output %q resolves to %q, outside operation-private manager state", lineNo, raw, resolved)
			return
		}
	}
	bind(PlanBinding{Bucket: bucket, Flag: flag, Raw: raw, Checked: checked, Resolved: resolved, Present: present, Identity: identityOf(info), info: info})
}
