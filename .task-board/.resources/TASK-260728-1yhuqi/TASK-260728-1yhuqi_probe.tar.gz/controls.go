package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Controls are expected-red: each one restores a retired defect from this same
// binary and MUST fail. A control that passes means the property it guards is
// no longer being checked.
func Controls(tc *Toolchain, h *harness, base string, cases []Case) []ControlResult {
	var out []ControlResult

	// C1 — recognise leads instead of whole outcomes.
	{
		findings := 0
		var detail []string
		for _, c := range cases[:min(6, len(cases))] {
			r := RunCase(tc, filepath.Join(base, "c1"), c, modeLead, false)
			if r.Isolated.Class != c.Isolated || r.Corroborating.Class != c.Corroborating {
				findings++
				if len(detail) < 3 {
					detail = append(detail, fmt.Sprintf("%s isolated=%s(want %s) corroborating=%s(want %s)",
						c.ID, r.Isolated.Class, c.Isolated, r.Corroborating.Class, c.Corroborating))
				}
			}
		}
		out = append(out, ControlResult{
			ID: "C1-lead-only-recognition", Guards: "an outcome is a whole line, not a message lead",
			Failed: findings > 0, Findings: findings, Detail: strings.Join(detail, "; "),
		})
	}

	// C2 — substring matching anywhere in the output.
	{
		findings := 0
		var detail []string
		for _, m := range []struct {
			raw    string
			stderr string
		}{
			{"6.0", "note: context\nerror: the Swift tools version '6.0' is misspelt or otherwise invalid; consider replacing it with '// swift-tools-version: " + tc.Normalized + "' to specify the current Swift toolchain version as the lowest Swift version supported by the project trailing"},
		} {
			exact := recognise(isolatedExpectations(m.raw, PkgDir, tc.Normalized, tc.CompilerMM), 1, "", m.stderr, "", modeExact)
			sub := recognise(isolatedExpectations(m.raw, PkgDir, tc.Normalized, tc.CompilerMM), 1, "", m.stderr, "", modeSubstring)
			if exact.Class == ClassUnknown && sub.Class != ClassUnknown {
				findings++
				detail = append(detail, fmt.Sprintf("substring yielded %s where exact yielded unknown", sub.Class))
			}
		}
		out = append(out, ControlResult{
			ID: "C2-substring-recognition", Guards: "a diagnostic embedded in a longer line is not that diagnostic",
			Failed: findings > 0, Findings: findings, Detail: strings.Join(detail, "; "),
		})
	}

	// C3 — exit status as semantics.
	{
		findings := 0
		var detail []string
		for _, c := range cases {
			// Only the corroborating command distinguishes the floor, the host
			// gate and a grammar rejection. Reading its exit status instead of
			// its diagnostic collapses all three into one.
			if c.Corroborating == ClassAccepted {
				continue
			}
			r := RunCase(tc, filepath.Join(base, "c3"), c, modeExitStatus, false)
			if r.Corroborating.Class != c.Corroborating {
				findings++
				if len(detail) < 3 {
					detail = append(detail, fmt.Sprintf("%s collapsed to %s (want %s)", c.ID, r.Corroborating.Class, c.Corroborating))
				}
			}
		}
		out = append(out, ControlResult{
			ID: "C3-exit-status-as-semantics", Guards: "the floor, the host gate and a grammar rejection are not one exit status",
			Failed: findings > 0, Findings: findings, Detail: strings.Join(detail, "; "),
		})
	}

	// C4 — `swift build` used as the isolated command, which folds the host gate
	// and the floor into representability.
	{
		findings := 0
		var detail []string
		for _, c := range cases {
			if !c.HostGate && c.Isolated != ClassAccepted {
				continue
			}
			if c.Isolated != ClassAccepted || c.Corroborating == ClassAccepted {
				continue
			}
			r := RunCase(tc, filepath.Join(base, "c4"), c, modeExact, true)
			if r.Isolated.Class != ClassAccepted {
				findings++
				if len(detail) < 3 {
					detail = append(detail, fmt.Sprintf("%s isolated=%s under the wrong command", c.ID, r.Isolated.Class))
				}
			}
		}
		out = append(out, ControlResult{
			ID: "C4-build-as-the-isolated-command", Guards: "representability is measured by a command that cannot apply the host gate",
			Failed: findings > 0, Findings: findings, Detail: strings.Join(detail, "; "),
		})
	}

	// C5 — a PATH-closure zero claimed without a firing sensitivity control.
	{
		// The shim directory is not on PATH at all: the pinned run still reports
		// zero resolutions, and that zero is worthless.
		h.resetLog()
		env := &Env{PATH: h.emptyDir, HOME: filepath.Join(h.base, "home"), TMP: filepath.Join(h.base, "tmp") + string(os.PathSeparator)}
		r := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c5"), nil,
			[]string{filepath.Join(h.srcDir, "main.swift"), filepath.Join(h.srcDir, "helper.swift")}), h.srcDir, env)
		hits := len(h.shimHits())
		h.resetLog()
		ctl := runFixed(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c5ctl"), []string{"-use-ld=lld"},
			[]string{filepath.Join(h.srcDir, "main.swift")}), h.srcDir, env)
		ctlHits := len(h.shimHits())
		unearned := r.Exit == 0 && hits == 0 && ctlHits == 0
		out = append(out, ControlResult{
			ID: "C5-unearned-path-closure-zero", Guards: "a zero without a firing control is not evidence",
			Failed: unearned, Findings: boolToInt(unearned),
			Detail: fmt.Sprintf("pinned exit=%d hits=%d; sensitivity control exit=%d hits=%d", r.Exit, hits, ctl.Exit, ctlHits),
		})
	}

	// C6 — plugin-path closure not checked: the declared SDK path is used
	// directly and an executable plugin tree outside every fingerprinted root
	// enters the closure unnoticed.
	{
		pol := h.policy(h.defaultSources())
		_, planOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(tc.DeclaredSDK, filepath.Join(h.stage, "c6"), nil, h.defaultSources()), h.srcDir, h.cleanEnv())
		_, plugins := LenientPlanScan(planOut)
		findings := 0
		var detail []string
		for _, p := range distinct(plugins) {
			if r, err := filepath.EvalSymlinks(p); err == nil && !contained(r, pol.FingerprintedRoots) {
				findings++
			}
		}
		if findings > 0 {
			detail = append(detail, fmt.Sprintf("the declared SDK path derives %d distinct live plugin paths outside every fingerprinted root", findings))
		}
		out = append(out, ControlResult{
			ID: "C6-plugin-closure-unchecked", Guards: "the macro plugin surface is inside the fingerprinted closure",
			Failed: findings > 0, Findings: findings, Detail: strings.Join(detail, "; "),
		})
	}

	// C7 — the retired plan parser: silently ignore a line whose first token is
	// not absolute, a flag with no value, and any shape it does not recognise.
	{
		vectors := BadPlanVectors(h)
		admitted := LenientlyAdmitted(vectors)
		pol := h.policy(h.defaultSources())
		strictRejected := 0
		for _, b := range vectors {
			if !VerifyPlan(b.Plan+"\n", pol).OK() {
				strictRejected++
			}
		}
		out = append(out, ControlResult{
			ID: "C7-lenient-plan-parsing", Guards: "a plan shape the grammar does not cover is a rejection, not a skip",
			Failed: len(admitted) > 0, Findings: len(admitted),
			Detail: fmt.Sprintf("the retired scan admits %d of %d malformed plans the strict verifier rejects (%d rejected): %s",
				len(admitted), len(vectors), strictRejected, clipTo(strings.Join(admitted, ", "), 400)),
		})
	}

	// C8 — lexical prefix containment instead of resolved containment.
	{
		fakeRoot := filepath.Join(h.base, "c8root")
		_ = os.MkdirAll(filepath.Join(fakeRoot, "bin"), 0o755)
		resolved, _ := filepath.EvalSymlinks(fakeRoot)
		escape := filepath.Join(resolved, "bin", "ld")
		_ = os.Remove(escape)
		_ = os.Symlink("/bin/sh", escape)
		findings := 0
		var detail []string
		if lexicallyContained(escape, []string{resolved}) {
			real, err := filepath.EvalSymlinks(escape)
			if err == nil && !contained(real, []string{resolved}) {
				findings++
				detail = append(detail, fmt.Sprintf("%s is lexically inside the root and really resolves to %s", escape, real))
			}
		}
		out = append(out, ControlResult{
			ID: "C8-lexical-containment", Guards: "containment is resolved, not a string prefix",
			Failed: findings > 0, Findings: findings, Detail: strings.Join(detail, "; "),
		})
	}

	// C9 — the retired module-name rule: replace every character outside the
	// module alphabet with an underscore.
	{
		naive := map[string][]string{}
		for _, k := range []string{"my-tool", "my.tool", "my_tool", "a.b-c", "a-b.c", "9.tool", "9-tool"} {
			m := NaiveModuleName(k)
			naive[m] = append(naive[m], k)
		}
		findings := 0
		var detail []string
		for m, keys := range naive {
			if len(keys) > 1 {
				findings++
				if len(detail) < 3 {
					detail = append(detail, fmt.Sprintf("%v all map to %q", keys, m))
				}
			}
		}
		out = append(out, ControlResult{
			ID: "C9-collapsing-module-name-derivation", Guards: "two distinct command keys never share one module name",
			Failed: findings > 0, Findings: findings, Detail: strings.Join(detail, "; "),
		})
	}

	// C10 — the retired prefix-only banner parser: match the prefix, take the
	// numeric token before the first space, never look at the rest.
	{
		vs := BannerVectors(tc.CompilerVersion)
		var admitted []string
		for _, v := range vs {
			if v.Accept {
				continue
			}
			if _, ok := NaiveCompilerVersionPrefixOnly(v.Value); ok {
				admitted = append(admitted, fmt.Sprintf("%s %q", v.ID, clipTo(v.Value, 60)))
			}
		}
		out = append(out, ControlResult{
			ID: "C10-prefix-only-banner-parser", Guards: "the compiler banner is matched as a whole value, not by its prefix",
			Failed: len(admitted) > 0, Findings: len(admitted),
			Detail: fmt.Sprintf("the retired parser admits %d banner values the whole-value grammar rejects: %s",
				len(admitted), clipTo(strings.Join(admitted, ", "), 400)),
		})
	}

	// C11 — the retired runtime-library rule: only entries ALREADY inside the
	// toolchain root have to exist. It says nothing about an empty list, a
	// dangling symlink, a regular file, or an entry outside every root.
	{
		root := resolveOr(tc.Root)
		outsideDir := filepath.Join(base, "c11", "outside")
		_ = os.MkdirAll(outsideDir, 0o755)
		aFile := filepath.Join(base, "c11", "a-file")
		_ = os.WriteFile(aFile, []byte("x"), 0o644)
		dangling := filepath.Join(base, "c11", "dangling")
		_ = os.Remove(dangling)
		_ = os.Symlink(filepath.Join(base, "c11", "nothing"), dangling)

		pol := RuntimePolicy{
			Roots: []RootRecord{
				{Role: RoleSwiftToolchain, Ordinal: 0, Resolved: root},
				{Role: RolePlatformSDK, Ordinal: 0, Resolved: resolveOr(tc.DeclaredSDK)},
			},
			BaseInstallPrefixes: baseInstallPrefixes("darwin"),
		}
		vectors := []struct {
			id    string
			paths []string
		}{
			{"empty list", nil},
			{"out-of-closure directory", []string{outsideDir}},
			{"regular file", []string{aFile}},
			{"dangling symlink", []string{dangling}},
			{"relative path", []string{"usr/lib/swift/macosx"}},
			{"base-installation only", []string{"/usr/lib/swift"}},
		}
		findings := 0
		var detail []string
		for _, v := range vectors {
			lenient := NaiveRuntimeAdmission(v.paths, root)
			strict := AdmitRuntimeLibraryPaths(tc.Triple, v.paths, pol).OK()
			if lenient && !strict {
				findings++
				detail = append(detail, v.id)
			}
		}
		out = append(out, ControlResult{
			ID: "C11-lenient-runtime-library-admission", Guards: "the standard-library closure is total, not \"whatever is already in the root\"",
			Failed: findings > 0, Findings: findings,
			Detail: fmt.Sprintf("the retired rule admits %d of %d runtime-library shapes the closed rule rejects: %s",
				findings, len(vectors), strings.Join(detail, ", ")),
		})
	}

	// C12 — the retired plan splitter: optional terminal LF, and one trailing
	// CR silently removed from every line.
	{
		body := "/bin/true -x"
		vectors := []struct{ id, plan string }{
			{"unterminated final line", body},
			{"CRLF", body + "\r\n"},
			{"bare CR before the terminator", body + "\r\n"},
			{"trailing CR on every line", body + "\r\n" + body + "\r\n"},
		}
		findings := 0
		var detail []string
		for _, v := range vectors {
			_, lenientErr := NaiveSplitPlanLines(v.plan)
			_, strictErr := SplitPlanLines(v.plan)
			if lenientErr == nil && strictErr != nil {
				findings++
				detail = append(detail, v.id)
			}
		}
		out = append(out, ControlResult{
			ID: "C12-cr-normalizing-plan-splitter", Guards: "LF is the only terminator and a bare CR is a rejection, never a stripped byte",
			Failed: findings > 0, Findings: findings,
			Detail: fmt.Sprintf("the retired splitter admits %d of %d plan shapes the physical-line grammar rejects: %s",
				findings, len(vectors), strings.Join(detail, ", ")),
		})
	}

	// C13 — the retired Stage B: no source admission at all, which is what every
	// cycle before this one shipped. Restoring it lets macro-selecting source
	// pass verification, receive a compile permit and load a macro implementation
	// under the contract's own single compile command. This is the control the
	// cycle-4 reviewer required for "macro-selecting source cannot receive a
	// compile permit".
	{
		dir, path := h.writeSource("c13-macro", macroSource)
		retiredAdm := AdmitSourcesRetired([]string{path})
		permitted := retiredAdm.OK()
		rec := RetiredCompile(tc.Swiftc, h.compileVector(h.presentedSDK(), filepath.Join(h.stage, "c13"),
			[]string{"-Xfrontend", "-Rmacro-loading"}, []string{path}), dir, h.cleanEnv())
		lib := ""
		for _, l := range strings.Split(rec.Stderr, "\n") {
			if strings.Contains(l, macroLoadRemark) {
				lib = strings.TrimSpace(l)
				break
			}
		}
		admitted := permitted && rec.Exit == 0 && lib != ""
		out = append(out, ControlResult{
			ID:     "C13-macro-source-admitted-without-stage-b",
			Guards: "a compiler macro selected by package source is rejected before the graph phase, not left to fail inside a compile child",
			Failed: admitted, Findings: boolToInt(admitted),
			Detail: fmt.Sprintf("without curator-swift-source-admission-v1 the macro-selecting source is admitted (permit granted=%v), "+
				"the compile command exits %d and loads a macro implementation: %s",
				permitted, rec.Exit, clipTo(lib, 260)),
		})
	}

	// C14 — the retired path-shape-only totality: unknown flags, joined carriers
	// and pass-through values are accepted because the token itself is not
	// path-shaped.
	{
		pol := h.policy(h.defaultSources())
		_, planOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "c14"), nil, h.defaultSources()), h.srcDir, h.cleanEnv())
		res := VerifyPlan(planOut, pol)
		findings := 0
		var detail []string
		if len(res.Jobs) > 0 {
			for _, neg := range closedGrammarNegatives(res.Jobs[0], tc, h) {
				line := renderJob(neg.job) + "\n"
				if VerifyPlanPathShapeOnly(line, pol).OK() && !VerifyPlan(line, pol).OK() {
					findings++
					detail = append(detail, neg.name)
				}
			}
		}
		out = append(out, ControlResult{
			ID:     "C14-path-shape-only-totality",
			Guards: "totality is over every token, not over the tokens already recognised as paths",
			Failed: findings > 0, Findings: findings,
			Detail: fmt.Sprintf("the retired verifier admits %d unknown-channel vectors the closed grammar rejects: %s",
				findings, clipTo(strings.Join(detail, ", "), 400)),
		})
	}

	// C15 — the retired cycle-3 pipeline: the manager executes every verified
	// plan job itself with the plugin channel deleted. It works, and it is still
	// not manager-worker-v2: accepted decision 0008 section 7 admits at most one
	// graph command and EXACTLY ONE compile command, started by the driver's own
	// trusted launcher. This control reports the command count that design
	// produces, which is the cycle-4 reviewer's "a multi-command compile sequence
	// cannot be admitted under manager-worker-v2".
	{
		srcs := h.defaultSources()
		pol := h.policy(srcs)
		_, planOut, _ := runFixedRaw(tc.Swiftc, h.graphVector(h.presentedSDK(), filepath.Join(h.stage, "c15"), nil, srcs), h.srcDir, h.cleanEnv())
		res := VerifyPlan(planOut, pol)
		jobs := 0
		if res.OK() {
			jobs = len(StripPluginChannel(res.Jobs).Executed)
		}
		// 1 graph command + one command per plan job.
		total := 1 + jobs
		var names []string
		for _, j := range StripPluginChannel(res.Jobs).Executed {
			if len(j) > 0 {
				names = append(names, filepath.Base(j[0]))
			}
		}
		overCardinality := jobs > 1
		out = append(out, ControlResult{
			ID:     "C15-multi-command-compile-under-v2",
			Guards: "one manager-worker-v2 session is at most one graph command and exactly one compile command",
			Failed: overCardinality, Findings: jobs,
			Detail: fmt.Sprintf("the retired plan-execution design starts %d manager commands for this source set "+
				"(1 graph + %d plan jobs: %s) where manager-worker-v2 admits 2, and it starts %s directly instead of "+
				"through the driver's trusted launcher",
				total, jobs, strings.Join(names, ", "), clipTo(strings.Join(distinct(names), "/"), 80)),
		})
	}

	// C16 — the retired cycle-4 session: graph command, plan verification, then
	// straight to compile_argv with no permit-time re-binding. That is exactly
	// the session the cycle-5 reviewer found: the mechanism existed, and the
	// session the probe exercised did not call it. Restoring it lets a plugin
	// path verified ABSENT appear after verification and still receive a compile
	// permit.
	{
		dir := filepath.Join(base, "c16-src")
		_ = os.RemoveAll(dir)
		_ = os.MkdirAll(dir, 0o755)
		var srcs []string
		for _, s := range h.defaultSources() {
			dst := filepath.Join(dir, filepath.Base(s))
			copyFile(s, dst)
			srcs = append(srcs, dst)
		}
		outDir := filepath.Join(h.stage, "c16")
		_ = os.RemoveAll(outDir)
		_ = os.MkdirAll(outDir, 0o755)
		out2 := filepath.Join(outDir, "artifact")

		dry := h.runSession(sessionSpec{sources: srcs, dir: dir, out: out2})
		target := ""
		for _, bd := range dry.Verify.Bindings {
			if bd.Bucket == BucketPlugin && !bd.Present && strings.HasPrefix(bd.Raw, h.base) {
				target = bd.Raw
				break
			}
		}
		_ = os.RemoveAll(outDir)
		_ = os.MkdirAll(outDir, 0o755)

		appear := func() {
			if target != "" {
				_ = os.MkdirAll(target, 0o755)
			}
		}
		retired := h.runSession(sessionSpec{sources: srcs, dir: dir, out: out2, mutate: appear, skipReverify: true})
		retiredPermitted := retired.CompileRan()
		_ = os.RemoveAll(target)

		// And the live session, same mutation, for the side-by-side number.
		_ = os.RemoveAll(outDir)
		_ = os.MkdirAll(outDir, 0o755)
		live := h.runSession(sessionSpec{sources: srcs, dir: dir, out: out2, mutate: appear})
		_ = os.RemoveAll(target)

		out = append(out, ControlResult{
			ID:     "C16-compile-permit-without-permit-time-rebinding",
			Guards: "the single compile command is started only after every binding is re-resolved and re-identified at the permit",
			Failed: retiredPermitted, Findings: boolToInt(retiredPermitted),
			Detail: fmt.Sprintf("with the re-binding step removed, a plugin path verified absent appears after verification and the "+
				"session still starts %d manager commands (compile ran=%v, artifact=%v); the live session stops at %d command(s) "+
				"with %s/%s and no artifact",
				retired.ManagerCommands(), retiredPermitted, exists(out2), live.ManagerCommands(), live.Class, live.Diagnostic),
		})
		_ = os.RemoveAll(outDir)
	}

	// C17 — the retired permit-time re-check itself: re-resolve the RAW token
	// and treat any Lstat error on an absent plugin path as continued absence.
	// The first defect rejects the ordinary happy path, because a correct
	// not-yet-created output does not resolve; the second admits a plugin path
	// whose state cannot be established at all.
	{
		dir := filepath.Join(h.stage, "c17")
		_ = os.RemoveAll(dir)
		_ = os.MkdirAll(dir, 0o755)
		// Measured AT the permit, on the same bindings, in the same moment: after
		// the session the compile command has already changed the world.
		var live int
		var retired []string
		_ = h.runSession(sessionSpec{sources: h.defaultSources(), dir: h.srcDir, out: filepath.Join(dir, "artifact"),
			observe: func(b BuildOutcome) {
				live = len(Reverify(b.Verify.Bindings))
				retired = ReverifyRetired(b.Verify.Bindings)
			}})

		denied := filepath.Join(base, "c17-denied")
		_ = os.RemoveAll(denied)
		_ = os.MkdirAll(filepath.Join(denied, "inner"), 0o755)
		p := filepath.Join(denied, "inner", "plugins")
		bindings := []PlanBinding{{Bucket: BucketPlugin, Raw: p, Checked: p, Present: false}}
		_ = os.Chmod(denied, 0o000)
		liveDenied := len(Reverify(bindings))
		retiredDenied := len(ReverifyRetired(bindings))
		_ = os.Chmod(denied, 0o755)

		findings := len(retired) + boolToInt(liveDenied > retiredDenied)
		failed := (live == 0 && len(retired) > 0) || retiredDenied < liveDenied
		out = append(out, ControlResult{
			ID:     "C17-retired-permit-recheck-binding-model",
			Guards: "a binding re-checks the path whose identity it recorded, and an absent plugin path stays absent only on ENOENT",
			Failed: failed, Findings: findings,
			Detail: fmt.Sprintf("on the same verified happy-path bindings the retired re-check reports %d finding(s) where the live one "+
				"reports %d, rejecting a correctly absent output: %s; on an absent plugin path that cannot be stat'ed the retired "+
				"re-check reports %d and the live one %d",
				len(retired), live, clipTo(firstOf(retired), 220), retiredDenied, liveDenied),
		})
		_ = os.RemoveAll(dir)
	}

	return out
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
