package main

// Cases is the single canonical case table. Every emitted case is re-checked
// against this table at the end of the run, so a declared expectation and an
// executed one can never drift apart silently.
//
// "F" marks the security partition: a value upstream represents and Curator
// deliberately refuses. P2 (no narrowing) is asserted only outside F.
func Cases(compilerFull string) []Case {
	return []Case{
		{
			ID: "canonical-current", Manifest: "// swift-tools-version:" + compilerFull + "\n",
			Display: "// swift-tools-version:<compiler>",
			Curator: ClassAccepted, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			Note: "the resolved toolchain's own version is admissible",
		},
		{
			ID: "canonical-6.0", Manifest: "// swift-tools-version:6.0\n",
			Display: "// swift-tools-version:6.0",
			Curator: ClassAccepted, Isolated: ClassAccepted, Corroborating: ClassAccepted,
		},
		{
			ID: "canonical-floor", Manifest: "// swift-tools-version:4.0\n",
			Display: "// swift-tools-version:4.0",
			Curator: ClassAccepted, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			Note: "lowest tools version the resolved toolchain still supports",
		},
		{
			ID: "below-floor-3.1", Manifest: "// swift-tools-version:3.1\n",
			Display: "// swift-tools-version:3.1",
			Curator: ClassFloor, Isolated: ClassAccepted, Corroborating: ClassFloor,
			Note: "representable and unsupported: the isolated command has no floor",
		},
		{
			ID: "below-floor-1.0", Manifest: "// swift-tools-version:1.0\n",
			Display: "// swift-tools-version:1.0",
			Curator: ClassFloor, Isolated: ClassAccepted, Corroborating: ClassFloor,
		},
		{
			ID: "above-host-99.0", Manifest: "// swift-tools-version:99.0\n",
			Display: "// swift-tools-version:99.0",
			Curator: ClassHostGate, Isolated: ClassAccepted, Corroborating: ClassHostGate,
			HostGate: true,
			Note:     "the isolated command reports 99.0.0 with exit 0, so it cannot be applying the host gate",
		},
		{
			ID: "grammar-one-component", Manifest: "// swift-tools-version:6\n",
			Display: "// swift-tools-version:6",
			Curator: ClassGrammar, Isolated: ClassGrammar, Corroborating: ClassGrammar,
		},
		{
			ID: "grammar-four-components", Manifest: "// swift-tools-version:6.0.0.0\n",
			Display: "// swift-tools-version:6.0.0.0",
			Curator: ClassGrammar, Isolated: ClassGrammar, Corroborating: ClassGrammar,
		},
		{
			ID: "grammar-not-a-version", Manifest: "// swift-tools-version:notaversion\n",
			Display: "// swift-tools-version:notaversion",
			Curator: ClassGrammar, Isolated: ClassGrammar, Corroborating: ClassGrammar,
		},
		{
			ID: "missing-specifier", Manifest: "// swift-tools-version:\n",
			Display: "// swift-tools-version:",
			Curator: ClassNoSpecifier, Isolated: ClassNoSpecifier, Corroborating: ClassNoSpecifier,
		},
		{
			ID: "absent-header", Manifest: "",
			Display: "<no header>",
			Curator: ClassNoHeader, Isolated: ClassNoHeader, Corroborating: ClassNoHeader,
			Note: "upstream falls back to 3.1.0 and refuses it; the diagnostic names 'package.swift'",
		},
		{
			ID: "bom-header", Manifest: "\ufeff// swift-tools-version:6.0\n",
			Display: "<BOM>// swift-tools-version:6.0",
			Curator: ClassNoHeader, Isolated: ClassNoHeader, Corroborating: ClassNoHeader,
			Note: "a byte-order mark defeats upstream's own recognition too, so this is not a narrowing",
		},
		{
			ID: "carriage-return", Manifest: "// swift-tools-version:6.0\r\n",
			Display: "// swift-tools-version:6.0<CR>",
			Curator: ClassAccepted, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			Note: "one trailing CR is stripped before the canonical comparison",
		},
		{
			ID: "later-specification-ignored", Manifest: "// swift-tools-version:6.0\n// swift-tools-version:99.0\n",
			Display: "// swift-tools-version:6.0 / // swift-tools-version:99.0",
			Curator: ClassAccepted, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			Note: "line 1 decides for both: measured, upstream reports 6.0.0 and never reaches the line-2 value",
		},
		{
			ID: "specification-inside-a-single-line-string", Manifest: "import PackageDescription\nlet s = \"// swift-tools-version:9.9\"\n",
			Display: "let s = \"// swift-tools-version:9.9\"",
			Curator: ClassNoHeader, Isolated: ClassNoHeader, Corroborating: ClassNoHeader,
			Note: "the line does not begin with the comment marker, so neither upstream nor Curator sees a specification",
		},

		// --- security partition F: upstream represents, Curator refuses -------
		//
		// F has two shapes. The first six members reinterpret a specification that
		// IS on line 1. The last two carry a specification BELOW line 1, which
		// Curator never reads: those classify as rejected-absent-header, because
		// absent means "line 1 carries none", not "the file carries none".
		{
			ID: "F-no-space-after-slashes", Manifest: "//swift-tools-version:6.0\n",
			Display: "//swift-tools-version:6.0",
			Curator: ClassNonCanonical, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
		},
		{
			ID: "F-uppercase-keyword", Manifest: "// SWIFT-TOOLS-VERSION:6.0\n",
			Display: "// SWIFT-TOOLS-VERSION:6.0",
			Curator: ClassNonCanonical, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
		},
		{
			ID: "F-leading-zero", Manifest: "// swift-tools-version:06.0\n",
			Display: "// swift-tools-version:06.0",
			Curator: ClassNonCanonical, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
			Note:              "upstream silently normalises 06.0 to 6.0.0",
		},
		{
			ID: "F-prerelease-suffix", Manifest: "// swift-tools-version:6.0-beta\n",
			Display: "// swift-tools-version:6.0-beta",
			Curator: ClassNonCanonical, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
			Note:              "upstream silently discards the prerelease component",
		},
		{
			ID: "F-build-suffix", Manifest: "// swift-tools-version:6.0+build\n",
			Display: "// swift-tools-version:6.0+build",
			Curator: ClassNonCanonical, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
		},
		{
			ID: "F-extra-whitespace", Manifest: "//   swift-tools-version:  6.0\n",
			Display: "//   swift-tools-version:  6.0",
			Curator: ClassNonCanonical, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
		},
		{
			ID: "F-below-line-one", Manifest: "import Foundation\n// swift-tools-version:6.0\n",
			Display: "import Foundation / // swift-tools-version:6.0",
			Curator: ClassNoHeader, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
			Note:              "upstream finds the specification below manifest code; Curator reads line 1 and stops",
		},
		{
			ID: "F-inside-a-multi-line-string-literal",
			Manifest: "import PackageDescription\nlet unused = \"\"\"\n" +
				"// swift-tools-version:6.0\n\"\"\"\n",
			Display: "let unused = \"\"\" / // swift-tools-version:6.0 / \"\"\"",
			Curator: ClassNoHeader, Isolated: ClassAccepted, Corroborating: ClassAccepted,
			SecurityPartition: true,
			Note: "measured: upstream's scan reports the value from inside a string literal, " +
				"so a whole-file scan would let arbitrary manifest body bytes set the compared version",
		},
	}
}

// ManifestBody is appended after every case's header. It is valid for every
// tools version in the table, so a manifest-API error can never be mistaken for
// a header verdict.
const ManifestBody = "import PackageDescription\n" +
	"let package = Package(name: \"probe\", targets: [.target(name: \"probe\")])\n"

// SourceBody is a library source unit, so `swift build` never has to reason
// about executable shape.
const SourceBody = "public func probeValue() -> Int { return 42 }\n"
