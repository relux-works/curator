package main

import (
	"strings"
	"testing"
)

func TestSplitPlanLinesAcceptsTheMeasuredShape(t *testing.T) {
	plan := "/a/b -x\n/c/d -y\n"
	lines, err := SplitPlanLines(plan)
	if err != nil {
		t.Fatalf("unexpected rejection: %v", err)
	}
	if len(lines) != 2 || lines[0] != "/a/b -x" || lines[1] != "/c/d -y" {
		t.Fatalf("lines = %q", lines)
	}
}

func TestSplitPlanLinesRejections(t *testing.T) {
	cases := []struct{ name, plan, want string }{
		{"empty", "", "empty"},
		{"unterminated", "/a/b", "does not end with LF"},
		{"crlf", "/a/b\r\n", "bare CR"},
		{"bare CR mid-line", "/a\rb\n", "bare CR"},
		{"blank line", "/a\n\n", "empty"},
		{"leading blank", "\n/a\n", "empty"},
		{"NUL", "/a\x00b\n", "control byte 0x00"},
		{"TAB", "/a\tb\n", "control byte 0x09"},
		{"DEL", "/a\x7fb\n", "control byte 0x7f"},
		{"line too long", strings.Repeat("x", planMaxLineBytes+1) + "\n", "admits at most"},
		{"plan too long", strings.Repeat("x\n", planMaxBytes), "admits at most"},
	}
	for _, c := range cases {
		_, err := SplitPlanLines(c.plan)
		if err == nil {
			t.Errorf("%s: expected rejection, got acceptance", c.name)
			continue
		}
		if !strings.Contains(err.Error(), c.want) {
			t.Errorf("%s: error %q does not mention %q", c.name, err, c.want)
		}
	}
}

// High bytes are admitted and compared byte-exactly: a POSIX path is a byte
// string and the plan is not required to be valid UTF-8.
func TestSplitPlanLinesAdmitsHighBytes(t *testing.T) {
	plan := "/a/\xff\xfe -x\n"
	lines, err := SplitPlanLines(plan)
	if err != nil {
		t.Fatalf("high bytes rejected: %v", err)
	}
	if lines[0] != "/a/\xff\xfe -x" {
		t.Fatalf("bytes mutated: %q", lines[0])
	}
}

// The retired splitter must admit something the grammar rejects, or C12 cannot
// fire; and it must not reject anything the grammar accepts.
func TestRetiredSplitterIsStrictlyLooser(t *testing.T) {
	looser := 0
	for _, p := range []string{"/a/b", "/a/b\r\n", "/a\r\n/b\r\n"} {
		_, lerr := NaiveSplitPlanLines(p)
		_, serr := SplitPlanLines(p)
		if lerr == nil && serr != nil {
			looser++
		}
	}
	if looser == 0 {
		t.Fatal("the retired splitter admits nothing the grammar rejects; C12 would not fire")
	}
}

func TestVectorRelation(t *testing.T) {
	prog := "/tc/usr/bin/swiftc"
	compile := []string{"-swift-version", "6", "-O", "-o", "/stage/out"}
	graph := append([]string{"-###"}, compile...)

	v := CheckVectorRelation(prog, compile, graph)
	if !v.OK {
		t.Fatalf("valid pair rejected: %v", v.Findings)
	}
	if v.InsertionIndex != 1 || v.GraphOccurrence != 1 {
		t.Fatalf("insertion=%d occurrences=%d", v.InsertionIndex, v.GraphOccurrence)
	}

	bad := []struct {
		name     string
		comp, gr []string
	}{
		{"no insertion", compile, compile},
		{"doubled", compile, append([]string{"-###", "-###"}, compile...)},
		{"appended", compile, append(append([]string{}, compile...), "-###")},
		{"in the compile vector", append([]string{"-###"}, compile...), append([]string{"-###", "-###"}, compile...)},
		{"co-mutated", compile, append([]string{"-###", "-Onone"}, compile[1:]...)},
	}
	for _, b := range bad {
		if CheckVectorRelation(prog, b.comp, b.gr).OK {
			t.Errorf("%s: accepted", b.name)
		}
	}
}
