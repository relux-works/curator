package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// closedPolicy is testPolicy plus the four opaque constants and the two
// pass-through allow-sets the closed grammar compares against.
func closedPolicy(t *testing.T) (PlanPolicy, string) {
	t.Helper()
	pol, base := testPolicy(t)
	pol.Triple = "arm64-apple-macosx26.0"
	pol.SwiftVersion = "6"
	pol.ModuleName = "Sk_probe"
	pol.XllvmValues = []string{"-aarch64-use-tbi"}
	pol.XccValues = []string{"-fno-color-diagnostics"}
	return pol, base
}

// frontendJob builds a minimal but complete frontend job whose every token the
// closed grammar has to claim.
func frontendJob(base string, pol PlanPolicy, extra ...string) string {
	toks := []string{
		filepath.Join(base, "root", "bin", "frontend"),
		"-frontend", "-c",
		"-primary-file", pol.Sources[0],
		"-target", pol.Triple,
		"-Xllvm", "-aarch64-use-tbi",
		"-enable-objc-interop",
		"-sdk", filepath.Join(base, "sdk"),
		"-no-color-diagnostics",
		"-Xcc", "-fno-color-diagnostics",
		"-swift-version", "6",
		"-O",
		"-module-name", "Sk_probe",
		"-target-sdk-version", "26.5",
		"-target-sdk-name", "macosx26.5",
		"-plugin-path", filepath.Join(base, "root", "plugins"),
		"-o", filepath.Join(base, "priv", "out.o"),
	}
	return strings.Join(append(toks, extra...), " ")
}

func TestClosedGrammarAcceptsTheMeasuredFrontendJob(t *testing.T) {
	pol, base := closedPolicy(t)
	res := VerifyPlan(frontendJob(base, pol)+"\n", pol)
	if !res.OK() {
		t.Fatalf("the measured frontend job shape was rejected: %v", res.Rejections)
	}
}

func TestClosedGrammarAcceptsTheMeasuredLinkJob(t *testing.T) {
	pol, base := closedPolicy(t)
	obj := filepath.Join(base, "priv", "a.o")
	if err := os.WriteFile(obj, []byte("o"), 0o644); err != nil {
		t.Fatal(err)
	}
	line := strings.Join([]string{
		filepath.Join(base, "root", "bin", "frontend"),
		obj,
		"-O3",
		"--sysroot", filepath.Join(base, "sdk"),
		"--target=" + pol.Triple,
		"-L", filepath.Join(base, "root"),
		"-o", filepath.Join(base, "priv", "bin"),
	}, " ")
	if res := VerifyPlan(line+"\n", pol); !res.OK() {
		t.Fatalf("the measured link job shape was rejected: %v", res.Rejections)
	}
}

// Every unknown channel family rejects. Each vector is an otherwise valid job
// carrying exactly one extra or substituted token.
func TestClosedGrammarRejectsEveryUnknownChannel(t *testing.T) {
	pol, base := closedPolicy(t)
	evil := filepath.Join(base, "evil.dylib")
	if err := os.WriteFile(evil, []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct{ name, extra string }{
		{"unknown flag", "-new-channel"},
		{"unknown joined flag with an absolute value", "-new-channel=" + evil},
		{"unknown joined flag with a relative value", "-new-channel=evil.dylib"},
		{"joined LLVM pass plugin", "-load-pass-plugin=" + evil},
		{"pass-through carrying a plugin load", "-Xllvm -load-pass-plugin=" + evil},
		{"pass-through carrying a search path", "-Xcc -I" + base},
		{"pass-through with an unmeasured value", "-Xllvm -some-new-llvm-option"},
		{"stray non-path operand", "stray-operand"},
		{"response file", "@" + evil},
		{"link-only flag in a frontend job", "-O3"},
		{"one extra unknown token", "-enable-future-thing"},
		{"empty token", "''"},
	} {
		line := frontendJob(base, pol) + " " + tc.extra
		if VerifyPlan(line+"\n", pol).OK() {
			t.Errorf("%s: accepted %q", tc.name, tc.extra)
		}
	}
}

// An opaque value is a constant the manager already chose. It may not carry a
// path, a separator, or a different value.
func TestClosedGrammarRejectsOpaqueValueCarriers(t *testing.T) {
	pol, base := closedPolicy(t)
	for _, tc := range []struct{ name, flag, value string }{
		{"module name carrying a path", "-module-name", "/etc/passwd"},
		{"module name carrying a separator", "-module-name", "Sk#probe"},
		{"module name outside the derivation", "-module-name", "Other"},
		{"sdk name carrying a separator", "-target-sdk-name", "macosx#evil"},
		{"sdk version that is not a version", "-target-sdk-version", "26.5-evil"},
		{"language version that is not the manager's", "-swift-version", "5"},
		{"target that is not the manager's", "-target", "x86_64-unknown-linux-gnu"},
		{"target carrying a path", "-target", "/x"},
	} {
		line := filepath.Join(base, "root", "bin", "frontend") + " -frontend " + tc.flag + " " + tc.value
		if VerifyPlan(line+"\n", pol).OK() {
			t.Errorf("%s: accepted %s %s", tc.name, tc.flag, tc.value)
		}
	}
}

// The retired verifier is strictly looser: every vector the closed grammar
// rejects for an unknown-channel reason has to be one it admitted, or the
// control that reports the gap would be reporting nothing.
func TestRetiredVerifierAdmitsWhatTheClosedGrammarRejects(t *testing.T) {
	pol, base := closedPolicy(t)
	evil := filepath.Join(base, "evil.dylib")
	if err := os.WriteFile(evil, []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	// retiredAdmits records what the retired verifier actually does, measured
	// rather than assumed. It catches exactly one of these, and only by
	// accident: `-I<path>` matches its joined-search scan, so the value is
	// boundary-checked even though the flag carrying it was never recognised.
	// Every other channel passes it without a verdict.
	for _, tc := range []struct {
		vector        string
		retiredAdmits bool
	}{
		{"-new-channel", true},
		{"-new-channel=" + evil, true},
		{"-load-pass-plugin=" + evil, true},
		{"-Xllvm -load-pass-plugin=" + evil, true},
		{"-Xcc -isystem" + base, true},
		{"-Xcc -I" + base, false},
		{"-enable-future-thing", true},
	} {
		line := frontendJob(base, pol) + " " + tc.vector + "\n"
		if VerifyPlan(line, pol).OK() {
			t.Errorf("closed grammar accepted %q", tc.vector)
		}
		if got := VerifyPlanPathShapeOnly(line, pol).OK(); got != tc.retiredAdmits {
			t.Errorf("retired verifier admits %q = %v, measured %v", tc.vector, got, tc.retiredAdmits)
		}
	}
}

func TestIsPluginChannelTokenCoversBothSpellings(t *testing.T) {
	for _, yes := range []string{
		"-plugin-path", "-external-plugin-path", "-in-process-plugin-server-path",
		"-load-plugin-library", "-load-plugin-executable", "-load-resolved-plugin",
		"-cas-plugin-path", "-cas-plugin-option",
		"-plugin-path=/x", "-load-pass-plugin=/x",
	} {
		if !IsPluginChannelToken(yes) {
			t.Errorf("IsPluginChannelToken(%q) = false", yes)
		}
	}
	for _, no := range []string{"-sdk", "-o", "-frontend", "-plugin", "", "/usr/lib/swift/host/plugins"} {
		if IsPluginChannelToken(no) {
			t.Errorf("IsPluginChannelToken(%q) = true", no)
		}
	}
}
