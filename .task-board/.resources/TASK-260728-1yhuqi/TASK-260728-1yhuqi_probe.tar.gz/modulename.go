package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strings"
)

// ---------------------------------------------------------------------------
// curator-swift-module-v1
//
// The total derivation from a protocol command key to the Swift module name the
// compiler is given. It exists because the two grammars do not overlap:
//
//	command key    ^[A-Za-z0-9][A-Za-z0-9._-]*$      unbounded, may start with a digit
//	Swift module   ^[A-Za-z_][A-Za-z0-9_]{0,63}$     bounded, may not start with a digit
//
// A replacement rule ("every character outside the module alphabet becomes _")
// is not usable: `my-tool` and `my.tool` would collide, and a collision merges
// two module identities that the protocol keeps distinct.
//
// The derivation below is:
//
//   - total     — every protocol-valid key has a result, including punctuation,
//     leading digits and keys longer than the module bound;
//   - deterministic — no host, clock or filesystem input;
//   - injective on the short branch, provably: DecodeModuleName inverts it;
//   - collision-resistant on the long branch, by a 160-bit digest of the whole
//     key rather than of a truncation;
//   - branch-separated — a short result begins `Sk_` and a long one `Tk_`, so the
//     two branches cannot collide with each other.
//
// The `Sk_`/`Tk_` prefixes are reserved by the manager. Measured on the probed
// closure: no module in the toolchain root or the platform SDK carries either
// prefix, so a derived name cannot shadow a module package source can import.
// The prefixes also make the result start with an uppercase letter, so no
// derived name can be a Swift keyword or the `Swift` standard-library module.
// ---------------------------------------------------------------------------

const (
	moduleShortTag = "Sk_"
	moduleLongTag  = "Tk_"

	// ModuleNameMax is the Swift module-name bound this derivation targets.
	ModuleNameMax = 64

	moduleDigestHex = 40 // 160 bits of SHA-256, hex
	moduleShortMax  = ModuleNameMax - len(moduleShortTag)
	moduleLongMax   = ModuleNameMax - len(moduleLongTag) - moduleDigestHex - 1

	// moduleDomain separates this digest from every other digest in the system.
	moduleDomain = "curator-swift-module-v1\x00"
)

// ValidCommandKey is the protocol command-key grammar, spelled out rather than
// compiled, so the rejection is byte-exact.
func ValidCommandKey(k string) bool {
	if k == "" {
		return false
	}
	for i := 0; i < len(k); i++ {
		c := k[i]
		alnum := (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
		if i == 0 {
			if !alnum {
				return false
			}
			continue
		}
		if !alnum && c != '.' && c != '_' && c != '-' {
			return false
		}
	}
	return true
}

// escapeCommandKey maps the key alphabet into [A-Za-z0-9] with a prefix-free
// code, so the result is decodable and therefore injective.
//
//	z -> zz    .  -> zd    -  -> zh    _  -> zu    anything else -> itself
func escapeCommandKey(k string) (string, bool) {
	var b strings.Builder
	b.Grow(2 * len(k))
	for i := 0; i < len(k); i++ {
		c := k[i]
		switch {
		case c == 'z':
			b.WriteString("zz")
		case c == '.':
			b.WriteString("zd")
		case c == '-':
			b.WriteString("zh")
		case c == '_':
			b.WriteString("zu")
		case (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'y') || (c >= '0' && c <= '9'):
			b.WriteByte(c)
		default:
			return "", false
		}
	}
	return b.String(), true
}

func unescapeCommandKey(e string) (string, bool) {
	var b strings.Builder
	b.Grow(len(e))
	for i := 0; i < len(e); i++ {
		if e[i] != 'z' {
			b.WriteByte(e[i])
			continue
		}
		i++
		if i >= len(e) {
			return "", false
		}
		switch e[i] {
		case 'z':
			b.WriteByte('z')
		case 'd':
			b.WriteByte('.')
		case 'h':
			b.WriteByte('-')
		case 'u':
			b.WriteByte('_')
		default:
			return "", false
		}
	}
	return b.String(), true
}

// DeriveModuleName is the manager's only way to produce a `-module-name` value.
// No package string, manifest byte or descriptor byte reaches it: the input is
// the consuming manifest command key and nothing else.
func DeriveModuleName(key string) (string, error) {
	if !ValidCommandKey(key) {
		return "", fmt.Errorf("command key %q is outside the protocol grammar ^[A-Za-z0-9][A-Za-z0-9._-]*$", key)
	}
	esc, ok := escapeCommandKey(key)
	if !ok {
		return "", fmt.Errorf("command key %q carries a byte the module escape does not cover", key)
	}
	if len(esc) <= moduleShortMax {
		return moduleShortTag + esc, nil
	}
	sum := sha256.Sum256([]byte(moduleDomain + key))
	digest := hex.EncodeToString(sum[:])[:moduleDigestHex]
	prefix := esc
	if len(prefix) > moduleLongMax {
		prefix = prefix[:moduleLongMax]
	}
	return moduleLongTag + digest + "_" + prefix, nil
}

// DecodeModuleName inverts the short branch. It exists so injectivity is a
// property that can be executed rather than argued: every short result decodes
// to exactly the key it came from. The long branch is not invertible and says
// so, which is why the canonical build input binds the command key itself
// alongside the module name.
func DecodeModuleName(m string) (key string, exact bool) {
	if !strings.HasPrefix(m, moduleShortTag) {
		return "", false
	}
	k, ok := unescapeCommandKey(strings.TrimPrefix(m, moduleShortTag))
	if !ok {
		return "", false
	}
	return k, true
}

// ValidModuleName is the Swift module-name grammar the derivation must land in.
func ValidModuleName(m string) bool {
	if m == "" || len(m) > ModuleNameMax {
		return false
	}
	c := m[0]
	if !((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_') {
		return false
	}
	for i := 1; i < len(m); i++ {
		c := m[i]
		if !((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_') {
			return false
		}
	}
	return true
}

// NaiveModuleName is the rule this derivation replaces. It is retained only so
// expected-red control C9 can restore it from the same binary and report the
// collision it admits.
func NaiveModuleName(key string) string {
	var b strings.Builder
	for i := 0; i < len(key); i++ {
		c := key[i]
		if (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') {
			b.WriteByte(c)
			continue
		}
		b.WriteByte('_')
	}
	s := b.String()
	if s == "" || (s[0] >= '0' && s[0] <= '9') {
		s = "_" + s
	}
	if len(s) > ModuleNameMax {
		s = s[:ModuleNameMax]
	}
	return s
}
