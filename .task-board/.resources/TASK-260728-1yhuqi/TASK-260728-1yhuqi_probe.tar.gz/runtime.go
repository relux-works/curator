package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// ---------------------------------------------------------------------------
// Probe P2 and the native runtime-library admission gate.
//
// P2 is `swiftc -print-target-info -target <target.triple>` — the EXACT triple
// the compile vector passes, not P1's default. It is run, its whole result is
// recorded, and Stage A green is gated on it.
//
// MEASURED, this host, and it is the fact that shapes the rule:
//
//	runtimeLibraryPaths = [
//	  "<toolchain-root>/usr/lib/swift/macosx",   inside the fingerprinted root
//	  "/usr/lib/swift"                           the macOS OS-level Swift runtime
//	]
//
// The second entry EXISTS, is a directory, and is outside every fingerprinted
// root. A rule of the form "every entry must resolve inside a fingerprinted
// root" would therefore reject the very host this contract is measured on. The
// closed set is instead three classes, and the third one rejects:
//
//	class A  in-closure          resolves inside a declared fingerprinted root
//	class B  base-installation   resolves inside a declared, closed, per-platform
//	                             base-installation prefix set — the same trust
//	                             boundary the artifact rule already accepts when
//	                             it requires the executable's dynamic
//	                             dependencies to be base-installation libraries
//	class C  anything else       REJECT
//
// The rule is:
//
//	R2.1  the list is NON-EMPTY;
//	R2.2  every entry is absolute;
//	R2.3  every entry RESOLVES (a dangling symlink is a rejection, not an
//	      absence) and resolves to a DIRECTORY;
//	R2.4  every entry classifies into A or B; a class-C entry rejects;
//	R2.5  AT LEAST ONE entry is class A. This is the entry that carries the
//	      standard library for the compiled triple, and it is what the
//	      representability surface does not prove;
//	R2.6  every class-A entry is serialized into identity as a (role, relpath)
//	      pair through curator-swift-relpath-v1; class-B entries are serialized
//	      with the reserved role `platform-base-installation` so that a change
//	      from "OS runtime" to "in-closure runtime" moves cache identity;
//	R2.7  the base-installation prefix set is declared per platform in the
//	      registry, is resolved and required to exist and be a directory, and
//	      MUST NOT lie inside any fingerprinted root — otherwise class B could
//	      launder a class-A obligation.
//
// MEASURED, and this is why the escape hatch is narrow rather than a hole: the
// class-B entry never reaches the compiler. In the verified job plan the linker
// job's search paths are `<root>/usr/lib/swift/macosx` — the class-A entry —
// and the presented SDK's `usr/lib/swift`. The bare `/usr/lib/swift` appears as
// ZERO tokens in the plan. Class B is an admission-surface fact about where the
// runtime could live, not a path the driver hands to a child; section 4.1's
// plan verification remains total and admits no base-installation path.
//
// MEASURED: for the unserved `x86_64-unknown-linux-gnu` triple, P2 returns ONE
// entry, `<root>/usr/lib/swift/linux`, which is class-A-shaped and does not
// exist. R2.3 rejects it. That is the admission test the representability
// surface cannot perform.
//
// MEASURED: on this host P1 and P2 return byte-identical JSON. P2 is still run
// and bound, because equality is a property of this host and this triple, not
// of the contract; the admission is defined on the triple the compile uses.
// ---------------------------------------------------------------------------

// Runtime member classes.
const (
	RuntimeClassInClosure       = "in-closure"
	RuntimeClassBaseInstall     = "base-installation"
	RuntimeClassRejected        = "rejected"
	RoleBaseInstallation        = "platform-base-installation"
	RoleSwiftToolchain          = "swift-toolchain"
	RolePlatformSDK             = "platform-sdk"
	runtimeMaxEntries       int = 64
)

// RuntimeEntry is one classified `runtimeLibraryPaths` element.
type RuntimeEntry struct {
	Raw      string `json:"raw"`
	Resolved string `json:"resolved,omitempty"`
	Class    string `json:"class"`
	Role     string `json:"role,omitempty"`
	Relpath  string `json:"relpath,omitempty"`
	Reason   string `json:"reason,omitempty"`
}

// RuntimeAdmission is the whole P2 verdict.
type RuntimeAdmission struct {
	Triple      string          `json:"triple"`
	Probe       RunRecord       `json:"probe"`
	Raw         []string        `json:"raw_runtime_library_paths"`
	Entries     []RuntimeEntry  `json:"entries"`
	Members     []ClosureMember `json:"identity_members"`
	InClosure   int             `json:"in_closure"`
	BaseInstall int             `json:"base_installation"`
	Rejections  []string        `json:"rejections"`
	// P1EqualsP2 records whether the whole P1 and P2 documents agreed on this
	// host. It is evidence, never a licence to skip P2.
	P1EqualsP2 bool `json:"p1_equals_p2"`
}

// OK reports whether the native target is admitted.
func (a RuntimeAdmission) OK() bool { return len(a.Rejections) == 0 }

// RuntimePolicy is what the admission is allowed to trust. Every path in it has
// already been resolved by the manager.
type RuntimePolicy struct {
	// Roots are the resolved fingerprinted roots, in identity order, with the
	// role token each one serializes under.
	Roots []RootRecord
	// BaseInstallPrefixes is the closed, per-platform, registry-declared set of
	// OS base-installation prefixes, resolved. macOS: exactly ["/usr/lib/swift"].
	BaseInstallPrefixes []string
}

// AdmitRuntimeLibraryPaths applies R2.1 through R2.7. It is total: every input
// yields either an empty Rejections list or at least one typed rejection.
func AdmitRuntimeLibraryPaths(triple string, paths []string, pol RuntimePolicy) RuntimeAdmission {
	a := RuntimeAdmission{Triple: triple, Raw: paths}
	reject := func(f string, v ...any) { a.Rejections = append(a.Rejections, fmt.Sprintf(f, v...)) }

	// R2.7 — a base prefix inside a fingerprinted root would launder class A.
	var rootPaths []string
	for _, r := range pol.Roots {
		rootPaths = append(rootPaths, r.Resolved)
	}
	for _, b := range pol.BaseInstallPrefixes {
		if b == "" {
			reject("a declared base-installation prefix is empty")
			continue
		}
		if !filepath.IsAbs(b) {
			reject("declared base-installation prefix %q is not absolute", b)
			continue
		}
		if contained(b, rootPaths) {
			reject("declared base-installation prefix %q lies inside a fingerprinted root; it would launder an in-closure obligation", b)
		}
		if fi, err := os.Stat(b); err != nil || !fi.IsDir() {
			reject("declared base-installation prefix %q is absent or not a directory", b)
		}
	}

	// R2.1 — non-empty.
	if len(paths) == 0 {
		reject("runtimeLibraryPaths is empty for target %q; the standard-library closure would be unbounded", triple)
		return a
	}
	if len(paths) > runtimeMaxEntries {
		reject("runtimeLibraryPaths carries %d entries for target %q; the grammar admits at most %d", len(paths), triple, runtimeMaxEntries)
		return a
	}

	for _, raw := range paths {
		e := RuntimeEntry{Raw: raw, Class: RuntimeClassRejected}

		// R2.2 — absolute.
		if raw == "" || !filepath.IsAbs(raw) {
			e.Reason = "not an absolute path"
			reject("runtimeLibraryPaths entry %q is not absolute", raw)
			a.Entries = append(a.Entries, e)
			continue
		}

		// R2.3 — resolves, and to a directory. A dangling symlink is a
		// rejection: it is neither absent nor present-and-contained.
		resolved, present, info, err := resolveEntry(raw)
		if err != nil {
			e.Reason = "does not resolve: " + err.Error()
			reject("runtimeLibraryPaths entry %q does not resolve: %v", raw, err)
			a.Entries = append(a.Entries, e)
			continue
		}
		if !present {
			e.Reason = "absent"
			reject("runtimeLibraryPaths entry %q does not exist; the standard library for target %q is not in the tree", raw, triple)
			a.Entries = append(a.Entries, e)
			continue
		}
		if !info.IsDir() {
			e.Reason = "not a directory"
			reject("runtimeLibraryPaths entry %q resolves to %q, which is not a directory", raw, resolved)
			a.Entries = append(a.Entries, e)
			continue
		}
		e.Resolved = resolved

		// R2.4 — classify. Fingerprinted roots first, so a base prefix can never
		// shadow a root even if R2.7 were somehow satisfied vacuously.
		classified := false
		for _, r := range pol.Roots {
			if r.Resolved == "" || !contained(resolved, []string{r.Resolved}) {
				continue
			}
			rel, rerr := CanonicalRelpath(r.Resolved, resolved)
			if rerr != nil {
				e.Reason = rerr.Error()
				reject("runtimeLibraryPaths entry %q: %v", raw, rerr)
				classified = true
				break
			}
			e.Class, e.Role, e.Relpath = RuntimeClassInClosure, r.Role, rel
			a.InClosure++
			a.Members = append(a.Members, ClosureMember{Role: r.Role, Relpath: rel, Resolved: resolved, Identity: identityOf(info)})
			classified = true
			break
		}
		if !classified {
			for _, b := range pol.BaseInstallPrefixes {
				if b == "" || !contained(resolved, []string{b}) {
					continue
				}
				rel, rerr := CanonicalRelpath(b, resolved)
				if rerr != nil {
					e.Reason = rerr.Error()
					reject("runtimeLibraryPaths entry %q: %v", raw, rerr)
					classified = true
					break
				}
				e.Class, e.Role, e.Relpath = RuntimeClassBaseInstall, RoleBaseInstallation, rel
				a.BaseInstall++
				a.Members = append(a.Members, ClosureMember{Role: RoleBaseInstallation, Relpath: rel, Resolved: resolved, Identity: identityOf(info)})
				classified = true
				break
			}
		}
		if !classified {
			e.Reason = "outside every fingerprinted root and every declared base-installation prefix"
			reject("runtimeLibraryPaths entry %q resolves to %q, outside every fingerprinted root and every declared base-installation prefix", raw, resolved)
		}
		a.Entries = append(a.Entries, e)
	}

	// R2.5 — at least one in-closure member.
	if a.InClosure == 0 && len(a.Rejections) == 0 {
		reject("no runtimeLibraryPaths entry for target %q lies inside a fingerprinted root; the toolchain's own standard library for that triple is not in the closure", triple)
	}

	// R2.6 — canonical order and duplicate collapse.
	a.Members = SerializeMembers(a.Members)
	return a
}

// NaiveRuntimeAdmission is the RETIRED rule: "every entry that lies inside the
// toolchain root must exist and must be a directory". It says nothing about an
// empty list, nothing about an entry outside every root, and nothing about a
// dangling symlink. It is retained only so expected-red control C11 can restore
// it from this same binary and report what it admits.
func NaiveRuntimeAdmission(paths []string, toolchainRoot string) bool {
	for _, p := range paths {
		if !strings.HasPrefix(p, toolchainRoot) {
			continue
		}
		if !isDir(p) {
			return false
		}
	}
	return true
}

// readTargetInfoFor runs a -print-target-info probe for an explicit triple and
// returns the parsed document plus the raw record.
func readTargetInfoFor(swiftc, triple string, env *Env) (targetInfo, RunRecord, string, error) {
	args := []string{"-print-target-info"}
	if triple != "" {
		args = append(args, "-target", triple)
	}
	rec, stdout, _ := runFixedRaw(swiftc, args, "", env)
	var ti targetInfo
	if rec.Exit != 0 {
		return ti, rec, stdout, fmt.Errorf("-print-target-info -target %s exited %d", triple, rec.Exit)
	}
	if !jsonInto(stdout, &ti) {
		return ti, rec, stdout, fmt.Errorf("-print-target-info -target %s did not emit JSON", triple)
	}
	return ti, rec, stdout, nil
}

// sortedStrings is a small helper used by the structural checks so evidence is
// emitted in a stable order.
func sortedStrings(in []string) []string {
	out := append([]string{}, in...)
	sort.Strings(out)
	return out
}
