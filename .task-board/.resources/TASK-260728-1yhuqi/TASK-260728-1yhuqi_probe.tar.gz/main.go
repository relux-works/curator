package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

func main() {
	var (
		root     = flag.String("root", "", "Swift toolchain root (never resolved through PATH, xcrun or a version manager)")
		platform = flag.String("platform-root", "", "platform developer root carrying SDKs/MacOSX.sdk")
		work     = flag.String("work", "", "working directory for fixtures")
		outPath  = flag.String("out", "fixture.json", "fixture output path")
		evidence = flag.String("evidence", "", "optional command-evidence output path")
		red      = flag.String("red", "", "run one expected-red control only")
	)
	flag.Parse()

	if *work == "" {
		d, err := os.MkdirTemp("", "swiftboundaryprobe")
		if err != nil {
			fatal(err)
		}
		*work = d
	}
	if err := os.MkdirAll(*work, 0o755); err != nil {
		fatal(err)
	}
	// Every path the probe hands to a child must be absolute: children run with
	// their own working directory, so a relative one would silently miss.
	abs, err := filepath.Abs(*work)
	if err != nil {
		fatal(err)
	}
	*work = abs

	fx := Fixture{
		FixtureVersion: "swift-boundary-fixture-v1",
		Task:           "TASK-260728-1yhuqi",
		Host: Host{
			OperatingSystem: runtime.GOOS,
			Architecture:    runtime.GOARCH,
			ProbeGoVersion:  runtime.Version(),
		},
	}

	tc, err := ResolveToolchain(*root, *platform)
	if err != nil {
		fx.Toolchain = ToolchainRecord{Available: false, Reason: err.Error()}
		for _, c := range Cases("0.0.0") {
			fx.Cases = append(fx.Cases, CaseResult{Case: c, Status: "not_run", Reason: err.Error()})
		}
		fx.Summary = Summary{Cases: len(fx.Cases), NotRun: len(fx.Cases), Green: true}
		emit(fx, *outPath, *evidence)
		fmt.Printf("swift-boundary-fixture-v1: toolchain unavailable, %d cases not run; nothing was installed\n", len(fx.Cases))
		return
	}

	fx.Toolchain = ToolchainRecord{
		Available: true, Root: tc.Root, SwiftcPath: tc.Swiftc, SwiftPath: tc.Swift,
		FrontendPath: tc.Frontend, ClangPath: tc.Clang, LinkerPath: tc.Linker,
		PlatformRoot: tc.PlatformRoot, DeclaredSDK: tc.DeclaredSDK,
		CompilerVer: tc.CompilerVersion, CompilerTag: tc.CompilerTag, Normalized: tc.Normalized,
		Triple: tc.Triple, Unversioned: tc.Unversioned, RuntimePaths: tc.RuntimePaths,
		StdlibPresent: tc.StdlibPresent,
		BannerSuffix:  tc.BannerSuffix, Admission: tc.Admission,
	}

	h, err := newHarness(filepath.Join(*work, "structural"), tc)
	if err != nil {
		fatal(err)
	}
	fx.Toolchain.PresentedSDK = h.presentedSDK()

	if *red != "" {
		ctrls := Controls(tc, h, filepath.Join(*work, "controls"), Cases(tc.Normalized))
		for _, c := range ctrls {
			if c.ID == *red || strings.Contains(c.ID, *red) {
				fmt.Printf("%s: failed=%v findings=%d %s\n", c.ID, c.Failed, c.Findings, c.Detail)
				if c.Failed {
					os.Exit(1)
				}
				os.Exit(0)
			}
		}
		fmt.Printf("no such control: %s\n", *red)
		os.Exit(2)
	}

	cases := Cases(tc.Normalized)
	for _, c := range cases {
		r := RunCase(tc, filepath.Join(*work, "cases"), c, modeExact, false)
		if c.HostGate {
			fx.HostGateCases = append(fx.HostGateCases, r)
		} else {
			fx.Cases = append(fx.Cases, r)
		}
	}

	all := append(append([]CaseResult{}, fx.Cases...), fx.HostGateCases...)
	// Re-apply the canonical table so a declared expectation and an executed one
	// cannot drift.
	byID := map[string]Case{}
	for _, c := range cases {
		byID[c.ID] = c
	}
	for i := range all {
		all[i].Case = byID[all[i].Case.ID]
	}

	fx.Alignment, _ = CheckAlignment(all)
	fx.Closure = Closure(tc, all)
	fx.Structural = Structurals(h, true)
	fx.Controls = Controls(tc, h, filepath.Join(*work, "controls"), cases)

	sum := Summary{Cases: len(all), ControlsTotal: len(fx.Controls), StructuralTotal: len(fx.Structural), ClosureChecks: len(fx.Closure)}
	for _, r := range all {
		switch {
		case r.Status != "run":
			sum.NotRun++
		case r.Matched && r.Agreed:
			sum.Matched++
		default:
			sum.Divergences++
		}
	}
	for _, c := range fx.Closure {
		if !c.NoVerdict {
			sum.ClosureFailures++
		}
	}
	for _, c := range fx.Controls {
		if c.Failed {
			sum.ControlsFailingRequired++
		}
	}
	for _, s := range fx.Structural {
		if s.Verdict != "match" {
			sum.StructuralDivergences++
		}
	}
	// Green additionally gates on the EXECUTED P2 admission: an in-closure
	// standard library for the exact compile triple, with no rejection. A run
	// that never established that is not green regardless of the other counts.
	sum.NativeAdmissionOK = tc.Admission.OK() && tc.Admission.InClosure > 0
	sum.Green = sum.Divergences == 0 && sum.ClosureFailures == 0 &&
		sum.ControlsFailingRequired == sum.ControlsTotal &&
		sum.StructuralDivergences == 0 &&
		sum.NativeAdmissionOK &&
		fx.Alignment.P1NoWidening && fx.Alignment.P2NoNarrowing
	fx.Summary = sum

	emit(fx, *outPath, *evidence)

	fmt.Printf("cases: %d, matched %d, divergences %d, not run %d\n", sum.Cases, sum.Matched, sum.Divergences, sum.NotRun)
	fmt.Printf("alignment: P1 no-widening=%v P2 no-narrowing=%v (security partition empty=%v)\n",
		fx.Alignment.P1NoWidening, fx.Alignment.P2NoNarrowing, fx.Alignment.SecurityPartitionEmpty)
	fmt.Printf("closure: %d checks, %d yielded a verdict (must be 0)\n", sum.ClosureChecks, sum.ClosureFailures)
	fmt.Printf("controls: %d of %d failing as required\n", sum.ControlsFailingRequired, sum.ControlsTotal)
	fmt.Printf("structural: %d checks, %d divergences\n", sum.StructuralTotal, sum.StructuralDivergences)
	fmt.Printf("native target admission (P2 %s): ok=%v in-closure=%d base-installation=%d p1==p2=%v\n",
		tc.Triple, sum.NativeAdmissionOK, tc.Admission.InClosure, tc.Admission.BaseInstall, tc.Admission.P1EqualsP2)
	for _, s := range fx.Structural {
		if s.Verdict != "match" {
			fmt.Printf("  DIVERGENCE %s: expected %s; observed %s\n", s.ID, s.Expected, s.Observed)
		}
	}
	for _, r := range all {
		if r.Status == "run" && (!r.Matched || !r.Agreed) {
			fmt.Printf("  DIVERGENCE %s: curator=%s isolated=%s corroborating=%s (declared %s/%s/%s)\n",
				r.Case.ID, r.Curator, r.Isolated.Class, r.Corroborating.Class, r.Case.Curator, r.Case.Isolated, r.Case.Corroborating)
		}
	}
	for _, c := range fx.Controls {
		if !c.Failed {
			fmt.Printf("  CONTROL DID NOT FIRE %s (%s)\n", c.ID, c.Guards)
		}
	}
	fmt.Printf("green: %v\n", sum.Green)
	if !sum.Green {
		os.Exit(1)
	}
}

func emit(fx Fixture, outPath, evidencePath string) {
	b, err := json.MarshalIndent(fx, "", "  ")
	if err != nil {
		fatal(err)
	}
	if err := os.WriteFile(outPath, append(b, '\n'), 0o644); err != nil {
		fatal(err)
	}
	if evidencePath == "" {
		return
	}
	var sb strings.Builder
	fmt.Fprintf(&sb, "# TASK-260728-1yhuqi command evidence\n\nfixture: %s\ntoolchain: %s (%s)\n\n",
		fx.FixtureVersion, fx.Toolchain.CompilerVer, fx.Toolchain.Root)
	writeRuns := func(title string, runs []RunRecord) {
		if len(runs) == 0 {
			return
		}
		fmt.Fprintf(&sb, "## %s\n\n", title)
		for _, r := range runs {
			fmt.Fprintf(&sb, "argv: %s\ndir: %s\nenv: %s\nexit: %d\nstdout: %s\nstderr: %s\n\n",
				strings.Join(r.Argv, " "), r.Dir, strings.Join(r.EnvDelta, " "), r.Exit,
				clipTo(strings.TrimSpace(r.Stdout), 700), clipTo(strings.TrimSpace(r.Stderr), 700))
		}
	}
	for _, c := range append(append([]CaseResult{}, fx.Cases...), fx.HostGateCases...) {
		writeRuns("case "+c.Case.ID, c.Runs)
	}
	for _, s := range fx.Structural {
		writeRuns("structural "+s.ID, s.Runs)
	}
	if err := os.WriteFile(evidencePath, []byte(sb.String()), 0o644); err != nil {
		fatal(err)
	}
}

func sha256File(p string) string {
	f, err := os.Open(p)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}
	return hex.EncodeToString(h.Sum(nil))
}

func jsonInto(s string, v any) bool { return json.Unmarshal([]byte(s), v) == nil }

func fatal(err error) {
	fmt.Fprintln(os.Stderr, "probe:", err)
	os.Exit(2)
}
