package main

import (
	"fmt"
	"strconv"
	"strings"
)

// ---------------------------------------------------------------------------
// Curator's own swift-tools-version classifier.
//
// Curator never runs SwiftPM, so this function reads manifest bytes directly.
//
// Its input is EXACTLY the first physical line of Package.swift — the bytes up
// to the first LF, with one trailing CR removed — and nothing else. No byte
// after that LF is a metadata input, is scanned, or can change the verdict. That
// is the whole normative rule, and it is the reason the manifest body can be
// declared "not a metadata source" without qualification.
//
// Upstream does scan the whole file, and that difference is deliberate.
// Measured on Apple Swift 6.3.2: `swift package tools-version` reports 9.9.0
// with exit 0 for a manifest whose only specification sits inside a multi-line
// string literal on line 3. A whole-file scan would therefore make the manager's
// verdict depend on arbitrary manifest body bytes — including bytes inside a
// string literal — which is exactly the input this driver refuses to have.
//
// Every value Curator refuses that upstream represents is placed in the security
// partition F and is excluded from the no-narrowing property, which is how
// decision 0007 frames a deliberate narrowing. A specification below line 1 is
// one such refusal: it classifies as rejected-absent-header, because line 1 is
// the only place Curator looks.
// ---------------------------------------------------------------------------

// Floor is the lowest tools version the resolved toolchain still supports.
// Measured on Apple Swift 6.3.2: 3.1.0 is refused, 4.0.0 is accepted.
const Floor = "4.0.0"

// canonicalPrefix is the only header prefix Curator accepts.
const canonicalPrefix = "// swift-tools-version:"

// CuratorClassify returns the class Curator assigns to the manifest bytes,
// given the resolved compiler version. It never consults the filesystem and
// never executes anything.
func CuratorClassify(manifest string, compilerVersion string) Class {
	line := FirstLine(manifest)
	raw, form, found := headerVersion(line)
	if !found {
		// Line 1 carries no specification in any case or spacing form. Whether
		// one sits below it is not consulted: those bytes are not a metadata
		// input. A manifest upstream would still accept this way is a member of
		// the security partition F, declared in the case table.
		return ClassNoHeader
	}
	if strings.TrimSpace(raw) == "" {
		return ClassNoSpecifier
	}
	if form != formCanonical {
		// Upstream represents these; Curator refuses the reinterpretation.
		if _, ok := parseStrict(strings.TrimSpace(raw)); ok {
			return ClassNonCanonical
		}
		if _, ok := predictNormalized(strings.TrimSpace(raw)); ok {
			return ClassNonCanonical
		}
		return ClassGrammar
	}
	v, ok := parseStrict(raw)
	if !ok {
		// Not strictly representable for Curator. If upstream would still take
		// it, the refusal is a deliberate narrowing rather than a grammar call.
		if _, up := predictNormalized(raw); up {
			return ClassNonCanonical
		}
		return ClassGrammar
	}
	if cmpVersion(v, mustParse(Floor)) < 0 {
		return ClassFloor
	}
	if c, ok := parseStrict(compilerVersion); ok && cmpVersion(v, c) > 0 {
		return ClassHostGate
	}
	return ClassAccepted
}

type headerForm int

const (
	formAbsent headerForm = iota
	formCanonical
	formLoose
)

// FirstLine is the manager's entire read of Package.swift: the bytes up to the
// first LF, with one trailing CR removed. It is the classifier's only input.
func FirstLine(s string) string {
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		s = s[:i]
	}
	return strings.TrimSuffix(s, "\r")
}

// headerVersion recognises the tools-version specification on one line. The
// canonical form is exactly "// swift-tools-version:" with at most one ASCII
// space after "//" and at most one after the colon, lowercase keyword, no tab,
// no BOM, and nothing after the version.
func headerVersion(line string) (raw string, form headerForm, found bool) {
	rest, ok := cutPrefixFold(line, "//")
	if !ok {
		return "", formAbsent, false
	}
	// The canonical prefix is exactly "// swift-tools-version:": two slashes,
	// one ASCII space, the lowercase keyword, the colon. Anything else is
	// represented by upstream and refused here.
	canonical := strings.HasPrefix(line, canonicalPrefix)
	trimmed := strings.TrimLeft(rest, " \t")
	body, ok := cutPrefixFold(trimmed, "swift-tools-version:")
	if !ok {
		return "", formAbsent, false
	}
	after := strings.TrimLeft(body, " \t")
	if n := len(body) - len(after); n > 1 || strings.ContainsAny(body[:n], "\t") {
		canonical = false
	}
	if after != strings.TrimRight(after, " \t") {
		canonical = false
		after = strings.TrimRight(after, " \t")
	}
	if canonical {
		return after, formCanonical, true
	}
	return after, formLoose, true
}

func cutPrefixFold(s, prefix string) (string, bool) {
	if len(s) < len(prefix) {
		return "", false
	}
	if !strings.EqualFold(s[:len(prefix)], prefix) {
		return "", false
	}
	return s[len(prefix):], true
}

// upstreamScanForHeader models SwiftPM, NOT Curator. Upstream scans the whole
// file for a specification; measured, it finds one below arbitrary manifest code
// and one inside a multi-line string literal. It is used only to predict what
// the upstream command will print, so the probe can compare a measured upstream
// outcome against Curator's line-1 verdict. CuratorClassify never calls it.
func upstreamScanForHeader(manifest string) (raw string, found bool) {
	for _, l := range strings.Split(manifest, "\n") {
		if r, _, ok := headerVersion(strings.TrimSuffix(l, "\r")); ok {
			return strings.TrimSpace(r), true
		}
	}
	return "", false
}

type version struct{ major, minor, patch int }

func mustParse(s string) version {
	v, ok := parseStrict(s)
	if !ok {
		panic("probe: unparsable constant " + s)
	}
	return v
}

// parseStrict is Curator's version grammar: two or three decimal components, no
// leading zeros, no prerelease, no build metadata.
func parseStrict(s string) (version, bool) {
	parts := strings.Split(s, ".")
	if len(parts) < 2 || len(parts) > 3 {
		return version{}, false
	}
	out := make([]int, 3)
	for i, p := range parts {
		if p == "" {
			return version{}, false
		}
		if len(p) > 1 && p[0] == '0' {
			return version{}, false
		}
		for _, c := range p {
			if c < '0' || c > '9' {
				return version{}, false
			}
		}
		n, err := strconv.Atoi(p)
		if err != nil {
			return version{}, false
		}
		out[i] = n
	}
	return version{out[0], out[1], out[2]}, true
}

func cmpVersion(a, b version) int {
	switch {
	case a.major != b.major:
		return sign(a.major - b.major)
	case a.minor != b.minor:
		return sign(a.minor - b.minor)
	default:
		return sign(a.patch - b.patch)
	}
}

func sign(n int) int {
	switch {
	case n < 0:
		return -1
	case n > 0:
		return 1
	}
	return 0
}

// predictNormalized reproduces the normalization upstream was measured to
// apply: leading zeros are dropped, a missing patch component becomes 0, and a
// prerelease or build suffix is discarded. It is used only to predict the
// upstream line before the command runs.
func predictNormalized(raw string) (string, bool) {
	s := raw
	if i := strings.IndexAny(s, "-+"); i >= 0 {
		s = s[:i]
	}
	parts := strings.Split(s, ".")
	if len(parts) < 2 || len(parts) > 3 {
		return "", false
	}
	nums := make([]int, 3)
	for i, p := range parts {
		if p == "" {
			return "", false
		}
		for _, c := range p {
			if c < '0' || c > '9' {
				return "", false
			}
		}
		n, err := strconv.Atoi(p)
		if err != nil {
			return "", false
		}
		nums[i] = n
	}
	return fmt.Sprintf("%d.%d.%d", nums[0], nums[1], nums[2]), true
}

// ---------------------------------------------------------------------------
// Upstream recognition.
//
// Every recognised outcome is one whole line predicted before the command runs
// from the value under test plus constants the probe itself fixes. A lead with
// an unconstrained tail is a family, not an outcome, and is never recognised.
// ---------------------------------------------------------------------------

type expectation struct {
	line   string
	stream string
	class  Class
}

// isolatedExpectations builds the closed recognised set for
// `swift package tools-version`.
func isolatedExpectations(rawVersion, pkgDir, compilerFull, compilerMM string) []expectation {
	out := []expectation{}
	if norm, ok := predictNormalized(rawVersion); ok {
		out = append(out, expectation{norm, "stdout", ClassAccepted})
	}
	out = append(out,
		expectation{
			fmt.Sprintf("error: the Swift tools version '%s' is misspelt or otherwise invalid; consider replacing it with '// swift-tools-version: %s' to specify the current Swift toolchain version as the lowest Swift version supported by the project", rawVersion, compilerFull),
			"stderr", ClassGrammar,
		},
		expectation{
			fmt.Sprintf("error: the Swift tools version specification is possibly missing a version specifier; consider using '// swift-tools-version: %s' to specify the current Swift toolchain version as the lowest Swift version supported by the project", compilerFull),
			"stderr", ClassNoSpecifier,
		},
		expectation{
			fmt.Sprintf("error: package 'package.swift' is using Swift tools version 3.1.0 which is no longer supported; consider using '// swift-tools-version: %s' to specify the current tools version", compilerMM),
			"stderr", ClassNoHeader,
		},
	)
	_ = pkgDir
	return out
}

// corroboratingExpectations builds the closed recognised set for `swift build`.
// Every diagnostic upstream renders here carries the package name as an infix,
// which is why the two sets cannot share one predictor.
func corroboratingExpectations(rawVersion, pkgDir, compilerFull, compilerMM string) []expectation {
	out := []expectation{}
	if norm, ok := predictNormalized(rawVersion); ok {
		out = append(out,
			expectation{
				fmt.Sprintf("error: '%s': package '%s' is using Swift tools version %s but the installed version is %s", pkgDir, pkgDir, norm, compilerFull),
				"stderr", ClassHostGate,
			},
			expectation{
				fmt.Sprintf("error: '%s': package '%s' is using Swift tools version %s which is no longer supported; consider using '// swift-tools-version: %s' to specify the current tools version", pkgDir, pkgDir, norm, compilerMM),
				"stderr", ClassFloor,
			},
		)
	}
	out = append(out,
		expectation{
			fmt.Sprintf("error: '%s': the Swift tools version '%s' is misspelt or otherwise invalid; consider replacing it with '// swift-tools-version: %s' to specify the current Swift toolchain version as the lowest Swift version supported by the project", pkgDir, rawVersion, compilerFull),
			"stderr", ClassGrammar,
		},
		expectation{
			fmt.Sprintf("error: '%s': the Swift tools version specification is possibly missing a version specifier; consider using '// swift-tools-version: %s' to specify the current Swift toolchain version as the lowest Swift version supported by the project", pkgDir, compilerFull),
			"stderr", ClassNoSpecifier,
		},
		expectation{
			fmt.Sprintf("error: '%s': package 'package.swift' is using Swift tools version 3.1.0 which is no longer supported; consider using '// swift-tools-version: %s' to specify the current tools version", pkgDir, compilerMM),
			"stderr", ClassNoHeader,
		},
	)
	return out
}

// recogniseMode selects how strictly a recognised line is matched. The strict
// mode is the contract; the loosened modes exist only so the expected-red
// controls can restore a retired defect from the same binary.
type recogniseMode int

const (
	modeExact recogniseMode = iota
	modeLead
	modeSubstring
	modeExitStatus
)

// recognise answers with exactly one class or with unknown. Two expected lines
// of different classes matching inside one output is unknown rather than
// first-wins.
func recognise(exp []expectation, exit int, stdout, stderr string, zeroClass Class, mode recogniseMode) Observation {
	obs := Observation{Exit: exit, Excerpt: excerpt(stdout, stderr)}
	if mode == modeExitStatus {
		if exit == 0 {
			z := zeroClass
			if z == "" {
				z = ClassAccepted
			}
			obs.Class, obs.Recognis = z, true
		} else {
			obs.Class, obs.Recognis = ClassGrammar, true
		}
		return obs
	}
	if exit == 0 && zeroClass != "" {
		// A zero exit is only ever the accepted outcome when nothing else in the
		// closed set claims the output.
		hit := matchAll(exp, stdout, stderr, mode)
		if len(hit) == 0 {
			obs.Class, obs.Recognis = zeroClass, true
			return obs
		}
		if len(hit) == 1 {
			obs.Class, obs.Matched, obs.Stream, obs.Recognis = hit[0].class, hit[0].line, hit[0].stream, true
			return obs
		}
		obs.Class = ClassUnknown
		return obs
	}
	hit := matchAll(exp, stdout, stderr, mode)
	if len(hit) == 1 {
		obs.Class, obs.Matched, obs.Stream, obs.Recognis = hit[0].class, hit[0].line, hit[0].stream, true
		return obs
	}
	if len(hit) > 1 {
		classes := map[Class]bool{}
		for _, h := range hit {
			classes[h.class] = true
		}
		if len(classes) == 1 {
			obs.Class, obs.Matched, obs.Stream, obs.Recognis = hit[0].class, hit[0].line, hit[0].stream, true
			return obs
		}
	}
	obs.Class = ClassUnknown
	return obs
}

func matchAll(exp []expectation, stdout, stderr string, mode recogniseMode) []expectation {
	var hits []expectation
	for _, e := range exp {
		src := stderr
		if e.stream == "stdout" {
			src = stdout
		}
		if matchOne(e.line, src, mode) {
			hits = append(hits, e)
		}
	}
	return hits
}

func matchOne(expected, output string, mode recogniseMode) bool {
	switch mode {
	case modeSubstring:
		return strings.Contains(output, expected)
	case modeLead:
		lead := expected
		if i := strings.Index(lead, "'"); i > 0 {
			lead = lead[:i]
		}
		for _, l := range strings.Split(output, "\n") {
			if strings.HasPrefix(strings.TrimSpace(l), strings.TrimSpace(lead)) {
				return true
			}
		}
		return false
	default:
		for _, l := range strings.Split(output, "\n") {
			if strings.TrimSpace(l) == expected {
				return true
			}
		}
		return false
	}
}

func excerpt(stdout, stderr string) string {
	s := strings.TrimSpace(stdout + "\n" + stderr)
	s = strings.ReplaceAll(s, "\n", " | ")
	if len(s) > 400 {
		s = s[:400] + "…"
	}
	return s
}
