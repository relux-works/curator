fun main() {
    println("curator-kotlin-native-probe")
}
