export KN_BASE=/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260728-168smo/kn
export KN_DIST=$KN_BASE/dist/kotlin-native-prebuilt-macos-aarch64-2.4.10
export JDK_ROOT=/opt/homebrew/Cellar/openjdk/26.0.1/libexec/openjdk.jdk/Contents/Home
export KN_JAR=$KN_DIST/konan/lib/kotlin-native-compiler-embeddable.jar
export KN_MAIN=org.jetbrains.kotlin.cli.utilities.MainKt
