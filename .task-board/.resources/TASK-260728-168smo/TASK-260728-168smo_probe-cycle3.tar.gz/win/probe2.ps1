$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$urls = @(
 'https://github.com/JetBrains/kotlin/releases/download/v2.4.10/kotlin-native-prebuilt-windows-x86_64-2.4.10.zip',
 'https://github.com/JetBrains/kotlin/releases/download/v2.4.10/kotlin-native-prebuilt-windows-x86_64-2.4.10.zip.sha256',
 'https://download.jetbrains.com/kotlin/native/builds/releases/2.4.10/windows-x86_64/kotlin-native-prebuilt-windows-x86_64-2.4.10.zip'
)
foreach ($u in $urls) {
  $o = & curl.exe -sIL --max-time 60 -o NUL -w "%{http_code} %{size_download} %{url_effective}" $u 2>&1
  "HEAD $u"
  "   -> $o"
  $h = & curl.exe -sIL --max-time 60 $u 2>&1 | Select-String -Pattern '^(HTTP/|content-length:|content-type:)' 
  ($h -join ' | ')
}
