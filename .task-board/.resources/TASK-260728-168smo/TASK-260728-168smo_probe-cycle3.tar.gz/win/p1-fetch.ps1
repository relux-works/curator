$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Stop'
$root = 'C:\kn168'
New-Item -ItemType Directory -Force -Path $root | Out-Null
New-Item -ItemType Directory -Force -Path "$root\dl" | Out-Null
$log = "$root\p1-fetch.log"
function L($m){ $m | Tee-Object -FilePath $log -Append }

L "== P1 fetch start =="
$knUrl = 'https://github.com/JetBrains/kotlin/releases/download/v2.4.10/kotlin-native-prebuilt-windows-x86_64-2.4.10.zip'
$knZip = "$root\dl\kotlin-native-prebuilt-windows-x86_64-2.4.10.zip"
if (-not (Test-Path $knZip)) {
  & curl.exe -sL --fail --max-time 3600 -o $knZip $knUrl
  L "curl kn exit=$LASTEXITCODE"
}
& curl.exe -sL --fail --max-time 120 -o "$knZip.sha256" "$knUrl.sha256"
L "curl kn.sha256 exit=$LASTEXITCODE"
$published = (Get-Content "$knZip.sha256" -Raw).Trim().Split()[0].ToLower()
$computed  = (Get-FileHash $knZip -Algorithm SHA256).Hash.ToLower()
L ("kn size_bytes=" + (Get-Item $knZip).Length)
L "kn published=$published"
L "kn computed =$computed"
L ("kn checksum_match=" + ($published -eq $computed))
if ($published -ne $computed) { throw "kotlin-native checksum MISMATCH" }

# JDK: Eclipse Temurin 21, windows x64, zip, with published checksum
$api = 'https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse'
$j = & curl.exe -sL --fail --max-time 120 $api | ConvertFrom-Json
$pkg = $j[0].binary.package
L ("jdk release=" + $j[0].release_name)
L ("jdk url=" + $pkg.link)
$jdkZip = "$root\dl\" + $pkg.name
if (-not (Test-Path $jdkZip)) {
  & curl.exe -sL --fail --max-time 3600 -o $jdkZip $pkg.link
  L "curl jdk exit=$LASTEXITCODE"
}
$jc = (Get-FileHash $jdkZip -Algorithm SHA256).Hash.ToLower()
L ("jdk size_bytes=" + (Get-Item $jdkZip).Length)
L ("jdk published=" + $pkg.checksum.ToLower())
L "jdk computed =$jc"
L ("jdk checksum_match=" + ($pkg.checksum.ToLower() -eq $jc))
if ($pkg.checksum.ToLower() -ne $jc) { throw "jdk checksum MISMATCH" }
L "== P1 fetch done =="
