$b='C:\kn168\b'
"--- llvm bin ---"
Get-ChildItem "$b\konan-data\dependencies\llvm-21-x86_64-windows-essentials-150\bin" -EA SilentlyContinue | ForEach-Object { $_.Name }
"--- msys2 top ---"
Get-ChildItem "$b\konan-data\dependencies\msys2-mingw-w64-x86_64-2" -EA SilentlyContinue | ForEach-Object { $_.Name }
"--- msys2 bin (first 40) ---"
Get-ChildItem "$b\konan-data\dependencies\msys2-mingw-w64-x86_64-2\bin" -EA SilentlyContinue | Select-Object -First 40 | ForEach-Object { $_.Name }
"--- platform klibs for mingw_x64 (count + first 10) ---"
$p = Get-ChildItem "$b\kotlin-native\klib\platform\mingw_x64" -EA SilentlyContinue
"count=" + $p.Count
$p | Select-Object -First 10 | ForEach-Object { $_.Name }
