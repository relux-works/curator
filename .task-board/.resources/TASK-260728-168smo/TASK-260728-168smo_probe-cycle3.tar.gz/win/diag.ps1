$root='C:\kn168'; $b="$root\b"
"s2.out len=" + (Get-Item "$root\wd\s2.out" -EA SilentlyContinue).Length
"s2.err len=" + (Get-Item "$root\wd\s2.err" -EA SilentlyContinue).Length
"--- s2.err ---"; Get-Content "$root\wd\s2.err" -EA SilentlyContinue | Select-Object -First 10
"--- s2.out ---"; Get-Content "$root\wd\s2.out" -EA SilentlyContinue | Select-Object -First 10
"--- direct java -version attempt ---"
try { $p = Start-Process -FilePath "$b\jdk\bin\java.exe" -ArgumentList '-version' -NoNewWindow -Wait -PassThru -RedirectStandardError "$root\wd\jv.err"; "exit=" + $p.ExitCode } catch { "EXCEPTION: " + $_.Exception.Message }
Get-Content "$root\wd\jv.err" -EA SilentlyContinue | Select-Object -First 5
"--- effective access on java.exe ---"
& icacls.exe "$b\jdk\bin\java.exe"
"--- extracted present in bundle? ---"
Test-Path "$b\konan-data\dependencies\.extracted"
