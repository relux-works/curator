Get-Content C:\kn168\suiteA4.log
