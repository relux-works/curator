Get-Content C:\kn168\suiteA.log -EA SilentlyContinue
