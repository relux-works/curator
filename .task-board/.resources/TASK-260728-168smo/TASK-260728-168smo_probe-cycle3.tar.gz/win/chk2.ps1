"final.ps1 present=" + (Test-Path C:\kn168\final.ps1) + " len=" + (Get-Item C:\kn168\final.ps1 -EA SilentlyContinue).Length
"final.log present=" + (Test-Path C:\kn168\final.log)
Get-Process | Where-Object { $_.ProcessName -match 'java|powershell' } | ForEach-Object { $_.Id.ToString() + " " + $_.ProcessName + " " + $_.StartTime }
