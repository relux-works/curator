Get-Content C:\kn168\suiteA2.log -EA SilentlyContinue
