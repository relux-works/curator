#!/bin/bash
# psrun.sh <script-file> : run a PowerShell script on the win host via -EncodedCommand
set -euo pipefail
enc=$(iconv -f UTF-8 -t UTF-16LE < "$1" | base64 | tr -d '\n')
ssh -o BatchMode=yes -o ServerAliveInterval=30 win "powershell -NoProfile -NonInteractive -EncodedCommand $enc" 2>&1 | grep -v 'WARNING: connection is not using' | grep -v 'store now, decrypt later' | grep -v 'openssh.com/pq.html' | grep -v '^\*\* '
