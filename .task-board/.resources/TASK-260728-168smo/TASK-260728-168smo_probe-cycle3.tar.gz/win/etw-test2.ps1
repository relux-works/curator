$ProgressPreference='SilentlyContinue'
$root='C:\kn168'
& logman.exe stop kn168 -ets 2>&1 | Out-Null
Remove-Item "$root\trace\t.etl","$root\trace\t.xml" -EA SilentlyContinue
& logman.exe create trace kn168 -p Microsoft-Windows-Kernel-Process 0x10 -o "$root\trace\t.etl" -ets -bs 64 -nb 32 128 2>&1 | Out-Null
& cmd.exe /c "where.exe cmd" | Out-Null
& logman.exe stop kn168 -ets 2>&1 | Out-Null
& tracerpt.exe "$root\trace\t.etl" -o "$root\trace\t.xml" -of XML -y 2>&1 | Out-Null
$x = [xml](Get-Content "$root\trace\t.xml" -Raw)
$starts = @($x.Events.Event | Where-Object { $_.System.Provider.Name -eq 'Microsoft-Windows-Kernel-Process' -and $_.System.EventID -eq '1' })
"start_events=" + $starts.Count
if ($starts.Count -gt 0) { $starts[0].OuterXml }
