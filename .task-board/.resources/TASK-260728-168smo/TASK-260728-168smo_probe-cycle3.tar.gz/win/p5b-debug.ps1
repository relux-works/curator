$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$b='C:\kn168\b'; $log='C:\kn168\p5b.log'
function L($m){ $m | Tee-Object -FilePath $log -Append }
$err=@()
$f = Get-ChildItem -LiteralPath $b -Recurse -Force -File -ErrorAction SilentlyContinue -ErrorVariable err
L ("count=" + $f.Count)
L ("errors=" + $err.Count)
$err | Select-Object -First 3 | ForEach-Object { L ("  ERR " + $_.ToString().Substring(0,[Math]::Min(200,$_.ToString().Length))) }
L ("longest_path_len=" + (($f | ForEach-Object { $_.FullName.Length } | Measure-Object -Maximum).Maximum))
