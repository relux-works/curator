$root='C:\kn168'
"--- entries created in the empty data dir by the airplaneMode fail-closed run ---"
Get-ChildItem "$root\ov-empty" -Recurse -Force -EA SilentlyContinue | ForEach-Object { "  " + $_.FullName.Substring("$root\ov-empty".Length) + " " + $(if($_.PSIsContainer){'<DIR>'}else{$_.Length.ToString()+' B'}) }
"--- entries created in the empty data dir by the network-denied control ---"
Get-ChildItem "$root\ov-empty2" -Recurse -Force -EA SilentlyContinue | ForEach-Object { "  " + $_.FullName.Substring("$root\ov-empty2".Length) + " " + $(if($_.PSIsContainer){'<DIR>'}else{$_.Length.ToString()+' B'}) }
"--- overlay after all compiles (non-payload) ---"
Get-ChildItem "$root\ov" -Recurse -Force -EA SilentlyContinue | Where-Object { $_.FullName -notmatch '\\dependencies\\(lldb-|llvm-|msys2-|libffi-)' } | ForEach-Object { "  " + $_.FullName.Substring("$root\ov".Length) + " " + $(if($_.PSIsContainer){'<DIR>'}else{$_.Length.ToString()+' B'}) }
"--- konanc.bat control stderr ---"
Get-Content "$root\wd\bat.err" -EA SilentlyContinue
"--- netctl stderr first 6 ---"
Get-Content "$root\wd\netctl.err" -EA SilentlyContinue | Select-Object -First 6
"--- netctl stdout first 6 ---"
Get-Content "$root\wd\netctl.out" -EA SilentlyContinue | Select-Object -First 6
