if (Test-Path C:\kn168\p1-fetch.log) { Get-Content C:\kn168\p1-fetch.log }; Get-ChildItem C:\kn168\dl -EA SilentlyContinue | ForEach-Object { $_.Name + " " + $_.Length }
