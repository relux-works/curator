function Get-TreeDigest($path) {
  $sha = [Security.Cryptography.SHA256]::Create()
  $files = Get-ChildItem -LiteralPath $path -Recurse -Force -File | Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb = New-Object Text.StringBuilder
  foreach ($f in $files) {
    $rel = $f.FullName.Substring($path.Length).Replace('\','/')
    $fs = [IO.File]::OpenRead($f.FullName)
    try { $h = [BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower() } finally { $fs.Dispose() }
    [void]$sb.Append($rel).Append(' ').Append($h).Append("`n")
  }
  $bytes = [Text.Encoding]::UTF8.GetBytes($sb.ToString())
  $agg = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace('-','').ToLower()
  return @{ digest = $agg; count = $files.Count; manifest = $sb.ToString() }
}
