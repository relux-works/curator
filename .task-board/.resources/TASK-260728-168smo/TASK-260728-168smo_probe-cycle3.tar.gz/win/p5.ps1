$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
function Get-TreeDigest($path) {
  $sha = [Security.Cryptography.SHA256]::Create()
  $files = @(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue) | Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb = New-Object Text.StringBuilder
  foreach ($f in $files) {
    $rel = $f.FullName.Substring($path.Length).Replace('\','/')
    $fs = [IO.File]::OpenRead($f.FullName)
    try { $h = [BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower() } finally { $fs.Dispose() }
    [void]$sb.Append($rel).Append(' ').Append($h).Append("`n")
  }
  $bytes = [Text.Encoding]::UTF8.GetBytes($sb.ToString())
  $agg = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace('-','').ToLower()
  return @{ digest = $agg; count = $files.Count; manifest = $sb.ToString() }
}
$JAVA = 'C:\kn168\b\jdk\bin\java.exe'
$JAR  = 'C:\kn168\b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar'
$MAIN = 'org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM  = @('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US','-Dkonan.home=C:\kn168\b\kotlin-native')
$root='C:\kn168'; $b="$root\b"; $log="$root\p5.log"
function L($m){ $m | Tee-Object -FilePath $log -Append }
Remove-Item $log -EA SilentlyContinue
L "== P5 finalize bundle =="
L ("cache dir present=" + (Test-Path "$b\konan-data\dependencies\cache"))
$d1 = Get-TreeDigest $b
L ("BUNDLE DIGEST (curated, pre-compile) files=" + $d1.count + " sha256=" + $d1.digest)
Set-Content "$root\bundle-manifest-1.txt" $d1.manifest -NoNewline
$sz = (Get-ChildItem $b -Recurse -File -Force -EA SilentlyContinue | Measure-Object Length -Sum).Sum
L ("bundle bytes=" + $sz)
L "== P5 done =="
