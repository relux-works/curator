$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
. C:\kn168\lib-hash.ps1
$root='C:\kn168'; $b="$root\b"; $log="$root\p5.log"
function L($m){ $m | Tee-Object -FilePath $log -Append }
L "== P5 finalize bundle =="
L "-- .extracted content --"
Get-Content "$b\konan-data\dependencies\.extracted" | ForEach-Object { L ("  | " + $_) }
$cacheSize = (Get-ChildItem "$b\konan-data\dependencies\cache" -Recurse -File -EA SilentlyContinue | Measure-Object Length -Sum).Sum
L ("download cache bytes=" + $cacheSize + "  (removed as a curation step)")
Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue

$d1 = Get-TreeDigest $b
L ("BUNDLE DIGEST (curated) files=" + $d1.count + " sha256=" + $d1.digest)
Set-Content "$root\bundle-manifest-1.txt" $d1.manifest
$sz = (Get-ChildItem $b -Recurse -File -Force | Measure-Object Length -Sum).Sum
L ("bundle bytes=" + $sz)
L "== P5 done =="
