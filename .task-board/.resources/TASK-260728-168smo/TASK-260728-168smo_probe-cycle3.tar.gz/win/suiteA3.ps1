$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $ov="$root\ov"; $log="$root\suiteA3.log"
Remove-Item $log -EA SilentlyContinue
function L($m){ $s=[string]$m; Add-Content -LiteralPath $log -Value $s; Write-Host $s }
function TreeDigest($path){
  $sha=[Security.Cryptography.SHA256]::Create()
  $files=@(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue)|Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb=New-Object Text.StringBuilder
  foreach($f in $files){
    $rel=$f.FullName.Substring($path.Length).Replace('\','/')
    $fs=[IO.File]::OpenRead($f.FullName)
    try{$h=[BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower()}finally{$fs.Dispose()}
    [void]$sb.Append($rel).Append(' ').Append($h).Append("`n")
  }
  return @{digest=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sb.ToString()))).Replace('-','').ToLower());count=$files.Count}
}
$JAVA="$b\jdk\bin\java.exe"; $JAR="$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$MAIN='org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM=@('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")
$script:LASTRC=$null
function RunKonanc([string]$tag,[string]$dataDir,[string]$outbase,[string[]]$srcs,[string[]]$extra){
  $o="$root\wd\$tag.out"; $e="$root\wd\$tag.err"; Remove-Item $o,$e -EA SilentlyContinue
  $sp=$env:PATH;$st=$env:TEMP;$st2=$env:TMP
  $env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"; $env:KONAN_DATA_DIR=$dataDir
  foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){Remove-Item "Env:\$v" -EA SilentlyContinue}
  $a=@($JVM)+@('-cp',$JAR,$MAIN,'konanc')
  if($extra){$a+=$extra}else{$a+=@('-Xoverride-konan-properties=airplaneMode=true')}
  $a+=@('-produce','program','-target','mingw_x64','-o',$outbase)+$srcs
  L ("ARGV[$tag] " + $JAVA + ' ' + ($a -join ' '))
  $rc=$null
  try { $p=Start-Process -FilePath $JAVA -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e -ErrorAction Stop; $rc=$p.ExitCode }
  catch { L ("  START-EXCEPTION: " + $_.Exception.Message) }
  $env:PATH=$sp;$env:TEMP=$st;$env:TMP=$st2
  L ("EXIT[$tag]=" + $rc)
  $ot=Get-Content $o -Raw -EA SilentlyContinue; $et=Get-Content $e -Raw -EA SilentlyContinue
  L ("  downloads_in_output=" + (@([regex]::Matches(([string]$ot + [string]$et),'Downloading')).Count))
  if($ot){($ot -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 8)|ForEach-Object{L ("  O| "+$_)}}
  if($et){($et -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 8)|ForEach-Object{L ("  E| "+$_)}}
  $script:LASTRC=$rc
}
$sid=([Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
L "=== SUITE A3 ==="
L ("SID=" + $sid)
L "--- A3.0 clear any deny ACE ---"
& icacls.exe $b /remove:d "*$sid" /T /C 2>&1 | Select-Object -Last 1 | ForEach-Object { L ("  | "+$_) }
Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue
Remove-Item -Recurse -Force "$root\out" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\out","$root\wd","$root\stg","$root\emptybin","$root\src2"|Out-Null

L "--- A3.1 is dependencies/.extracted required? (it is currently ABSENT) ---"
L ("  .extracted present=" + (Test-Path "$b\konan-data\dependencies\.extracted"))
RunKonanc 'noext' "$b\konan-data" "$root\out\noext" @("$root\src\main.kt") $null
$rcNoExt=$script:LASTRC
L ("  RESULT: compile without .extracted exit=" + $rcNoExt)
Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue

L "--- A3.2 restore .extracted (manager-independent curation artifact) ---"
$names=@('lldb-2-windows','msys2-mingw-w64-x86_64-2','llvm-21-x86_64-windows-essentials-150','libffi-3.3-windows-x64-1')
[IO.File]::WriteAllText("$b\konan-data\dependencies\.extracted", (($names -join "`n") + "`n"))
L ("  .extracted bytes=" + (Get-Item "$b\konan-data\dependencies\.extracted").Length)
RunKonanc 'withext' "$b\konan-data" "$root\out\withext" @("$root\src\main.kt") $null
L ("  RESULT: compile with restored .extracted exit=" + $script:LASTRC)
Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue

L "--- A3.3 curated baseline digest ---"
$D0=TreeDigest $b
L ("D0 digest=" + $D0.digest + " files=" + $D0.count)

L "--- A3.4 make the bundle read-only to the running account ---"
$sw=[Diagnostics.Stopwatch]::StartNew()
& icacls.exe $b /deny "*${sid}:(OI)(CI)(DE,DC,WD,AD,WEA,WA)" /T /C 2>&1 | Select-Object -Last 1 | ForEach-Object { L ("  | "+$_) }
$sw.Stop(); L ("  icacls elapsed_s=" + [math]::Round($sw.Elapsed.TotalSeconds,1))
try { $p=Start-Process -FilePath $JAVA -ArgumentList '-version' -NoNewWindow -Wait -PassThru -RedirectStandardError "$root\wd\jv.err" -ErrorAction Stop; L ("  EXEC-PROBE java -version exit=" + $p.ExitCode) } catch { L ("  EXEC-PROBE FAILED: " + $_.Exception.Message) }
try { [IO.File]::WriteAllText("$b\konan-data\wt.tmp","x"); L "  WRITE-PROBE: SUCCEEDED (NOT read-only)"; Remove-Item "$b\konan-data\wt.tmp" -Force -EA SilentlyContinue } catch { L ("  WRITE-PROBE: denied (" + $_.Exception.InnerException.GetType().Name + ")") }
try { Remove-Item "$b\konan-data\dependencies\.extracted" -Force -ErrorAction Stop; L "  DELETE-PROBE: SUCCEEDED (NOT read-only)" } catch { L "  DELETE-PROBE: denied" }
L ("  .extracted still present=" + (Test-Path "$b\konan-data\dependencies\.extracted"))

L "--- A3.5 S2: compile against the READ-ONLY bundle data dir ---"
RunKonanc 's2' "$b\konan-data" "$root\out\s2" @("$root\src\main.kt") $null
$rcS2=$script:LASTRC

L "--- A3.6 S3: operation-private overlay ---"
Remove-Item -Recurse -Force $ov -EA SilentlyContinue
New-Item -ItemType Directory -Force -Path "$ov\dependencies","$ov\dependencies\cache"|Out-Null
$mech='junction'
foreach($d in Get-ChildItem "$b\konan-data\dependencies" -Directory -Force){
  if($d.Name -eq 'cache'){continue}
  try { New-Item -ItemType Junction -Path "$ov\dependencies\$($d.Name)" -Target $d.FullName -EA Stop | Out-Null }
  catch { $mech='copy'; Copy-Item -Recurse -Force $d.FullName "$ov\dependencies\$($d.Name)" }
}
Copy-Item "$b\konan-data\dependencies\.extracted" "$ov\dependencies\.extracted" -Force
L ("  overlay mechanism=" + $mech)
Get-ChildItem "$ov\dependencies" -Force|ForEach-Object{L ("  ov " + $_.Name + " | " + $_.Attributes + " | " + $_.Target)}
RunKonanc 's3' $ov "$root\out\s3" @("$root\src\main.kt") $null
$rcS3=$script:LASTRC
Get-ChildItem "$root\out" -Force|ForEach-Object{L ("  out "+$_.Name+" "+$_.Length)}
L "  -- overlay writes (non-junction) --"
Get-ChildItem $ov -Recurse -Force -EA SilentlyContinue | Where-Object { $_.FullName -notmatch '\\dependencies\\(lldb-|llvm-|msys2-|libffi-)' } | ForEach-Object{L ("    ov "+$_.FullName.Substring($ov.Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length}))}
L "  -- staging writes --"
Get-ChildItem "$root\stg" -Recurse -Force -EA SilentlyContinue | Select-Object -First 25 | ForEach-Object{L ("    stg "+$_.FullName.Substring("$root\stg".Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length}))}

L "--- A3.7 bundle byte-identity ---"
$D2=TreeDigest $b
L ("D2 digest=" + $D2.digest + " files=" + $D2.count)
L ("BUNDLE_UNCHANGED=" + ($D2.digest -eq $D0.digest))
L ("=== SUITE A3 done rcNoExt=$rcNoExt rcS2=$rcS2 rcS3=$rcS3 ===")
