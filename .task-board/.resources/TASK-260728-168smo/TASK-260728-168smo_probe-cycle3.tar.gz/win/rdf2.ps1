$c = Get-Content C:\kn168\final.log -EA SilentlyContinue
"LINES=" + $c.Count
$c
