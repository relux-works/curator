$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $ov="$root\ov"; $log="$root\suiteB.log"
Remove-Item $log -EA SilentlyContinue
function L($m){ $s=[string]$m; Add-Content -LiteralPath $log -Value $s; Write-Output $s }
$JAVA="$b\jdk\bin\java.exe"
$JAR="$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$MAIN='org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM=@('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")
New-Item -ItemType Directory -Force -Path "$root\emptybin","$root\wd","$root\stg","$root\trace","$root\out" | Out-Null

Add-Type -Namespace N -Name W -MemberDefinition @'
[DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
public static extern uint QueryDosDevice(string lpDeviceName, System.Text.StringBuilder lpTargetPath, uint ucchMax);
'@
function Get-DeviceMap {
  $m=@{}
  foreach($d in [IO.DriveInfo]::GetDrives()){
    $letter=$d.Name.TrimEnd('\')
    $sb=New-Object Text.StringBuilder 1024
    if([N.W]::QueryDosDevice($letter,$sb,1024) -gt 0){ $m[$sb.ToString()]=$letter }
  }
  return $m
}
$DEV=Get-DeviceMap
function Resolve-NtPath($p){
  foreach($k in $DEV.Keys){ if($p.StartsWith($k+'\')){ return $DEV[$k] + $p.Substring($k.Length) } }
  return $p
}
function RunKonanc([string]$tag,[string]$dataDir,[string]$outbase,[string[]]$srcs,[string[]]$extra){
  $o="$root\wd\$tag.out"; $e="$root\wd\$tag.err"
  Remove-Item $o,$e -EA SilentlyContinue
  $sp=$env:PATH;$st=$env:TEMP;$st2=$env:TMP
  $env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"; $env:KONAN_DATA_DIR=$dataDir
  foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){Remove-Item "Env:\$v" -EA SilentlyContinue}
  $a=@($JVM)+@('-cp',$JAR,$MAIN,'konanc')
  if($extra){$a+=$extra}else{$a+=@('-Xoverride-konan-properties=airplaneMode=true')}
  $a+=@('-produce','program','-target','mingw_x64','-o',$outbase)+$srcs
  L ("ARGV[$tag] " + $JAVA + ' ' + ($a -join ' '))
  $p=Start-Process -FilePath $JAVA -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
  $env:PATH=$sp;$env:TEMP=$st;$env:TMP=$st2
  L ("EXIT[$tag]=" + $p.ExitCode)
  $ot=Get-Content $o -Raw -EA SilentlyContinue; $et=Get-Content $e -Raw -EA SilentlyContinue
  if($ot){($ot -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 10)|ForEach-Object{L ("  O| "+$_)}}
  if($et){($et -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 10)|ForEach-Object{L ("  E| "+$_)}}
  return $p.ExitCode
}

L "=== SUITE B start ==="
L "--- B1: ETW kernel process trace of the overlay compile (A3) ---"
& logman.exe stop kn168 -ets 2>&1 | Out-Null
Remove-Item "$root\trace\b1.etl","$root\trace\b1.xml" -EA SilentlyContinue
Remove-Item -Recurse -Force "$root\stg" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\stg"|Out-Null
Remove-Item "$root\out\b1.exe" -EA SilentlyContinue
& logman.exe create trace kn168 -p Microsoft-Windows-Kernel-Process 0x10 -o "$root\trace\b1.etl" -ets -bs 128 -nb 64 256 2>&1 | Out-Null
$myPid=$PID
$rcB1 = RunKonanc 'b1' $ov "$root\out\b1" @("$root\src\main.kt") $null
# tracer control: a deliberately out-of-root executable must appear in the trace
& "$env:SystemRoot\System32\where.exe" where.exe | Out-Null
& logman.exe stop kn168 -ets 2>&1 | Out-Null
& tracerpt.exe "$root\trace\b1.etl" -o "$root\trace\b1.xml" -of XML -y 2>&1 | Out-Null
$x=[xml](Get-Content "$root\trace\b1.xml" -Raw)
$starts=@($x.Events.Event|Where-Object{$_.System.Provider.Name -eq 'Microsoft-Windows-Kernel-Process' -and $_.System.EventID -eq '1'})
L ("ProcessStart events captured=" + $starts.Count)
$rows=@()
foreach($ev in $starts){
  $d=@{}; foreach($n in $ev.EventData.Data){ $d[$n.Name]=([string]$n.'#text').Trim() }
  $rows += [pscustomobject]@{ pid=[int]$d['ProcessID']; ppid=[int]$d['ParentProcessID']; image=(Resolve-NtPath $d['ImageName']) }
}
# descendants of this powershell process (which is the parent of java.exe)
$set=New-Object 'System.Collections.Generic.HashSet[int]'
[void]$set.Add($myPid)
for($i=0;$i -lt 6;$i++){ foreach($r in $rows){ if($set.Contains($r.ppid)){ [void]$set.Add($r.pid) } } }
$desc=@($rows|Where-Object{ $set.Contains($r.ppid) -or $set.Contains($_.ppid) })
L "--- all ProcessStart images below this session (resolved absolute path) ---"
$uniq=@($desc|Select-Object -ExpandProperty image -Unique|Sort-Object)
foreach($im in $uniq){
  $inBundle = $im.StartsWith($b + '\', [StringComparison]::OrdinalIgnoreCase)
  $inOv     = $im.StartsWith($ov + '\', [StringComparison]::OrdinalIgnoreCase)
  $cls = if($inBundle){'IN-BUNDLE'} elseif($inOv){'IN-OVERLAY'} else {'OUTSIDE'}
  L ("  [$cls] " + $im)
}
L ("distinct images below session=" + $uniq.Count)
L ("TRACER-CONTROL where.exe recorded=" + [bool](@($rows|Where-Object{$_.image -like '*\where.exe'}).Count))
L "--- full unfiltered image list (every ProcessStart in the trace window) ---"
@($rows|Select-Object -ExpandProperty image -Unique|Sort-Object)|ForEach-Object{ L ("  ANY " + $_) }

L "--- B2: artifact and by-products (A5) ---"
Get-ChildItem "$root\out" -Force -Recurse|ForEach-Object{L ("  out "+$_.FullName.Substring("$root\out".Length)+" "+$_.Length)}
Get-ChildItem "$root\stg" -Force -Recurse -EA SilentlyContinue|Select-Object -First 40|ForEach-Object{L ("  stg "+$_.FullName.Substring("$root\stg".Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length})) }
$art="$root\out\b1.exe"
if(Test-Path $art){
  $fs=[IO.File]::OpenRead($art); $hdr=New-Object byte[] 2; [void]$fs.Read($hdr,0,2); $fs.Position=0x3c
  $pe=New-Object byte[] 4; [void]$fs.Read($pe,0,4); $off=[BitConverter]::ToInt32($pe,0); $fs.Position=$off
  $sig=New-Object byte[] 6; [void]$fs.Read($sig,0,6); $fs.Dispose()
  L ("  artifact bytes=" + (Get-Item $art).Length)
  L ("  MZ=" + [char]$hdr[0] + [char]$hdr[1] + " PEsig=" + [char]$sig[0]+[char]$sig[1] + " machine=0x" + ([BitConverter]::ToUInt16($sig,4)).ToString('x4') + " (0x8664=AMD64)")
  $ro="$root\wd\run.out"
  $rp=Start-Process -FilePath $art -NoNewWindow -Wait -PassThru -RedirectStandardOutput $ro
  L ("  run exit=" + $rp.ExitCode + " stdout=" + ((Get-Content $ro -Raw) -replace "`r`n",'\n'))
}
L "=== SUITE B done rcB1=$rcB1 ==="
