Get-Content C:\kn168inal.log -EA SilentlyContinue
