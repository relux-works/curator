$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $ov="$root\ov"; $log="$root\suiteA.log"
Remove-Item $log -EA SilentlyContinue
function L($m){ $s = [string]$m; Add-Content -LiteralPath $log -Value $s; Write-Output $s }
function FileList($path){
  $f = @(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue) |
       ForEach-Object { $_.FullName.Substring($path.Length).Replace('\','/') + ' ' + $_.Length } | Sort-Object
  return $f
}
function TreeDigest($path){
  $sha=[Security.Cryptography.SHA256]::Create()
  $files=@(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue)|Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb=New-Object Text.StringBuilder
  foreach($f in $files){
    $rel=$f.FullName.Substring($path.Length).Replace('\','/')
    $fs=[IO.File]::OpenRead($f.FullName)
    try{$h=[BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower()}finally{$fs.Dispose()}
    [void]$sb.Append($rel).Append(' ').Append($h).Append("`n")
  }
  $agg=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sb.ToString()))).Replace('-','').ToLower()
  return @{digest=$agg;count=$files.Count;manifest=$sb.ToString()}
}
$JAVA="$b\jdk\bin\java.exe"
$JAR="$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$MAIN='org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM=@('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")
New-Item -ItemType Directory -Force -Path "$root\emptybin","$root\wd","$root\stg" | Out-Null

function RunKonanc([string]$tag,[string]$dataDir,[string]$outbase,[string[]]$srcs,[string[]]$extra){
  $o="$root\wd\$tag.out"; $e="$root\wd\$tag.err"
  Remove-Item $o,$e -EA SilentlyContinue
  $savedPath=$env:PATH; $savedTmp=$env:TEMP; $savedTmp2=$env:TMP
  $env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"
  $env:KONAN_DATA_DIR=$dataDir
  foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){ Remove-Item "Env:\$v" -EA SilentlyContinue }
  $a=@($JVM)+@('-cp',$JAR,$MAIN,'konanc')
  if($extra){$a+=$extra}else{$a+=@('-Xoverride-konan-properties=airplaneMode=true')}
  $a+=@('-produce','program','-target','mingw_x64','-o',$outbase)+$srcs
  L ("ARGV[$tag] " + $JAVA + ' ' + ($a -join ' '))
  $sw=[Diagnostics.Stopwatch]::StartNew()
  $p=Start-Process -FilePath $JAVA -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
  $sw.Stop()
  $env:PATH=$savedPath; $env:TEMP=$savedTmp; $env:TMP=$savedTmp2
  L ("EXIT[$tag]=" + $p.ExitCode + " elapsed_s=" + [math]::Round($sw.Elapsed.TotalSeconds,1))
  $ot=Get-Content $o -Raw -EA SilentlyContinue; $et=Get-Content $e -Raw -EA SilentlyContinue
  if($ot){ ($ot -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 8)|ForEach-Object{L ("  O| "+$_)} }
  if($et){ ($et -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 8)|ForEach-Object{L ("  E| "+$_)} }
  return $p.ExitCode
}

L "=== SUITE A start ==="
L "--- step 1: baseline ---"
$L0=FileList $b; [IO.File]::WriteAllLines("$root\list0.txt",$L0)
L ("L0 files=" + $L0.Count)
$D0=TreeDigest $b; [IO.File]::WriteAllText("$root\manifest0.txt",$D0.manifest)
L ("D0 digest=" + $D0.digest + " files=" + $D0.count)

L "--- step 2: compile with WRITABLE bundle data dir (S1) ---"
Remove-Item -Recurse -Force "$root\out" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\out"|Out-Null
$rc1=RunKonanc 's1' "$b\konan-data" "$root\out\s1" @("$root\src\main.kt") $null
Get-ChildItem "$root\out" -Force -Recurse|ForEach-Object{L ("  produced "+$_.FullName.Substring("$root\out".Length)+" "+$_.Length)}
$L1=FileList $b; [IO.File]::WriteAllLines("$root\list1.txt",$L1)
L ("L1 files=" + $L1.Count)
$diff=Compare-Object $L0 $L1
if($diff){ $diff|ForEach-Object{L ("  "+$_.SideIndicator+" "+$_.InputObject)} } else { L "  no file-list change" }

L "--- step 3: restore curated state, verify digest returns to D0 ---"
$added=@($diff|Where-Object{$_.SideIndicator -eq '=>'}|ForEach-Object{($_.InputObject -split ' ')[0]})
foreach($rel in $added){ Remove-Item -LiteralPath ($b + $rel.Replace('/','\')) -Force -EA SilentlyContinue; L ("  removed "+$rel) }
Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue
$D0b=TreeDigest $b
L ("D0' digest=" + $D0b.digest + " files=" + $D0b.count)
L ("RESTORED_TO_BASELINE=" + ($D0b.digest -eq $D0.digest))

L "--- step 4: make bundle read-only to the running account ---"
$acct = "$env:USERDOMAIN\$env:USERNAME"
$sw=[Diagnostics.Stopwatch]::StartNew()
$ic = & icacls.exe $b /deny "${acct}:(OI)(CI)(W,D,DC)" /T /C 2>&1 | Select-Object -Last 2
$sw.Stop()
L ("icacls deny elapsed_s=" + [math]::Round($sw.Elapsed.TotalSeconds,1))
$ic|ForEach-Object{L ("  | "+$_)}
try { [IO.File]::WriteAllText("$b\konan-data\writetest.tmp","x"); L "  WRITE-PROBE: SUCCEEDED (bundle NOT read-only)" ; Remove-Item "$b\konan-data\writetest.tmp" -Force -EA SilentlyContinue }
catch { L ("  WRITE-PROBE: denied -> " + $_.Exception.GetType().Name) }

L "--- step 5: compile with READ-ONLY bundle data dir (S2) ---"
$rc2=RunKonanc 's2' "$b\konan-data" "$root\out\s2" @("$root\src\main.kt") $null

L "--- step 6: build operation-private overlay, compile (S3) ---"
Remove-Item -Recurse -Force $ov -EA SilentlyContinue
New-Item -ItemType Directory -Force -Path "$ov\dependencies","$ov\dependencies\cache"|Out-Null
$mech='junction'
foreach($d in Get-ChildItem "$b\konan-data\dependencies" -Directory -Force){
  try { New-Item -ItemType Junction -Path "$ov\dependencies\$($d.Name)" -Target $d.FullName -EA Stop | Out-Null }
  catch { $mech='copy'; Copy-Item -Recurse -Force $d.FullName "$ov\dependencies\$($d.Name)" }
}
Copy-Item "$b\konan-data\dependencies\.extracted" "$ov\dependencies\.extracted" -Force
L ("overlay mechanism=" + $mech)
Get-ChildItem "$ov\dependencies" -Force|ForEach-Object{L ("  ov "+$_.Name+" "+$_.Attributes)}
$rc3=RunKonanc 's3' $ov "$root\out\s3" @("$root\src\main.kt") $null
Get-ChildItem "$root\out" -Force -Recurse|ForEach-Object{L ("  produced "+$_.FullName.Substring("$root\out".Length)+" "+$_.Length)}
L "--- overlay writes ---"
Get-ChildItem $ov -Recurse -Force -EA SilentlyContinue|Where-Object{-not $_.PSIsContainer -and $_.FullName -notlike "*\dependencies\lldb*" -and $_.FullName -notlike "*\dependencies\llvm*" -and $_.FullName -notlike "*\dependencies\msys2*" -and $_.FullName -notlike "*\dependencies\libffi*"}|ForEach-Object{L ("  ovfile "+$_.FullName.Substring($ov.Length)+" "+$_.Length)}

L "--- step 7: bundle byte-identity after overlay compile ---"
$D2=TreeDigest $b
L ("D2 digest=" + $D2.digest + " files=" + $D2.count)
L ("BUNDLE_UNCHANGED_BY_OVERLAY_COMPILE=" + ($D2.digest -eq $D0.digest))
L ("=== SUITE A done rc1=$rc1 rc2=$rc2 rc3=$rc3 ===")
