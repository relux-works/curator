Get-Item C:\kn168\suiteA.ps1 | ForEach-Object { $_.FullName + " " + $_.Length }
