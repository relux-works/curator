"now=" + (Get-Date).ToString('HH:mm:ss')
Get-CimInstance Win32_Process -Filter "Name='java.exe'" | ForEach-Object { "java pid=" + $_.ProcessId + " started=" + ([Management.ManagementDateTimeConverter]::ToDateTime($_.CreationDate)).ToString('HH:mm:ss') }
"netctl.out len=" + (Get-Item C:\kn168\wd\netctl.out -EA SilentlyContinue).Length
"netctl.err len=" + (Get-Item C:\kn168\wd\netctl.err -EA SilentlyContinue).Length
Get-Content C:\kn168\wd\netctl.out -EA SilentlyContinue | Select-Object -Last 3
Get-Content C:\kn168\wd\netctl.err -EA SilentlyContinue | Select-Object -Last 3
