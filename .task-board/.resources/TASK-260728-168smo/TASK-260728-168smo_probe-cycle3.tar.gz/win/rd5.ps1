Get-Content C:\kn168\suiteA3.log | Select-Object -Skip 24 -First 22
