Get-Content C:\kn168\suiteA3.log -EA SilentlyContinue
