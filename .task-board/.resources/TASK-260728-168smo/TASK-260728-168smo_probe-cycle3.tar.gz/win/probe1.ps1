$ErrorActionPreference='Continue'
$d = Get-PSDrive C
"free_GB=" + [math]::Round($d.Free/1GB,1)
foreach ($t in 'curl.exe','tar.exe','logman.exe','tracerpt.exe','certutil.exe','java.exe','netsh.exe','where.exe','wevtutil.exe') {
  $c = Get-Command $t -ErrorAction SilentlyContinue
  "$t=" + $(if ($c) { $c.Source } else { 'ABSENT' })
}
"konan_dir_exists=" + (Test-Path (Join-Path $env:USERPROFILE '.konan'))
"admin=" + ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
"tls=" + [Net.ServicePointManager]::SecurityProtocol
"temp=" + $env:TEMP
