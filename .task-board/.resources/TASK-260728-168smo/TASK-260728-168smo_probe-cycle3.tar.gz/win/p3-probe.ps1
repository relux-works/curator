$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $log="$root\p3-probe.log"
function L($m){ $m | Tee-Object -FilePath $log -Append }
L "== P3 probe =="
L "-- run_konan.bat source --"
Get-Content "$b\kotlin-native\bin\run_konan.bat" | ForEach-Object { L ("  | " + $_) }
L "-- konanc.bat source --"
Get-Content "$b\kotlin-native\bin\konanc.bat" | ForEach-Object { L ("  | " + $_) }

$java = "$b\jdk\bin\java.exe"
$jar  = "$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$main = 'org.jetbrains.kotlin.cli.utilities.MainKt'
$jvm  = @('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")

New-Item -ItemType Directory -Force -Path "$root\wd" | Out-Null
Push-Location "$root\wd"

L "-- E-W2: konanc -version --"
$o="$root\wd\v.out"; $e="$root\wd\v.err"
$p = Start-Process -FilePath $java -ArgumentList (@($jvm) + @('-cp',$jar,$main,'konanc','-version')) -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
L ("exit=" + $p.ExitCode)
L ("stdout_bytes=" + (Get-Item $o).Length)
L "stdout:"; Get-Content $o | ForEach-Object { L ("  | " + $_) }
L ("stdout_hex_first_line=" + ((Get-Content $o -Encoding Byte -TotalCount 64 | ForEach-Object { $_.ToString('x2') }) -join ''))
L ("stderr_bytes=" + (Get-Item $e).Length)
L "stderr:"; Get-Content $e | ForEach-Object { L ("  | " + $_) }

L "-- E-W3: konanc -list-targets --"
$o2="$root\wd\t.out"; $e2="$root\wd\t.err"
$p2 = Start-Process -FilePath $java -ArgumentList (@($jvm) + @('-cp',$jar,$main,'konanc','-list-targets')) -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o2 -RedirectStandardError $e2
L ("exit=" + $p2.ExitCode)
L ("stdout_bytes=" + (Get-Item $o2).Length)
L "stdout:"; Get-Content $o2 | ForEach-Object { L ("  | " + $_) }
L ("stderr_bytes=" + (Get-Item $e2).Length)
L "stderr:"; Get-Content $e2 | ForEach-Object { L ("  | " + $_) }
Pop-Location

L "-- E-W5: konan.properties mingw_x64 / linux_x64 relevant keys --"
Select-String -Path "$b\kotlin-native\konan\konan.properties" -Pattern '^(targetToolchain\.mingw|targetSysRoot\.mingw|additionalToolsDir\.mingw|llvm\.mingw|toolchainDependency\.mingw|dependencyProfiles|airplaneMode|internalDomain|downloadingProtocol|dependenciesUrl|libffi\.mingw|targetToolchain\.linux_x64|targetSysRoot\.linux_x64)' | ForEach-Object { L ("  | " + $_.Line) }
L "-- remote:internal occurrences (all) --"
Select-String -Path "$b\kotlin-native\konan\konan.properties" -Pattern 'remote:internal' | ForEach-Object { L ("  | " + $_.Line) }
L "== P3 done =="
