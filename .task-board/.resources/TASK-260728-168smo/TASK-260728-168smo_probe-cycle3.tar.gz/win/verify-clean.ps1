"C:\kn168 present=" + (Test-Path 'C:\kn168')
"~/.konan present=" + (Test-Path (Join-Path $env:USERPROFILE '.konan'))
"java on PATH=" + [bool](Get-Command java.exe -EA SilentlyContinue)
$fw = & netsh.exe advfirewall firewall show rule name=kn168-deny-java-out 2>&1
"firewall rule present=" + [bool](@($fw | Select-String 'kn168-deny').Count)
$tr = & logman.exe query -ets 2>&1
"etw session kn168 present=" + [bool](@($tr | Select-String 'kn168').Count)
"free GB=" + [math]::Round((Get-PSDrive C).Free/1GB,1)
