$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
function Get-TreeDigest($path) {
  $sha = [Security.Cryptography.SHA256]::Create()
  $files = @(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue) | Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb = New-Object Text.StringBuilder
  foreach ($f in $files) {
    $rel = $f.FullName.Substring($path.Length).Replace('\','/')
    $fs = [IO.File]::OpenRead($f.FullName)
    try { $h = [BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower() } finally { $fs.Dispose() }
    [void]$sb.Append($rel).Append(' ').Append($h).Append("`n")
  }
  $bytes = [Text.Encoding]::UTF8.GetBytes($sb.ToString())
  $agg = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace('-','').ToLower()
  return @{ digest = $agg; count = $files.Count; manifest = $sb.ToString() }
}
$JAVA = 'C:\kn168\b\jdk\bin\java.exe'
$JAR  = 'C:\kn168\b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar'
$MAIN = 'org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM  = @('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US','-Dkonan.home=C:\kn168\b\kotlin-native')
$root='C:\kn168'; $b="$root\b"; $log="$root\p6.log"
function L($m){ $m | Tee-Object -FilePath $log -Append }
Remove-Item $log -EA SilentlyContinue
function RunKonanc($outbase, $srcs, $dataDir, $extra) {
  $o = "$root\wd\r.out"; $e = "$root\wd\r.err"
  Remove-Item $o,$e -EA SilentlyContinue
  $env:KONAN_DATA_DIR = $dataDir
  $args = @($JVM) + @('-cp',$JAR,$MAIN,'konanc','-Xoverride-konan-properties=airplaneMode=true','-produce','program','-target','mingw_x64','-o',$outbase)
  if ($extra) { $args = @($JVM) + @('-cp',$JAR,$MAIN,'konanc') + $extra + @('-produce','program','-target','mingw_x64','-o',$outbase) }
  $args += $srcs
  $p = Start-Process -FilePath $JAVA -ArgumentList $args -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
  return @{ exit=$p.ExitCode; out=(Get-Content $o -Raw -EA SilentlyContinue); err=(Get-Content $e -Raw -EA SilentlyContinue) }
}
L "== P6 mutation / read-only / overlay =="
$m1 = Get-Content "$root\bundle-manifest-1.txt" -Raw
$d0 = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($m1))).Replace('-','').ToLower()
L ("baseline digest = " + $d0)

L "-- S1: compile with WRITABLE bundle data dir --"
Remove-Item -Recurse -Force "$root\out" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\out" | Out-Null
$r1 = RunKonanc "$root\out\s1" @("$root\src\main.kt") "$b\konan-data" $null
L ("exit=" + $r1.exit)
if ($r1.err) { ($r1.err -split "`r?`n" | Select-Object -First 6) | ForEach-Object { L ("  E| " + $_) } }
Get-ChildItem "$root\out" -Force | ForEach-Object { L ("  produced " + $_.Name + " " + $_.Length) }
$dA = Get-TreeDigest $b
L ("digest after writable-datadir compile = " + $dA.digest + " files=" + $dA.count)
L ("MUTATED = " + ($dA.digest -ne $d0))
if ($dA.digest -ne $d0) {
  $a = @{}; foreach ($ln in ($m1 -split "`n")) { if ($ln) { $p2=$ln -split ' '; $a[$p2[0]]=$p2[1] } }
  $bb = @{}; foreach ($ln in ($dA.manifest -split "`n")) { if ($ln) { $p2=$ln -split ' '; $bb[$p2[0]]=$p2[1] } }
  foreach ($k in $bb.Keys) { if (-not $a.ContainsKey($k)) { L ("  ADDED   " + $k) } elseif ($a[$k] -ne $bb[$k]) { L ("  CHANGED " + $k) } }
  foreach ($k in $a.Keys) { if (-not $bb.ContainsKey($k)) { L ("  REMOVED " + $k) } }
}
Set-Content "$root\bundle-manifest-2.txt" $dA.manifest -NoNewline
L "== P6 part A done =="
