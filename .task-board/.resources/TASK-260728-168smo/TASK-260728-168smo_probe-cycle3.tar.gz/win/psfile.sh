#!/bin/bash
# psfile.sh <local-script.ps1> : copy to host and run with powershell -File
set -euo pipefail
name=$(basename "$1")
scp -q "$1" "win:/kn168/$name"
ssh -o BatchMode=yes -o ServerAliveInterval=30 win "powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\\kn168\\$name" 2>&1 | grep -v 'WARNING: connection is not using' | grep -v 'store now, decrypt later' | grep -v 'openssh.com/pq.html' | grep -v '^\*\* '
