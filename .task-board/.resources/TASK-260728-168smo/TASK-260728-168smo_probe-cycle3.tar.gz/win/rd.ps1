Get-Content C:\kn168\p5.log; "---manifest1---"; (Get-Item C:\kn168undle-manifest-1.txt -EA SilentlyContinue).Length
