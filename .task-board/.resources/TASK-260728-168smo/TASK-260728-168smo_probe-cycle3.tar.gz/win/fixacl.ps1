$ProgressPreference='SilentlyContinue'
$root='C:\kn168'; $b="$root\b"
$sid=([Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
"remove bad deny:"
& icacls.exe $b /remove:d "*$sid" /T /C 2>&1 | Select-Object -Last 1
"apply write-only deny (DE,WD,AD,WEA,WA) - no SYNCHRONIZE, no RX:"
& icacls.exe $b /deny "*${sid}:(OI)(CI)(DE,WD,AD,WEA,WA)" /T /C 2>&1 | Select-Object -Last 1
"acl on java.exe:"
& icacls.exe "$b\jdk\bin\java.exe" 2>&1 | Select-Object -First 2
"exec probe:"
try { $p=Start-Process -FilePath "$b\jdk\bin\java.exe" -ArgumentList '-version' -NoNewWindow -Wait -PassThru -RedirectStandardError "$root\wd\jv.err"; "  java exit=" + $p.ExitCode; (Get-Content "$root\wd\jv.err" | Select-Object -First 1) } catch { "  EXEC EXCEPTION: " + $_.Exception.Message }
"write probe into bundle:"
try { [IO.File]::WriteAllText("$b\konan-data\wt.tmp","x"); "  WRITE SUCCEEDED (not read-only)"; Remove-Item "$b\konan-data\wt.tmp" -Force -EA SilentlyContinue } catch { "  write denied: " + $_.Exception.InnerException.GetType().Name }
"delete probe on an existing bundle file:"
try { Remove-Item "$b\konan-data\dependencies\.extracted" -Force -ErrorAction Stop; "  DELETE SUCCEEDED (not read-only)" } catch { "  delete denied" }
"read probe:"
"  .extracted still present=" + (Test-Path "$b\konan-data\dependencies\.extracted") + " bytes=" + (Get-Item "$b\konan-data\dependencies\.extracted").Length
