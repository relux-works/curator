Get-Process powershell,java -EA SilentlyContinue | ForEach-Object { $_.Id.ToString() + " " + $_.ProcessName }
