$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Stop'
$root='C:\kn168'; $b="$root\b"; $log="$root\p2-bundle.log"
function L($m){ $m | Tee-Object -FilePath $log -Append }
if (Test-Path $b) { Remove-Item -Recurse -Force $b }
New-Item -ItemType Directory -Force -Path $b,"$root\x" | Out-Null
L "== P2 bundle =="

# Kotlin/Native
$knx = "$root\x\kn"
if (Test-Path $knx) { Remove-Item -Recurse -Force $knx }
New-Item -ItemType Directory -Force -Path $knx | Out-Null
Push-Location $knx
& tar.exe -xf "$root\dl\kotlin-native-prebuilt-windows-x86_64-2.4.10.zip"
L "tar kn exit=$LASTEXITCODE"
Pop-Location
$knTop = (Get-ChildItem $knx -Directory)[0].FullName
L "kn top=$knTop"
Move-Item $knTop "$b\kotlin-native"

# JDK
$jx = "$root\x\jdk"
if (Test-Path $jx) { Remove-Item -Recurse -Force $jx }
New-Item -ItemType Directory -Force -Path $jx | Out-Null
Push-Location $jx
& tar.exe -xf "$root\dl\OpenJDK21U-jdk_x64_windows_hotspot_21.0.11_10.zip"
L "tar jdk exit=$LASTEXITCODE"
Pop-Location
$jTop = (Get-ChildItem $jx -Directory)[0].FullName
L "jdk top=$jTop"
Move-Item $jTop "$b\jdk"

New-Item -ItemType Directory -Force -Path "$b\konan-data" | Out-Null

L ("primary_relpath jdk\bin\java.exe exists=" + (Test-Path "$b\jdk\bin\java.exe"))
$ji = Get-Item "$b\jdk\bin\java.exe"
L ("  attributes=" + $ji.Attributes + " length=" + $ji.Length + " linktarget=" + $ji.LinkType)
L ("compiler jar exists=" + (Test-Path "$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"))
L ("  jar length=" + (Get-Item "$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar").Length)
L "-- kotlin-native\bin listing --"
Get-ChildItem "$b\kotlin-native\bin" | ForEach-Object { L ("  " + $_.Name + "  " + $_.Length) }
L "-- any regular .exe anywhere in the distribution --"
$exes = Get-ChildItem "$b\kotlin-native" -Recurse -File -Include *.exe -EA SilentlyContinue
L ("  count=" + ($exes | Measure-Object).Count)
$exes | Select-Object -First 20 | ForEach-Object { L ("  " + $_.FullName.Substring($b.Length)) }
L "== P2 done =="
