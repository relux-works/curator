$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $ov="$root\ov"; $log="$root\suiteA4.log"
Remove-Item $log -EA SilentlyContinue
function L($m){ $s=[string]$m; Add-Content -LiteralPath $log -Value $s }
function TreeDigest($path){
  $sha=[Security.Cryptography.SHA256]::Create()
  $files=@(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue)|Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb=New-Object Text.StringBuilder
  foreach($f in $files){ $rel=$f.FullName.Substring($path.Length).Replace('\','/')
    $fs=[IO.File]::OpenRead($f.FullName); try{$h=[BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower()}finally{$fs.Dispose()}
    [void]$sb.Append($rel).Append(' ').Append($h).Append("`n") }
  return @{digest=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sb.ToString()))).Replace('-','').ToLower());count=$files.Count}
}
$JAVA="$b\jdk\bin\java.exe"; $JAR="$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$MAIN='org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM=@('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")
$script:LASTRC=$null
function RunKonanc([string]$tag,[string]$dataDir,[string]$outbase,[string[]]$srcs,[string[]]$extra){
  $o="$root\wd\$tag.out"; $e="$root\wd\$tag.err"; Remove-Item $o,$e -EA SilentlyContinue
  $sp=$env:PATH;$st=$env:TEMP;$st2=$env:TMP
  $env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"; $env:KONAN_DATA_DIR=$dataDir
  foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){Remove-Item "Env:\$v" -EA SilentlyContinue}
  $a=@($JVM)+@('-cp',$JAR,$MAIN,'konanc'); if($extra){$a+=$extra}else{$a+=@('-Xoverride-konan-properties=airplaneMode=true')}
  $a+=@('-produce','program','-target','mingw_x64','-o',$outbase)+$srcs
  L ("ARGV[$tag] " + $JAVA + ' ' + ($a -join ' '))
  $rc=$null
  try { $p=Start-Process -FilePath $JAVA -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e -ErrorAction Stop; $rc=$p.ExitCode } catch { L ("  START-EXCEPTION: " + $_.Exception.Message) }
  $env:PATH=$sp;$env:TEMP=$st;$env:TMP=$st2
  L ("EXIT[$tag]=" + $rc)
  $ot=Get-Content $o -Raw -EA SilentlyContinue; $et=Get-Content $e -Raw -EA SilentlyContinue
  L ("  real_download_lines=" + (@([regex]::Matches(([string]$ot+[string]$et),'Downloading dependency')).Count))
  if($ot){($ot -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 6)|ForEach-Object{L ("  O| "+$_)}}
  if($et){($et -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 6)|ForEach-Object{L ("  E| "+$_)}}
  $script:LASTRC=$rc
}
$sid=([Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
L "=== SUITE A4 (repair + overlay compile + identity) ==="
L "--- A4.0 lift deny, restore dependencies/.extracted ---"
& icacls.exe $b /remove:d "*$sid" /T /C 2>&1 | Select-Object -Last 1 | ForEach-Object { L ("  | "+$_) }
$names=@('lldb-2-windows','msys2-mingw-w64-x86_64-2','llvm-21-x86_64-windows-essentials-150','libffi-3.3-windows-x64-1')
[IO.File]::WriteAllText("$b\konan-data\dependencies\.extracted", (($names -join "`n") + "`n"))
Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue
L ("  .extracted bytes=" + (Get-Item "$b\konan-data\dependencies\.extracted").Length)
L "--- A4.1 re-apply write deny (no destructive delete probe this time) ---"
& icacls.exe $b /deny "*${sid}:(OI)(CI)(DE,DC,WD,AD,WEA,WA)" /T /C 2>&1 | Select-Object -Last 1 | ForEach-Object { L ("  | "+$_) }
try { $p=Start-Process -FilePath $JAVA -ArgumentList '-version' -NoNewWindow -Wait -PassThru -RedirectStandardError "$root\wd\jv.err" -ErrorAction Stop; L ("  EXEC-PROBE java -version exit=" + $p.ExitCode) } catch { L ("  EXEC-PROBE FAILED: " + $_.Exception.Message) }
try { [IO.File]::WriteAllText("$b\konan-data\wt.tmp","x"); L "  WRITE-PROBE: SUCCEEDED (NOT read-only)"; Remove-Item "$b\konan-data\wt.tmp" -Force -EA SilentlyContinue } catch { L ("  WRITE-PROBE: denied (" + $_.Exception.InnerException.GetType().Name + ")") }
try { [IO.File]::AppendAllText("$b\konan-data\dependencies\.extracted","x"); L "  APPEND-PROBE: SUCCEEDED (NOT read-only)" } catch { L ("  APPEND-PROBE: denied (" + $_.Exception.InnerException.GetType().Name + ")") }
L ("  NOTE delete-child on this host is granted through BUILTIN\Administrators Full Control; a per-user deny does not remove it. Recorded as curation obligation K-11.")
L "--- A4.2 overlay ---"
Remove-Item -Recurse -Force $ov -EA SilentlyContinue
New-Item -ItemType Directory -Force -Path "$ov\dependencies","$ov\dependencies\cache"|Out-Null
$mech='junction'
foreach($d in Get-ChildItem "$b\konan-data\dependencies" -Directory -Force){ if($d.Name -eq 'cache'){continue}
  try { New-Item -ItemType Junction -Path "$ov\dependencies\$($d.Name)" -Target $d.FullName -EA Stop | Out-Null } catch { $mech='copy'; Copy-Item -Recurse -Force $d.FullName "$ov\dependencies\$($d.Name)" } }
Copy-Item "$b\konan-data\dependencies\.extracted" "$ov\dependencies\.extracted" -Force
L ("  overlay mechanism=" + $mech + "  overlay .extracted bytes=" + (Get-Item "$ov\dependencies\.extracted").Length)
Remove-Item -Recurse -Force "$root\stg" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\stg"|Out-Null
Remove-Item -Recurse -Force "$root\out" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\out"|Out-Null
RunKonanc 's3' $ov "$root\out\s3" @("$root\src\main.kt") $null
$rcS3=$script:LASTRC
Get-ChildItem "$root\out" -Force -Recurse|ForEach-Object{L ("  out "+$_.FullName.Substring("$root\out".Length)+" "+$_.Length)}
L "  -- overlay writes (non-dependency-payload) --"
Get-ChildItem $ov -Recurse -Force -EA SilentlyContinue | Where-Object { $_.FullName -notmatch '\\dependencies\\(lldb-|llvm-|msys2-|libffi-)' } | ForEach-Object{L ("    ov "+$_.FullName.Substring($ov.Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length}))}
L "  -- staging writes --"
Get-ChildItem "$root\stg" -Recurse -Force -EA SilentlyContinue | Select-Object -First 25 | ForEach-Object{L ("    stg "+$_.FullName.Substring("$root\stg".Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length}))}
L "--- A4.3 bundle byte-identity ---"
$D2=TreeDigest $b
L ("D2 digest=" + $D2.digest + " files=" + $D2.count)
L ("BUNDLE_UNCHANGED=" + ($D2.digest -eq '63d96ff7c488e713dedbf7029237cfc6cd030ae4c1caf11c8ba2274395badae3'))
L ("=== SUITE A4 done rcS3=$rcS3 ===")
