$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $ov="$root\ov"; $log="$root\suiteC.log"
Remove-Item $log -EA SilentlyContinue
function L($m){ $s=[string]$m; Add-Content -LiteralPath $log -Value $s; Write-Host $s }
$JAVA="$b\jdk\bin\java.exe"; $JAR="$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$MAIN='org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM=@('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")

function Get-PEInfo([string]$path){
  $y=[IO.File]::ReadAllBytes($path)
  $lf=[BitConverter]::ToInt32($y,0x3c); $coff=$lf+4
  $machine=[BitConverter]::ToUInt16($y,$coff); $numSec=[BitConverter]::ToUInt16($y,$coff+2)
  $optSize=[BitConverter]::ToUInt16($y,$coff+16); $opt=$coff+20
  $magic=[BitConverter]::ToUInt16($y,$opt)
  $dd = if($magic -eq 0x20b){$opt+112}else{$opt+96}
  $impRva=[BitConverter]::ToUInt32($y,$dd+8)
  $secs=@(); $so=$opt+$optSize
  for($i=0;$i -lt $numSec;$i++){ $o=$so+$i*40
    $secs+=[pscustomobject]@{va=[BitConverter]::ToUInt32($y,$o+12);vs=[BitConverter]::ToUInt32($y,$o+8);raw=[BitConverter]::ToUInt32($y,$o+20);rs=[BitConverter]::ToUInt32($y,$o+16)} }
  $names=@()
  if($impRva -ne 0){
    $off=-1; foreach($s in $secs){ $sz=[Math]::Max($s.vs,$s.rs); if($impRva -ge $s.va -and $impRva -lt ($s.va+$sz)){ $off=$s.raw+($impRva-$s.va); break } }
    if($off -ge 0){
      for($k=0;$k -lt 200;$k++){
        $d=$off+$k*20
        $nameRva=[BitConverter]::ToUInt32($y,$d+12)
        $ilt=[BitConverter]::ToUInt32($y,$d)
        if($nameRva -eq 0 -and $ilt -eq 0){break}
        $no=-1; foreach($s in $secs){ $sz=[Math]::Max($s.vs,$s.rs); if($nameRva -ge $s.va -and $nameRva -lt ($s.va+$sz)){ $no=$s.raw+($nameRva-$s.va); break } }
        if($no -lt 0){break}
        $e=$no; while($y[$e] -ne 0){$e++}
        $names+=[Text.Encoding]::ASCII.GetString($y,$no,$e-$no)
      }
    }
  }
  return @{machine=('0x'+$machine.ToString('x4'));magic=('0x'+$magic.ToString('x3'));imports=($names|Sort-Object -Unique);size=$y.Length}
}
function RunKonanc([string]$tag,[string]$dataDir,[string]$outbase,[string[]]$srcs,[string[]]$extra){
  $o="$root\wd\$tag.out"; $e="$root\wd\$tag.err"; Remove-Item $o,$e -EA SilentlyContinue
  $sp=$env:PATH;$st=$env:TEMP;$st2=$env:TMP
  $env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"; $env:KONAN_DATA_DIR=$dataDir
  foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){Remove-Item "Env:\$v" -EA SilentlyContinue}
  $a=@($JVM)+@('-cp',$JAR,$MAIN,'konanc')
  if($extra){$a+=$extra}else{$a+=@('-Xoverride-konan-properties=airplaneMode=true')}
  $a+=@('-produce','program','-target','mingw_x64','-o',$outbase)+$srcs
  L ("ARGV[$tag] " + $JAVA + ' ' + ($a -join ' '))
  $p=Start-Process -FilePath $JAVA -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
  $env:PATH=$sp;$env:TEMP=$st;$env:TMP=$st2
  L ("EXIT[$tag]=" + $p.ExitCode)
  $ot=Get-Content $o -Raw -EA SilentlyContinue; $et=Get-Content $e -Raw -EA SilentlyContinue
  L ("  downloads_in_stdout=" + @([regex]::Matches([string]$ot,'Downloading')).Count)
  if($ot){($ot -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 6)|ForEach-Object{L ("  O| "+$_)}}
  if($et){($et -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 6)|ForEach-Object{L ("  E| "+$_)}}
  return $p.ExitCode
}
L "=== SUITE C start ==="

L "--- C0: Stage A probe vectors under the operation environment, empty data dir ---"
$emptyData="$root\probe-data"; Remove-Item -Recurse -Force $emptyData -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path $emptyData,"$root\probe-wd"|Out-Null
$sp=$env:PATH;$st=$env:TEMP;$st2=$env:TMP
$env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"; $env:KONAN_DATA_DIR=$emptyData
foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){Remove-Item "Env:\$v" -EA SilentlyContinue}
foreach($pv in @(@{t='P1';a=@('-version')}, @{t='P2';a=@('-list-targets')})){
  $o="$root\wd\$($pv.t).out"; $e="$root\wd\$($pv.t).err"; Remove-Item $o,$e -EA SilentlyContinue
  $args=@($JVM)+@('-cp',$JAR,$MAIN,'konanc')+$pv.a
  L ("  ARGV[$($pv.t)] " + $JAVA + ' ' + ($args -join ' '))
  $p=Start-Process -FilePath $JAVA -ArgumentList $args -NoNewWindow -Wait -PassThru -WorkingDirectory "$root\probe-wd" -RedirectStandardOutput $o -RedirectStandardError $e
  $ob=[IO.File]::ReadAllBytes($o); $eb=[IO.File]::ReadAllBytes($e)
  L ("  EXIT=" + $p.ExitCode + " stdout_bytes=" + $ob.Length + " stderr_bytes=" + $eb.Length)
  L ("  stdout_hex=" + (($ob | Select-Object -First 48 | ForEach-Object { $_.ToString('x2') }) -join ''))
  (Get-Content $o -EA SilentlyContinue)|ForEach-Object{L ("    OUT| " + $_)}
  (Get-Content $e -EA SilentlyContinue)|Select-Object -First 4|ForEach-Object{L ("    ERR| " + $_)}
  L ("  data dir entries after probe=" + (@(Get-ChildItem $emptyData -Force -EA SilentlyContinue).Count))
}
$env:PATH=$sp;$env:TEMP=$st;$env:TMP=$st2

L "--- C1: PE class and imports of the plain program ---"
$i1=Get-PEInfo "$root\out\s3.exe"
L ("  s3.exe size=" + $i1.size + " magic=" + $i1.magic + " machine=" + $i1.machine)
L ("  imports: " + ($i1.imports -join ', '))

L "--- C2: distribution platform-library import sample ---"
Set-Content "$root\src2\main.kt" -Value @'
import platform.posix.getpid
import platform.windows.GetTickCount
fun main() { println("curator-kotlin-native-probe " + getpid() + " " + GetTickCount()) }
'@ -Encoding ASCII -Force
$rcP=RunKonanc 'plat' $ov "$root\out\plat" @("$root\src2\main.kt") $null
if(Test-Path "$root\out\plat.exe"){
  $i2=Get-PEInfo "$root\out\plat.exe"
  L ("  plat.exe size=" + $i2.size + " machine=" + $i2.machine)
  L ("  imports: " + ($i2.imports -join ', '))
  L ("  ADDED vs plain: " + ((Compare-Object $i1.imports $i2.imports|Where-Object{$_.SideIndicator -eq '=>'}|ForEach-Object{$_.InputObject}) -join ', '))
  $ro="$root\wd\plat.run"
  $rp=Start-Process -FilePath "$root\out\plat.exe" -NoNewWindow -Wait -PassThru -RedirectStandardOutput $ro
  L ("  run exit=" + $rp.ExitCode + " stdout=" + ((Get-Content $ro -Raw) -replace "`r`n",''))
}

L "--- C3: @-response-file expansion table (Windows) ---"
$ap="$root\argprobe"; Remove-Item -Recurse -Force $ap -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path $ap|Out-Null
Set-Content "$ap\inject" -Value '-version' -Encoding ASCII -NoNewline
Set-Content "$ap\@inject" -Value '-version' -Encoding ASCII -NoNewline
$cases=@(
 @{n='@inject';               tok='@inject'},
 @{n='@.\inject';             tok='@.\inject'},
 @{n='@<abs>\inject';         tok="@$ap\inject"},
 @{n='<abs>\@inject';         tok="$ap\@inject"},
 @{n='.\@inject';             tok='.\@inject'},
 @{n='@nonexistent';          tok='@nonexistent'}
)
$sp=$env:PATH; $env:PATH="$root\emptybin"
foreach($c in $cases){
  $o="$root\wd\arg.out"; $e="$root\wd\arg.err"; Remove-Item $o,$e -EA SilentlyContinue
  $p=Start-Process -FilePath $JAVA -ArgumentList (@($JVM)+@('-cp',$JAR,$MAIN,'konanc',$c.tok)) -NoNewWindow -Wait -PassThru -WorkingDirectory $ap -RedirectStandardOutput $o -RedirectStandardError $e
  $ot=((Get-Content $o -Raw -EA SilentlyContinue) -replace "`r?`n",' ').Trim()
  $et=((Get-Content $e -Raw -EA SilentlyContinue) -split "`r?`n"|Where-Object{$_ -ne '' -and $_ -notlike 'WARNING*'}|Select-Object -First 2) -join ' / '
  L ("  token=" + $c.n + "  exit=" + $p.ExitCode + "  stdout=[" + $ot + "]  stderr=[" + $et + "]")
}
$env:PATH=$sp

L "--- C4: launcher control under the manager-owned empty PATH ---"
$sp=$env:PATH; $env:PATH="$root\emptybin"
$o="$root\wd\bat.out"; $e="$root\wd\bat.err"; Remove-Item $o,$e -EA SilentlyContinue
$p=Start-Process -FilePath "$env:SystemRoot\System32\cmd.exe" -ArgumentList @('/c',"`"$b\kotlin-native\bin\konanc.bat`"",'-version') -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
L ("  konanc.bat exit=" + $p.ExitCode)
(Get-Content $o -EA SilentlyContinue|Select-Object -First 4)|ForEach-Object{L ("  O| "+$_)}
(Get-Content $e -EA SilentlyContinue|Select-Object -First 4)|ForEach-Object{L ("  E| "+$_)}
$env:PATH=$sp

L "--- C5: airplaneMode fail-closed on an empty data dir ---"
$emptyOv="$root\ov-empty"; Remove-Item -Recurse -Force $emptyOv -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path $emptyOv|Out-Null
$rcE=RunKonanc 'airplane' $emptyOv "$root\out\ap" @("$root\src\main.kt") $null


L "--- C6: network denial (scoped outbound block on the bundle JDK) ---"
$rule='kn168-deny-java-out'
& netsh.exe advfirewall firewall delete rule name=$rule 2>&1 | Out-Null
$add = & netsh.exe advfirewall firewall add rule name=$rule dir=out action=block program="$JAVA" enable=yes profile=any 2>&1
L ("  add rule: " + ($add -join ' '))
L "  C6a control: empty data dir with airplaneMode=false MUST fail to download"
$emptyOv2="$root\ov-empty2"; Remove-Item -Recurse -Force $emptyOv2 -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path $emptyOv2|Out-Null
$rcNet1=RunKonanc 'netctl' $emptyOv2 "$root\out\netctl" @("$root\src\main.kt") @('-Xoverride-konan-properties=airplaneMode=false')
L "  C6b hydrated overlay with airplaneMode=true MUST exit 0 with no download"
$rcNet2=RunKonanc 'netok' $ov "$root\out\netok" @("$root\src\main.kt") $null
$del = & netsh.exe advfirewall firewall delete rule name=$rule 2>&1
L ("  delete rule: " + ($del -join ' '))
L ("  firewall rule present after cleanup=" + [bool](@(& netsh.exe advfirewall firewall show rule name=$rule 2>&1 | Select-String 'kn168').Count))
L ("  netctl exit=$rcNet1  netok exit=$rcNet2")

L "=== SUITE C done ==="
