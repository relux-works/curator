$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $ov="$root\ov"; $log="$root\suiteA2.log"
Remove-Item $log -EA SilentlyContinue
function L($m){ $s=[string]$m; Add-Content -LiteralPath $log -Value $s; Write-Host $s }
function TreeDigest($path){
  $sha=[Security.Cryptography.SHA256]::Create()
  $files=@(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue)|Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb=New-Object Text.StringBuilder
  foreach($f in $files){
    $rel=$f.FullName.Substring($path.Length).Replace('\','/')
    $fs=[IO.File]::OpenRead($f.FullName)
    try{$h=[BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower()}finally{$fs.Dispose()}
    [void]$sb.Append($rel).Append(' ').Append($h).Append("`n")
  }
  return @{digest=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sb.ToString()))).Replace('-','').ToLower());count=$files.Count}
}
$JAVA="$b\jdk\bin\java.exe"; $JAR="$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$MAIN='org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM=@('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")
function RunKonanc([string]$tag,[string]$dataDir,[string]$outbase,[string[]]$srcs,[string[]]$extra){
  $o="$root\wd\$tag.out"; $e="$root\wd\$tag.err"; Remove-Item $o,$e -EA SilentlyContinue
  $sp=$env:PATH;$st=$env:TEMP;$st2=$env:TMP
  $env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"; $env:KONAN_DATA_DIR=$dataDir
  foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){Remove-Item "Env:\$v" -EA SilentlyContinue}
  $a=@($JVM)+@('-cp',$JAR,$MAIN,'konanc')
  if($extra){$a+=$extra}else{$a+=@('-Xoverride-konan-properties=airplaneMode=true')}
  $a+=@('-produce','program','-target','mingw_x64','-o',$outbase)+$srcs
  L ("ARGV[$tag] " + $JAVA + ' ' + ($a -join ' '))
  $p=Start-Process -FilePath $JAVA -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
  $env:PATH=$sp;$env:TEMP=$st;$env:TMP=$st2
  L ("EXIT[$tag]=" + $p.ExitCode)
  $ot=Get-Content $o -Raw -EA SilentlyContinue; $et=Get-Content $e -Raw -EA SilentlyContinue
  if($ot){($ot -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 10)|ForEach-Object{L ("  O| "+$_)}}
  if($et){($et -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 10)|ForEach-Object{L ("  E| "+$_)}}
  return $p.ExitCode
}
L "=== SUITE A2 (read-only + overlay, corrected principal) ==="
$sid=([Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
L ("running SID=" + $sid + "  name=" + ([Security.Principal.WindowsIdentity]::GetCurrent()).Name)
Remove-Item "$b\konan-data\dependencies\cache\.lock" -Force -EA SilentlyContinue
Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue
$sw=[Diagnostics.Stopwatch]::StartNew()
$ic = & icacls.exe $b /deny "*${sid}:(OI)(CI)(W,D,DC)" /T /C 2>&1 | Select-Object -Last 2
$sw.Stop(); L ("icacls elapsed_s=" + [math]::Round($sw.Elapsed.TotalSeconds,1))
$ic|ForEach-Object{L ("  | "+$_)}
try { [IO.File]::WriteAllText("$b\konan-data\writetest.tmp","x"); L "  WRITE-PROBE: SUCCEEDED (NOT read-only)"; Remove-Item "$b\konan-data\writetest.tmp" -Force -EA SilentlyContinue }
catch { L ("  WRITE-PROBE: denied -> " + $_.Exception.GetType().Name + ": " + $_.Exception.Message) }
L "--- S2: compile with READ-ONLY bundle data dir ---"
$rc2=RunKonanc 's2' "$b\konan-data" "$root\out\s2" @("$root\src\main.kt") $null
L "--- S3: build operation-private overlay, compile ---"
Remove-Item -Recurse -Force $ov -EA SilentlyContinue
New-Item -ItemType Directory -Force -Path "$ov\dependencies","$ov\dependencies\cache"|Out-Null
$mech='junction'
foreach($d in Get-ChildItem "$b\konan-data\dependencies" -Directory -Force){
  if($d.Name -eq 'cache'){ L '  SKIP bundle cache dir (overlay supplies a fresh writable cache)'; continue }
  try { New-Item -ItemType Junction -Path "$ov\dependencies\$($d.Name)" -Target $d.FullName -EA Stop | Out-Null }
  catch { $mech='copy'; Copy-Item -Recurse -Force $d.FullName "$ov\dependencies\$($d.Name)" }
}
Copy-Item "$b\konan-data\dependencies\.extracted" "$ov\dependencies\.extracted" -Force
L ("overlay mechanism=" + $mech)
Get-ChildItem "$ov\dependencies" -Force|ForEach-Object{L ("  ov " + $_.Name + " " + $_.Attributes + " -> " + $_.Target)}
$rc3=RunKonanc 's3' $ov "$root\out\s3" @("$root\src\main.kt") $null
Get-ChildItem "$root\out" -Force|ForEach-Object{L ("  out "+$_.Name+" "+$_.Length)}
L "--- overlay non-junction contents after compile ---"
Get-ChildItem $ov -Recurse -Force -EA SilentlyContinue -Attributes !ReparsePoint | Where-Object { $_.FullName -notmatch '\\dependencies\\(lldb|llvm|msys2|libffi)' } | ForEach-Object{L ("  ovfile "+$_.FullName.Substring($ov.Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length}))}
L "--- staging contents after compile ---"
Get-ChildItem "$root\stg" -Recurse -Force -EA SilentlyContinue | Select-Object -First 30 | ForEach-Object{L ("  stg "+$_.FullName.Substring("$root\stg".Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length}))}
L "--- bundle byte-identity after read-only overlay compile ---"
$D2=TreeDigest $b
L ("D2 digest=" + $D2.digest + " files=" + $D2.count)
L ("BUNDLE_UNCHANGED=" + ($D2.digest -eq '63d96ff7c488e713dedbf7029237cfc6cd030ae4c1caf11c8ba2274395badae3'))
L "=== SUITE A2 done rc2=$rc2 rc3=$rc3 ==="
