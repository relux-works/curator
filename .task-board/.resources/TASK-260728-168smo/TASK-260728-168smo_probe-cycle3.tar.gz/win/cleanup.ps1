$ProgressPreference='SilentlyContinue'
$root='C:\kn168'
$sid=([Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
"lift deny ACE:"
& icacls.exe "$root\b" /remove:d "*$sid" /T /C 2>&1 | Select-Object -Last 1
"free before GB=" + [math]::Round((Get-PSDrive C).Free/1GB,1)
& logman.exe stop kn168 -ets 2>&1 | Out-Null
& netsh.exe advfirewall firewall delete rule name=kn168-deny-java-out 2>&1 | Out-Null
Remove-Item -Recurse -Force $root -ErrorAction SilentlyContinue
"C:\kn168 present after removal=" + (Test-Path $root)
"~/.konan present=" + (Test-Path (Join-Path $env:USERPROFILE '.konan'))
"java on PATH=" + [bool](Get-Command java.exe -EA SilentlyContinue)
$fw = & netsh.exe advfirewall firewall show rule name=kn168-deny-java-out 2>&1
"firewall rule kn168-deny-java-out present=" + [bool](@($fw | Select-String 'kn168-deny').Count)
$tr = & logman.exe query -ets 2>&1
"etw session kn168 present=" + [bool](@($tr | Select-String 'kn168').Count)
"free after GB=" + [math]::Round((Get-PSDrive C).Free/1GB,1)
