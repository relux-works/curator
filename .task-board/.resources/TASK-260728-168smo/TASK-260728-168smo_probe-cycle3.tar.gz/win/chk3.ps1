"now=" + (Get-Date).ToString('HH:mm:ss')
$f = Get-Item C:\kn168\final.log -EA SilentlyContinue
"final.log len=" + $f.Length + " modified=" + $f.LastWriteTime.ToString('HH:mm:ss')
Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='java.exe'" | ForEach-Object { $_.ProcessId.ToString() + " " + $_.Name + " :: " + $_.CommandLine.Substring(0,[Math]::Min(160,$_.CommandLine.Length)) }
