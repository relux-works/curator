#!/bin/bash
cd /Users/iv/Developer/ReluxWorks/curator
echo "### A4"; .temp/TASK-260728-168smo/win/psfile.sh .temp/TASK-260728-168smo/win/suiteA4.ps1
echo "### B";  .temp/TASK-260728-168smo/win/psfile.sh .temp/TASK-260728-168smo/win/suiteB.ps1
echo "### C";  .temp/TASK-260728-168smo/win/psfile.sh .temp/TASK-260728-168smo/win/suiteC.ps1
echo "### CHAIN COMPLETE"
