$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $ov="$root\ov"; $log="$root\final.log"
Remove-Item $log -EA SilentlyContinue
function L($m){ $s=[string]$m; Add-Content -LiteralPath $log -Value $s; Write-Host $s }
function Step($name,$sb){ L ""; L ("##### " + $name); try { & $sb } catch { L ("  !!! EXCEPTION: " + $_.Exception.Message) } }
function TreeDigest($path){
  $sha=[Security.Cryptography.SHA256]::Create()
  $files=@(Get-ChildItem -LiteralPath $path -Recurse -Force -File -ErrorAction SilentlyContinue)|Sort-Object { $_.FullName.Substring($path.Length).Replace('\','/') }
  $sb2=New-Object Text.StringBuilder
  foreach($f in $files){ $rel=$f.FullName.Substring($path.Length).Replace('\','/')
    $fs=[IO.File]::OpenRead($f.FullName); try{$h=[BitConverter]::ToString($sha.ComputeHash($fs)).Replace('-','').ToLower()}finally{$fs.Dispose()}
    [void]$sb2.Append($rel).Append(' ').Append($h).Append("`n") }
  return @{digest=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sb2.ToString()))).Replace('-','').ToLower());count=$files.Count}
}
function Get-PEInfo([string]$path){
  $y=[IO.File]::ReadAllBytes($path)
  $lf=[BitConverter]::ToInt32($y,0x3c); $coff=$lf+4
  $machine=[BitConverter]::ToUInt16($y,$coff); $numSec=[BitConverter]::ToUInt16($y,$coff+2)
  $optSize=[BitConverter]::ToUInt16($y,$coff+16); $opt=$coff+20
  $magic=[BitConverter]::ToUInt16($y,$opt)
  $dd = if($magic -eq 0x20b){$opt+112}else{$opt+96}
  $impRva=[BitConverter]::ToUInt32($y,$dd+8)
  $secs=@(); $so=$opt+$optSize
  for($i=0;$i -lt $numSec;$i++){ $o2=$so+$i*40
    $secs+=[pscustomobject]@{va=[BitConverter]::ToUInt32($y,$o2+12);vs=[BitConverter]::ToUInt32($y,$o2+8);raw=[BitConverter]::ToUInt32($y,$o2+20);rs=[BitConverter]::ToUInt32($y,$o2+16)} }
  $names=@()
  if($impRva -ne 0){
    $off=-1; foreach($s in $secs){ $sz=[Math]::Max($s.vs,$s.rs); if($impRva -ge $s.va -and $impRva -lt ($s.va+$sz)){ $off=$s.raw+($impRva-$s.va); break } }
    if($off -ge 0){ for($k=0;$k -lt 200;$k++){ $d=$off+$k*20
        $nameRva=[BitConverter]::ToUInt32($y,$d+12); $ilt=[BitConverter]::ToUInt32($y,$d)
        if($nameRva -eq 0 -and $ilt -eq 0){break}
        $no=-1; foreach($s in $secs){ $sz=[Math]::Max($s.vs,$s.rs); if($nameRva -ge $s.va -and $nameRva -lt ($s.va+$sz)){ $no=$s.raw+($nameRva-$s.va); break } }
        if($no -lt 0){break}
        $e2=$no; while($y[$e2] -ne 0){$e2++}
        $names+=[Text.Encoding]::ASCII.GetString($y,$no,$e2-$no) } } }
  return @{machine=('0x'+$machine.ToString('x4'));magic=('0x'+$magic.ToString('x3'));imports=@($names|Sort-Object -Unique);size=$y.Length}
}
Add-Type -Namespace N2 -Name W -MemberDefinition @'
[DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
public static extern uint QueryDosDevice(string lpDeviceName, System.Text.StringBuilder lpTargetPath, uint ucchMax);
'@
$DEV=@{}; foreach($d in [IO.DriveInfo]::GetDrives()){ $lt=$d.Name.TrimEnd('\'); $sb3=New-Object Text.StringBuilder 1024; if([N2.W]::QueryDosDevice($lt,$sb3,1024) -gt 0){ $DEV[$sb3.ToString()]=$lt } }
function Resolve-NtPath($p){ foreach($k in $DEV.Keys){ if($p.StartsWith($k+'\')){ return $DEV[$k]+$p.Substring($k.Length) } } return $p }

$JAVA="$b\jdk\bin\java.exe"; $JAR="$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$MAIN='org.jetbrains.kotlin.cli.utilities.MainKt'
$JVM=@('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")
$script:LASTRC=$null
function RunKonanc([string]$tag,[string]$dataDir,[string]$outbase,[string[]]$srcs,[string[]]$extra){
  $o="$root\wd\$tag.out"; $e="$root\wd\$tag.err"; Remove-Item $o,$e -Force -EA SilentlyContinue
  $sp=$env:PATH;$st=$env:TEMP;$st2=$env:TMP
  $env:PATH="$root\emptybin"; $env:TEMP="$root\stg"; $env:TMP="$root\stg"; $env:KONAN_DATA_DIR=$dataDir
  foreach($v in 'KONAN_USE_INTERNAL_SERVER','JDK_JAVA_OPTIONS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','CLASSPATH','JAVA_HOME','JAVACMD','JAVA_OPTS','KOTLIN_HOME','KOTLIN_COMPILER','KOTLIN_TOOL','KOTLIN_RUNNER','LIBCLANG_DISABLE_CRASH_RECOVERY'){Remove-Item "Env:\$v" -EA SilentlyContinue}
  $a=@($JVM)+@('-cp',$JAR,$MAIN,'konanc'); if($extra){$a+=$extra}else{$a+=@('-Xoverride-konan-properties=airplaneMode=true')}
  $a+=@('-produce','program','-target','mingw_x64','-o',$outbase)+$srcs
  L ("ARGV[$tag] " + $JAVA + ' ' + ($a -join ' '))
  $rc=$null
  try { $p=Start-Process -FilePath $JAVA -ArgumentList $a -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e -ErrorAction Stop; $rc=$p.ExitCode } catch { L ("  START-EXCEPTION: " + $_.Exception.Message) }
  $env:PATH=$sp;$env:TEMP=$st;$env:TMP=$st2
  $ot=Get-Content $o -Raw -EA SilentlyContinue; $et=Get-Content $e -Raw -EA SilentlyContinue
  L ("EXIT[$tag]=" + $rc + "  dependency_download_lines=" + (@([regex]::Matches(([string]$ot+[string]$et),'Downloading dependency')).Count))
  if($ot){($ot -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 5)|ForEach-Object{L ("  O| "+$_)}}
  if($et){($et -split "`r?`n"|Where-Object{$_ -ne ''}|Select-Object -First 5)|ForEach-Object{L ("  E| "+$_)}}
  $script:LASTRC=$rc
}
$sid=([Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
L "=== FINAL MEASUREMENT RUN ==="
L ("host=" + (Get-CimInstance Win32_OperatingSystem).Version + " arch=" + $env:PROCESSOR_ARCHITECTURE + " sid=" + $sid)
New-Item -ItemType Directory -Force -Path "$root\wd","$root\stg","$root\emptybin","$root\out","$root\src2","$root\trace" | Out-Null

Step 'R1 lift deny + restore dependencies/.extracted' {
  $o=& icacls.exe $b /remove:d "*$sid" /T /C 2>&1; L ("  icacls remove -> " + ($o | Select-Object -Last 1))
  $names=@('lldb-2-windows','msys2-mingw-w64-x86_64-2','llvm-21-x86_64-windows-essentials-150','libffi-3.3-windows-x64-1')
  [IO.File]::WriteAllText("$b\konan-data\dependencies\.extracted", (($names -join "`n") + "`n"))
  L ("  .extracted bytes=" + (Get-Item "$b\konan-data\dependencies\.extracted").Length)
  Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue
  Remove-Item -Recurse -Force "$root\out" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\out"|Out-Null
  RunKonanc 'r1' "$b\konan-data" "$root\out\r1" @("$root\src\main.kt") $null
  Remove-Item -Recurse -Force "$b\konan-data\dependencies\cache" -EA SilentlyContinue
  $d=TreeDigest $b; L ("  D0 digest=" + $d.digest + " files=" + $d.count)
  L ("  D0_MATCHES_ORIGINAL=" + ($d.digest -eq '63d96ff7c488e713dedbf7029237cfc6cd030ae4c1caf11c8ba2274395badae3'))
}
Step 'R2 re-apply write deny' {
  $o=& icacls.exe $b /deny "*${sid}:(OI)(CI)(DE,DC,WD,AD,WEA,WA)" /T /C 2>&1; L ("  icacls deny -> " + ($o | Select-Object -Last 1))
  try { $p=Start-Process -FilePath $JAVA -ArgumentList '-version' -NoNewWindow -Wait -PassThru -RedirectStandardError "$root\wd\jv.err" -ErrorAction Stop; L ("  EXEC-PROBE exit=" + $p.ExitCode) } catch { L ("  EXEC-PROBE FAILED " + $_.Exception.Message) }
  try { [IO.File]::WriteAllText("$b\konan-data\wt.tmp","x"); L "  WRITE-PROBE SUCCEEDED (not read-only)"; Remove-Item "$b\konan-data\wt.tmp" -Force -EA SilentlyContinue } catch { L ("  WRITE-PROBE denied") }
  try { [IO.File]::AppendAllText("$b\konan-data\dependencies\.extracted","x"); L "  APPEND-PROBE SUCCEEDED (not read-only)" } catch { L ("  APPEND-PROBE denied") }
  L ("  .extracted bytes still=" + (Get-Item "$b\konan-data\dependencies\.extracted").Length)
}
Step 'R3 overlay + ETW-traced compile' {
  Remove-Item -Recurse -Force $ov -EA SilentlyContinue
  New-Item -ItemType Directory -Force -Path "$ov\dependencies","$ov\dependencies\cache"|Out-Null
  $mech='junction'
  foreach($d in Get-ChildItem "$b\konan-data\dependencies" -Directory -Force){ if($d.Name -eq 'cache'){continue}
    try { New-Item -ItemType Junction -Path "$ov\dependencies\$($d.Name)" -Target $d.FullName -EA Stop|Out-Null } catch { $mech='copy'; Copy-Item -Recurse -Force $d.FullName "$ov\dependencies\$($d.Name)" } }
  Copy-Item "$b\konan-data\dependencies\.extracted" "$ov\dependencies\.extracted" -Force
  L ("  overlay mechanism=" + $mech + " overlay .extracted bytes=" + (Get-Item "$ov\dependencies\.extracted").Length)
  Remove-Item -Recurse -Force "$root\stg" -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path "$root\stg"|Out-Null
  & logman.exe stop kn168 -ets 2>&1|Out-Null
  Remove-Item "$root\trace\f.etl","$root\trace\f.xml" -Force -EA SilentlyContinue
  & logman.exe create trace kn168 -p Microsoft-Windows-Kernel-Process 0x10 -o "$root\trace\f.etl" -ets -bs 128 -nb 64 256 2>&1|Out-Null
  RunKonanc 'f1' $ov "$root\out\f1" @("$root\src\main.kt") $null
  & "$env:SystemRoot\System32\where.exe" where.exe | Out-Null
  & logman.exe stop kn168 -ets 2>&1|Out-Null
  & tracerpt.exe "$root\trace\f.etl" -o "$root\trace\f.xml" -of XML -y 2>&1|Out-Null
  $x=[xml](Get-Content "$root\trace\f.xml" -Raw)
  $starts=@($x.Events.Event|Where-Object{$_.System.Provider.Name -eq 'Microsoft-Windows-Kernel-Process' -and $_.System.EventID -eq '1'})
  L ("  ProcessStart events in window=" + $starts.Count)
  $rows=@(); foreach($ev in $starts){ $dd=@{}; foreach($n in $ev.EventData.Data){ $dd[$n.Name]=([string]$n.'#text').Trim() }
    $rows+=[pscustomobject]@{pid=[int]$dd['ProcessID'];ppid=[int]$dd['ParentProcessID'];image=(Resolve-NtPath $dd['ImageName'])} }
  $set=New-Object 'System.Collections.Generic.HashSet[int]'; [void]$set.Add($PID)
  for($i=0;$i -lt 8;$i++){ foreach($r in $rows){ if($set.Contains($r.ppid)){[void]$set.Add($r.pid)} } }
  L "  -- every ProcessStart in the window, resolved image path, classified --"
  foreach($im in @($rows|Select-Object -ExpandProperty image -Unique|Sort-Object)){
    $cls = if($im.StartsWith($b+'\',[StringComparison]::OrdinalIgnoreCase)){'IN-BUNDLE'} elseif($im.StartsWith($ov+'\',[StringComparison]::OrdinalIgnoreCase)){'IN-OVERLAY'} else {'OUTSIDE'}
    $n=@($rows|Where-Object{$_.image -eq $im}).Count
    L ("    [$cls] x$n " + $im) }
  $javaPids=@($rows|Where-Object{$_.image -eq $JAVA}|Select-Object -ExpandProperty pid)
  $below=@(); $q=New-Object 'System.Collections.Generic.HashSet[int]'; foreach($p2 in $javaPids){[void]$q.Add($p2)}
  for($i=0;$i -lt 8;$i++){ foreach($r in $rows){ if($q.Contains($r.ppid)){ [void]$q.Add($r.pid); $below+=$r } } }
  L ("  children spawned BELOW the compiler JVM=" + @($below|Select-Object -ExpandProperty image -Unique).Count)
  @($below|Select-Object -ExpandProperty image -Unique|Sort-Object)|ForEach-Object{L ("    child " + $_)}
  L ("  TRACER-CONTROL where.exe present in trace=" + [bool](@($rows|Where-Object{$_.image -like '*\where.exe'}).Count))
}
Step 'R4 artifact class, run, imports' {
  Get-ChildItem "$root\out" -Force -Recurse|ForEach-Object{L ("  out "+$_.FullName.Substring("$root\out".Length)+" "+$_.Length)}
  L "  -- staging after compile --"
  Get-ChildItem "$root\stg" -Recurse -Force -EA SilentlyContinue|Select-Object -First 30|ForEach-Object{L ("    stg "+$_.FullName.Substring("$root\stg".Length)+" "+$(if($_.PSIsContainer){'<DIR>'}else{$_.Length}))}
  $art="$root\out\f1.exe"
  if(Test-Path $art){ $i=Get-PEInfo $art
    L ("  f1.exe size=" + $i.size + " magic=" + $i.magic + " machine=" + $i.machine + " (0x8664=AMD64)")
    L ("  imports: " + ($i.imports -join ', '))
    $ro="$root\wd\f1.run"; $rp=Start-Process -FilePath $art -NoNewWindow -Wait -PassThru -RedirectStandardOutput $ro
    L ("  run exit=" + $rp.ExitCode + " stdout=" + ((Get-Content $ro -Raw) -replace "`r`n",'')) }
  else { L "  ARTIFACT MISSING" }
}
Step 'R5 distribution platform-library sample' {
  [IO.File]::WriteAllText("$root\src2\main.kt", "import platform.posix.getpid`nimport platform.windows.GetTickCount`nfun main() { println(`"curator-kotlin-native-probe `" + getpid() + `" `" + GetTickCount()) }`n")
  RunKonanc 'plat' $ov "$root\out\plat" @("$root\src2\main.kt") $null
  if(Test-Path "$root\out\plat.exe"){
    $i1=Get-PEInfo "$root\out\f1.exe"; $i2=Get-PEInfo "$root\out\plat.exe"
    L ("  plat.exe size=" + $i2.size + " machine=" + $i2.machine)
    L ("  imports: " + ($i2.imports -join ', '))
    $add=@(Compare-Object $i1.imports $i2.imports|Where-Object{$_.SideIndicator -eq '=>'}|ForEach-Object{$_.InputObject})
    L ("  ADDED vs plain program: " + $(if($add.Count){$add -join ', '}else{'(none)'}))
    $ro="$root\wd\plat.run"; $rp=Start-Process -FilePath "$root\out\plat.exe" -NoNewWindow -Wait -PassThru -RedirectStandardOutput $ro
    L ("  run exit=" + $rp.ExitCode + " stdout=" + ((Get-Content $ro -Raw) -replace "`r`n","")) }
}
Step 'R6 @-response-file expansion table' {
  $ap="$root\argprobe"; Remove-Item -Recurse -Force $ap -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path $ap|Out-Null
  [IO.File]::WriteAllText("$ap\inject","-version"); [IO.File]::WriteAllText("$ap\@inject","-version")
  $cases=@(@{n='@inject';t='@inject'},@{n='@.\inject';t='@.\inject'},@{n='@<abs>\inject';t="@$ap\inject"},@{n='<abs>\@inject';t="$ap\@inject"},@{n='.\@inject';t='.\@inject'},@{n='@nonexistent';t='@nonexistent'})
  $sp=$env:PATH; $env:PATH="$root\emptybin"; $k=0
  foreach($c in $cases){ $k++
    $o="$root\wd\arg$k.out"; $e="$root\wd\arg$k.err"
    $p=Start-Process -FilePath $JAVA -ArgumentList (@($JVM)+@('-cp',$JAR,$MAIN,'konanc',$c.t)) -NoNewWindow -Wait -PassThru -WorkingDirectory $ap -RedirectStandardOutput $o -RedirectStandardError $e
    $ob=[IO.File]::ReadAllBytes($o)
    $ot=(([Text.Encoding]::ASCII.GetString($ob)) -replace "`r?`n",' ').Trim()
    $et=(((Get-Content $e -EA SilentlyContinue)|Where-Object{$_ -ne '' -and $_ -notlike 'WARNING*' -and $_ -notlike 'info:*'})|Select-Object -First 1)
    L ("  token=" + $c.n + " | exit=" + $p.ExitCode + " | stdout_bytes=" + $ob.Length + " | stdout=[" + $ot + "] | stderr=[" + $et + "]") }
  $env:PATH=$sp
}
Step 'R7 launcher control under the manager-owned empty PATH' {
  $sp=$env:PATH; $env:PATH="$root\emptybin"
  $o="$root\wd\bat.out"; $e="$root\wd\bat.err"
  $p=Start-Process -FilePath "$env:SystemRoot\System32\cmd.exe" -ArgumentList @('/c',"`"$b\kotlin-native\bin\konanc.bat`"",'-version') -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
  L ("  konanc.bat exit=" + $p.ExitCode + " (9009 = command not found)")
  L ("  stdout_bytes=" + (Get-Item $o).Length + " stderr_bytes=" + (Get-Item $e).Length)
  $env:PATH=$sp
}
Step 'R8 airplaneMode fail-closed on an empty data dir' {
  $eo="$root\ov-empty"; Remove-Item -Recurse -Force $eo -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path $eo|Out-Null
  RunKonanc 'airplane' $eo "$root\out\ap" @("$root\src\main.kt") $null
  L ("  files created in the empty data dir=" + @(Get-ChildItem $eo -Recurse -Force -EA SilentlyContinue).Count)
}
Step 'R9 network denial' {
  $rule='kn168-deny-java-out'
  & netsh.exe advfirewall firewall delete rule name=$rule 2>&1|Out-Null
  $a=& netsh.exe advfirewall firewall add rule name=$rule dir=out action=block program="$JAVA" enable=yes profile=any 2>&1
  L ("  add rule -> " + ($a -join ' ').Trim())
  $eo="$root\ov-empty2"; Remove-Item -Recurse -Force $eo -EA SilentlyContinue; New-Item -ItemType Directory -Force -Path $eo|Out-Null
  L "  control: empty data dir + airplaneMode=false, network denied -> must not obtain any dependency"
  RunKonanc 'netctl' $eo "$root\out\netctl" @("$root\src\main.kt") @('-Xoverride-konan-properties=airplaneMode=false')
  L "  subject: hydrated overlay + airplaneMode=true, network denied -> must exit 0 with no download"
  RunKonanc 'netok' $ov "$root\out\netok" @("$root\src\main.kt") $null
  $d=& netsh.exe advfirewall firewall delete rule name=$rule 2>&1
  L ("  delete rule -> " + ($d -join ' ').Trim())
  $chk=& netsh.exe advfirewall firewall show rule name=$rule 2>&1
  L ("  rule present after cleanup=" + [bool](@($chk|Select-String 'kn168-deny').Count))
}
Step 'R10 final bundle identity' {
  $d=TreeDigest $b
  L ("  D_final digest=" + $d.digest + " files=" + $d.count)
  L ("  BUNDLE_UNCHANGED_ACROSS_ALL_OPERATIONS=" + ($d.digest -eq '63d96ff7c488e713dedbf7029237cfc6cd030ae4c1caf11c8ba2274395badae3'))
}
L ""
L "=== FINAL MEASUREMENT RUN COMPLETE ==="
