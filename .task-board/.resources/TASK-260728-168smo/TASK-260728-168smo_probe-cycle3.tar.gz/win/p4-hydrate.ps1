$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'; $b="$root\b"; $log="$root\p4-hydrate.log"
function L($m){ $m | Tee-Object -FilePath $log -Append }
L "== P4 hydrate =="
New-Item -ItemType Directory -Force -Path "$root\src","$root\out","$root\wd" | Out-Null
Set-Content -Path "$root\src\main.kt" -Value 'fun main() { println("curator-kotlin-native-probe") }' -NoNewline -Encoding ASCII

$java = "$b\jdk\bin\java.exe"
$jar  = "$b\kotlin-native\konan\lib\kotlin-native-compiler-embeddable.jar"
$main = 'org.jetbrains.kotlin.cli.utilities.MainKt'
$jvm  = @('-ea','-Xmx3G','-XX:TieredStopAtLevel=1','-Dfile.encoding=UTF-8','-Duser.language=en','-Duser.country=US',"-Dkonan.home=$b\kotlin-native")

$env:KONAN_DATA_DIR = "$b\konan-data"
L ("KONAN_DATA_DIR=" + $env:KONAN_DATA_DIR)
$o="$root\wd\h.out"; $e="$root\wd\h.err"
$sw=[Diagnostics.Stopwatch]::StartNew()
$p = Start-Process -FilePath $java -ArgumentList (@($jvm)+@('-cp',$jar,$main,'konanc','-produce','program','-target','mingw_x64','-o',"$root\out\hyd","$root\src\main.kt")) -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
$sw.Stop()
L ("exit=" + $p.ExitCode + " elapsed_s=" + [math]::Round($sw.Elapsed.TotalSeconds,1))
L "stdout:"; Get-Content $o -EA SilentlyContinue | ForEach-Object { L ("  | " + $_) }
L "stderr:"; Get-Content $e -EA SilentlyContinue | ForEach-Object { L ("  | " + $_) }
L "-- konan-data contents --"
Get-ChildItem "$b\konan-data" -Force | ForEach-Object { L ("  " + $_.Name) }
L "-- dependencies --"
Get-ChildItem "$b\konan-data\dependencies" -Force -EA SilentlyContinue | ForEach-Object { L ("  " + $_.Name) }
L "-- produced --"
Get-ChildItem "$root\out" -Force -EA SilentlyContinue | ForEach-Object { L ("  " + $_.Name + "  " + $_.Length) }
L "== P4 done =="
