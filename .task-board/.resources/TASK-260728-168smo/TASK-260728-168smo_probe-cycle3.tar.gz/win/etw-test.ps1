$ProgressPreference='SilentlyContinue'
$ErrorActionPreference='Continue'
$root='C:\kn168'
New-Item -ItemType Directory -Force -Path "$root\trace" | Out-Null
& logman.exe stop kn168 -ets 2>&1 | Out-Null
Remove-Item "$root\trace\t.etl","$root\trace\t.xml" -EA SilentlyContinue
"create: " + (& logman.exe create trace kn168 -p Microsoft-Windows-Kernel-Process 0x10 -o "$root\trace\t.etl" -ets -bs 64 -nb 32 128 2>&1 | Out-String)
& cmd.exe /c "echo hello" | Out-Null
& "$root\b\jdk\bin\java.exe" -version 2>&1 | Out-Null
"stop: " + (& logman.exe stop kn168 -ets 2>&1 | Out-String)
"tracerpt: " + (& tracerpt.exe "$root\trace\t.etl" -o "$root\trace\t.xml" -of XML -y 2>&1 | Out-String)
"xml_size=" + (Get-Item "$root\trace\t.xml" -EA SilentlyContinue).Length
$x = [xml](Get-Content "$root\trace\t.xml" -Raw)
"events=" + $x.Events.Event.Count
$x.Events.Event | Select-Object -First 3 | ForEach-Object { $_.OuterXml.Substring(0,[Math]::Min(700,$_.OuterXml.Length)) }
