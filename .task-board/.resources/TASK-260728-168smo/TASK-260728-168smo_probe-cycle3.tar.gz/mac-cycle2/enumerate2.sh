#!/bin/bash
. /Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260728-168smo/kn/vars.sh
export KONAN_DATA_DIR="$KN_BASE/konan-data"
ALLOW_FILE="$KN_BASE/evidence/allowed-externals.txt"
LOG="$KN_BASE/evidence/run8-enumeration.log"
: > "$LOG"
printf '%s\n' /bin/bash /usr/bin/xcrun /usr/bin/xcode-select /usr/libexec/PlistBuddy > "$ALLOW_FILE"
for i in $(seq 1 25); do
  {
    echo '(version 1)'
    echo '(allow default)'
    echo '(deny process-exec*)'
    echo "(allow process-exec* (subpath \"/opt/homebrew/Cellar/openjdk/26.0.1\"))"
    echo "(allow process-exec* (subpath \"$KN_DIST\"))"
    echo "(allow process-exec* (subpath \"$KN_BASE/konan-data\"))"
    while IFS= read -r p; do [ -n "$p" ] && echo "(allow process-exec* (literal \"$p\"))"; done < "$ALLOW_FILE"
  } > "$KN_BASE/sb-iter.sb"
  rm -rf "$KN_BASE/oute"; mkdir -p "$KN_BASE/oute"
  out=$(sandbox-exec -f "$KN_BASE/sb-iter.sb" "$JDK_ROOT/bin/java" -ea -Xmx3G -XX:TieredStopAtLevel=1 \
        -Dfile.encoding=UTF-8 -Dkonan.home="$KN_DIST" -cp "$KN_JAR" "$KN_MAIN" konanc \
        -produce program -target macos_arm64 -o "$KN_BASE/oute/app" "$KN_BASE/src/main.kt" 2>&1)
  rc=$?
  echo "=== iteration $i exit=$rc ===" >> "$LOG"
  echo "$out" | grep -E "Cannot run program|can't exec|Operation not permitted|^error:" | head -4 >> "$LOG"
  if [ $rc -eq 0 ]; then echo "SUCCESS at iteration $i" >> "$LOG"; break; fi
  prog=$(echo "$out" | grep -oE 'Cannot run program "[^"]+"' | head -1 | sed 's/Cannot run program "//; s/"$//')
  [ -z "$prog" ] && prog=$(echo "$out" | grep -oE "can't exec '[^']+'" | head -1 | sed "s/can't exec '//; s/'$//")
  [ -z "$prog" ] && prog=$(echo "$out" | grep -oE "^/bin/bash: /[^:]+: Operation not permitted" | head -1 | sed 's|^/bin/bash: ||; s|: Operation not permitted$||')
  [ -z "$prog" ] && prog=$(echo "$out" | grep -oE "^[a-z]+: (error: )?/[^ :]+: (Operation not permitted|Permission denied)" | head -1 | sed -E 's/^[a-z]+: (error: )?//; s/: (Operation not permitted|Permission denied)$//')
  if [ -z "$prog" ]; then echo "NO-PROGRAM-IN-MESSAGE; stopping" >> "$LOG"; echo "$out" | grep -vE "^WARNING" | head -25 >> "$LOG"; break; fi
  echo "$prog" >> "$ALLOW_FILE"
  echo "allowed: $prog" >> "$LOG"
done
cat "$LOG"
echo "--- final allow list ---"; cat "$ALLOW_FILE"
