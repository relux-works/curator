#!/usr/bin/env python3
from pathlib import Path
import sys


OVERLAY_PATHS = {
    ".github/ci/candidate-suite.sh",
    ".github/ci/excluded-packages.sh",
    ".github/ci/gate-selftest.sh",
    ".github/ci/ledger-consistency.sh",
    ".github/ci/no-broad-suppression.sh",
    ".github/ci/platform-case-gate.sh",
    ".github/ci/platform-cases.tsv",
    ".github/ci/platform-exclusions.tsv",
    ".github/ci/root-artifacts.tsv",
    ".github/ci/skip-classes.tsv",
    ".github/ci/suite-plan.sh",
    ".github/ci/test-gate.sh",
    ".github/ci/toolchain-identity.sh",
    ".github/workflows/ci.yml",
    "Makefile",
    "README.md",
}

PATCH_PATHS = {
    "internal/godriver/builddriver_positive_conformance_test.go",
    "internal/godriver/fingerprint.go",
    "internal/godriver/fingerprint_equivalence_test.go",
    "internal/protocoljson/ccj.go",
    "internal/protocoljson/ccj_test.go",
    "internal/transaction/journal.go",
    "internal/transaction/journal_order_test.go",
}

ADDED_PATHS = {
    "internal/protocoljson/ccj_test.go",
    "internal/transaction/journal_order_test.go",
}


def read_manifest(path: Path) -> dict[str, tuple[str, str]]:
    result: dict[str, tuple[str, str]] = {}
    for line in path.read_text().splitlines():
        kind, digest, entry_path = line.split(None, 2)
        result[entry_path] = (kind, digest)
    return result


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


if len(sys.argv) != 4:
    fail("usage: verify_manifest_delta.py PRE_FULL PRE_PRODUCT POST_FULL")

pre_full = read_manifest(Path(sys.argv[1]))
pre_product = read_manifest(Path(sys.argv[2]))
post_full = read_manifest(Path(sys.argv[3]))
post_product = {
    path: identity for path, identity in post_full.items() if path not in OVERLAY_PATHS
}

if len(pre_full) != 372:
    fail(f"accepted composite entry count is {len(pre_full)}, want 372")
if len(pre_product) != 356:
    fail(f"accepted product entry count is {len(pre_product)}, want 356")
if len(post_full) != 374:
    fail(f"integrated composite entry count is {len(post_full)}, want 374")
if len(post_product) != 358:
    fail(f"integrated product entry count is {len(post_product)}, want 358")

changed_full = {
    path
    for path in pre_full.keys() | post_full.keys()
    if pre_full.get(path) != post_full.get(path)
}
changed_product = {
    path
    for path in pre_product.keys() | post_product.keys()
    if pre_product.get(path) != post_product.get(path)
}

if changed_full != PATCH_PATHS:
    fail(f"full manifest delta is {sorted(changed_full)}, want {sorted(PATCH_PATHS)}")
if changed_product != PATCH_PATHS:
    fail(
        f"product manifest delta is {sorted(changed_product)}, "
        f"want {sorted(PATCH_PATHS)}"
    )

actual_added = post_product.keys() - pre_product.keys()
actual_removed = pre_product.keys() - post_product.keys()
if actual_added != ADDED_PATHS:
    fail(f"added paths are {sorted(actual_added)}, want {sorted(ADDED_PATHS)}")
if actual_removed:
    fail(f"unexpected removed paths: {sorted(actual_removed)}")

changed_overlay = {
    path
    for path in OVERLAY_PATHS
    if pre_full.get(path) != post_full.get(path)
}
if changed_overlay:
    fail(f"CI/quality overlay changed: {sorted(changed_overlay)}")

print("accepted_full_entries=372")
print("accepted_product_entries=356")
print("integrated_full_entries=374")
print("integrated_product_entries=358")
print("changed_paths=7")
print("modified_paths=5")
print("added_paths=2")
print("removed_paths=0")
print("overlay_changed_paths=0")
for path in sorted(PATCH_PATHS):
    disposition = "added" if path in ADDED_PATHS else "modified"
    print(f"{disposition}\t{path}")
