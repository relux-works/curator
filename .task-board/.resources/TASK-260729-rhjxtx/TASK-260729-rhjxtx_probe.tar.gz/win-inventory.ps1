$ErrorActionPreference = 'Continue'
'== host =='
'os_version    :: ' + (Get-CimInstance Win32_OperatingSystem).Version
'os_caption    :: ' + (Get-CimInstance Win32_OperatingSystem).Caption
'architecture  :: ' + $env:PROCESSOR_ARCHITECTURE
'user          :: ' + $env:USERNAME
'== PATH-visible compilers (recorded only; the probe never resolves from PATH) =='
foreach ($t in @('rustc','cargo','rustup','swift','swiftc','xcrun','kotlinc','kotlinc-native','konanc','gradle','java','go')) {
  $c = Get-Command $t -ErrorAction SilentlyContinue
  if ($c) { '{0,-16} :: {1}' -f $t, $c.Source } else { '{0,-16} :: absent' -f $t }
}
'== candidate trusted roots (Test-Path, read-only) =='
$roots = @(
  'C:\Program Files\Rust stable MSVC 1.91',
  "$env:USERPROFILE\.rustup\toolchains",
  "$env:USERPROFILE\.cargo",
  'C:\Program Files\Swift',
  "$env:LOCALAPPDATA\Programs\Swift",
  'C:\Library\Developer\Toolchains',
  "$env:USERPROFILE\.konan",
  'C:\Program Files\Kotlin',
  'C:\kotlinc',
  "$env:USERPROFILE\.sdkman",
  'C:\Program Files\Java',
  'C:\Program Files\Eclipse Adoptium'
)
foreach ($r in $roots) { '{0,-46} :: {1}' -f $r, (Test-Path -LiteralPath $r) }
'== nothing was installed, downloaded, or modified by this inventory =='
