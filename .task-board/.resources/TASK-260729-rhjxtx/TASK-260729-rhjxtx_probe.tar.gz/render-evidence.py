#!/usr/bin/env python3
"""Render toolchain-probe-fixture-v1 documents into a reviewable transcript.

Every argv, environment delta, exit code, output excerpt, fixture digest, and
manager obligation in the JSON is reproduced here in reading order. The renderer
adds nothing: if a claim is not in the fixture, it is not printed.
"""
import json
import sys


def w(s=""):
    print(s)


def render(path, label):
    d = json.load(open(path))
    h = d["host"]
    w("=" * 78)
    w(f"{label}")
    w("=" * 78)
    w(f"fixture_version : {d['fixture_version']}")
    w(f"task            : {d['task']}")
    w(f"host            : {h['operating_system']}/{h['architecture']} "
      f"(goos={h['goos']} goarch={h['goarch']} os_version={h.get('os_version','')})")
    w(f"probe go        : {h['probe_go_version']}")
    s = d["summary"]
    w(f"summary         : {s['total']} cases, {s['matched']} matched, "
      f"{s['divergences']} divergences, {s['not_run']} not run; "
      f"{s['unavailable_toolchains']} toolchains unavailable, "
      f"{s['wrong_backend_toolchains']} wrong backend")
    w()

    for t in d["toolchains"]:
        w("-" * 78)
        w(f"TOOLCHAIN {t['toolchain_id']}  ::  {t['availability']}")
        w("-" * 78)
        if t.get("reason"):
            w(f"  reason          : {t['reason']}")
        if t.get("guidance_id"):
            w(f"  guidance        : {t['guidance_id']}")
        dec = t["declaration"]
        w(f"  declaration     : channel={dec['channel']} root={dec.get('root','') or '(none)'}")
        w(f"                    primary_relpath={dec.get('primary_relpath','')} "
          f"present={dec['primary_present']} path_was_searched={dec['path_was_searched']}")
        for name, key in (("version probe", "version_probe"), ("target probe", "target_probe")):
            r = t.get(key)
            if r:
                w(f"  {name}   : {' '.join(r['argv'])}")
                w(f"                    exit={r['exit_code']}")
                for stream in ("stdout", "stderr"):
                    if r.get(stream):
                        for ln in r[stream].strip().splitlines()[:6]:
                            w(f"                    {stream}| {ln}")
        n = t.get("normalization")
        if n:
            w(f"  normalization   : rule={n['rule_id']} stream={n['stream']}")
            w(f"                    pattern={n['pattern']}")
            if n.get("undetermined"):
                w(f"                    UNDETERMINED: {n['undetermined']}")
            else:
                c = n["canonical"]
                w(f"                    canonical={c['major']}.{c['minor']}.{c['patch']} "
                  f"prerelease={c['prerelease']}")
                w(f"                    native={c.get('native','')!r}")
            w(f"                    verified_against_real_output={n['verified_against_real_output']}")
        nt = t.get("native_target")
        if nt:
            w(f"  native target   : reported={nt['reported']!r} stable_form={nt['stable_form']!r}")
            if nt.get("host_varying_components"):
                w(f"                    host_varying={nt['host_varying_components']}")
            w(f"                    source={nt['source']}")
        for ms in t["metadata_sources"]:
            w(f"  metadata source : {ms['file']}")
            w(f"                    readable_without_execution={ms['readable_without_execution']}")
            if ms.get("reader_command"):
                w(f"                    reader={ms['reader_command']}")
            if ms.get("evidence"):
                w(f"                    evidence: {ms['evidence']}")
            for f in ms["fields"]:
                w(f"                    field {f['name']} -> {f['disposition']} "
                  f"(measured={f['measured']})")
                w(f"                      {f['rationale']}")
        for note in t.get("notes", []) or []:
            w(f"  note            : {note}")
        w()

    w("-" * 78)
    w("CASES")
    w("-" * 78)
    for c in sorted(d["cases"], key=lambda x: x["id"]):
        w()
        w(f"[{c['verdict'].upper()}] {c['id']}")
        w(f"  {c['title']}")
        w(f"  language={c['language']} kind={c['kind']}")
        w(f"  expected={c['expected_gate_class']} observed={c.get('observed_gate_class') or '-'}")
        w(f"  decidable_before_compiler_work={c['decidable_before_compiler_work']} "
          f"(expected {c['expect_decidable_before_compiler_work']})")
        w(f"  upstream_rejects_after_compilation={c['upstream_rejects_after_compilation']}")
        if c.get("not_run_reason"):
            w(f"  NOT RUN: {c['not_run_reason']}")
        o = c["observation"]
        meas = []
        if o["metadata_ran"]:
            meas.append(f"metadata_exit={o['metadata_exit']} "
                        f"extracted={o.get('metadata_extracted_value','')!r}")
        if o["target_print_ran"]:
            meas.append(f"target_print_exit={o['target_print_exit']} "
                        f"std_checked={o['target_std_checked']} std_present={o['target_std_present']}")
        if o["build_ran"]:
            meas.append(f"build_exit={o['build_exit']} "
                        f"started_compilation={o['build_started_compilation']}")
        if o["selector_measured"]:
            meas.append(f"selector shim_exit={o['selector_shim_exit']} "
                        f"root_exit={o['selector_root_exit']} "
                        f"attempted_install={o['selector_shim_attempted_install']}")
        if o.get("backend"):
            meas.append(f"backend={o['backend']!r}")
        for m in meas:
            w(f"  measured: {m}")
        if o.get("build_compilation_evidence"):
            w(f"  compilation evidence line (measured, not inferred):")
            w(f"    {o['build_compilation_evidence']}")
        for f in c.get("fixtures", []) or []:
            w(f"  fixture file: {f['path']}  sha256={f['sha256']}  bytes={f['bytes']}")
        for r in c.get("runs", []) or []:
            w(f"  $ {' '.join(r['argv'])}")
            if r.get("dir"):
                w(f"      dir  : {r['dir']}")
            if r.get("env_delta"):
                w(f"      env  : {' '.join(r['env_delta'])}")
            w(f"      exit : {r['exit_code']}"
              + (f"  (truncated output)" if r.get("truncated") else ""))
            if r.get("error"):
                w(f"      error: {r['error']}")
            for stream in ("stdout", "stderr"):
                if r.get(stream):
                    for ln in r[stream].strip().splitlines()[:12]:
                        w(f"      {stream[3:]}| {ln}")
        if c.get("manager_obligation"):
            w(f"  MANAGER OBLIGATION: {c['manager_obligation']}")
        w(f"  consumers: {', '.join(c['consumers'])}")
    w()

    w("-" * 78)
    w("INSTALLATION GUIDANCE INPUTS (manager-owned; this probe never installs)")
    w("-" * 78)
    for g in d["installation_guidance_inputs"]:
        w(f"  {g['id']}")
        w(f"    toolchain     : {g['toolchain_id']}")
        w(f"    reason        : {g['reason']}")
        w(f"    primary source: {g['primary_source_url']}  ({g['primary_source_owner']})")
        w(f"    operator action: {g['operator_action']}")
        w(f"    auto_install  : {g['auto_install']}")
    w()


if __name__ == "__main__":
    for arg in sys.argv[1:]:
        path, label = arg.split("=", 1)
        render(path, label)
