#!/bin/bash
# Records every command of the rework-cycle-1 macOS and Windows runs with its
# exact argv, exit code, and output. Nothing here installs, downloads, updates,
# or modifies a toolchain on either host.
#
# Usage: run-evidence.sh <macos|windows> <output-log>
set -u

BASE="/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260729-rhjxtx"
PHASE="${1:?phase}"
LOG="${2:?log}"
: >"$LOG"

step() { printf '\n=== [%02d] %s\n' "$1" "$2" >>"$LOG"; }

# run logs the exact argv, then the real exit code of the command itself.
# The command is run directly, not through a pipe, so $? is its own status.
run() {
	{
		printf '$ '
		printf '%q ' "$@"
		printf '\n'
	} >>"$LOG"
	local out rc
	out="$("$@" 2>&1)"
	rc=$?
	if [ -n "$out" ]; then
		printf -- '--- output ---\n%s\n' "$out" >>"$LOG"
	else
		printf -- '--- output --- (empty)\n' >>"$LOG"
	fi
	printf -- '--- exit code: %d\n' "$rc" >>"$LOG"
	return $rc
}

RUST_ROOT="/Users/iv/.rustup/toolchains/1.91.0-aarch64-apple-darwin"
SWIFT_ROOT="/Applications/Xcode_26_5.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain"
RUST_SHIM="/Users/iv/.cargo/bin/rustc"
KOTLINC_JVM="/opt/homebrew/bin/kotlinc"
GRADLE="/opt/homebrew/bin/gradle"

case "$PHASE" in
macos)
	OUT="$BASE/run2-macos"
	rm -rf "$OUT"
	mkdir -p "$OUT/work"
	step 1 "build the probe for the local host"
	run env -C "$BASE/probe" go build -o "$OUT/toolchainboundary" .
	step 2 "record the probe binary digest"
	run shasum -a 256 "$OUT/toolchainboundary"
	step 3 "confirm the supplied roots exist (read-only)"
	run test -x "$RUST_ROOT/bin/rustc"
	run test -x "$SWIFT_ROOT/usr/bin/swiftc"
	run test -x "$RUST_SHIM"
	run test -x "$KOTLINC_JVM"
	run test -x "$GRADLE"
	step 4 "run the probe"
	run "$OUT/toolchainboundary" \
		-rust "$RUST_ROOT" \
		-swift "$SWIFT_ROOT" \
		-rust-shim "$RUST_SHIM" \
		-kotlinc-jvm "$KOTLINC_JVM" \
		-gradle "$GRADLE" \
		-work "$OUT/work" -out "$OUT/fixture-macos.json"
	PROBE_RC=$?
	step 5 "record the fixture digest"
	run shasum -a 256 "$OUT/fixture-macos.json"
	step 6 "confirm the operator Gradle home was not written to by the probe"
	run find "$HOME/.gradle" -newer "$OUT/toolchainboundary" -print -quit
	printf '\n=== probe exit code: %d\n' "$PROBE_RC" >>"$LOG"
	;;

windows)
	OUT="$BASE/run2-windows"
	rm -rf "$OUT"
	mkdir -p "$OUT"
	REMOTE='C:\Users\admin\AppData\Local\Temp\tb-rhjxtx'
	step 1 "cross-compile the probe for the remote host; no toolchain is installed on either side"
	run env -C "$BASE/probe" env GOOS=windows GOARCH=amd64 CGO_ENABLED=0 \
		go build -o "$OUT/toolchainboundary.exe" .
	step 2 "local digest of the artifact that will be transferred"
	run shasum -a 256 "$OUT/toolchainboundary.exe"
	LOCAL_SHA=$(shasum -a 256 "$OUT/toolchainboundary.exe" | awk '{print $1}')
	printf 'local sha256: %s\n' "$LOCAL_SHA" >>"$LOG"
	step 3 "create the remote working directory"
	run ssh -o BatchMode=yes win "cmd /c if not exist \"$REMOTE\" mkdir \"$REMOTE\""
	step 4 "transfer the probe"
	run scp -o BatchMode=yes "$OUT/toolchainboundary.exe" "win:$REMOTE\\toolchainboundary.exe"
	step 5 "verify the transferred digest on the remote host"
	run ssh -o BatchMode=yes win "certutil -hashfile \"$REMOTE\\toolchainboundary.exe\" SHA256"
	step 6 "read-only host inventory; every check is Test-Path or Get-Command, nothing is installed"
	run scp -o BatchMode=yes "$BASE/win-inventory.ps1" "win:$REMOTE\\win-inventory.ps1"
	run ssh -o BatchMode=yes win "powershell -NoProfile -ExecutionPolicy Bypass -File \"$REMOTE\\win-inventory.ps1\""
	step 7 "run the probe with no toolchain roots supplied; absence is the measurement"
	run ssh -o BatchMode=yes win "cd /d \"$REMOTE\" && toolchainboundary.exe -work \"$REMOTE\\work\" -out \"$REMOTE\\fixture-windows.json\""
	step 8 "remote digest of the emitted fixture"
	run ssh -o BatchMode=yes win "certutil -hashfile \"$REMOTE\\fixture-windows.json\" SHA256"
	step 9 "fetch the fixture back; the remote path uses forward slashes because a download path is expanded by the remote cmd.exe, which eats backslashes"
	run scp -o BatchMode=yes "win:${REMOTE//\\//}/fixture-windows.json" "$OUT/fixture-windows.json"
	step 10 "local digest of the fetched fixture; it must equal the remote one"
	run shasum -a 256 "$OUT/fixture-windows.json"
	step 11 "remove everything this run put on the remote host"
	run ssh -o BatchMode=yes win "cmd /c rmdir /s /q \"$REMOTE\""
	step 12 "confirm the remote working directory is gone"
	run ssh -o BatchMode=yes win "cmd /c if exist \"$REMOTE\" (echo STILL-PRESENT) else (echo REMOVED)"
	;;
esac
