package main

import (
	"testing"
)

// The tests below exercise the supplied-root Kotlin/Native branch against the
// synthetic root built by kotlinStubRoot. Read the doc comment there before
// reading these: nothing here is evidence about Kotlin/Native. These verify
// that the probe's parsing, membership, and case construction behave as
// declared, so that when a qualified host does appear the branch runs rather
// than returning "the corpus is not authored".

func kotlinStubEnv(t *testing.T) *probeEnv {
	t.Helper()
	root := kotlinStubRoot(t)
	if root == "" {
		t.Skip("the Kotlin/Native stub root is a POSIX shell script; not built on this platform")
	}
	return &probeEnv{work: t.TempDir(), roots: map[string]string{"kotlin": root}}
}

func TestKotlinSuppliedRootActuallyRunsTheCorpus(t *testing.T) {
	ev, cases := probeKotlin(kotlinStubEnv(t))
	if ev.Availability != Available {
		t.Fatalf("availability = %q, want available (reason: %s)", ev.Availability, ev.Reason)
	}
	if ev.VersionProbe == nil || ev.TargetProbe == nil {
		t.Fatal("a supplied root must produce both a version probe and a target probe")
	}
	ran := 0
	for _, c := range cases {
		if c.Verdict != "not_run" {
			ran++
		}
	}
	// backend-is-not-native and metadata-is-a-program need companions this env
	// does not supply; the three root-dependent cases must all run.
	if ran != 3 {
		for _, c := range cases {
			t.Logf("%-40s %-10s %s", c.ID, c.Verdict, c.NotRunReason)
		}
		t.Fatalf("%d cases ran against a supplied root, want 3", ran)
	}
}

func TestKotlinSuppliedRootNormalizesTheStderrBanner(t *testing.T) {
	ev, _ := probeKotlin(kotlinStubEnv(t))
	if ev.Normalization == nil {
		t.Fatal("a supplied root must produce a normalization record")
	}
	if ev.Normalization.Undetermined != "" {
		t.Fatalf("normalization undetermined: %s", ev.Normalization.Undetermined)
	}
	if got := ev.Normalization.Canonical.String(); got != "2.1.0" {
		t.Fatalf("canonical = %q, want 2.1.0", got)
	}
	if ev.Normalization.Stream != StreamStderr {
		t.Fatalf("stream = %q, want stderr", ev.Normalization.Stream)
	}
	// The rule is carried as UNVERIFIED and must stay that way: a stub is not
	// a real distribution.
	if ev.Normalization.Verified {
		t.Fatal("the Kotlin/Native normalization rule must not report itself verified against real output")
	}
}

func TestKotlinSuppliedRootReportsTheDefaultTarget(t *testing.T) {
	ev, _ := probeKotlin(kotlinStubEnv(t))
	if ev.NativeTarget == nil {
		t.Fatal("a -list-targets run naming a (default) entry must yield a native target")
	}
	if ev.NativeTarget.Reported != "macos_arm64" || ev.NativeTarget.StableForm != "macos_arm64" {
		t.Fatalf("native target = %+v", *ev.NativeTarget)
	}
}

func TestKotlinTargetCasesUseMeasuredMembershipNotAssumption(t *testing.T) {
	_, cases := probeKotlin(kotlinStubEnv(t))
	byID := map[string]Case{}
	for _, c := range cases {
		byID[c.ID] = c
	}
	unknown := byID["kotlin.negative.target-unknown"]
	if unknown.Observed != GateTargetRepresentability {
		t.Fatalf("unknown target observed %q, want target_representability", unknown.Observed)
	}
	unlisted := byID["kotlin.negative.target-not-listed"]
	if unlisted.Observed != GateTargetHost {
		t.Fatalf("unlisted target observed %q, want target_host", unlisted.Observed)
	}
	if unlisted.Observation.TargetStdPresent {
		t.Fatal("the unlisted target must not be reported as served by the distribution")
	}
	positive := byID["kotlin.positive.version-and-target"]
	if positive.Observed != GateNone || positive.Verdict != "match" {
		t.Fatalf("positive case: observed %q verdict %q", positive.Observed, positive.Verdict)
	}
}

// A distribution whose -list-targets output the parser does not recognise must
// produce not_run records, never a plausible-looking pass.
func TestKotlinTargetListRefusesToGuess(t *testing.T) {
	targets, def := kotlinTargetList("Kotlin/Native compiler\nAvailable targets are listed below.\n")
	if len(targets) != 0 || def != "" {
		t.Fatalf("prose was parsed as targets: %v / %q", targets, def)
	}
	targets, def = kotlinTargetList("macos_arm64: (default)\nlinux_x64:\nnot-a-target\nMACOS_ARM64:\n")
	if def != "macos_arm64" {
		t.Fatalf("default = %q", def)
	}
	if len(targets) != 2 || targets[0] != "linux_x64" || targets[1] != "macos_arm64" {
		t.Fatalf("targets = %v, want the two konan-shaped names only", targets)
	}
}

func TestKotlinWrongBackendRootIsNotAvailable(t *testing.T) {
	env := kotlinStubEnv(t)
	// Rewrite the stub to answer as the JVM front end.
	writeStubBanner(t, env.roots["kotlin"], "info: kotlinc-jvm 2.4.10 (JRE 26.0.1)")
	ev, cases := probeKotlin(env)
	if ev.Availability != WrongBackend {
		t.Fatalf("availability = %q, want wrong_backend", ev.Availability)
	}
	for _, c := range cases {
		if c.Verdict != "not_run" {
			t.Fatalf("case %s ran against a wrong-backend root", c.ID)
		}
	}
}

// The Kotlin metadata boundary is the finding, so it must be stated as evidence
// rather than left as an undecided placeholder.
func TestKotlinMetadataBoundaryIsRecordedAsAnExplicitAbsence(t *testing.T) {
	ev, _ := probeKotlin(kotlinStubEnv(t))
	if len(ev.MetadataSources) == 0 {
		t.Fatal("no metadata sources recorded")
	}
	first := ev.MetadataSources[0]
	if first.ReadableWithoutExecution {
		t.Fatal("no Kotlin metadata surface has been measured as readable without execution")
	}
	if first.Evidence == "" || len(first.Fields) == 0 {
		t.Fatal("the metadata boundary must carry evidence and a field disposition")
	}
	if first.Fields[0].Disposition != "forbidden" || first.Fields[0].Measured {
		t.Fatalf("boundary field = %+v; it must be forbidden and unmeasured", first.Fields[0])
	}
}
