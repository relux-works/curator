package main

import "fmt"

// caseSpec declares one case exactly once.
//
// Before this table existed, a case's identity lived in two places: a stub list
// used to emit not_run records on a host without the toolchain, and the
// executed builder that measured it. The two drifted —
// swift.negative.selector-swift-version-file was declared package_selector in
// the stub list and none in the builder, so the same case ID carried two
// different expected classes depending on which host produced the fixture.
//
// An expected classification is part of the case contract. It cannot vary with
// the host that happened to run the probe, because the whole point of the
// expectation is that the classifier can disagree with it. This table is
// therefore the single source, and finish() re-applies it to every case it
// emits, so an executed case physically cannot carry a different expectation
// from its not_run twin.
type caseSpec struct {
	ID       string
	Language string
	Kind     string // positive | negative
	Title    string
	Expected GateClass
	// ExpectEarly is the contract's claim that a manager holding only
	// manager-owned data plus the cheap metadata command could reject the case
	// before starting a compiler.
	ExpectEarly bool
}

// caseTable is the complete corpus. Order is not significant; the fixture sorts
// by ID.
func caseTable() []caseSpec {
	return []caseSpec{
		// Rust.
		{"rust.positive.msrv-below-host", "rust", "positive",
			"valid Cargo.toml whose rust-version is below the resolved toolchain", GateNone, true},
		{"rust.negative.msrv-future", "rust", "negative",
			"Cargo.toml rust-version above the resolved toolchain", GateHostVersion, true},
		{"rust.negative.msrv-malformed", "rust", "negative",
			"Cargo.toml rust-version that is not a version", GateRepresentability, true},
		{"rust.negative.target-unknown", "rust", "negative",
			"target triple the compiler does not know", GateTargetRepresentability, true},
		{"rust.negative.target-std-absent", "rust", "negative",
			"known target triple whose standard library is not in the trusted tree", GateTargetHost, true},
		{"rust.negative.selector-toolchain-path", "rust", "negative",
			"rust-toolchain.toml path selects the compiler through the shim", GatePackageSelector, true},
		{"rust.negative.selector-toolchain-nightly", "rust", "negative",
			"rust-toolchain.toml channel makes the shim attempt an install", GatePackageSelector, true},

		// Swift.
		{"swift.positive.tools-version-below-host", "swift", "positive",
			"Package.swift tools version below the resolved toolchain", GateNone, true},
		{"swift.negative.tools-version-future", "swift", "negative",
			"Package.swift tools version above the resolved toolchain", GateHostVersion, true},
		{"swift.negative.tools-version-malformed", "swift", "negative",
			"Package.swift tools version that is not a version", GateRepresentability, true},
		{"swift.negative.manifest-is-a-program", "swift", "negative",
			"reading the manifest body executes package-authored code", GatePackageSelector, true},
		{"swift.negative.target-unknown", "swift", "negative",
			"target triple the compiler does not know", GateTargetRepresentability, true},
		{"swift.negative.target-stdlib-absent", "swift", "negative",
			"known target triple whose standard library this toolchain cannot load", GateTargetHost, true},
		// The expected class is none on purpose, and that is the measurement:
		// .swift-version is honored by the swiftly version manager, not by a
		// directly resolved toolchain, so a negative control that asserts the
		// selector does NOT fire is exactly what admits the field as `compared`
		// rather than `forbidden`. A control whose expected outcome is "no
		// effect" is still a negative control.
		{"swift.negative.selector-swift-version-file", "swift", "negative",
			".swift-version does not redirect a directly resolved toolchain", GateNone, true},

		// Kotlin/Native.
		{"kotlin.negative.backend-is-not-native", "kotlin", "negative",
			"a Kotlin compiler on the host is a JVM front end, not Kotlin/Native", GateBackendIdentity, true},
		{"kotlin.negative.metadata-is-a-program", "kotlin", "negative",
			"reading Kotlin project metadata compiles package-authored code as a program", GatePackageSelector, true},
		{"kotlin.positive.version-and-target", "kotlin", "positive",
			"Kotlin/Native version normalizes and the host target is one the distribution serves", GateNone, true},
		{"kotlin.negative.target-unknown", "kotlin", "negative",
			"target the Kotlin/Native compiler does not know", GateTargetRepresentability, true},
		{"kotlin.negative.target-not-listed", "kotlin", "negative",
			"legal Kotlin/Native target this distribution does not serve", GateTargetHost, true},
	}
}

var caseIndex = func() map[string]caseSpec {
	m := make(map[string]caseSpec, len(caseTable()))
	for _, s := range caseTable() {
		if _, dup := m[s.ID]; dup {
			panic("duplicate case ID in caseTable: " + s.ID)
		}
		m[s.ID] = s
	}
	return m
}()

// spec returns the declaration for an ID. An unknown ID is a programming error
// in this probe, not a measurement outcome, so it stops the run rather than
// producing an unclassifiable record.
func spec(id string) caseSpec {
	s, ok := caseIndex[id]
	if !ok {
		panic(fmt.Sprintf("case %q is not declared in caseTable", id))
	}
	return s
}

func specsFor(lang string) []caseSpec {
	var out []caseSpec
	for _, s := range caseTable() {
		if s.Language == lang {
			out = append(out, s)
		}
	}
	return out
}

// newCase builds a case pre-filled from its declaration. Callers supply
// measurements only; they never restate an expectation.
func newCase(id string) Case {
	s := spec(id)
	return Case{
		ID: s.ID, Language: s.Language, Kind: s.Kind, Title: s.Title,
		Expected: s.Expected, ExpectDecidableBeforeCompilerWork: s.ExpectEarly,
		Consumers: consumersFor(s.Language),
	}
}

// notRunLanguage turns the declared corpus for one language into honest not_run
// records. A case whose toolchain is absent is never a pass and never a
// divergence.
func notRunLanguage(lang, reason string) []Case {
	specs := specsFor(lang)
	out := make([]Case, 0, len(specs))
	for _, s := range specs {
		c := newCase(s.ID)
		c.Verdict = "not_run"
		c.NotRunReason = reason
		out = append(out, c)
	}
	return out
}

// notRunCase is the single-case form, used when one case of a language cannot
// run for a reason that does not apply to the rest.
func notRunCase(id, reason string) Case {
	c := newCase(id)
	c.Verdict = "not_run"
	c.NotRunReason = reason
	return c
}
