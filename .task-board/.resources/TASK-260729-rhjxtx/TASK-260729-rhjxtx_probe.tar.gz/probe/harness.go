package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"
)

// FixtureVersion names the machine-readable evidence format this program
// emits. Consumers pin it.
const FixtureVersion = "toolchain-probe-fixture-v1"

// commandTimeout bounds every child process. A probe that can hang is not
// reproducible.
const commandTimeout = 8 * time.Minute

// excerptBytes bounds recorded output. Full logs are the run transcript; the
// fixture carries bounded, diffable excerpts.
const excerptBytes = 1200

// Run is one recorded child process: the exact argv, the environment deltas
// that were applied, the exit code, and bounded output.
type Run struct {
	Argv     []string `json:"argv"`
	Dir      string   `json:"dir,omitempty"`
	EnvDelta []string `json:"env_delta,omitempty"`
	ExitCode int      `json:"exit_code"`
	Stdout   string   `json:"stdout"`
	Stderr   string   `json:"stderr"`
	// Truncated records that the excerpt is shorter than the real output.
	Truncated bool `json:"truncated,omitempty"`
	// Error is set only when the process could not be started or timed out;
	// a non-zero exit is not an error.
	Error string `json:"error,omitempty"`

	// fullStdout and fullStderr hold the untruncated output. They are
	// unexported so they never reach the fixture, and they exist because a
	// classifier that parses the bounded excerpt silently loses any value
	// that falls past the excerpt boundary — which is exactly what happened
	// to cargo's rust_version on the first run of this probe.
	fullStdout string
	fullStderr string
}

func excerpt(b []byte) (string, bool) {
	s := strings.ReplaceAll(string(b), "\r\n", "\n")
	if len(s) <= excerptBytes {
		return s, false
	}
	return s[:excerptBytes], true
}

// exec runs one child process with an operation-private, minimal environment.
//
// The environment is built rather than inherited. Inheriting it would let the
// probing shell decide which compiler answers, which is the exact confusion the
// selector cases exist to measure.
func execRun(dir string, envDelta []string, argv ...string) Run {
	r := Run{Argv: append([]string(nil), argv...), Dir: dir, EnvDelta: append([]string(nil), envDelta...)}
	ctx, cancel := context.WithTimeout(context.Background(), commandTimeout)
	defer cancel()

	// The argv is operator-supplied by construction: this program exists to
	// run named toolchain commands from roots given on its own command line,
	// and it never derives an executable path from package data, PATH, or an
	// inherited environment variable. Constructing the child from a constant
	// would defeat the measurement.
	//nolint:gosec // G204: running an operator-named toolchain command is this program's purpose
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	cmd.Dir = dir
	cmd.Env = privateEnv(envDelta)

	stdout, stderr := &byteCollector{}, &byteCollector{}
	cmd.Stdout = stdout
	cmd.Stderr = stderr

	err := cmd.Run()
	r.fullStdout = strings.ReplaceAll(string(stdout.b), "\r\n", "\n")
	r.fullStderr = strings.ReplaceAll(string(stderr.b), "\r\n", "\n")
	r.Stdout, r.Truncated = excerpt(stdout.b)
	se, t2 := excerpt(stderr.b)
	r.Stderr = se
	r.Truncated = r.Truncated || t2

	switch {
	case err == nil:
		r.ExitCode = 0
	case ctx.Err() != nil:
		r.ExitCode = -1
		r.Error = "timed out after " + commandTimeout.String()
	default:
		var ee *exec.ExitError
		if errors.As(err, &ee) {
			r.ExitCode = ee.ExitCode()
		} else {
			r.ExitCode = -1
			r.Error = err.Error()
		}
	}
	return r
}

type byteCollector struct{ b []byte }

func (c *byteCollector) Write(p []byte) (int, error) {
	// Bound retention so a chatty compiler cannot exhaust memory; keep the
	// head, which is where diagnostics appear.
	if len(c.b) < 1<<20 {
		c.b = append(c.b, p...)
	}
	return len(p), nil
}

// privateEnv builds the child environment from a fixed, manager-owned base
// plus the case's explicit deltas. Nothing else is inherited: no PATH from the
// invoking shell, no RUSTUP_*, TOOLCHAINS, JAVA_HOME, or GOROOT.
func privateEnv(delta []string) []string {
	base := []string{
		"HOME=" + os.Getenv("HOME"),
		"PATH=" + minimalPath(),
		"LC_ALL=C",
		"LANG=C",
		"CARGO_NET_OFFLINE=true",
	}
	if runtime.GOOS == "windows" {
		for _, k := range []string{"SystemRoot", "SystemDrive", "USERPROFILE", "TEMP", "TMP", "PATHEXT", "ProgramFiles", "LOCALAPPDATA", "APPDATA", "ComSpec"} {
			if v := os.Getenv(k); v != "" {
				base = append(base, k+"="+v)
			}
		}
	}
	return append(base, delta...)
}

func minimalPath() string {
	if runtime.GOOS == "windows" {
		root := os.Getenv("SystemRoot")
		if root == "" {
			root = `C:\Windows`
		}
		return strings.Join([]string{
			filepath.Join(root, "system32"),
			root,
			filepath.Join(root, "System32", "Wbem"),
		}, string(os.PathListSeparator))
	}
	return strings.Join([]string{"/usr/bin", "/bin", "/usr/sbin", "/sbin"}, string(os.PathListSeparator))
}

// FixtureFile records one generated corpus file by content digest, so a case
// can be reproduced byte for byte without embedding the whole corpus in the
// evidence.
type FixtureFile struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Bytes  int    `json:"bytes"`
}

func writeFixture(root, rel, content string) (FixtureFile, error) {
	p := filepath.Join(root, filepath.FromSlash(rel))
	if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		return FixtureFile{}, err
	}
	if err := os.WriteFile(p, []byte(content), 0o644); err != nil {
		return FixtureFile{}, err
	}
	sum := sha256.Sum256([]byte(content))
	return FixtureFile{Path: rel, SHA256: hex.EncodeToString(sum[:]), Bytes: len(content)}, nil
}

func sortedFixtureFiles(f []FixtureFile) []FixtureFile {
	sort.Slice(f, func(i, j int) bool { return f[i].Path < f[j].Path })
	return f
}

// fileExists is the manager-side check used wherever a compiler's own
// "do you know this target" answer is not the question being asked.
func fileExists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

func dirExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}
