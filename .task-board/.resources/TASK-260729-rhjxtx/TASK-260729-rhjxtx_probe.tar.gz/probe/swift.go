package main

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"regexp"
	"strings"
)

const swiftGuidanceID = "toolchain.swift.absent.primary-source"

func swiftPrimaryRelpath() string {
	if isWindows() {
		return `usr\bin\swift.exe`
	}
	return "usr/bin/swift"
}

func swiftcRelpath() string {
	if isWindows() {
		return `usr\bin\swiftc.exe`
	}
	return "usr/bin/swiftc"
}

const swiftPackageSwift = `// swift-tools-version:%s
import PackageDescription
let package = Package(name: "probe", targets: [.executableTarget(name: "probe")])
`

const swiftMainSwift = "print(\"x\")\n"

// swiftManifestFatal proves whether a reader command executes the manifest
// program. A fatalError is unambiguous: it can only be reported by a process
// that ran.
const swiftManifestFatal = `// swift-tools-version:6.0
import PackageDescription
fatalError("PROBE-MANIFEST-EXECUTED")
let package = Package(name: "probe", targets: [.executableTarget(name: "probe")])
`

func probeSwift(env *probeEnv) (ToolchainEvid, []Case) {
	ev := ToolchainEvid{
		ToolchainID: "swift",
		Companions:  []string{},
		Declaration: Declaration{Channel: "probe_explicit_root", Root: env.roots["swift"], PrimaryRelpath: swiftPrimaryRelpath()},
		MetadataSources: []MetadataSource{
			{
				File:                     "Package.swift (// swift-tools-version header)",
				ReadableWithoutExecution: true,
				ReaderCommand:            "swift package tools-version",
				Evidence:                 "measured: returns exit 0 and the normalized tools version for a manifest carrying a Swift syntax error and for a manifest whose body is a fatalError, so it reads the header line and neither compiles nor runs the manifest",
				Fields: []MetadataField{
					{Name: "swift-tools-version", Disposition: "compared", Measured: true,
						Rationale: "an assertion about the resolved toolchain; SwiftPM normalizes it to major.minor.patch on stdout"},
				},
			},
			{
				File:                     "Package.swift (body)",
				ReadableWithoutExecution: false,
				ReaderCommand:            "swift package dump-package",
				Evidence:                 "measured: dump-package compiles Package.swift with swiftc into a `<name>-manifest` executable and runs it; the fatalError fixture reports `Fatal error: PROBE-MANIFEST-EXECUTED`",
				Fields: []MetadataField{
					{Name: "<entire manifest program>", Disposition: "forbidden", Measured: true,
						Rationale: "reading it is package-selected code execution; no driver admitted by decision 0008 may invoke it"},
				},
			},
			{
				File:                     ".swift-version",
				ReadableWithoutExecution: true,
				ReaderCommand:            "read the file",
				Evidence:                 "measured: the Xcode-provided swift driver ignores it; it is honored by the swiftly version manager, which the trusted-resolution rule already forbids",
				Fields: []MetadataField{
					{Name: "<bare version string>", Disposition: "compared", Measured: true,
						Rationale: "an assertion about which toolchain the author expected; never honored, because resolution is operator-owned"},
				},
			},
		},
	}

	root := env.roots["swift"]
	if root == "" {
		ev.Availability = Unavailable
		ev.Reason = "no trusted Swift root was supplied to the probe; the probe does not search PATH, DEVELOPER_DIR, TOOLCHAINS, or a version-manager shim for one"
		ev.GuidanceID = swiftGuidanceID
		return ev, notRunLanguage("swift", ev.Reason)
	}
	swift := filepath.Join(root, filepath.FromSlash(swiftPrimaryRelpath()))
	swiftc := filepath.Join(root, filepath.FromSlash(swiftcRelpath()))
	ev.Declaration.PrimaryPresent = fileExists(swift)
	if !ev.Declaration.PrimaryPresent || !fileExists(swiftc) {
		ev.Availability = Unavailable
		ev.Reason = fmt.Sprintf("supplied root %q does not carry both %s and %s", root, swiftPrimaryRelpath(), swiftcRelpath())
		ev.GuidanceID = swiftGuidanceID
		return ev, notRunLanguage("swift", ev.Reason)
	}

	ti := execRun(env.work, nil, swiftc, "-print-target-info")
	ev.VersionProbe = &ti
	ev.Availability = Available

	info := parseSwiftTargetInfo(ti.fullStdout)
	ne := &NormEvid{RuleID: swiftVersionRule.ID, Stream: swiftVersionRule.Stream, Pattern: swiftVersionRule.Pattern.String(), Verified: true}
	if c, err := swiftVersionRule.Normalize(info.CompilerVersion); err != nil {
		ne.Undetermined = err.Error()
	} else {
		ne.Canonical = c
	}
	ev.Normalization = ne

	ev.TargetProbe = &ti
	ev.NativeTarget = &TargetIdenti{
		Reported:    info.Target.Triple,
		StableForm:  info.Target.UnversionedTriple,
		HostVarying: swiftHostVaryingComponents(info.Target.Triple, info.Target.UnversionedTriple),
		Source:      "swiftc -print-target-info, target.triple and target.unversionedTriple",
	}

	// The split-stream banner is a measured normalization hazard, not a
	// stylistic note: a rule written against merged output and a rule written
	// against stdout disagree about the first line.
	banner := execRun(env.work, nil, swift, "--version")
	ev.Notes = append(ev.Notes,
		fmt.Sprintf("`swift --version` splits one banner across two streams: stderr carries %q and stdout carries the version line. A normalization rule that reads the merged stream sees them concatenated into a single line, so the rule must name its stream.",
			strings.TrimRight(banner.fullStderr, "\n")),
		"`target.triple` carries a platform-version component supplied by the selected SDK, so it is not stable across hosts with different SDKs; `target.unversionedTriple` is the form a native-target identity should bind.",
		"SwiftPM compiles the manifest with a different platform version than the compiler reports for the host, which is a second reason the versioned triple is not an identity.",
	)

	var cases []Case
	cases = append(cases, swiftToolsVersionCases(env, swift)...)
	cases = append(cases, swiftManifestExecutionCase(env, swift))
	cases = append(cases, swiftTargetCases(env, swiftc)...)
	cases = append(cases, swiftSelectorCase(env, swift))
	return ev, cases
}

// swiftpmCompilingMarker is SwiftPM's own compile-phase progress line, and
// swiftFrontendJobMarker is the executed-job line the Swift driver writes under
// -v. Both are measured signals that a compiler process ran; neither is
// inferred from an exit code.
const (
	swiftpmCompilingMarker  = "Compiling "
	swiftFrontendJobMarker  = "swift-frontend -frontend"
	swiftFrontendJobMarker2 = "swift-frontend  -frontend"
)

type swiftTargetInfo struct {
	CompilerVersion string `json:"compilerVersion"`
	Target          struct {
		Triple            string `json:"triple"`
		UnversionedTriple string `json:"unversionedTriple"`
		ModuleTriple      string `json:"moduleTriple"`
		Arch              string `json:"arch"`
		Platform          string `json:"platform"`
	} `json:"target"`
}

func parseSwiftTargetInfo(stdout string) swiftTargetInfo {
	var t swiftTargetInfo
	_ = json.Unmarshal([]byte(stdout), &t)
	return t
}

var swiftPlatformVersion = regexp.MustCompile(`[0-9]+(\.[0-9]+)*$`)

// swiftHostVaryingComponents names the part of the versioned triple that the
// unversioned form drops. It is derived from the two measured strings rather
// than asserted, so a toolchain that stops adding a version component produces
// an empty list instead of a stale claim.
func swiftHostVaryingComponents(triple, unversioned string) []string {
	if triple == "" || unversioned == "" || triple == unversioned {
		return nil
	}
	if m := swiftPlatformVersion.FindString(triple); m != "" {
		return []string{"platform version " + m}
	}
	return []string{"suffix " + strings.TrimPrefix(triple, unversioned)}
}

func swiftToolsVersionCases(env *probeEnv, swift string) []Case {
	specs := []struct {
		id, dir, tv string
	}{
		{"swift.positive.tools-version-below-host", "positive", "6.0"},
		{"swift.negative.tools-version-future", "future", "99.0"},
		{"swift.negative.tools-version-malformed", "malformed", "not-a-version"},
	}
	var out []Case
	for _, s := range specs {
		dir := filepath.Join(env.work, "sw", s.dir)
		f1, _ := writeFixture(env.work, filepath.ToSlash(filepath.Join("sw", s.dir, "Package.swift")), fmt.Sprintf(swiftPackageSwift, s.tv))
		f2, _ := writeFixture(env.work, filepath.ToSlash(filepath.Join("sw", s.dir, "Sources", "probe", "main.swift")), swiftMainSwift)

		meta := execRun(dir, nil, swift, "package", "tools-version")
		build := execRun(dir, nil, swift, "build")

		obs := Observation{
			MetadataRan:            true,
			MetadataExit:           meta.ExitCode,
			MetadataExtractedValue: strings.TrimSpace(meta.fullStdout),
			BuildRan:               true,
			BuildExit:              build.ExitCode,
			// SwiftPM's tools-version gate fires before it compiles
			// anything, so the marker is expected to be absent on the
			// failing cases — but that is read off the output, not
			// assumed.
			BuildCompilationEvidence: compilationMarker(build, swiftpmCompilingMarker),
		}
		c := newCase(s.id)
		c.Fixtures = sortedFixtureFiles([]FixtureFile{f1, f2})
		c.Runs = []Run{meta, build}
		switch c.Expected {
		case GateHostVersion:
			c.ManagerObligation = "Read the tools version with `swift package tools-version` in the graph phase and compare it against the resolved toolchain identity. Unlike cargo, SwiftPM also rejects it itself before compiling, so this preflight removes a wasted process rather than a security gap."
		case GateRepresentability:
			c.ManagerObligation = "The header is refused by the reader command itself, with no host input, so this is a Stage B file-shape rejection."
		}
		out = append(out, finish(c, obs))
	}
	return out
}

func swiftManifestExecutionCase(env *probeEnv, swift string) Case {
	dir := filepath.Join(env.work, "sw", "fatal")
	f1, _ := writeFixture(env.work, "sw/fatal/Package.swift", swiftManifestFatal)
	f2, _ := writeFixture(env.work, "sw/fatal/Sources/probe/main.swift", swiftMainSwift)

	header := execRun(dir, nil, swift, "package", "tools-version")
	dump := execRun(dir, nil, swift, "package", "dump-package")

	executed := strings.Contains(dump.fullStderr, "PROBE-MANIFEST-EXECUTED") || strings.Contains(dump.fullStdout, "PROBE-MANIFEST-EXECUTED")
	compiled := strings.Contains(dump.fullStderr, "compiled with:") || strings.Contains(dump.fullStdout, "compiled with:")

	// Modelled as a selector case: the two readers disagree about the same
	// directory, and the disagreement is exactly package-authored code
	// running or not running.
	obs := Observation{
		SelectorMeasured:             true,
		SelectorShimExit:             dump.ExitCode,
		SelectorRootExit:             header.ExitCode,
		SelectorShimAttemptedInstall: executed,
	}
	c := newCase("swift.negative.manifest-is-a-program")
	c.Fixtures = sortedFixtureFiles([]FixtureFile{f1, f2})
	c.Runs = []Run{header, dump}
	c.ManagerObligation = fmt.Sprintf(
		"Never invoke `swift package dump-package`, `describe`, `resolve`, or `build` to learn what a package declares. Measured on this host: dump-package compiled the manifest (%t) and executed it (%t), while `swift package tools-version` returned the header from the same directory without doing either. A Swift driver's graph phase is therefore limited to the header, and the target/product set must come from the manager-owned wire surface rather than from the manifest.",
		compiled, executed)
	return finish(c, obs)
}

func swiftTargetCases(env *probeEnv, swiftc string) []Case {
	specs := []struct {
		id, triple string
	}{
		{"swift.negative.target-unknown", "not-a-real-triple"},
		{"swift.negative.target-stdlib-absent", "x86_64-unknown-linux-gnu"},
	}
	src, _ := writeFixture(env.work, "sw/target/main.swift", swiftMainSwift)
	var out []Case
	for _, s := range specs {
		targetPrint := execRun(env.work, nil, swiftc, "-print-target-info", "-target", s.triple)
		// -v makes the Swift driver print each job as it executes it. That
		// trace is the only way to measure whether a compiler process was
		// actually started for this target: swiftc emits no progress output of
		// its own, and its exit code cannot distinguish "the driver refused
		// the triple" from "the frontend ran and failed". The flag changes
		// what the driver reports, not what it does, and the argv is recorded
		// in the fixture.
		compile := execRun(env.work, nil, swiftc, "-v", "-target", s.triple, "-c",
			filepath.Join(env.work, "sw", "target", "main.swift"),
			"-o", filepath.Join(env.work, "sw", "target", "main.o"))

		// The manager-side early gate for Swift: -print-target-info reports
		// the runtime library paths the target would need, and for a target
		// this toolchain cannot serve those directories are simply not
		// there. Statting them is a pure filesystem check inside the
		// trusted tree, so it resolves the target before a compiler runs —
		// which the compiler's own exit 0 does not.
		stdChecked, stdPresent := swiftRuntimeLibrariesPresent(targetPrint)

		obs := Observation{
			TargetPrintRan:           true,
			TargetPrintExit:          targetPrint.ExitCode,
			TargetStdChecked:         stdChecked,
			TargetStdPresent:         stdPresent,
			BuildRan:                 true,
			BuildExit:                compile.ExitCode,
			BuildCompilationEvidence: compilationMarker(compile, swiftFrontendJobMarker, swiftFrontendJobMarker2),
		}
		c := newCase(s.id)
		c.Fixtures = []FixtureFile{src}
		c.Runs = []Run{targetPrint, compile}
		c.ManagerObligation = "A triple accepted by `-print-target-info` is only representable. Measured on this host, `-print-target-info -target x86_64-unknown-linux-gnu` exits 0 while compiling for it fails with `unable to load standard library for target`. The early gate is to stat the paths.runtimeLibraryPaths that the same command reports: for a target this toolchain cannot serve, they do not exist inside the trusted tree."
		if c.Expected == GateTargetRepresentability {
			c.ManagerObligation = "An unknown triple is refused by `-print-target-info` with a non-zero exit and `unknown target`, before any compilation. The measured -v job trace carries no frontend job, so the driver rejects the triple without starting a compiler."
		}
		out = append(out, finish(c, obs))
	}
	return out
}

func swiftSelectorCase(env *probeEnv, swift string) Case {
	dir := filepath.Join(env.work, "sw", "swiftver")
	f1, _ := writeFixture(env.work, "sw/swiftver/Package.swift", fmt.Sprintf(swiftPackageSwift, "6.0"))
	f2, _ := writeFixture(env.work, "sw/swiftver/Sources/probe/main.swift", swiftMainSwift)
	f3, _ := writeFixture(env.work, "sw/swiftver/.swift-version", "5.9.0\n")

	inDir := execRun(dir, nil, swift, "--version")
	outDir := execRun(env.work, nil, swift, "--version")

	// A selector case where the two measurements are expected to AGREE:
	// the file must not change which compiler answers. The classifier
	// returns GateNone when they agree, which is what this case asserts.
	obs := Observation{
		SelectorMeasured:             true,
		SelectorShimExit:             inDir.ExitCode,
		SelectorRootExit:             outDir.ExitCode,
		SelectorShimAttemptedInstall: inDir.fullStdout != outDir.fullStdout,
	}
	c := newCase("swift.negative.selector-swift-version-file")
	c.Fixtures = sortedFixtureFiles([]FixtureFile{f1, f2, f3})
	c.Runs = []Run{inDir, outDir}
	c.ManagerObligation = "`.swift-version` is honored by the swiftly version manager, not by a directly resolved toolchain. Measured on this host the file changed nothing, which is the property that lets the driver classify the field `compared` rather than `forbidden`: it is an assertion the manager reads and never honors."
	return finish(c, obs)
}

// swiftRuntimeLibrariesPresent stats the runtime library paths the compiler
// itself reports for a target.
//
// It returns (false, false) when the command produced no paths, so a target
// whose report cannot be read is never credited with an early decision.
func swiftRuntimeLibrariesPresent(targetPrint Run) (checked, present bool) {
	var doc struct {
		Paths struct {
			RuntimeLibraryPaths []string `json:"runtimeLibraryPaths"`
		} `json:"paths"`
	}
	if err := json.Unmarshal([]byte(targetPrint.fullStdout), &doc); err != nil {
		return false, false
	}
	if len(doc.Paths.RuntimeLibraryPaths) == 0 {
		return false, false
	}
	for _, p := range doc.Paths.RuntimeLibraryPaths {
		if dirExists(p) {
			return true, true
		}
	}
	return true, false
}

func swiftConsumers() []string { return []string{"TASK-260728-1yhuqi"} }
