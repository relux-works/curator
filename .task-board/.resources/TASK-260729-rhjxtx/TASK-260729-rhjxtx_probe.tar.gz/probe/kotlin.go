package main

import (
	"fmt"
	"path/filepath"
	"sort"
	"strings"
)

const kotlinGuidanceID = "toolchain.kotlin-native.absent.primary-source"

// kotlinNativePrimaryRelpath is the relpath inside a kotlin-native-prebuilt
// distribution. It is declared so the probe can state exactly what it looked
// for and did not find; it has not been confirmed against a real distribution
// on either probed host.
func kotlinNativePrimaryRelpath() string {
	if isWindows() {
		return `bin\kotlinc-native.bat`
	}
	return "bin/kotlinc-native"
}

func konancRelpath() string {
	if isWindows() {
		return `bin\konanc.bat`
	}
	return "bin/konanc"
}

// kotlinNativeUnverified is the standing caveat on every Kotlin/Native code
// path below. The supplied-root branch is implemented and exercised, but it has
// only ever been exercised against a synthetic root in the probe's own tests.
// No Kotlin/Native distribution was reachable on either probed host, so nothing
// under it constitutes a platform claim.
const kotlinNativeUnverified = "UNVERIFIED against a real Kotlin/Native distribution: the branch is implemented and unit-tested against a synthetic root, and has never seen output from a real konan compiler"

const kotlinMainKT = "fun main() {}\n"

// kotlinProbeTargets are legal Kotlin/Native target names used only to find one
// this distribution does not serve. The probe picks the first that is absent
// from the distribution's own -list-targets output, so it never asserts which
// targets a distribution ought to carry.
var kotlinProbeTargets = []string{"linux_x64", "mingw_x64", "linux_arm64", "ios_arm64", "macos_x64"}

func probeKotlin(env *probeEnv) (ToolchainEvid, []Case) {
	ev := ToolchainEvid{
		ToolchainID: "kotlin",
		Companions:  []string{},
		Declaration: Declaration{Channel: "probe_explicit_root", Root: env.roots["kotlin"], PrimaryRelpath: kotlinNativePrimaryRelpath()},
	}
	ev.MetadataSources = kotlinMetadataSources(nil)

	root := env.roots["kotlin"]
	var cases []Case
	if root == "" {
		ev.Availability = Unavailable
		ev.Reason = "no trusted Kotlin/Native root was supplied to the probe, and none was found by the operator on either probed host; the probe does not search PATH, KOTLIN_HOME, ~/.konan, sdkman, or a package manager for one, and it never installs"
		ev.GuidanceID = kotlinGuidanceID
		cases = notRunRootCases(ev.Reason)
	} else {
		ev, cases = probeKotlinNativeRoot(env, ev, root)
	}
	cases = append(cases, kotlinCompanionNotRun()...)

	// Two Kotlin controls need no Kotlin/Native distribution at all, and on a
	// host without one they are the only Kotlin evidence there is. Both are
	// attempted regardless of the branch above.
	if c, ok := kotlinBackendCase(env); ok {
		cases = replaceCase(cases, c)
		if ev.Availability != Available {
			ev.Notes = append(ev.Notes, c.ManagerObligation)
		}
	}
	if c, ok := kotlinMetadataIsAProgramCase(env); ok {
		cases = replaceCase(cases, c)
		ev.MetadataSources = kotlinMetadataSources(&c)
	}
	return ev, cases
}

// kotlinRootCaseIDs are the cases that need a Kotlin/Native distribution.
// The rest of the Kotlin corpus is measurable without one.
var kotlinRootCaseIDs = []string{
	"kotlin.positive.version-and-target",
	"kotlin.negative.target-unknown",
	"kotlin.negative.target-not-listed",
}

func notRunRootCases(reason string) []Case {
	out := make([]Case, 0, len(kotlinRootCaseIDs))
	for _, id := range kotlinRootCaseIDs {
		out = append(out, notRunCase(id, reason))
	}
	return out
}

// kotlinCompanionNotRun is the honest default for the two controls that need a
// companion tool rather than a Kotlin/Native distribution. Each is replaced
// when its companion is supplied.
func kotlinCompanionNotRun() []Case {
	return []Case{
		notRunCase("kotlin.negative.backend-is-not-native",
			"no Kotlin compiler path was supplied (-kotlinc-jvm), so backend identity could not be measured on this host"),
		notRunCase("kotlin.negative.metadata-is-a-program",
			"no Gradle launcher path was supplied (-gradle), so the cost of reading Kotlin project metadata could not be measured on this host"),
	}
}

// probeKotlinNativeRoot is the supplied-root branch: a real, runnable probe of
// a Kotlin/Native distribution.
//
// Every command it issues reads from the supplied root and writes only inside
// the probe's own working directory. It installs nothing, and a distribution
// whose output does not match the declared shapes yields not_run records rather
// than a plausible wrong answer.
func probeKotlinNativeRoot(env *probeEnv, ev ToolchainEvid, root string) (ToolchainEvid, []Case) {
	native := filepath.Join(root, filepath.FromSlash(kotlinNativePrimaryRelpath()))
	konanc := filepath.Join(root, filepath.FromSlash(konancRelpath()))
	ev.Declaration.PrimaryPresent = fileExists(native) || fileExists(konanc)
	if !ev.Declaration.PrimaryPresent {
		ev.Availability = Unavailable
		ev.Reason = fmt.Sprintf("supplied root %q carries neither %s nor %s, so it is not a Kotlin/Native distribution", root, kotlinNativePrimaryRelpath(), konancRelpath())
		ev.GuidanceID = kotlinGuidanceID
		return ev, notRunRootCases(ev.Reason)
	}

	primary := native
	if !fileExists(primary) {
		primary = konanc
	}

	// The authoritative version surface. `kotlinc -version` writes its banner
	// to stderr and leaves stdout empty, which is why the rule names its
	// stream; stdout is read only as a fallback so a distribution that moved
	// the banner is measured rather than reported undetermined for the wrong
	// reason.
	vr := execRun(env.work, nil, primary, "-version")
	ev.VersionProbe = &vr
	banner := vr.fullStderr
	stream := StreamStderr
	if strings.TrimSpace(banner) == "" {
		banner = vr.fullStdout
		stream = StreamStdout
	}
	backend := kotlinBackendFromVersionBanner(banner)

	ne := &NormEvid{RuleID: kotlinNativeVersionRule.ID, Stream: kotlinNativeVersionRule.Stream, Pattern: kotlinNativeVersionRule.Pattern.String(), Verified: false}
	canonical, normErr := kotlinNativeVersionRule.Normalize(banner)
	if normErr != nil {
		ne.Undetermined = normErr.Error()
	} else {
		ne.Canonical = canonical
	}
	ev.Normalization = ne
	if stream != kotlinNativeVersionRule.Stream {
		ev.Notes = append(ev.Notes, fmt.Sprintf("the version banner was found on %s, not the %s the rule names", stream, kotlinNativeVersionRule.Stream))
	}

	if backend != "native" {
		ev.Availability = WrongBackend
		ev.Reason = fmt.Sprintf("the executable at %s reports backend %q; only the native backend can produce the admitted native-executable-v1 artifact class", primary, backend)
		ev.GuidanceID = kotlinGuidanceID
		return ev, notRunRootCases(ev.Reason)
	}
	ev.Availability = Available
	ev.Notes = append(ev.Notes, kotlinNativeUnverified)

	// The target surface. -list-targets is the distribution's own statement of
	// which targets it serves, and it is the manager-side membership check that
	// separates a representable target name from one this distribution can
	// build.
	lt := execRun(env.work, nil, primary, "-list-targets")
	ev.TargetProbe = &lt
	targets, hostDefault := kotlinTargetList(lt.fullStdout + "\n" + lt.fullStderr)
	if hostDefault != "" {
		ev.NativeTarget = &TargetIdenti{
			Reported:   hostDefault,
			StableForm: hostDefault,
			Source:     "kotlinc-native -list-targets, the entry marked (default)",
		}
	} else {
		ev.Notes = append(ev.Notes, "-list-targets named no (default) entry, so the native konan target is undetermined and every case that depends on it is not_run")
	}
	ev.Notes = append(ev.Notes, fmt.Sprintf("-list-targets reported %d targets", len(targets)))

	src, _ := writeFixture(env.work, "kt/main.kt", kotlinMainKT)
	cases := []Case{
		kotlinPositiveCase(env, primary, src, lt, targets, hostDefault, canonical, normErr),
		kotlinUnknownTargetCase(env, primary, src, lt, targets),
		kotlinUnlistedTargetCase(env, primary, src, lt, targets),
	}
	return ev, cases
}

// kotlinPositiveCase asserts the two things a driver must be able to do before
// it compiles anything: normalize the toolchain's own version, and confirm the
// host target is one this distribution serves.
func kotlinPositiveCase(env *probeEnv, primary string, src FixtureFile, lt Run, targets []string, hostDefault string, canonical Canonical, normErr error) Case {
	const id = "kotlin.positive.version-and-target"
	if normErr != nil {
		return notRunCase(id, "the version banner did not normalize: "+normErr.Error())
	}
	if hostDefault == "" {
		return notRunCase(id, "-list-targets named no (default) entry, so the host konan target is undetermined and a positive target case would be a guess")
	}

	out := filepath.Join(env.work, "kt", "out-positive")
	compile := execRun(env.work, nil, primary, "-target", hostDefault, "-o", out,
		filepath.Join(env.work, "kt", "main.kt"))

	obs := Observation{
		TargetPrintRan:           true,
		TargetPrintExit:          lt.ExitCode,
		TargetStdChecked:         len(targets) > 0,
		TargetStdPresent:         containsString(targets, hostDefault),
		BuildRan:                 true,
		BuildExit:                compile.ExitCode,
		BuildCompilationEvidence: compilationMarker(compile, kotlinCompilationMarkers()...),
	}
	c := newCase(id)
	c.Fixtures = []FixtureFile{src}
	c.Runs = []Run{lt, compile}
	c.ManagerObligation = fmt.Sprintf(
		"The resolved Kotlin/Native version is %s, normalized from the %s banner by rule %s. The native target %q is a member of the distribution's own -list-targets set, which is the membership check a driver must perform before compiling. %s",
		canonical, kotlinNativeVersionRule.Stream, kotlinNativeVersionRule.ID, hostDefault, kotlinNativeUnverified)
	return finish(c, obs)
}

// kotlinUnknownTargetCase is the representability control: a name that is not a
// konan target at all is refused by the compiler with no host input.
func kotlinUnknownTargetCase(env *probeEnv, primary string, src FixtureFile, lt Run, targets []string) Case {
	const unknown = "not-a-real-konan-target"
	out := filepath.Join(env.work, "kt", "out-unknown")
	compile := execRun(env.work, nil, primary, "-target", unknown, "-o", out,
		filepath.Join(env.work, "kt", "main.kt"))

	obs := Observation{
		TargetPrintRan: true,
		// A name absent from -list-targets is refused before any host
		// question is asked, so the representability answer is the
		// membership answer and the exit code below only confirms it.
		TargetPrintExit:          boolExit(!containsString(targets, unknown) && compile.ExitCode != 0),
		TargetStdChecked:         len(targets) > 0,
		TargetStdPresent:         containsString(targets, unknown),
		BuildRan:                 true,
		BuildExit:                compile.ExitCode,
		BuildCompilationEvidence: compilationMarker(compile, kotlinCompilationMarkers()...),
	}
	c := newCase("kotlin.negative.target-unknown")
	c.Fixtures = []FixtureFile{src}
	c.Runs = []Run{lt, compile}
	c.ManagerObligation = fmt.Sprintf(
		"A target name is representable only if it appears in the distribution's own -list-targets set. %q does not, and the compiler refuses it. Unlike Rust and Swift there is no separate target-print command, so -list-targets is both the representability surface and the manager-side membership check. %s",
		unknown, kotlinNativeUnverified)
	return finish(c, obs)
}

// kotlinUnlistedTargetCase is the host-gate control: a legal konan target name
// that this particular distribution does not serve.
//
// The target is chosen from what the distribution actually reported, never
// asserted, so a distribution that serves every candidate produces an honest
// not_run instead of a fabricated expectation.
func kotlinUnlistedTargetCase(env *probeEnv, primary string, src FixtureFile, lt Run, targets []string) Case {
	const id = "kotlin.negative.target-not-listed"
	if len(targets) == 0 {
		return notRunCase(id, "-list-targets produced no parsable target names, so no known-but-unserved target could be selected without guessing")
	}
	unserved := ""
	for _, t := range kotlinProbeTargets {
		if !containsString(targets, t) {
			unserved = t
			break
		}
	}
	if unserved == "" {
		return notRunCase(id, "this distribution serves every candidate target the probe knows, so it carries no known-but-unserved target to measure")
	}

	out := filepath.Join(env.work, "kt", "out-unlisted")
	compile := execRun(env.work, nil, primary, "-target", unserved, "-o", out,
		filepath.Join(env.work, "kt", "main.kt"))

	obs := Observation{
		TargetPrintRan:           true,
		TargetPrintExit:          lt.ExitCode,
		TargetStdChecked:         true,
		TargetStdPresent:         false,
		BuildRan:                 true,
		BuildExit:                compile.ExitCode,
		BuildCompilationEvidence: compilationMarker(compile, kotlinCompilationMarkers()...),
	}
	c := newCase(id)
	c.Fixtures = []FixtureFile{src}
	c.Runs = []Run{lt, compile}
	c.ManagerObligation = fmt.Sprintf(
		"%q is a legal Kotlin/Native target name that this distribution does not list. Admission is therefore a membership test against this distribution's -list-targets output, not against the set of names the ecosystem defines. %s",
		unserved, kotlinNativeUnverified)
	return finish(c, obs)
}

// kotlinCompilationMarkers are the output lines that would prove a konan
// compiler process ran.
//
// They are DECLARED, not measured: no real Kotlin/Native output has been
// observed. The consequence of that honesty is deliberate — on a distribution
// whose progress output differs, BuildCompilationEvidence stays empty and
// UpstreamRejectsAfterCompilation reads false, which understates rather than
// invents. A false "compilation started" is the failure mode this probe was
// reworked to remove.
func kotlinCompilationMarkers() []string {
	return []string{"Compiling ", "produce: PROGRAM", "error: compilation failed"}
}

// kotlinTargetList parses `kotlinc-native -list-targets`.
//
// UNVERIFIED: no Kotlin/Native distribution was reachable on either probed
// host, so this parser has never seen real output. It is deliberately shaped so
// an unexpected format yields no targets and no default rather than a plausible
// wrong answer: every case that depends on it then reports not_run. A target
// name is accepted only in the documented konan form — lowercase alphanumerics
// and underscores — so prose, banners, and headers are not mistaken for targets.
func kotlinTargetList(out string) (targets []string, hostDefault string) {
	seen := map[string]bool{}
	for _, ln := range strings.Split(strings.ReplaceAll(out, "\r\n", "\n"), "\n") {
		fields := strings.Fields(ln)
		if len(fields) == 0 {
			continue
		}
		// Konan lists a target as `name:` followed by optional annotations.
		name := strings.TrimSuffix(fields[0], ":")
		if !isKonanTargetName(name) {
			continue
		}
		if !seen[name] {
			seen[name] = true
			targets = append(targets, name)
		}
		if strings.Contains(ln, "(default)") && hostDefault == "" {
			hostDefault = name
		}
	}
	sort.Strings(targets)
	return targets, hostDefault
}

func isKonanTargetName(s string) bool {
	if len(s) < 3 || len(s) > 40 || !strings.Contains(s, "_") {
		return false
	}
	for _, r := range s {
		switch {
		case r >= 'a' && r <= 'z', r >= '0' && r <= '9', r == '_':
		default:
			return false
		}
	}
	return true
}

func containsString(xs []string, s string) bool {
	for _, x := range xs {
		if x == s {
			return true
		}
	}
	return false
}

// boolExit maps a manager-side yes/no into the exit-code slot the classifier
// reads for a target-print command. Kotlin/Native has no separate target-print
// command, so the membership answer occupies that slot directly.
func boolExit(refused bool) int {
	if refused {
		return 1
	}
	return 0
}

// kotlinBackendCase is the one Kotlin control that a host without Kotlin/Native
// can still measure, and it is the control that matters most on such a host:
// it proves that the Kotlin compiler which *is* present is the wrong backend,
// so a driver cannot silently satisfy a Kotlin requirement with it.
func kotlinBackendCase(env *probeEnv) (Case, bool) {
	jvm := env.kotlincJVM
	if jvm == "" {
		return Case{}, false
	}
	vr := execRun(env.work, nil, jvm, "-version")
	banner := vr.fullStderr
	if strings.TrimSpace(banner) == "" {
		banner = vr.fullStdout
	}
	backend := kotlinBackendFromVersionBanner(banner)

	c := newCase("kotlin.negative.backend-is-not-native")
	c.Runs = []Run{vr}
	c.ManagerObligation = fmt.Sprintf(
		"The Kotlin compiler present on this host reports backend %q on stderr with an `info:` prefix and an empty stdout. A version probe that reads stdout gets nothing, and a probe that accepts any `kotlinc` banner would admit a front end that cannot produce a native executable. The Kotlin entry's probe must name the stderr stream and its normalization must require the backend token.",
		backend)
	return finish(c, Observation{Backend: backend}), true
}

// kotlinMetadataIsAProgramCase measures the Kotlin ecosystem's project-metadata
// surface, and needs no Kotlin/Native distribution.
//
// Decision 0008 section 4 requires every local driver to bind exactly one
// closed project-metadata file that exists directly in the build root, as
// `go-v1` binds `go.mod`. Kotlin's mainstream answer to that slot is a Gradle
// build script, and this case measures what reading one costs: Gradle compiles
// the script as a program source unit before it can answer any metadata query.
// That is the same disqualification `swift package dump-package` earns, and it
// is the load-bearing input to whether a Kotlin driver has a legal metadata file
// at all.
func kotlinMetadataIsAProgramCase(env *probeEnv) (Case, bool) {
	const id = "kotlin.negative.metadata-is-a-program"
	if env.gradle == "" {
		return Case{}, false
	}
	dir := filepath.Join(env.work, "kt", "gradle")
	f1, _ := writeFixture(env.work, "kt/gradle/build.gradle", "println(\"PROBE-BUILD-SCRIPT-EXECUTED\")\n")
	f2, _ := writeFixture(env.work, "kt/gradle/settings.gradle", "rootProject.name = 'probe'\n")

	// GRADLE_USER_HOME is redirected into the probe's working directory so the
	// measurement cannot write to the operator's Gradle home, and --offline
	// with --no-daemon keeps it from fetching anything or leaving a process
	// behind. Nothing is installed.
	gradleEnv := []string{"GRADLE_USER_HOME=" + filepath.Join(env.work, "gradle-home")}
	props := execRun(dir, gradleEnv, env.gradle, "--offline", "--no-daemon", "--console=plain", "properties")

	executed := runContains(props, "PROBE-BUILD-SCRIPT-EXECUTED")
	compiled := runContains(props, "_BuildScript_")

	c := newCase(id)
	c.Fixtures = sortedFixtureFiles([]FixtureFile{f1, f2})
	c.Runs = []Run{props}
	if !executed && !compiled {
		return notRunCase(id, fmt.Sprintf(
			"the Gradle run at exit %d showed neither the executed-script marker nor a build-script compilation unit, so it measured nothing about the metadata surface", props.ExitCode)), true
	}

	// Modelled as a selector case for the same reason the Swift manifest case
	// is: the disagreement being measured is exactly package-authored code
	// running or not running.
	obs := Observation{
		SelectorMeasured:             true,
		SelectorShimExit:             props.ExitCode,
		SelectorRootExit:             0,
		SelectorShimAttemptedInstall: executed || compiled,
	}
	c.ManagerObligation = fmt.Sprintf(
		"Measured on this host: answering a pure metadata query (`gradle properties`) compiled the build script as a program source unit (%t) and ran it to completion (%t). The build-script compilation is the finding; whether it then finishes is incidental, and on this host it did not, because the installed JDK is newer than the Gradle distribution accepts. A Gradle script therefore cannot be the closed project-metadata file decision 0008 section 4 requires, and SECURITY.md already forbids invoking it. The Kotlin/Native compiler-only path defines no manifest of its own, so TASK-260728-168smo must either name a curator-owned metadata file for the build root or accept that section 10's retirement clause applies. The Kotlin DSL form (build.gradle.kts) was NOT measured: resolving it requires network fetches this probe refuses to perform.",
		compiled, executed)
	return finish(c, obs), true
}

func runContains(r Run, s string) bool {
	return strings.Contains(r.fullStdout, s) || strings.Contains(r.fullStderr, s)
}

// kotlinMetadataSources records the source-ecosystem metadata surfaces a Kotlin
// driver could bind, and what each one costs. The Gradle entry carries a
// measured evidence line when the Gradle case ran.
func kotlinMetadataSources(gradleCase *Case) []MetadataSource {
	gradleEvidence := "not measured on this host: no Gradle launcher was supplied with -gradle. Recorded because the mainstream Kotlin build path is a general-purpose script engine and reading it is package-selected code execution by construction"
	if gradleCase != nil && gradleCase.Verdict != "not_run" {
		gradleEvidence = fmt.Sprintf("measured by case %s: %s", gradleCase.ID, gradleCase.ManagerObligation)
	} else if gradleCase != nil {
		gradleEvidence = fmt.Sprintf("attempted by case %s and not measured: %s", gradleCase.ID, gradleCase.NotRunReason)
	}
	return []MetadataSource{
		{
			File:                     "(none defined by the Kotlin/Native compiler-only path)",
			ReadableWithoutExecution: false,
			Evidence:                 "no candidate is proposed. Decision 0008 section 4 requires exactly one closed driver-defined project-metadata file directly in the build root, as go-v1 binds go.mod. kotlinc-native consumes .kt sources and an output path and defines no manifest, and the ecosystem's manifest is a Gradle script, which the entry below measures as executable code. Naming a candidate without a qualified Kotlin/Native host would be a fabricated platform claim, so this probe supplies the boundary rather than a file: " + kotlinNativeUnverified,
			Fields: []MetadataField{
				{Name: "<no legal field>", Disposition: "forbidden", Measured: false,
					Rationale: "the only source-tree surface the ecosystem offers for this slot is a program; whether a curator-owned metadata file is minted instead is TASK-260728-168smo's decision under section 10's retirement clause"},
			},
		},
		{
			File:                     "build.gradle / build.gradle.kts / settings.gradle*",
			ReadableWithoutExecution: false,
			ReaderCommand:            "gradle properties (measured only to establish the cost of reading it; never a driver command)",
			Evidence:                 gradleEvidence,
			Fields: []MetadataField{
				{Name: "<entire build script>", Disposition: "forbidden", Measured: gradleCase != nil && gradleCase.Verdict != "not_run",
					Rationale: "a Gradle build script is a program; no driver admitted by decision 0008 may invoke it, and the Gradle wrapper additionally downloads its own distribution"},
			},
		},
	}
}

func kotlinConsumers() []string { return []string{"TASK-260728-168smo"} }
