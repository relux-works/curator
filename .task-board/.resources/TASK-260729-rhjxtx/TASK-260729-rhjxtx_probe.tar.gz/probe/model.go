package main

// Fixture is the complete machine-readable evidence document.
type Fixture struct {
	FixtureVersion string           `json:"fixture_version"`
	Task           string           `json:"task"`
	Host           Host             `json:"host"`
	Toolchains     []ToolchainEvid  `json:"toolchains"`
	Cases          []Case           `json:"cases"`
	Summary        Summary          `json:"summary"`
	Guidance       []GuidanceRecord `json:"installation_guidance_inputs"`
}

// Host records the machine the evidence came from. Nothing in the fixture is
// portable across hosts without it.
type Host struct {
	OperatingSystem string `json:"operating_system"`
	Architecture    string `json:"architecture"`
	GOOS            string `json:"goos"`
	GOARCH          string `json:"goarch"`
	OSVersion       string `json:"os_version,omitempty"`
	NativeTarget    string `json:"native_target"`
	ProbeGoVersion  string `json:"probe_go_version"`
}

// Availability is the honest three-way answer to "is this toolchain here".
type Availability string

const (
	// Available: a trusted root was supplied, its primary executable exists
	// inside that root, and it answered the version probe.
	Available Availability = "available"
	// Unavailable: no trusted root was supplied, or the supplied root does
	// not contain the primary executable. Never an installation trigger.
	Unavailable Availability = "unavailable"
	// WrongBackend: a real compiler of this language family answered, and it
	// is not the backend the admitted artifact class requires.
	WrongBackend Availability = "wrong_backend"
)

// ToolchainEvid is the per-toolchain evidence record.
type ToolchainEvid struct {
	ToolchainID  string       `json:"toolchain_id"`
	Availability Availability `json:"availability"`
	// Reason is populated for every non-available state and is the text a
	// manager would surface. It never names an install command.
	Reason string `json:"reason,omitempty"`
	// GuidanceID links to the manager-owned guidance record. Present
	// whenever Availability is not Available.
	GuidanceID string `json:"guidance_id,omitempty"`

	// Declaration records how this probe reached the root. The probe is not
	// the manager: it accepts a root on the command line. The field exists so
	// evidence never gets mistaken for a claim that the manager resolved it
	// this way.
	Declaration Declaration `json:"declaration"`

	VersionProbe  *Run      `json:"version_probe,omitempty"`
	Normalization *NormEvid `json:"normalization,omitempty"`

	TargetProbe  *Run          `json:"target_probe,omitempty"`
	NativeTarget *TargetIdenti `json:"native_target,omitempty"`

	MetadataSources []MetadataSource `json:"metadata_sources"`
	Companions      []string         `json:"companions"`
	Notes           []string         `json:"notes,omitempty"`
}

// Declaration is the probe's own origin record.
type Declaration struct {
	// Channel is always probe_explicit_root or absent. The probe never
	// searches PATH for a toolchain root, and says so in the evidence.
	Channel string `json:"channel"`
	Root    string `json:"root,omitempty"`
	// PrimaryRelpath is the fixed relpath of the primary executable inside
	// the fingerprinted root.
	PrimaryRelpath  string `json:"primary_relpath,omitempty"`
	PrimaryPresent  bool   `json:"primary_present"`
	PATHWasSearched bool   `json:"path_was_searched"`
}

// NormEvid records which rule was applied, on which stream, and what it
// produced. A rule that produced nothing is an undetermined version, never a
// default.
type NormEvid struct {
	RuleID       string    `json:"rule_id"`
	Stream       Stream    `json:"stream"`
	Pattern      string    `json:"pattern"`
	Canonical    Canonical `json:"canonical,omitempty"`
	Undetermined string    `json:"undetermined,omitempty"`
	Verified     bool      `json:"verified_against_real_output"`
}

// TargetIdenti records the native target the toolchain reports, and whether
// that string is stable enough to be part of a build identity.
type TargetIdenti struct {
	Reported string `json:"reported"`
	// StableForm is the value a driver should bind into a cache key when the
	// reported form carries host-varying components.
	StableForm string `json:"stable_form"`
	// HostVarying names the components that move with the host or SDK.
	HostVarying []string `json:"host_varying_components,omitempty"`
	Source      string   `json:"source"`
}

// MetadataSource is one source-ecosystem file the driver's Stage B must read,
// with the disposition of each field the probe exercised.
type MetadataSource struct {
	File   string          `json:"file"`
	Fields []MetadataField `json:"fields"`
	// ReadableWithoutExecution records whether the file's value can be
	// obtained without compiling or running package-authored code. It is the
	// single most important property of a metadata source.
	ReadableWithoutExecution bool   `json:"readable_without_execution"`
	ReaderCommand            string `json:"reader_command,omitempty"`
	Evidence                 string `json:"evidence,omitempty"`
}

// MetadataField carries the section 3.1 disposition.
type MetadataField struct {
	Name        string `json:"name"`
	Disposition string `json:"disposition"` // forbidden | compared | ignored
	Rationale   string `json:"rationale"`
	Measured    bool   `json:"measured"`
}

// Case is one measured positive or negative control.
type Case struct {
	ID       string    `json:"id"`
	Language string    `json:"language"`
	Kind     string    `json:"kind"` // positive | negative
	Title    string    `json:"title"`
	Expected GateClass `json:"expected_gate_class"`
	Observed GateClass `json:"observed_gate_class"`
	Verdict  string    `json:"verdict"` // match | divergence | not_run

	// NotRunReason is set when the toolchain the case needs is unavailable.
	// A case that could not run is never reported as a pass.
	NotRunReason string `json:"not_run_reason,omitempty"`

	Observation Observation `json:"observation"`

	DecidableBeforeCompilerWork       bool `json:"decidable_before_compiler_work"`
	UpstreamRejectsAfterCompilation   bool `json:"upstream_rejects_after_compilation"`
	ExpectDecidableBeforeCompilerWork bool `json:"expect_decidable_before_compiler_work"`

	Fixtures []FixtureFile `json:"fixtures,omitempty"`
	Runs     []Run         `json:"runs,omitempty"`
	// ManagerObligation is the concrete preflight a driver contract must own
	// because the ecosystem does not provide it early enough.
	ManagerObligation string   `json:"manager_obligation,omitempty"`
	Consumers         []string `json:"consumers"`
}

// Summary is the pass/fail accounting the exit status is derived from.
type Summary struct {
	Total        int `json:"total"`
	Matched      int `json:"matched"`
	Divergences  int `json:"divergences"`
	NotRun       int `json:"not_run"`
	Unavailable  int `json:"unavailable_toolchains"`
	WrongBackend int `json:"wrong_backend_toolchains"`
}

// GuidanceRecord is a manager-owned installation-guidance input.
//
// It carries a primary source, never a command. The manager surfaces the
// source; it does not run it, and this probe does not either.
type GuidanceRecord struct {
	ID          string `json:"id"`
	ToolchainID string `json:"toolchain_id"`
	Reason      string `json:"reason"`
	// PrimarySourceURL is the vendor's own documentation. Never a mirror,
	// never a package manager, never a script endpoint.
	PrimarySourceURL   string `json:"primary_source_url"`
	PrimarySourceOwner string `json:"primary_source_owner"`
	// OperatorAction is prose describing what the operator must do. It is
	// deliberately not a command line: a copyable command is an install
	// instruction the manager would be inviting itself to run.
	OperatorAction string `json:"operator_action"`
	AutoInstall    bool   `json:"auto_install"` // always false
}
