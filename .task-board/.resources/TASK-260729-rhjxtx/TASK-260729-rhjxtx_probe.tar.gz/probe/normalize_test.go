package main

import "testing"

// The inputs below are the exact bytes the probed toolchains produced on the
// macOS host recorded in the run log. They are pinned here so a change to a
// normalization rule that stops matching real output fails in `go test` rather
// than at the next probe run.

const (
	realRustcVV = `rustc 1.91.0 (f8297e351 2025-10-28)
binary: rustc
commit-hash: f8297e351a40c1439a467bbbb6879088047f50b3
commit-date: 2025-10-28
host: aarch64-apple-darwin
release: 1.91.0
LLVM version: 21.1.2
`
	realCargoVersion         = "cargo 1.91.0 (ea2d97820 2025-10-10)\n"
	realSwiftCompilerVersion = "Apple Swift version 6.3.2 (swiftlang-6.3.2.1.108 clang-2100.1.1.101)"
	realKotlincStderr        = "info: kotlinc-jvm 2.4.10 (JRE 26.0.1)\n"
)

func TestRustcVersionRuleMatchesRealOutput(t *testing.T) {
	got, err := rustcVersionRule.Normalize(realRustcVV)
	if err != nil {
		t.Fatalf("normalize real rustc -vV: %v", err)
	}
	if got.Major != 1 || got.Minor != 91 || got.Patch != 0 {
		t.Fatalf("got %d.%d.%d, want 1.91.0", got.Major, got.Minor, got.Patch)
	}
	if got.Prerelease {
		t.Fatal("1.91.0 is a release, not a prerelease")
	}
	if got.Native != "release: 1.91.0" {
		t.Fatalf("native = %q, want the matched line", got.Native)
	}
}

// The short form carries the commit hash on the same line, which is why the
// rule reads the verbose block. This test pins that the rule does NOT match the
// short form, so the two can never be swapped by accident.
func TestRustcVersionRuleRejectsShortForm(t *testing.T) {
	if _, err := rustcVersionRule.Normalize("rustc 1.91.0 (f8297e351 2025-10-28)\n"); err == nil {
		t.Fatal("the release: rule must not match `rustc --version` output")
	}
}

func TestRustcVersionRuleFlagsPrerelease(t *testing.T) {
	got, err := rustcVersionRule.Normalize("release: 1.92.0-nightly\n")
	if err != nil {
		t.Fatalf("normalize nightly: %v", err)
	}
	if !got.Prerelease {
		t.Fatal("a -nightly suffix must set the prerelease flag")
	}
}

func TestCargoVersionRuleMatchesRealOutput(t *testing.T) {
	got, err := cargoVersionRule.Normalize(realCargoVersion)
	if err != nil {
		t.Fatalf("normalize real cargo --version: %v", err)
	}
	if got.Major != 1 || got.Minor != 91 || got.Patch != 0 {
		t.Fatalf("got %d.%d.%d, want 1.91.0", got.Major, got.Minor, got.Patch)
	}
}

func TestSwiftVersionRuleMatchesAppleAndOpenSourceForms(t *testing.T) {
	cases := []struct {
		name       string
		in         string
		maj        int
		min        int
		patch      int
		prerelease bool
	}{
		// Only the first vector was measured. The remaining three are
		// upstream-documented shapes of the open-source distribution,
		// which was not reachable on either probed host; the emitted
		// evidence records them as unmeasured, and a driver contract must
		// re-measure them on a host that has one.
		{"apple release, MEASURED", realSwiftCompilerVersion, 6, 3, 2, false},
		{"open source release, unmeasured", "Swift version 6.0.3 (swift-6.0.3-RELEASE)", 6, 0, 3, false},
		{"open source two component, unmeasured", "Swift version 6.1 (swift-6.1-RELEASE)", 6, 1, 0, false},
		{"development snapshot, unmeasured", "Swift version 6.2-dev (swift-6.2-DEVELOPMENT-SNAPSHOT-2025-01-01-a)", 6, 2, 0, true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, err := swiftVersionRule.Normalize(c.in)
			if err != nil {
				t.Fatalf("normalize %q: %v", c.in, err)
			}
			if got.Major != c.maj || got.Minor != c.min || got.Patch != c.patch {
				t.Fatalf("got %d.%d.%d, want %d.%d.%d", got.Major, got.Minor, got.Patch, c.maj, c.min, c.patch)
			}
			if got.Prerelease != c.prerelease {
				t.Fatalf("prerelease = %t, want %t", got.Prerelease, c.prerelease)
			}
		})
	}
}

// The measured hazard: `swift --version` writes its driver line to stderr with
// no trailing newline, so anything that merges the streams produces one
// concatenated line. The rule is anchored, so the merged line must not match —
// that is what forces the registry entry to name a stream.
func TestSwiftVersionRuleRejectsMergedStreamLine(t *testing.T) {
	merged := "swift-driver version: 1.148.6 " + realSwiftCompilerVersion
	if _, err := swiftVersionRule.Normalize(merged); err == nil {
		t.Fatal("an anchored rule must not match the merged-stream line")
	}
}

// A snapshot that spells its prerelease status only inside the parenthetical
// must still be flagged. Section 2.4 rejects a prerelease host outright, so a
// missed marker is not a cosmetic slip: it resolves a snapshot as a release.
func TestSwiftSnapshotMarkerAloneSetsPrerelease(t *testing.T) {
	got, err := swiftVersionRule.Normalize("Swift version 6.2 (swift-6.2-DEVELOPMENT-SNAPSHOT-2025-01-01-a)")
	if err != nil {
		t.Fatalf("normalize: %v", err)
	}
	if !got.Prerelease {
		t.Fatal("a DEVELOPMENT-SNAPSHOT tag must set the prerelease flag even with no -dev suffix")
	}
}

func TestKotlinJVMRuleReadsStderrBanner(t *testing.T) {
	got, err := kotlinJVMVersionRule.Normalize(realKotlincStderr)
	if err != nil {
		t.Fatalf("normalize real kotlinc -version stderr: %v", err)
	}
	if got.Major != 2 || got.Minor != 4 || got.Patch != 10 {
		t.Fatalf("got %d.%d.%d, want 2.4.10", got.Major, got.Minor, got.Patch)
	}
}

// The empty stdout is the whole point: a rule that read stdout would report the
// version as undetermined on a host where the compiler is present and working.
func TestKotlinJVMRuleFindsNothingOnStdout(t *testing.T) {
	if _, err := kotlinJVMVersionRule.Normalize(""); err == nil {
		t.Fatal("kotlinc writes nothing to stdout; reading it must be undetermined, not a default")
	}
}

func TestKotlinBackendClassification(t *testing.T) {
	cases := map[string]string{
		"info: kotlinc-jvm 2.4.10 (JRE 26.0.1)": "jvm",
		"info: kotlinc-native 2.4.10":           "native",
		"info: kotlinc-js 2.4.10":               "js",
		"info: kotlinc-wasm 2.4.10":             "wasm",
		"info: kotlinc 2.4.10":                  "unqualified",
		"something else entirely":               "unknown",
	}
	for banner, want := range cases {
		if got := kotlinBackendFromVersionBanner(banner); got != want {
			t.Errorf("banner %q: got backend %q, want %q", banner, got, want)
		}
	}
}

func TestNormalizeRejectsAmbiguousOutput(t *testing.T) {
	two := "release: 1.91.0\nrelease: 1.92.0\n"
	_, err := rustcVersionRule.Normalize(two)
	if err == nil {
		t.Fatal("two matching lines must be undetermined, not first-wins")
	}
	var u *ErrUndetermined
	if !asUndetermined(err, &u) {
		t.Fatalf("want *ErrUndetermined, got %T", err)
	}
}

func TestNormalizeRejectsUnboundedOutput(t *testing.T) {
	var s string
	for i := 0; i < maxProbeLines+2; i++ {
		s += "noise\n"
	}
	if _, err := rustcVersionRule.Normalize(s); err == nil {
		t.Fatal("output beyond the line bound must be undetermined")
	}
}

func TestCanonicalCompare(t *testing.T) {
	mk := func(a, b, c int) Canonical { return Canonical{Major: a, Minor: b, Patch: c} }
	cases := []struct {
		l, r Canonical
		want int
	}{
		{mk(1, 91, 0), mk(1, 91, 0), 0},
		{mk(1, 91, 0), mk(1, 99, 0), -1},
		{mk(2, 0, 0), mk(1, 99, 9), 1},
		{mk(1, 23, 4), mk(1, 23, 5), -1},
	}
	for _, c := range cases {
		if got := c.l.Compare(c.r); got != c.want {
			t.Errorf("%v vs %v: got %d, want %d", c.l, c.r, got, c.want)
		}
	}
}

func TestParseCanonicalLiteralRejectsNonCanonicalForms(t *testing.T) {
	bad := []string{"1.91", "v1.91.0", "1.91.0-nightly", "01.91.0", "1.91.0+build", "1.91.*", "go1.23.0", "swift-6.0.3", ""}
	for _, s := range bad {
		if _, err := ParseCanonicalLiteral(s); err == nil {
			t.Errorf("%q must not parse as a canonical literal", s)
		}
	}
	if _, err := ParseCanonicalLiteral("1.91.0"); err != nil {
		t.Errorf("1.91.0 must parse: %v", err)
	}
}

func TestRequirementSatisfaction(t *testing.T) {
	host := Canonical{Major: 1, Minor: 91}
	cases := []struct {
		name string
		req  Requirement
		want bool
	}{
		{"at_least below host", Requirement{Kind: "at_least", Min: "1.85.0"}, true},
		{"at_least at host", Requirement{Kind: "at_least", Min: "1.91.0"}, true},
		{"at_least above host", Requirement{Kind: "at_least", Min: "1.99.0"}, false},
		{"exact match", Requirement{Kind: "exact", Equals: "1.91.0"}, true},
		{"exact mismatch", Requirement{Kind: "exact", Equals: "1.90.0"}, false},
		{"range inside", Requirement{Kind: "range", Min: "1.85.0", Below: "2.0.0"}, true},
		{"range at upper bound", Requirement{Kind: "range", Min: "1.85.0", Below: "1.91.0"}, false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, err := c.req.Satisfies(host)
			if err != nil {
				t.Fatalf("Satisfies: %v", err)
			}
			if got != c.want {
				t.Fatalf("got %t, want %t", got, c.want)
			}
		})
	}
}

// Section 2.4: a prerelease host satisfies nothing. It is not ranked below or
// above anything, because no cross-language prerelease order exists.
func TestPrereleaseHostSatisfiesNothing(t *testing.T) {
	host := Canonical{Major: 1, Minor: 99, Patch: 0, Prerelease: true}
	for _, r := range []Requirement{
		{Kind: "at_least", Min: "1.0.0"},
		{Kind: "exact", Equals: "1.99.0"},
		{Kind: "range", Min: "1.0.0", Below: "2.0.0"},
	} {
		got, err := r.Satisfies(host)
		if err != nil {
			t.Fatalf("Satisfies: %v", err)
		}
		if got {
			t.Fatalf("requirement %+v must not be satisfied by a prerelease host", r)
		}
	}
}

func TestRangeMinMustBeStrictlyBelowBound(t *testing.T) {
	_, err := Requirement{Kind: "range", Min: "1.91.0", Below: "1.91.0"}.Satisfies(Canonical{Major: 1, Minor: 91})
	if err == nil {
		t.Fatal("a range whose min is not strictly below its bound must be an error")
	}
}

func asUndetermined(err error, out **ErrUndetermined) bool {
	u, ok := err.(*ErrUndetermined)
	if ok {
		*out = u
	}
	return ok
}
