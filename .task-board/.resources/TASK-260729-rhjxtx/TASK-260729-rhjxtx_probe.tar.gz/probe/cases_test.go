package main

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

// The regression for review finding 1.
//
// Before the case table existed, swift.negative.selector-swift-version-file was
// declared package_selector by the stub list that produced not_run records and
// none by the builder that measured it, so the macOS and Windows fixtures
// disagreed about the same case ID's expected class. This test compares the
// declared expectation against the expectation an emitted case actually carries,
// for every case the probe can produce, and fails on any difference.
func TestEmittedCasesCarryTheDeclaredExpectation(t *testing.T) {
	for _, c := range allEmittedCases(t) {
		s := spec(c.ID)
		if c.Expected != s.Expected {
			t.Errorf("case %s: emitted expected_gate_class %q, declared %q", c.ID, c.Expected, s.Expected)
		}
		if c.ExpectDecidableBeforeCompilerWork != s.ExpectEarly {
			t.Errorf("case %s: emitted expect_early %t, declared %t", c.ID, c.ExpectDecidableBeforeCompilerWork, s.ExpectEarly)
		}
		if c.Kind != s.Kind || c.Title != s.Title || c.Language != s.Language {
			t.Errorf("case %s: emitted (%s/%s/%q) differs from declared (%s/%s/%q)",
				c.ID, c.Language, c.Kind, c.Title, s.Language, s.Kind, s.Title)
		}
	}
}

// A not_run case and an executed case of the same ID must be interchangeable in
// every field except the measurement, because a consumer reading two fixtures
// from two hosts sees exactly that pair.
func TestNotRunAndExecutedCasesAgreeOnTheContract(t *testing.T) {
	declared := map[string]Case{}
	for _, lang := range []string{"rust", "swift", "kotlin"} {
		for _, c := range notRunLanguage(lang, "absent") {
			declared[c.ID] = c
		}
	}
	for _, c := range allEmittedCases(t) {
		d, ok := declared[c.ID]
		if !ok {
			t.Fatalf("case %s is emitted but has no not_run twin", c.ID)
		}
		if c.Expected != d.Expected || c.ExpectDecidableBeforeCompilerWork != d.ExpectDecidableBeforeCompilerWork {
			t.Errorf("case %s: executed (%s, early=%t) and not_run (%s, early=%t) disagree",
				c.ID, c.Expected, c.ExpectDecidableBeforeCompilerWork,
				d.Expected, d.ExpectDecidableBeforeCompilerWork)
		}
	}
}

// allEmittedCases runs every probe against the current host. Roots come from
// the environment the test process was given, so on a host with no toolchain at
// all this still exercises the not_run path; on a host with Rust and Swift it
// additionally exercises every executed builder.
func allEmittedCases(t *testing.T) []Case {
	t.Helper()
	env := &probeEnv{
		work:       t.TempDir(),
		roots:      map[string]string{"rust": os.Getenv("PROBE_TEST_RUST"), "swift": os.Getenv("PROBE_TEST_SWIFT"), "kotlin": kotlinStubRoot(t)},
		kotlincJVM: os.Getenv("PROBE_TEST_KOTLINC_JVM"),
	}
	var out []Case
	for _, p := range []func(*probeEnv) (ToolchainEvid, []Case){probeRust, probeSwift, probeKotlin} {
		_, cases := p(env)
		out = append(out, cases...)
	}
	if len(out) != len(caseTable()) {
		t.Fatalf("probes emitted %d cases, the table declares %d", len(out), len(caseTable()))
	}
	return out
}

func TestCaseTableIDsAreUniqueAndNamespaced(t *testing.T) {
	seen := map[string]bool{}
	for _, s := range caseTable() {
		if seen[s.ID] {
			t.Fatalf("duplicate case ID %s", s.ID)
		}
		seen[s.ID] = true
		if !strings.HasPrefix(s.ID, s.Language+".") {
			t.Errorf("case %s is not namespaced by its language %q", s.ID, s.Language)
		}
		if s.Kind != "positive" && s.Kind != "negative" {
			t.Errorf("case %s: kind %q", s.ID, s.Kind)
		}
		if s.Title == "" {
			t.Errorf("case %s carries no title", s.ID)
		}
	}
}

// Every language must carry at least one malformed, one future-version, one
// incompatible-target, and one forbidden-selector control, or an honest record
// of why it cannot. This is the acceptance criterion stated as a test.
func TestEveryLanguageCarriesNegativeControls(t *testing.T) {
	kinds := map[string]map[string]bool{}
	for _, s := range caseTable() {
		if kinds[s.Language] == nil {
			kinds[s.Language] = map[string]bool{}
		}
		kinds[s.Language][string(s.Expected)] = true
	}
	for _, lang := range []string{"rust", "swift", "kotlin"} {
		if !kinds[lang][string(GateTargetRepresentability)] {
			t.Errorf("%s carries no incompatible-target control", lang)
		}
		if !kinds[lang][string(GatePackageSelector)] && !kinds[lang][string(GateBackendIdentity)] {
			t.Errorf("%s carries no forbidden-selector or backend-identity control", lang)
		}
	}
	// Rust and Swift bind a project-metadata file, so both carry a malformed
	// and a future-version control over it. Kotlin/Native binds none — that
	// absence is the finding, recorded as a metadata source rather than
	// invented as a case.
	for _, lang := range []string{"rust", "swift"} {
		if !kinds[lang][string(GateRepresentability)] {
			t.Errorf("%s carries no malformed control", lang)
		}
		if !kinds[lang][string(GateHostVersion)] {
			t.Errorf("%s carries no future-version control", lang)
		}
	}
	if kinds["kotlin"][string(GateRepresentability)] || kinds["kotlin"][string(GateHostVersion)] {
		t.Error("kotlin declares a metadata-file control, but no Kotlin/Native project-metadata file has been identified; " +
			"if one is added, kotlinMetadataSources must stop reporting the boundary as open")
	}
}

// kotlinStubRoot builds a synthetic Kotlin/Native root so the supplied-root
// branch is genuinely executed by the test suite.
//
// It is emphatically NOT evidence about Kotlin/Native. It emits the declared
// output shapes the probe's parsers are written against, so what it verifies is
// the probe's own normalization, target-membership, and case-construction
// logic. Whether a real konan compiler produces those shapes stays UNVERIFIED
// until a qualified host exists, and no fixture is ever generated from this
// root.
func kotlinStubRoot(t *testing.T) string {
	t.Helper()
	if runtime.GOOS == "windows" {
		// The stub is a POSIX shell script. Skipping here keeps the Windows
		// run honest rather than silently reporting a branch as covered.
		return ""
	}
	root := t.TempDir()
	bin := filepath.Join(root, "bin")
	if err := os.MkdirAll(bin, 0o755); err != nil {
		t.Fatal(err)
	}
	script := `#!/bin/sh
case "$1" in
-version)
  echo "info: kotlinc-native 2.1.0 (JRE 21.0.1)" >&2
  exit 0 ;;
-list-targets)
  echo "macos_arm64:                  (default)"
  echo "macos_x64:"
  echo "ios_arm64:"
  exit 0 ;;
esac
if [ "$1" = "-target" ]; then
  case "$2" in
  macos_arm64) echo "Compiling for $2"; exit 0 ;;
  *) echo "error: target $2 is not supported" >&2; exit 1 ;;
  esac
fi
exit 2
`
	if err := os.WriteFile(filepath.Join(bin, "kotlinc-native"), []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	return root
}

// writeStubBanner rewrites the stub's -version answer so the wrong-backend
// branch can be exercised.
func writeStubBanner(t *testing.T, root, banner string) {
	t.Helper()
	script := "#!/bin/sh\nif [ \"$1\" = \"-version\" ]; then echo '" + banner + "' >&2; exit 0; fi\nexit 2\n"
	if err := os.WriteFile(filepath.Join(root, "bin", "kotlinc-native"), []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
}
