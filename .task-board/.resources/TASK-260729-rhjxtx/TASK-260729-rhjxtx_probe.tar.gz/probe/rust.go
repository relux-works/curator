package main

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"strings"
)

// rustPrimaryRelpath is the fixed relpath of the primary executable inside the
// fingerprinted Rust root. `cargo` rather than `rustc` because the graph phase
// is a cargo command; both live in the same tree and both are recorded.
func rustPrimaryRelpath() string {
	if isWindows() {
		return `bin\cargo.exe`
	}
	return "bin/cargo"
}

func rustcRelpath() string {
	if isWindows() {
		return `bin\rustc.exe`
	}
	return "bin/rustc"
}

const (
	rustGuidanceID = "toolchain.rust.absent.primary-source"
	rustCargoTOML  = `[package]
name = "%s"
version = "0.1.0"
edition = "2021"
rust-version = "%s"
`
	rustMainRS = "fn main() {}\n"
)

func probeRust(env *probeEnv) (ToolchainEvid, []Case) {
	ev := ToolchainEvid{
		ToolchainID: "rust",
		Companions:  []string{},
		Declaration: Declaration{Channel: "probe_explicit_root", Root: env.roots["rust"], PrimaryRelpath: rustPrimaryRelpath()},
		MetadataSources: []MetadataSource{
			{
				File:                     "Cargo.toml",
				ReadableWithoutExecution: true,
				ReaderCommand:            "cargo metadata --no-deps --format-version 1 --offline",
				Fields: []MetadataField{
					{Name: "package.rust-version", Disposition: "compared", Measured: true,
						Rationale: "an MSRV assertion about the resolved toolchain; surfaced by cargo metadata as packages[].rust_version without compiling anything"},
					{Name: "workspace.package.rust-version", Disposition: "compared", Measured: false,
						Rationale: "same assertion inherited through a workspace; the reader command resolves the inheritance"},
				},
			},
			{
				File:                     "rust-toolchain.toml",
				ReadableWithoutExecution: true,
				ReaderCommand:            "read the file; never hand it to a shim",
				Fields: []MetadataField{
					{Name: "toolchain.path", Disposition: "forbidden", Measured: true,
						Rationale: "names where a toolchain comes from; measured to change which rustc runs"},
					{Name: "toolchain.channel", Disposition: "compared", Measured: true,
						Rationale: "a version literal or `stable` is an assertion and is never honored; `nightly`, `beta` and dated channels assert a prerelease host, which is never resolved"},
					{Name: "toolchain.components", Disposition: "ignored", Measured: false, Rationale: "selects distribution contents, which the trusted root already fixes"},
					{Name: "toolchain.targets", Disposition: "ignored", Measured: false, Rationale: "selects installable targets; target admission is manager-owned"},
					{Name: "toolchain.profile", Disposition: "ignored", Measured: false, Rationale: "selects distribution contents"},
				},
			},
			{
				File:                     "rust-toolchain",
				ReadableWithoutExecution: true,
				ReaderCommand:            "read the file",
				Fields: []MetadataField{
					{Name: "<bare channel string>", Disposition: "compared", Measured: false,
						Rationale: "the legacy one-line form of toolchain.channel; the same classifier applies"},
				},
			},
		},
	}

	root := env.roots["rust"]
	if root == "" {
		ev.Availability = Unavailable
		ev.Reason = "no trusted Rust root was supplied to the probe; the probe does not search PATH, an inherited environment, or a version-manager shim for one"
		ev.GuidanceID = rustGuidanceID
		return ev, notRunLanguage("rust", ev.Reason)
	}
	cargo := filepath.Join(root, filepath.FromSlash(rustPrimaryRelpath()))
	rustc := filepath.Join(root, filepath.FromSlash(rustcRelpath()))
	ev.Declaration.PrimaryPresent = fileExists(cargo)
	if !ev.Declaration.PrimaryPresent || !fileExists(rustc) {
		ev.Availability = Unavailable
		ev.Reason = fmt.Sprintf("supplied root %q does not carry both %s and %s", root, rustPrimaryRelpath(), rustcRelpath())
		ev.GuidanceID = rustGuidanceID
		return ev, notRunLanguage("rust", ev.Reason)
	}

	vr := execRun(env.work, nil, rustc, "-vV")
	ev.VersionProbe = &vr
	ne := &NormEvid{RuleID: rustcVersionRule.ID, Stream: rustcVersionRule.Stream, Pattern: rustcVersionRule.Pattern.String(), Verified: true}
	if c, err := rustcVersionRule.Normalize(vr.fullStdout); err != nil {
		ne.Undetermined = err.Error()
	} else {
		ne.Canonical = c
	}
	ev.Normalization = ne
	ev.Availability = Available

	tr := execRun(env.work, nil, rustc, "--print", "host-tuple")
	ev.TargetProbe = &tr
	host := strings.TrimSpace(tr.fullStdout)
	ev.NativeTarget = &TargetIdenti{
		Reported:   host,
		StableForm: host,
		Source:     "rustc --print host-tuple",
	}
	ev.Notes = append(ev.Notes,
		"`rustc -vV` also carries `host:`, identical to `--print host-tuple` on the probed toolchain; `--print host-tuple` is the narrower surface and is preferred.",
		"The Rust host tuple carries no platform-version component, so unlike the Swift target triple it is directly usable as a native-target identity.",
		"Measured: cargo resolves `rustc` by name and fails with \"could not execute process `rustc -vV` (never executed)\" under a minimal PATH that excludes the trusted root's bin directory. The driver MUST pass RUSTC explicitly, or the second node of its process graph is chosen by PATH order rather than by the fingerprinted closure.",
	)

	var cases []Case
	cases = append(cases, rustManifestCases(env, cargo)...)
	cases = append(cases, rustTargetCases(env, root, rustc, cargo)...)
	cases = append(cases, rustSelectorCases(env)...)
	return ev, cases
}

// cargoCompilingMarker is cargo's own compile-phase progress line. It is the
// measured signal that cargo left the graph phase and started a compiler.
const cargoCompilingMarker = "Compiling "

func rustManifestCases(env *probeEnv, cargo string) []Case {
	specs := []struct {
		id, pkg, msrv string
	}{
		{"rust.positive.msrv-below-host", "probe-positive", "1.85"},
		{"rust.negative.msrv-future", "probe-future", "1.99"},
		{"rust.negative.msrv-malformed", "probe-malformed", "not-a-version"},
	}
	var out []Case
	for _, s := range specs {
		dir := filepath.Join(env.work, "rs", s.pkg)
		f1, err1 := writeFixture(env.work, filepath.ToSlash(filepath.Join("rs", s.pkg, "Cargo.toml")), fmt.Sprintf(rustCargoTOML, s.pkg, s.msrv))
		f2, err2 := writeFixture(env.work, filepath.ToSlash(filepath.Join("rs", s.pkg, "src", "main.rs")), rustMainRS)
		if err1 != nil || err2 != nil {
			out = append(out, notRunCase(s.id, "could not write the fixture corpus"))
			continue
		}

		cenv := cargoEnv(env, s.pkg)
		meta := execRun(dir, cenv, cargo, "metadata", "--no-deps", "--format-version", "1", "--offline")
		build := execRun(dir, cenv, cargo, "build", "--offline")

		obs := Observation{
			MetadataRan:              true,
			MetadataExit:             meta.ExitCode,
			MetadataExtractedValue:   cargoRustVersion(meta.fullStdout),
			BuildRan:                 true,
			BuildExit:                build.ExitCode,
			BuildCompilationEvidence: compilationMarker(build, cargoCompilingMarker),
		}
		c := newCase(s.id)
		c.Fixtures = sortedFixtureFiles([]FixtureFile{f1, f2})
		c.Runs = []Run{meta, build}
		c.ManagerObligation = rustManifestObligation(c.Expected)
		out = append(out, finish(c, obs))
	}
	return out
}

func rustManifestObligation(g GateClass) string {
	switch g {
	case GateHostVersion:
		return "Read packages[].rust_version from `cargo metadata --no-deps` in the graph phase and compare it against the resolved toolchain identity. Cargo's own rejection is a build-time error, so a driver that waits for it has already entered the compile phase."
	case GateRepresentability:
		return "No comparison is needed: the graph command already refuses the manifest, so this is a Stage B file-shape rejection with no host input."
	default:
		return ""
	}
}

// cargoRustVersion extracts packages[0].rust_version from cargo metadata
// output. A missing or malformed document yields the empty string, which the
// classifier reads as "the manager holds no assertion".
func cargoRustVersion(stdout string) string {
	var doc struct {
		Packages []struct {
			RustVersion string `json:"rust_version"`
		} `json:"packages"`
	}
	if err := json.Unmarshal([]byte(stdout), &doc); err != nil {
		return ""
	}
	if len(doc.Packages) == 0 {
		return ""
	}
	return doc.Packages[0].RustVersion
}

func rustTargetCases(env *probeEnv, root, rustc, cargo string) []Case {
	specs := []struct {
		id, triple string
	}{
		{"rust.negative.target-unknown", "not-a-real-target"},
		{"rust.negative.target-std-absent", "x86_64-unknown-linux-gnu"},
	}
	var out []Case
	for _, s := range specs {
		// The compiler's own answer: does it know this triple at all?
		targetPrint := execRun(env.work, nil, rustc, "--print", "target-libdir", "--target", s.triple)
		// The manager-owned answer: is the target's standard library
		// actually inside the fingerprinted tree? rustc answers the first
		// question with exit 0 and a path even when the answer to the
		// second is no, so the two are measured separately.
		stdDir := filepath.Join(root, "lib", "rustlib", s.triple, "lib")
		stdPresent := dirExists(stdDir)

		dir := filepath.Join(env.work, "rs", "probe-positive")
		build := execRun(dir, cargoEnv(env, "target-"+s.triple), cargo, "build", "--offline", "--target", s.triple)

		obs := Observation{
			TargetPrintRan:           true,
			TargetPrintExit:          targetPrint.ExitCode,
			TargetStdChecked:         targetPrint.ExitCode == 0,
			TargetStdPresent:         stdPresent,
			BuildRan:                 true,
			BuildExit:                build.ExitCode,
			BuildCompilationEvidence: compilationMarker(build, cargoCompilingMarker),
		}
		c := newCase(s.id)
		c.Runs = []Run{targetPrint, build}
		c.ManagerObligation = "Membership in `rustc --print target-list` is representability only. Admission requires the manager to stat <root>/lib/rustlib/<target>/lib inside the fingerprinted tree; `rustc --print target-libdir` returns exit 0 and a path for a target whose standard library is absent."
		if c.Expected == GateTargetRepresentability {
			c.ManagerObligation = "An unknown triple is refused by `rustc --print target-libdir --target <t>` with a non-zero exit before any compilation, so representability needs no extra manager check."
		}
		out = append(out, finish(c, obs))
	}
	return out
}

func rustSelectorCases(env *probeEnv) []Case {
	shim := env.rustShim
	specs := []struct {
		id, dir, toml   string
		unreachableDist bool
	}{
		{"rust.negative.selector-toolchain-path", "probe-tc-path",
			"[toolchain]\npath = \"/nonexistent/trusted/root\"\n", false},
		{"rust.negative.selector-toolchain-nightly", "probe-tc-nightly",
			"[toolchain]\nchannel = \"nightly\"\n", true},
	}
	var out []Case
	for _, s := range specs {
		base := newCase(s.id)
		base.ManagerObligation = "Resolve the concrete toolchain root directly and never through a version-manager shim. rust-toolchain.toml is then inert: the same directory that redirects the shim leaves a directly resolved rustc unchanged."
		if shim == "" || env.roots["rust"] == "" {
			out = append(out, notRunCase(s.id, "no rustup shim path was supplied (-rust-shim), so shim-versus-root cannot be measured"))
			continue
		}
		dir := filepath.Join(env.work, "rs", s.dir)
		f1, _ := writeFixture(env.work, filepath.ToSlash(filepath.Join("rs", s.dir, "Cargo.toml")), fmt.Sprintf(rustCargoTOML, s.dir, "1.85"))
		f2, _ := writeFixture(env.work, filepath.ToSlash(filepath.Join("rs", s.dir, "src", "main.rs")), rustMainRS)
		f3, _ := writeFixture(env.work, filepath.ToSlash(filepath.Join("rs", s.dir, "rust-toolchain.toml")), s.toml)

		var delta []string
		if s.unreachableDist {
			// Point the distribution endpoints at a closed loopback port.
			// The attempt is then observable and cannot succeed, so the
			// measurement records that the shim tries to install without
			// this probe ever installing anything.
			delta = []string{"RUSTUP_DIST_SERVER=http://127.0.0.1:1", "RUSTUP_UPDATE_ROOT=http://127.0.0.1:1"}
		}
		viaShim := execRun(dir, delta, shim, "--version")
		viaRoot := execRun(dir, nil, filepath.Join(env.roots["rust"], filepath.FromSlash(rustcRelpath())), "--version")

		obs := Observation{
			SelectorMeasured:             true,
			SelectorShimExit:             viaShim.ExitCode,
			SelectorRootExit:             viaRoot.ExitCode,
			SelectorShimAttemptedInstall: strings.Contains(viaShim.fullStderr, "syncing channel updates") || strings.Contains(viaShim.fullStderr, "downloading"),
		}
		base.Fixtures = sortedFixtureFiles([]FixtureFile{f1, f2, f3})
		base.Runs = []Run{viaShim, viaRoot}
		out = append(out, finish(base, obs))
	}
	return out
}

// cargoEnv is the operation-private environment every cargo invocation runs
// under.
//
// RUSTC is not a convenience. Cargo resolves the compiler by name, so on a
// PATH that does not contain the trusted root's bin directory it fails with
// "could not execute process `rustc -vV` (never executed)" before it does
// anything else. That is measured behaviour from this probe's first run, and it
// means a Rust driver cannot start cargo with a manager-owned minimal PATH and
// expect the fingerprinted compiler to be found: it MUST name the compiler
// explicitly, or the process graph's second node is decided by PATH order.
func cargoEnv(env *probeEnv, targetDirLeaf string) []string {
	return []string{
		"CARGO_TARGET_DIR=" + filepath.Join(env.work, "cargo-target", targetDirLeaf),
		"RUSTC=" + filepath.Join(env.roots["rust"], filepath.FromSlash(rustcRelpath())),
	}
}

func rustConsumers() []string { return []string{"TASK-260728-12pnm1"} }
