package main

import (
	"strings"
	"testing"
)

// The observations below are the ones the macOS run actually recorded. They
// pin the classifier against real exit codes rather than invented ones.

func TestClassifyRustFutureMSRVIsAHostGateNotRepresentability(t *testing.T) {
	// Measured: `cargo metadata` exits 0 and reports rust_version "1.99";
	// `cargo build` exits 101 with "requires rustc 1.99".
	obs := Observation{
		MetadataRan: true, MetadataExit: 0, MetadataExtractedValue: "1.99",
		BuildRan: true, BuildExit: 101, BuildStartedCompilation: false,
	}
	got, err := Classify(obs)
	if err != nil {
		t.Fatal(err)
	}
	if got != GateHostVersion {
		t.Fatalf("got %s, want %s", got, GateHostVersion)
	}
	if !DecidableBeforeCompilerWork(obs) {
		t.Fatal("the value was surfaced by the graph command, so the comparison is manager-side and needs no compiler")
	}
}

func TestClassifyRustMalformedMSRVIsRepresentability(t *testing.T) {
	// Measured: both commands exit 101 with the same manifest parse error.
	obs := Observation{MetadataRan: true, MetadataExit: 101, BuildRan: true, BuildExit: 101}
	got, err := Classify(obs)
	if err != nil {
		t.Fatal(err)
	}
	if got != GateRepresentability {
		t.Fatalf("got %s, want %s", got, GateRepresentability)
	}
	if !DecidableBeforeCompilerWork(obs) {
		t.Fatal("the graph command already rejected it")
	}
}

// This is the regression the whole two-command design exists to prevent: with
// only the build exit code, the future-MSRV case and the malformed case are
// indistinguishable, and a classifier built on it reports a representable
// future release as unrepresentable.
func TestBuildExitAloneCannotSeparateTheTwo(t *testing.T) {
	future := Observation{MetadataRan: true, MetadataExit: 0, MetadataExtractedValue: "1.99", BuildRan: true, BuildExit: 101}
	malformed := Observation{MetadataRan: true, MetadataExit: 101, BuildRan: true, BuildExit: 101}
	if future.BuildExit != malformed.BuildExit {
		t.Fatal("fixture drift: the two cases must share a build exit code for this regression to be meaningful")
	}
	f, _ := Classify(future)
	m, _ := Classify(malformed)
	if f == m {
		t.Fatal("the classifier collapsed two distinct gates that share a build exit code")
	}
}

func TestClassifyUnknownTargetIsTargetRepresentability(t *testing.T) {
	// Measured: `rustc --print target-libdir --target not-a-real-target`
	// exits 1 with "could not find specification for target".
	obs := Observation{TargetPrintRan: true, TargetPrintExit: 1}
	got, err := Classify(obs)
	if err != nil {
		t.Fatal(err)
	}
	if got != GateTargetRepresentability {
		t.Fatalf("got %s, want %s", got, GateTargetRepresentability)
	}
}

// Measured: rustc reports a target-libdir path with exit 0 for a target whose
// standard library is not installed, and cargo only fails after it has started
// compiling. Both facts are load-bearing for the Rust driver contract.
func TestClassifyKnownTargetWithoutStdIsAHostGateDiscoverableEarly(t *testing.T) {
	obs := Observation{
		TargetPrintRan: true, TargetPrintExit: 0,
		TargetStdChecked: true, TargetStdPresent: false,
		BuildRan: true, BuildExit: 101, BuildStartedCompilation: true,
	}
	got, err := Classify(obs)
	if err != nil {
		t.Fatal(err)
	}
	if got != GateTargetHost {
		t.Fatalf("got %s, want %s", got, GateTargetHost)
	}
	if !UpstreamRejectionArrivesAfterCompilation(obs) {
		t.Fatal("cargo's own rejection arrives after compilation starts; that is the reason the manager must own the preflight")
	}
	if !DecidableBeforeCompilerWork(obs) {
		t.Fatal("the manager-side standard-library check resolves it before any compiler runs")
	}
}

// Without the manager-side check there is nothing left to decide on, and the
// probe must say so rather than credit an early decision it did not make.
func TestTargetHostGateIsNotEarlyWithoutTheManagerSideCheck(t *testing.T) {
	obs := Observation{
		TargetPrintRan: true, TargetPrintExit: 0,
		TargetStdChecked: false,
		BuildRan:         true, BuildExit: 101, BuildStartedCompilation: true,
	}
	if DecidableBeforeCompilerWork(obs) {
		t.Fatal("with no standard-library check, rustc's exit-0 target-libdir answer decides nothing")
	}
}

func TestClassifySelectorFromShimVersusRootDisagreement(t *testing.T) {
	// Measured: through the rustup shim the directory carrying
	// rust-toolchain.toml exits 1; through the trusted root it exits 0.
	obs := Observation{SelectorMeasured: true, SelectorShimExit: 1, SelectorRootExit: 0}
	got, err := Classify(obs)
	if err != nil {
		t.Fatal(err)
	}
	if got != GatePackageSelector {
		t.Fatalf("got %s, want %s", got, GatePackageSelector)
	}
}

func TestClassifySelectorFromAttemptedInstallEvenWhenExitsAgree(t *testing.T) {
	obs := Observation{SelectorMeasured: true, SelectorShimExit: 1, SelectorRootExit: 1, SelectorShimAttemptedInstall: true}
	got, err := Classify(obs)
	if err != nil {
		t.Fatal(err)
	}
	if got != GatePackageSelector {
		t.Fatalf("got %s, want %s", got, GatePackageSelector)
	}
}

// The .swift-version case is a selector case that is expected to find no
// selection: the file must leave a directly resolved toolchain alone.
func TestClassifySelectorAgreementIsNoGate(t *testing.T) {
	obs := Observation{SelectorMeasured: true, SelectorShimExit: 0, SelectorRootExit: 0}
	got, err := Classify(obs)
	if err != nil {
		t.Fatal(err)
	}
	if got != GateNone {
		t.Fatalf("got %s, want %s", got, GateNone)
	}
}

func TestClassifyBackendIdentity(t *testing.T) {
	if got, _ := Classify(Observation{Backend: "jvm"}); got != GateBackendIdentity {
		t.Fatalf("a JVM front end must not satisfy a Kotlin/Native requirement, got %s", got)
	}
	if got, _ := Classify(Observation{Backend: "native"}); got != GateNone {
		t.Fatalf("the native backend is the admitted one, got %s", got)
	}
}

func TestClassifyRefusesAnEmptyObservation(t *testing.T) {
	if _, err := Classify(Observation{}); err == nil {
		t.Fatal("an observation with no measurement must be an error, not a silent pass")
	}
}

// finish is the only place a verdict is produced. These two tests pin that it
// can actually disagree with the case table, which is what makes the probe a
// measurement rather than a restatement.
func TestFinishReportsDivergenceOnClassMismatch(t *testing.T) {
	// The malformed-MSRV case expects representability. Hand it the
	// future-MSRV observation, which classifies as a host gate.
	c := finish(newCase("rust.negative.msrv-malformed"), Observation{
		MetadataRan: true, MetadataExit: 0, MetadataExtractedValue: "1.99", BuildRan: true, BuildExit: 101,
	})
	if c.Verdict != "divergence" {
		t.Fatalf("verdict = %q, want divergence", c.Verdict)
	}
}

func TestFinishReportsDivergenceWhenTheEarlyDecisionIsMissing(t *testing.T) {
	// The class still matches target_host, but with no manager-side check
	// nothing resolved it before a compiler ran.
	c := finish(newCase("rust.negative.target-std-absent"), Observation{
		TargetPrintRan: true, TargetPrintExit: 0, TargetStdChecked: false,
		BuildRan: true, BuildExit: 101, BuildCompilationEvidence: "   Compiling probe v0.1.0",
	})
	if c.Observed != GateTargetHost {
		t.Fatalf("observed = %q, want target_host", c.Observed)
	}
	if c.Verdict != "divergence" {
		t.Fatalf("verdict = %q, want divergence: the class matched but nothing decided it early", c.Verdict)
	}
}

func TestFinishReportsMatchOnAgreement(t *testing.T) {
	c := finish(newCase("rust.negative.msrv-future"), Observation{
		MetadataRan: true, MetadataExit: 0, MetadataExtractedValue: "1.99", BuildRan: true, BuildExit: 101,
	})
	if c.Verdict != "match" {
		t.Fatalf("verdict = %q, want match", c.Verdict)
	}
}

func TestNotRunIsNeverAPass(t *testing.T) {
	cases := notRunLanguage("rust", "toolchain absent")
	if len(cases) == 0 {
		t.Fatal("the rust case table is empty")
	}
	for _, c := range cases {
		if c.Verdict != "not_run" {
			t.Fatalf("case %s: verdict %q", c.ID, c.Verdict)
		}
		if c.NotRunReason == "" {
			t.Fatalf("case %s: a not_run case must carry a reason", c.ID)
		}
		if c.Observed != "" {
			t.Fatalf("case %s: a not_run case must not carry an observed class", c.ID)
		}
	}
}

// Every case table entry must name at least one consuming design task,
// otherwise the evidence has no declared reader.
func TestEveryCaseNamesAConsumer(t *testing.T) {
	want := map[string]string{
		"rust":   "TASK-260728-12pnm1",
		"swift":  "TASK-260728-1yhuqi",
		"kotlin": "TASK-260728-168smo",
	}
	for lang := range want {
		for _, c := range notRunLanguage(lang, "x") {
			if len(c.Consumers) == 0 {
				t.Fatalf("case %s names no consumer", c.ID)
			}
			if c.Consumers[0] != want[lang] {
				t.Fatalf("case %s: consumer %q, want %q", c.ID, c.Consumers[0], want[lang])
			}
		}
	}
}

// The regression for review finding 2.
//
// BuildStartedCompilation used to be computed in the Swift target cases as
// `compile.ExitCode != 0 && targetPrint.ExitCode == 0`, which reports
// compilation for any target the compiler recognises and then refuses, without
// having observed a compiler process. finish() now derives the boolean from the
// measured line alone, so a builder that sets it directly is overwritten.
func TestCompilationBooleanIsDerivedFromMeasuredEvidenceOnly(t *testing.T) {
	// A builder claiming compilation with no measured line is corrected.
	c := finish(newCase("swift.negative.target-stdlib-absent"), Observation{
		TargetPrintRan: true, TargetPrintExit: 0, TargetStdChecked: true, TargetStdPresent: false,
		BuildRan: true, BuildExit: 1, BuildStartedCompilation: true,
	})
	if c.Observation.BuildStartedCompilation {
		t.Fatal("an unmeasured compilation claim survived finish()")
	}
	if c.UpstreamRejectsAfterCompilation {
		t.Fatal("upstream_rejects_after_compilation fired without measured evidence")
	}

	// A measured line sets it, and the line travels with the fixture.
	const line = "  /toolchain/usr/bin/swift-frontend -frontend -c -primary-file main.swift"
	c = finish(newCase("swift.negative.target-stdlib-absent"), Observation{
		TargetPrintRan: true, TargetPrintExit: 0, TargetStdChecked: true, TargetStdPresent: false,
		BuildRan: true, BuildExit: 1, BuildCompilationEvidence: line,
	})
	if !c.Observation.BuildStartedCompilation || !c.UpstreamRejectsAfterCompilation {
		t.Fatal("a measured compilation line did not set the derived fields")
	}
	if c.Observation.BuildCompilationEvidence != line {
		t.Fatalf("evidence line = %q", c.Observation.BuildCompilationEvidence)
	}
}

func TestCompilationMarkerReadsBothStreamsAndReturnsTheLine(t *testing.T) {
	r := Run{fullStderr: "warning: x\n   Compiling probe v0.1.0 (/tmp/probe)\nerror: y\n"}
	if got := compilationMarker(r, "Compiling "); got != "   Compiling probe v0.1.0 (/tmp/probe)" {
		t.Fatalf("stderr marker = %q", got)
	}
	r = Run{fullStdout: "Apple Swift version 6.3.2\n/x/swift-frontend -frontend -c -primary-file main.swift\n"}
	if got := compilationMarker(r, "swift-frontend -frontend"); got == "" {
		t.Fatal("stdout marker not found")
	}
	r = Run{fullStderr: "error: unknown target 'not-a-real-triple'\n"}
	if got := compilationMarker(r, "swift-frontend -frontend", "Compiling "); got != "" {
		t.Fatalf("a driver-level rejection produced a compilation marker: %q", got)
	}
}

func TestCompilationMarkerBoundsTheRecordedLine(t *testing.T) {
	long := "swift-frontend -frontend " + strings.Repeat("-flag ", 400)
	got := compilationMarker(Run{fullStdout: long}, "swift-frontend -frontend")
	if len(got) > markerLineBytes+4 {
		t.Fatalf("recorded marker is %d bytes", len(got))
	}
	if !strings.HasSuffix(got, "…") {
		t.Fatal("a truncated marker must say so")
	}
}

// finish() is the single authority on a case's declared contract, so a builder
// that restates an expectation cannot change what the fixture reports.
func TestFinishOverwritesARestatedExpectation(t *testing.T) {
	c := newCase("swift.negative.selector-swift-version-file")
	c.Expected = GatePackageSelector // exactly the drift finding 1 reported
	c.Title = "something else"
	out := finish(c, Observation{SelectorMeasured: true, SelectorShimExit: 0, SelectorRootExit: 0})
	if out.Expected != GateNone {
		t.Fatalf("expected = %q, want none from the case table", out.Expected)
	}
	if out.Title != spec(c.ID).Title {
		t.Fatalf("title = %q", out.Title)
	}
	if out.Verdict != "match" {
		t.Fatalf("verdict = %q", out.Verdict)
	}
}

func TestGuidanceCarriesAPrimarySourceAndNeverAutoInstalls(t *testing.T) {
	g := guidance()
	if len(g) != 3 {
		t.Fatalf("want one guidance record per toolchain, got %d", len(g))
	}
	seen := map[string]bool{}
	for _, r := range g {
		if r.AutoInstall {
			t.Fatalf("%s: auto_install must always be false", r.ID)
		}
		if r.PrimarySourceURL == "" || r.PrimarySourceOwner == "" {
			t.Fatalf("%s: guidance must name a primary source and its owner", r.ID)
		}
		if r.OperatorAction == "" {
			t.Fatalf("%s: guidance must state what the operator does", r.ID)
		}
		seen[r.ToolchainID] = true
	}
	for _, id := range []string{"rust", "swift", "kotlin"} {
		if !seen[id] {
			t.Fatalf("no guidance record for %s", id)
		}
	}
}
