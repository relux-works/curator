package main

import (
	"fmt"
	"strings"
)

// GateClass is the boundary a case actually exercises.
//
// The distinction this enumeration exists to hold is the one decision 0007
// section 4.2.1.2 records for Go: a value the ecosystem can *represent* and a
// value *this host* can build are two different questions, and an exit code
// from a build command answers their conjunction rather than either one. Every
// case below is therefore classified from two measurements — a cheap
// metadata-only command and a build command — and never from a single status.
type GateClass string

const (
	// GateRepresentability: the ecosystem's own parser cannot hold the
	// value at all. Host-independent, so it is the same verdict on every
	// machine.
	GateRepresentability GateClass = "representability"

	// GateHostVersion: the value is representable, and whether it is
	// admitted depends on the resolved host toolchain version.
	GateHostVersion GateClass = "host_version"

	// GateTargetRepresentability: the target triple is not a triple the
	// compiler knows.
	GateTargetRepresentability GateClass = "target_representability"

	// GateTargetHost: the triple is known, and this host's toolchain
	// nevertheless cannot build for it, normally because the target's
	// standard library is not installed inside the trusted tree.
	GateTargetHost GateClass = "target_host"

	// GatePackageSelector: a package-owned file or an inherited environment
	// value changes which compiler executable runs.
	GatePackageSelector GateClass = "package_selector"

	// GateBackendIdentity: the resolved executable is a real compiler of the
	// right language family and the wrong backend, so it cannot produce the
	// admitted artifact class.
	GateBackendIdentity GateClass = "backend_identity"

	// GateNone: the case is a positive control and no gate fires.
	GateNone GateClass = "none"
)

// Observation is what the probe measured for one case.
//
// MetadataExit and BuildExit are kept apart on purpose. Collapsing them is the
// exact mistake the Go boundary probe was rewritten to remove.
type Observation struct {
	// MetadataRan is false when the case has no cheap metadata command.
	MetadataRan  bool `json:"metadata_ran"`
	MetadataExit int  `json:"metadata_exit"`
	// MetadataExtractedValue is the assertion the cheap command surfaced to
	// a manager, when it surfaced one. Its presence is what lets a manager
	// decide a host-version gate before starting a compiler.
	MetadataExtractedValue string `json:"metadata_extracted_value,omitempty"`

	BuildRan  bool `json:"build_ran"`
	BuildExit int  `json:"build_exit"`
	// BuildStartedCompilation records whether the build command reached actual
	// compilation before failing.
	//
	// It is derived in finish() from BuildCompilationEvidence and can never be
	// set independently. An earlier revision of the Swift target cases computed
	// it as `compile.ExitCode != 0 && targetPrint.ExitCode == 0`, which is an
	// inference from failure rather than a measurement: it would report
	// compilation for any target the compiler recognises and then refuses, on
	// any host, without ever having observed a compiler process. The pair below
	// makes the boolean unfalsifiable-by-construction — it is true exactly when
	// a line of the build command's own output says a compiler ran, and that
	// line is carried in the fixture so a reader can check it.
	BuildStartedCompilation bool `json:"build_started_compilation"`
	// BuildCompilationEvidence is the exact output line that proved a compiler
	// process ran. Empty means no such line was observed.
	BuildCompilationEvidence string `json:"build_compilation_evidence,omitempty"`

	// TargetPrintRan/Exit measure a triple against the compiler's own target
	// knowledge, with no compilation.
	TargetPrintRan  bool `json:"target_print_ran"`
	TargetPrintExit int  `json:"target_print_exit"`
	// TargetStdPresent is a manager-side filesystem check inside the trusted
	// tree. It exists because the compiler's target-print command answers
	// representability and says nothing about whether the target's standard
	// library is installed.
	TargetStdChecked bool `json:"target_std_checked"`
	TargetStdPresent bool `json:"target_std_present"`

	// SelectorShimExit/SelectorRootExit measure the same directory twice,
	// once through the ecosystem's version-manager shim and once through a
	// directly resolved trusted root. A difference is package selection.
	SelectorMeasured bool `json:"selector_measured"`
	SelectorShimExit int  `json:"selector_shim_exit"`
	SelectorRootExit int  `json:"selector_root_exit"`
	// SelectorShimAttemptedInstall records whether the shim tried to fetch a
	// toolchain. Measured against an unreachable distribution endpoint, so
	// the attempt is observable and cannot succeed.
	SelectorShimAttemptedInstall bool `json:"selector_shim_attempted_install"`

	// Backend is the compiler backend a version banner named, when the case
	// measures backend identity.
	Backend string `json:"backend,omitempty"`
}

// Classify derives the gate class from the observation alone.
//
// It is deliberately total and deliberately free of any per-case knowledge:
// the expected class lives in the case table, and this function must be able
// to disagree with it. A classifier that consulted the expectation could not
// produce a divergence.
func Classify(o Observation) (GateClass, error) {
	switch {
	case o.SelectorMeasured:
		if o.SelectorShimExit != o.SelectorRootExit || o.SelectorShimAttemptedInstall {
			return GatePackageSelector, nil
		}
		return GateNone, nil

	case o.Backend != "":
		if o.Backend != "native" {
			return GateBackendIdentity, nil
		}
		return GateNone, nil

	case o.TargetPrintRan:
		if o.TargetPrintExit != 0 {
			return GateTargetRepresentability, nil
		}
		if o.TargetStdChecked && !o.TargetStdPresent {
			return GateTargetHost, nil
		}
		if o.BuildRan && o.BuildExit != 0 {
			return GateTargetHost, nil
		}
		return GateNone, nil

	case o.MetadataRan:
		if o.MetadataExit != 0 {
			return GateRepresentability, nil
		}
		if o.BuildRan && o.BuildExit != 0 {
			return GateHostVersion, nil
		}
		return GateNone, nil
	}
	return "", fmt.Errorf("observation carries no measurement to classify")
}

// DecidableBeforeCompilerWork reports whether a manager holding only
// manager-owned data plus the cheap metadata command could have rejected the
// case without starting a compiler.
//
// Two ways qualify, and they are not the same thing:
//
//   - the cheap command already rejected the value, so no comparison is even
//     needed; or
//   - the cheap command surfaced the asserted value, so the remaining decision
//     is a comparison against the already-resolved toolchain identity, which is
//     manager-owned data.
//
// A target case qualifies when the triple is refused by the target-print
// command, or when the manager-side standard-library check inside the trusted
// tree resolves it. That second clause is load-bearing for Rust: cargo's own
// rejection of an uninstalled target arrives *after* compilation starts, so a
// driver that relies on cargo's exit status has already run a compiler.
func DecidableBeforeCompilerWork(o Observation) bool {
	switch {
	case o.SelectorMeasured:
		return true
	case o.Backend != "":
		return true
	case o.TargetPrintRan:
		if o.TargetPrintExit != 0 {
			return true
		}
		return o.TargetStdChecked
	case o.MetadataRan:
		return o.MetadataExit != 0 || o.MetadataExtractedValue != ""
	}
	return false
}

// UpstreamRejectionArrivesAfterCompilation reports whether the ecosystem's own
// tooling only rejects the case once compilation has begun. It is recorded per
// case so a driver contract can see exactly which preflights it must own rather
// than delegate.
//
// Because BuildStartedCompilation is derived from a measured output line, this
// predicate cannot fire on a case where no compiler process was observed.
func UpstreamRejectionArrivesAfterCompilation(o Observation) bool {
	return o.BuildRan && o.BuildExit != 0 && o.BuildStartedCompilation
}

// compilationMarker returns the first line of a build command's own output that
// names a compiler process, or the empty string when the command produced no
// such line.
//
// Returning the line rather than a boolean is the point: the fixture then
// carries the measurement, so "compilation started" is auditable instead of
// asserted. Both streams are scanned because the ecosystems disagree about
// which one carries progress — cargo writes `Compiling` to stderr and the Swift
// driver writes its executed job trace to stdout.
func compilationMarker(r Run, markers ...string) string {
	for _, stream := range []string{r.fullStdout, r.fullStderr} {
		for _, ln := range strings.Split(stream, "\n") {
			for _, m := range markers {
				if strings.Contains(ln, m) {
					return truncateLine(strings.TrimRight(ln, " \t\r"))
				}
			}
		}
	}
	return ""
}

// markerLineBytes bounds a recorded marker line. A driver job trace is a full
// argv and can be kilobytes long; the fixture needs the proof, not the argv.
const markerLineBytes = 240

func truncateLine(s string) string {
	if len(s) <= markerLineBytes {
		return s
	}
	return s[:markerLineBytes] + "…"
}
