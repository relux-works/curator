module curator.probe/toolchainboundary

go 1.25
