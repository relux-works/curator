// Command toolchainboundary is the host-verified probe required by
// TASK-260729-rhjxtx.
//
// It measures, on real hosts, the toolchain detection, version normalization,
// native-target identity, source-metadata compatibility, and compiler-boundary
// behaviour that the Rust (TASK-260728-12pnm1), Swift (TASK-260728-1yhuqi), and
// Kotlin (TASK-260728-168smo) driver contracts must each fix.
//
// # What it measures, and why it is not a fixture table
//
// Decision 0007 section 4.2.1.2 records the failure a fixture table produces:
// a table says what a contract believes an ecosystem does. Only a probe against
// a real toolchain says what it does. The specific error that motivated the Go
// probe's rewrite was collapsing two independent questions into one exit code:
//
//	representability  can the ecosystem hold this value at all? A property of
//	                  the value, identical on every host.
//	host gate         will THIS toolchain accept it? A property of the pair.
//
// A build command's exit status answers their conjunction and cannot be
// decomposed back. Every case here is therefore measured with at least two
// commands — a cheap metadata-only command and a build or compile command — and
// classified by classify.go from the observations alone. The expected class
// lives in the case table and the classifier cannot see it, so a divergence is
// possible and is what the exit status reports.
//
// # What it never does
//
// It never installs, downloads, updates, activates, or switches a toolchain,
// and it never treats an absent toolchain as a failure. An absent toolchain is
// an evidence record with a manager-owned guidance input naming a primary
// source. Where a measurement requires observing that a version manager WOULD
// install something, the distribution endpoint is pointed at a closed loopback
// port so the attempt is observable and cannot succeed.
//
// It also never resolves a toolchain from PATH, an inherited environment
// variable, or a version-manager shim. Roots are supplied explicitly on the
// command line and are recorded as such, so nothing in the emitted evidence can
// be mistaken for a claim about how a manager resolved anything.
//
// # Usage
//
//	toolchainboundary [-rust ROOT] [-swift ROOT] [-kotlin ROOT]
//	                  [-rust-shim PATH] [-kotlinc-jvm PATH] [-gradle PATH]
//	                  [-work DIR] [-out FILE]
//
// Exit status 0 means every case that ran matched its expected classification;
// 1 means at least one diverged; 2 means the probe could not run at all.
// Cases that could not run are reported as not_run and are never counted as
// passes.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
)

type probeEnv struct {
	work       string
	roots      map[string]string
	rustShim   string
	kotlincJVM string
	gradle     string
}

func isWindows() bool { return runtime.GOOS == "windows" }

func replaceCase(cases []Case, c Case) []Case {
	for i := range cases {
		if cases[i].ID == c.ID {
			cases[i] = c
			return cases
		}
	}
	return append(cases, c)
}

func consumersFor(lang string) []string {
	switch lang {
	case "rust":
		return rustConsumers()
	case "swift":
		return swiftConsumers()
	default:
		return kotlinConsumers()
	}
}

// finish classifies an observation and records the verdict. It is the only
// place a verdict is produced, so no per-language code can declare its own
// case a pass.
//
// It also re-applies the case declaration and re-derives the compilation
// boolean. Both are enforcement rather than convenience: a per-language builder
// that restated an expectation, or that set BuildStartedCompilation from
// something other than a measured output line, is overwritten here rather than
// trusted.
func finish(c Case, obs Observation) Case {
	s := spec(c.ID)
	c.Language, c.Kind, c.Title = s.Language, s.Kind, s.Title
	c.Expected, c.ExpectDecidableBeforeCompilerWork = s.Expected, s.ExpectEarly
	if len(c.Consumers) == 0 {
		c.Consumers = consumersFor(s.Language)
	}

	obs.BuildStartedCompilation = obs.BuildCompilationEvidence != ""
	c.Observation = obs
	got, err := Classify(obs)
	if err != nil {
		c.Verdict = "not_run"
		c.NotRunReason = err.Error()
		return c
	}
	c.Observed = got
	c.DecidableBeforeCompilerWork = DecidableBeforeCompilerWork(obs)
	c.UpstreamRejectsAfterCompilation = UpstreamRejectionArrivesAfterCompilation(obs)
	switch {
	case c.Observed != c.Expected:
		c.Verdict = "divergence"
	case c.ExpectDecidableBeforeCompilerWork && !c.DecidableBeforeCompilerWork:
		c.Verdict = "divergence"
	default:
		c.Verdict = "match"
	}
	return c
}

func guidance() []GuidanceRecord {
	return []GuidanceRecord{
		{
			ID: rustGuidanceID, ToolchainID: "rust",
			Reason:             "build_toolchain_unavailable",
			PrimarySourceURL:   "https://www.rust-lang.org/tools/install",
			PrimarySourceOwner: "Rust Project (rust-lang.org)",
			OperatorAction:     "The operator installs a Rust release toolchain from the Rust Project's own distribution and then configures the concrete toolchain root in manager-owned configuration. The root is the directory carrying bin/rustc and bin/cargo, never a rustup shim directory and never a PATH entry.",
		},
		{
			ID: swiftGuidanceID, ToolchainID: "swift",
			Reason:             "build_toolchain_unavailable",
			PrimarySourceURL:   "https://www.swift.org/install/",
			PrimarySourceOwner: "Swift Project (swift.org)",
			OperatorAction:     "The operator installs a Swift release toolchain from the Swift Project's own distribution, or on macOS uses the toolchain inside an installed Xcode, and then configures the concrete toolchain root in manager-owned configuration. The root is the directory carrying usr/bin/swiftc, never a swiftly shim and never DEVELOPER_DIR or TOOLCHAINS.",
		},
		{
			ID: kotlinGuidanceID, ToolchainID: "kotlin",
			Reason:             "build_toolchain_unavailable",
			PrimarySourceURL:   "https://github.com/JetBrains/kotlin/releases",
			PrimarySourceOwner: "JetBrains (Kotlin release distribution)",
			OperatorAction:     "The operator installs a Kotlin/Native release distribution published by JetBrains and configures its concrete root in manager-owned configuration. The Kotlin compiler shipped by a general package manager is normally the JVM front end and does not satisfy this requirement; a JVM front end is reported as wrong_backend rather than accepted.",
		},
	}
}

func hostRecord() Host {
	h := Host{
		GOOS: runtime.GOOS, GOARCH: runtime.GOARCH,
		ProbeGoVersion: runtime.Version(),
	}
	switch runtime.GOOS {
	case "darwin":
		h.OperatingSystem = "macos"
	case "windows":
		h.OperatingSystem = "windows"
	default:
		h.OperatingSystem = runtime.GOOS
	}
	switch runtime.GOARCH {
	case "amd64":
		h.Architecture = "amd64"
	case "arm64":
		h.Architecture = "arm64"
	default:
		h.Architecture = runtime.GOARCH
	}
	h.NativeTarget = h.OperatingSystem + "/" + h.Architecture
	h.OSVersion = osVersion()
	return h
}

func osVersion() string {
	switch runtime.GOOS {
	case "darwin":
		out, err := exec.Command("/usr/bin/sw_vers", "-productVersion").Output()
		if err != nil {
			return ""
		}
		return strings.TrimSpace(string(out))
	case "windows":
		out, err := exec.Command("cmd", "/c", "ver").Output()
		if err != nil {
			return ""
		}
		return strings.TrimSpace(string(out))
	}
	return ""
}

func main() {
	var (
		rustRoot   = flag.String("rust", "", "trusted Rust toolchain root (the directory carrying bin/rustc and bin/cargo)")
		swiftRoot  = flag.String("swift", "", "trusted Swift toolchain root (the directory carrying usr/bin/swiftc)")
		kotlinRoot = flag.String("kotlin", "", "trusted Kotlin/Native distribution root (the directory carrying bin/kotlinc-native or bin/konanc)")
		rustShim   = flag.String("rust-shim", "", "path to a rustup shim, used only to measure that a package file can redirect it")
		kotlincJVM = flag.String("kotlinc-jvm", "", "path to a Kotlin JVM compiler, used only to measure that it is the wrong backend")
		gradle     = flag.String("gradle", "", "path to a Gradle launcher, used only to measure that reading Kotlin project metadata runs package-authored code")
		work       = flag.String("work", "", "working directory for the generated fixture corpus (default: a temporary directory)")
		out        = flag.String("out", "", "write the fixture JSON here (default: stdout)")
	)
	flag.Parse()

	w := *work
	if w == "" {
		d, err := os.MkdirTemp("", "toolchain-probe-")
		if err != nil {
			fmt.Fprintln(os.Stderr, "probe: cannot create a working directory:", err)
			os.Exit(2)
		}
		w = d
	}
	if err := os.MkdirAll(w, 0o755); err != nil {
		fmt.Fprintln(os.Stderr, "probe: cannot create a working directory:", err)
		os.Exit(2)
	}
	abs, err := filepath.Abs(w)
	if err != nil {
		fmt.Fprintln(os.Stderr, "probe: cannot resolve the working directory:", err)
		os.Exit(2)
	}

	env := &probeEnv{
		work:       abs,
		roots:      map[string]string{"rust": *rustRoot, "swift": *swiftRoot, "kotlin": *kotlinRoot},
		rustShim:   *rustShim,
		kotlincJVM: *kotlincJVM,
		gradle:     *gradle,
	}

	fx := Fixture{
		FixtureVersion: FixtureVersion,
		Task:           "TASK-260729-rhjxtx",
		Host:           hostRecord(),
		Guidance:       guidance(),
	}

	for _, p := range []func(*probeEnv) (ToolchainEvid, []Case){probeRust, probeSwift, probeKotlin} {
		ev, cases := p(env)
		fx.Toolchains = append(fx.Toolchains, ev)
		fx.Cases = append(fx.Cases, cases...)
	}

	sort.Slice(fx.Cases, func(i, j int) bool { return fx.Cases[i].ID < fx.Cases[j].ID })

	for _, c := range fx.Cases {
		fx.Summary.Total++
		switch c.Verdict {
		case "match":
			fx.Summary.Matched++
		case "divergence":
			fx.Summary.Divergences++
		default:
			fx.Summary.NotRun++
		}
	}
	for _, t := range fx.Toolchains {
		switch t.Availability {
		case Unavailable:
			fx.Summary.Unavailable++
		case WrongBackend:
			fx.Summary.WrongBackend++
		}
	}

	enc, err := json.MarshalIndent(fx, "", "  ")
	if err != nil {
		fmt.Fprintln(os.Stderr, "probe: cannot encode the fixture:", err)
		os.Exit(2)
	}
	enc = append(enc, '\n')
	if *out == "" {
		if _, err := os.Stdout.Write(enc); err != nil {
			fmt.Fprintln(os.Stderr, "probe: cannot write the fixture:", err)
			os.Exit(2)
		}
	} else if err := os.WriteFile(*out, enc, 0o644); err != nil {
		fmt.Fprintln(os.Stderr, "probe: cannot write the fixture:", err)
		os.Exit(2)
	}

	for _, c := range fx.Cases {
		fmt.Fprintf(os.Stderr, "%-11s %-44s expected=%-24s observed=%-24s early=%-5t\n",
			c.Verdict, c.ID, c.Expected, orDash(string(c.Observed)), c.DecidableBeforeCompilerWork)
		if c.Verdict == "not_run" {
			fmt.Fprintf(os.Stderr, "            reason: %s\n", c.NotRunReason)
		}
	}
	fmt.Fprintf(os.Stderr, "\n%d cases: %d matched, %d divergences, %d not run; %d toolchains unavailable, %d wrong backend\n",
		fx.Summary.Total, fx.Summary.Matched, fx.Summary.Divergences, fx.Summary.NotRun,
		fx.Summary.Unavailable, fx.Summary.WrongBackend)

	if fx.Summary.Divergences > 0 {
		os.Exit(1)
	}
}

func orDash(s string) string {
	if s == "" {
		return "-"
	}
	return s
}
