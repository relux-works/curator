package main

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// Canonical is the canonical version triple of
// docs/compiled-build-toolchain-requirements.md section 2.1, plus the
// prerelease flag of section 2.4.
//
// Normalization always produces this type. Native version strings are never
// compared against each other; only triples are ordered.
type Canonical struct {
	Major      int    `json:"major"`
	Minor      int    `json:"minor"`
	Patch      int    `json:"patch"`
	Prerelease bool   `json:"prerelease"`
	Native     string `json:"native"`
}

func (c Canonical) String() string {
	s := fmt.Sprintf("%d.%d.%d", c.Major, c.Minor, c.Patch)
	if c.Prerelease {
		s += " (prerelease)"
	}
	return s
}

// Compare orders two canonical triples lexicographically. The prerelease flag
// takes no part in the order: section 2.4 rejects a prerelease host outright
// rather than ranking it, precisely because no cross-language prerelease order
// exists.
func (c Canonical) Compare(o Canonical) int {
	for _, p := range [][2]int{{c.Major, o.Major}, {c.Minor, o.Minor}, {c.Patch, o.Patch}} {
		if p[0] != p[1] {
			if p[0] < p[1] {
				return -1
			}
			return 1
		}
	}
	return 0
}

// Stream names which of a probe's output streams a normalization rule reads.
// It is part of the rule rather than an implementation detail: three of the
// four version probes measured by this program write their version to a
// different stream, and a rule that does not say which stream it reads is not
// reproducible.
type Stream string

const (
	StreamStdout Stream = "stdout"
	StreamStderr Stream = "stderr"
)

// ErrUndetermined is returned when bounded probe output does not yield exactly
// one candidate. It maps to build_toolchain_version_undetermined; the rule
// never guesses and never defaults.
type ErrUndetermined struct {
	Rule   string
	Reason string
}

func (e *ErrUndetermined) Error() string {
	return fmt.Sprintf("version undetermined by rule %s: %s", e.Rule, e.Reason)
}

// NormalizationRule is an anchored, locale-independent rule from one bounded
// probe output stream to a Canonical.
type NormalizationRule struct {
	// ID is the stable name used in the emitted fixture.
	ID string
	// Stream is the stream the rule reads. Reading the wrong stream is the
	// single most common way one of these rules silently stops matching.
	Stream Stream
	// Pattern is anchored and must match at most one line of bounded output.
	Pattern *regexp.Regexp
	// PrereleaseGroup is the 1-based submatch index carrying the prerelease
	// remainder, or 0 when the rule's grammar has no prerelease position.
	PrereleaseGroup int
	// PrereleaseMarker is a second, independent prerelease signal carried
	// somewhere else on the matched line.
	//
	// Swift needs it: a development snapshot spells its prerelease status
	// twice, once as a `-dev` suffix on the version and once as a
	// DEVELOPMENT-SNAPSHOT tag inside the parenthetical, and the two are not
	// always both present across the forms upstream ships. One capture group
	// cannot carry both positions, and treating the second position as
	// decoration would let a snapshot toolchain be resolved as a release —
	// which section 2.4 forbids outright rather than ranks.
	PrereleaseMarker *regexp.Regexp
}

// maxProbeLines bounds the output a normalization rule will consider. Probe
// output is required to be bounded; an unbounded search is not a rule.
const maxProbeLines = 64

// Normalize applies the rule to one stream's bytes.
//
// It requires exactly one matching line. Zero matches and more than one match
// are both undetermined, which is what makes the rule anchored rather than
// best-effort: a toolchain that starts emitting a second version-shaped line
// fails the probe instead of being silently re-read.
func (r NormalizationRule) Normalize(out string) (Canonical, error) {
	lines := strings.Split(strings.ReplaceAll(out, "\r\n", "\n"), "\n")
	if len(lines) > maxProbeLines {
		return Canonical{}, &ErrUndetermined{Rule: r.ID, Reason: fmt.Sprintf("output exceeds the %d-line bound", maxProbeLines)}
	}
	var matches [][]string
	var matchedLine string
	for _, ln := range lines {
		ln = strings.TrimRight(ln, " \t")
		if m := r.Pattern.FindStringSubmatch(ln); m != nil {
			matches = append(matches, m)
			matchedLine = ln
		}
	}
	switch len(matches) {
	case 0:
		return Canonical{}, &ErrUndetermined{Rule: r.ID, Reason: "no line matched the anchored pattern"}
	case 1:
	default:
		return Canonical{}, &ErrUndetermined{Rule: r.ID, Reason: fmt.Sprintf("%d lines matched the anchored pattern", len(matches))}
	}

	m := matches[0]
	c := Canonical{Native: matchedLine}
	var err error
	if c.Major, err = strconv.Atoi(m[1]); err != nil {
		return Canonical{}, &ErrUndetermined{Rule: r.ID, Reason: "major is not an integer"}
	}
	if c.Minor, err = strconv.Atoi(m[2]); err != nil {
		return Canonical{}, &ErrUndetermined{Rule: r.ID, Reason: "minor is not an integer"}
	}
	if len(m) > 3 && m[3] != "" {
		if c.Patch, err = strconv.Atoi(m[3]); err != nil {
			return Canonical{}, &ErrUndetermined{Rule: r.ID, Reason: "patch is not an integer"}
		}
	}
	if r.PrereleaseGroup > 0 && r.PrereleaseGroup < len(m) && m[r.PrereleaseGroup] != "" {
		c.Prerelease = true
	}
	if r.PrereleaseMarker != nil && r.PrereleaseMarker.MatchString(matchedLine) {
		c.Prerelease = true
	}
	return c, nil
}

// The four normalization rules below are stated per toolchain and per probe.
// Each one is measured by this program against a real toolchain, except
// kotlinNativeVersionRule, which is declared unverified because no Kotlin/Native
// distribution was reachable on either probed host.
var (
	// rustcVersionRule reads the `release:` line of `rustc -vV`, not the
	// first line of `rustc --version`. The verbose form is a stable
	// key/value block whose release field is already the bare triple; the
	// short form embeds the commit hash and date in the same line.
	rustcVersionRule = NormalizationRule{
		ID:              "rust.rustc.vV.release",
		Stream:          StreamStdout,
		Pattern:         regexp.MustCompile(`^release: (0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?$`),
		PrereleaseGroup: 4,
	}

	// cargoVersionRule reads `cargo --version`. Cargo and rustc share a
	// release train but not a build, so both are recorded; the driver
	// contract decides which one is the primary.
	cargoVersionRule = NormalizationRule{
		ID:              "rust.cargo.version",
		Stream:          StreamStdout,
		Pattern:         regexp.MustCompile(`^cargo (0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.]+)? \(.*\)$`),
		PrereleaseGroup: 4,
	}

	// swiftVersionRule reads the compilerVersion string of
	// `swiftc -print-target-info`, which is JSON on stdout.
	//
	// It deliberately does not read `swift --version`: that command splits
	// one logical banner across two streams, writing `swift-driver version:
	// N` to stderr without a trailing newline and the Apple/open-source
	// version line to stdout. Anything that merges the streams sees the two
	// concatenated into one line, so an anchored rule over the merged text
	// and an anchored rule over stdout do not agree.
	//
	// Only the Apple release form has been measured. The open-source release
	// and development-snapshot forms are upstream-documented shapes the rule
	// is written to cover; the emitted evidence marks them unmeasured.
	swiftVersionRule = NormalizationRule{
		ID:               "swift.print-target-info.compilerVersion",
		Stream:           StreamStdout,
		Pattern:          regexp.MustCompile(`^(?:Apple )?Swift version (0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:\.(0|[1-9][0-9]*))?(-[0-9A-Za-z.]+)? \([^()]*\)$`),
		PrereleaseGroup:  4,
		PrereleaseMarker: regexp.MustCompile(`DEVELOPMENT|SNAPSHOT`),
	}

	// kotlinJVMVersionRule reads `kotlinc -version`, which writes to stderr
	// with an `info:` prefix and leaves stdout empty. It is recorded because
	// the JVM compiler is the thing a Kotlin/Native probe is most likely to
	// be pointed at by mistake, and because the stream and the prefix are
	// both normalization hazards worth pinning.
	//
	// It is NOT a Kotlin/Native rule. See kotlinBackendFromVersionBanner.
	kotlinJVMVersionRule = NormalizationRule{
		ID:              "kotlin.kotlinc.version.stderr",
		Stream:          StreamStderr,
		Pattern:         regexp.MustCompile(`^info: kotlinc-jvm (0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.]+)? \(JRE .*\)$`),
		PrereleaseGroup: 4,
	}

	// kotlinNativeVersionRule is UNVERIFIED. No Kotlin/Native distribution
	// was reachable on either probed host, so this rule has never been run
	// against real output. It is carried so the obligation is explicit and
	// so the probe fails loudly rather than quietly when a root is supplied.
	kotlinNativeVersionRule = NormalizationRule{
		ID:              "kotlin.konanc.version.UNVERIFIED",
		Stream:          StreamStderr,
		Pattern:         regexp.MustCompile(`^info: kotlinc-native (0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.]+)?.*$`),
		PrereleaseGroup: 4,
	}
)

// kotlinBackendFromVersionBanner reports which Kotlin compiler backend a
// version banner names.
//
// The Kotlin distribution ships several front ends behind near-identical
// banners, and only the native one can produce the native-executable-v1
// artifact class. Accepting a `kotlinc-jvm` banner where a native compiler is
// required would claim a platform this boundary does not admit, so the
// classification is explicit and total.
func kotlinBackendFromVersionBanner(banner string) string {
	switch {
	case strings.Contains(banner, "kotlinc-native"):
		return "native"
	case strings.Contains(banner, "kotlinc-jvm"):
		return "jvm"
	case strings.Contains(banner, "kotlinc-js"):
		return "js"
	case strings.Contains(banner, "kotlinc-wasm"):
		return "wasm"
	case strings.Contains(banner, "kotlinc"):
		return "unqualified"
	default:
		return "unknown"
	}
}

// requirementKind and Requirement mirror toolchain-requirement-v1 closely
// enough to evaluate the host gates this probe measures. The probe does not
// define the wire object; it only needs the interval semantics of section 2.3
// to say whether a measured host satisfies a measured assertion.
type Requirement struct {
	Kind   string `json:"kind"`
	Equals string `json:"equals,omitempty"`
	Min    string `json:"min,omitempty"`
	Below  string `json:"below,omitempty"`
}

var canonicalLiteral = regexp.MustCompile(`^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$`)

// ParseCanonicalLiteral parses a canonical `major.minor.patch` requirement
// literal. No prefix, prerelease, build metadata, wildcard, or leading zero is
// admitted, and each component is bounded at 999999.
func ParseCanonicalLiteral(s string) (Canonical, error) {
	m := canonicalLiteral.FindStringSubmatch(s)
	if m == nil {
		return Canonical{}, fmt.Errorf("%q is not a canonical major.minor.patch literal", s)
	}
	var c Canonical
	c.Native = s
	for i, dst := range []*int{&c.Major, &c.Minor, &c.Patch} {
		v, err := strconv.Atoi(m[i+1])
		if err != nil || v > 999999 {
			return Canonical{}, fmt.Errorf("component %d of %q is out of range", i+1, s)
		}
		*dst = v
	}
	return c, nil
}

// Satisfies reports whether a resolved host version satisfies a requirement.
// A prerelease host satisfies nothing, per section 2.4.
func (r Requirement) Satisfies(host Canonical) (bool, error) {
	if host.Prerelease {
		return false, nil
	}
	switch r.Kind {
	case "exact":
		v, err := ParseCanonicalLiteral(r.Equals)
		if err != nil {
			return false, err
		}
		return host.Compare(v) == 0, nil
	case "at_least":
		v, err := ParseCanonicalLiteral(r.Min)
		if err != nil {
			return false, err
		}
		return host.Compare(v) >= 0, nil
	case "range":
		lo, err := ParseCanonicalLiteral(r.Min)
		if err != nil {
			return false, err
		}
		hi, err := ParseCanonicalLiteral(r.Below)
		if err != nil {
			return false, err
		}
		if lo.Compare(hi) >= 0 {
			return false, fmt.Errorf("range min %s is not strictly below %s", r.Min, r.Below)
		}
		return host.Compare(lo) >= 0 && host.Compare(hi) < 0, nil
	default:
		return false, fmt.Errorf("unknown requirement kind %q", r.Kind)
	}
}
