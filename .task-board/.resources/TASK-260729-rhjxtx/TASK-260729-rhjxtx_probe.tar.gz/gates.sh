#!/bin/bash
# Runs every gate as a standalone process and reports its real exit code.
# No gate is piped through tee; $? is always the gate command's own status.
set -u
PROBE="/Users/iv/Developer/ReluxWorks/curator/.temp/TASK-260729-rhjxtx/probe"
REPO="/Users/iv/Developer/ReluxWorks/curator"

gate() {
	local label="$1" dir="$2"
	shift 2
	printf '\n=== %s\n' "$label"
	printf '    cwd  : %s\n' "$dir"
	printf '    argv : '
	printf '%q ' "$@"
	printf '\n'
	local out rc
	out="$(cd "$dir" && "$@" 2>&1)"
	rc=$?
	if [ -n "$out" ]; then
		printf -- '    --- output ---\n'
		printf '%s\n' "$out" | sed 's/^/    /'
	else
		printf -- '    --- output --- (empty)\n'
	fi
	printf -- '    --- REAL EXIT CODE: %d\n' "$rc"
}

printf 'TASK-260729-rhjxtx gate transcript, rework cycle 1\n'
printf 'Every command below was run directly. The exit code shown is the command'"'"'s own.\n'

printf '\n\n##### PROBE MODULE (task-owned, standalone Go module) #####\n'
gate "probe: gofmt -l ." "$PROBE" gofmt -l .
gate "probe: go build ./..." "$PROBE" go build ./...
gate "probe: go vet ./..." "$PROBE" go vet ./...
gate "probe: go test -count=1 ./..." "$PROBE" go test -count=1 ./...
gate "probe: golangci-lint run ./..." "$PROBE" \
	go run github.com/golangci/golangci-lint/v2/cmd/golangci-lint@latest run ./...
gate "probe: executed-vs-declared regression against REAL local toolchains" "$PROBE" \
	env PROBE_TEST_RUST=/Users/iv/.rustup/toolchains/1.91.0-aarch64-apple-darwin \
	PROBE_TEST_SWIFT=/Applications/Xcode_26_5.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain \
	PROBE_TEST_KOTLINC_JVM=/opt/homebrew/bin/kotlinc \
	go test -count=1 -run 'TestEmittedCasesCarryTheDeclaredExpectation|TestNotRunAndExecutedCasesAgreeOnTheContract' -v ./...

printf '\n\n##### CURATOR PROJECT (unmodified by this task) #####\n'
gate "curator: go build ./..." "$REPO" go build ./...
gate "curator: make vet" "$REPO" make vet
gate "curator: make test" "$REPO" make test
gate "curator: make check" "$REPO" make check
gate "curator: gofmt -l . (attribution for the make check failure above)" "$REPO" gofmt -l .
gate "curator: git status --porcelain (nothing tracked was modified)" "$REPO" \
	git status --porcelain -- ':!.temp' ':!.task-board' ':!.planning' ':!.research'
