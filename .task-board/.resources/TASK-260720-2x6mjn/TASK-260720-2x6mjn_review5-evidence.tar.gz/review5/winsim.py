"""Pytest plugin simulating Windows path/fd st_ctime divergence.

Only the planner's own fstat call site is affected, so unrelated stdlib
consumers keep receiving real os.stat_result objects.
"""
from __future__ import annotations

import os

_real_fstat = os.fstat


class _WindowsDescriptorStat:
    def __init__(self, value: object) -> None:
        object.__setattr__(self, "_value", value)

    def __getattr__(self, name: str) -> object:
        value = getattr(object.__getattribute__(self, "_value"), name)
        if name == "st_ctime_ns":
            return value + 1
        if name == "st_ctime":
            return value + 1.0
        return value


def _fstat(descriptor: int) -> object:
    return _WindowsDescriptorStat(_real_fstat(descriptor))


def pytest_configure(config: object) -> None:
    from csk.builds import planner

    # planner.os is the stdlib os module; patch only for the duration of
    # planner-driven reads by wrapping the module attribute it resolves.
    planner.os = _OsShim(os)  # type: ignore[attr-defined]


class _OsShim:
    def __init__(self, real: object) -> None:
        object.__setattr__(self, "_real", real)

    def __getattr__(self, name: str) -> object:
        if name == "fstat":
            return _fstat
        return getattr(object.__getattribute__(self, "_real"), name)
