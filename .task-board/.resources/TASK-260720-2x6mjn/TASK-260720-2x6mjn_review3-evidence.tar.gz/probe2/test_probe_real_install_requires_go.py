from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from csk_tests_helpers import make_config, make_project, make_skill_repo, write_skillfile
from csk import config, installer


def _build_skill(skills_root: Path) -> None:
    make_skill_repo(
        skills_root,
        "skill-build",
        {
            "agent-skill.json": json.dumps(
                {
                    "schema_version": 6,
                    "build_roots": ["build"],
                    "commands": {
                        "tool": {
                            "type": "build",
                            "driver": "go-v1",
                            "source_dir": "build/cmd/tool",
                        }
                    },
                    "capabilities": {},
                }
            ),
            "build/go.mod": "module example.com/tool\n\ngo 1.23\n",
            "build/cmd/tool/main.go": "package main\n\nfunc main() {}\n",
        },
        tag="v1",
    )


def test_probe_real_project_install_without_go_on_path(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    print("go on host PATH:", shutil.which("go"))
    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project)
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))
    _build_skill(skills_root)
    write_skillfile(
        project,
        {"schema_version": 1, "skills": [{"name": "skill-build", "tag": "v1"}]},
    )

    empty_bin = tmp_path / "empty-bin"
    empty_bin.mkdir()
    for tool in ("git", "sh", "env", "uname"):
        found = shutil.which(tool)
        if found:
            (empty_bin / tool).symlink_to(found)
    monkeypatch.setenv("PATH", str(empty_bin))
    print("go visible after PATH strip:", shutil.which("go"))

    results = installer.install(cfg)
    for result in results:
        print("STATUS=", result.status)
        print("ERRORS=", result.errors)
    installed = project / ".agents" / "skills" / "skill-build"
    print("skill installed:", installed.is_dir())
