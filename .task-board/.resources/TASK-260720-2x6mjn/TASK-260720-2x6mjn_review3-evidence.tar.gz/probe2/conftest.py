from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(os.environ["CSK_PROBE_ROOT"]).resolve()
sys.path.insert(0, str(ROOT / "src"))

_spec = importlib.util.spec_from_file_location(
    "csk_tests_helpers", ROOT / "tests" / "conftest.py"
)
assert _spec is not None and _spec.loader is not None
helpers = importlib.util.module_from_spec(_spec)
sys.modules["csk_tests_helpers"] = helpers
_spec.loader.exec_module(helpers)

from csk import deprecation  # noqa: E402


@pytest.fixture
def skills_root(tmp_path: Path) -> Path:
    root = tmp_path / "skills"
    root.mkdir()
    return root


@pytest.fixture
def csk_home(tmp_path: Path) -> Path:
    home = tmp_path / ".cocoaskills"
    home.mkdir()
    return home


@pytest.fixture(autouse=True)
def stable_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    deprecation.reset_for_tests()
    monkeypatch.delenv("CSK_CONFIG", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("USERPROFILE", str(tmp_path / "home"))
