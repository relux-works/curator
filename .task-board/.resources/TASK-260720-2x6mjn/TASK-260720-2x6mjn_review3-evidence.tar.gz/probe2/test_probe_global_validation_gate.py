from __future__ import annotations

import json
from pathlib import Path

import pytest

from csk_tests_helpers import commit_all, make_config, make_project, make_skill_repo, run
from csk import config, global_install


def _write_global_skillfile(csk_home: Path, data: dict) -> None:
    root = csk_home / "global"
    root.mkdir(parents=True, exist_ok=True)
    (root / "Skillfile.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def test_probe_global_install_with_skill_missing_skill_md(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    """A global skill snapshot without SKILL.md used to install fine."""

    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project, agents=["codex_cli"])
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))

    make_skill_repo(
        skills_root,
        "skill-ok",
        {"csk-skill.json": json.dumps({"schema_version": 2})},
        tag="v1",
    )
    repo, _ = make_skill_repo(
        skills_root,
        "skill-nomd",
        {"csk-skill.json": json.dumps({"schema_version": 2})},
        tag="v0",
    )
    (repo / "SKILL.md").unlink()
    commit_all(repo, "drop SKILL.md")
    run(["git", "tag", "v1"], repo)

    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [
                {"name": "skill-nomd", "tag": "v1"},
                {"name": "skill-ok", "tag": "v1"},
            ],
        },
    )

    result = global_install.install(cfg)
    print("STATUS=", result.status)
    print("ERRORS=", result.errors)
    print("MESSAGES=", result.messages)
    ok = csk_home / "global" / "skills" / "skill-ok"
    nomd = csk_home / "global" / "skills" / "skill-nomd"
    print("skill-ok installed:", ok.is_dir())
    print("skill-nomd installed:", nomd.is_dir())
    assert ok.is_dir(), "healthy global skill must still install"


def test_probe_global_install_with_undeclared_skill_dependency(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    """Global declaration whose skill dependency is not itself declared."""

    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project, agents=["codex_cli"])
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))

    provider_repo, _ = make_skill_repo(
        skills_root,
        "provider",
        {"csk-skill.json": json.dumps({"schema_version": 2})},
        tag="v1",
    )
    make_skill_repo(
        skills_root,
        "consumer",
        {
            "csk-skill.json": json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {"exec": "none", "network": "none"},
                    "dependencies": {
                        "skills": {
                            "provider": {
                                "git": str(provider_repo),
                                "ref": {"kind": "tag", "value": "v1"},
                            }
                        }
                    },
                }
            )
        },
        tag="v1",
    )

    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [{"name": "consumer", "tag": "v1"}],
        },
    )

    result = global_install.install(cfg)
    print("STATUS=", result.status)
    print("ERRORS=", result.errors)
    print("MESSAGES=", result.messages)
    root = csk_home / "global" / "skills"
    print("installed dirs:", sorted(p.name for p in root.iterdir()) if root.is_dir() else None)
    bins = csk_home / "global" / "bin"
    print("global bins:", sorted(p.name for p in bins.iterdir()) if bins.is_dir() else None)
