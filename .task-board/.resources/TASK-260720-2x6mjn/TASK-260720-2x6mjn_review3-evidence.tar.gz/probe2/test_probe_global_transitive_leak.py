from __future__ import annotations

import json
from pathlib import Path

import pytest

from csk_tests_helpers import make_config, make_project, make_skill_repo
from csk import config, global_install


def _write_global_skillfile(csk_home: Path, data: dict) -> None:
    root = csk_home / "global"
    root.mkdir(parents=True, exist_ok=True)
    (root / "Skillfile.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def test_probe_global_transitive_provider_commands_and_context(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    """Global declares only `consumer`; provider is a context-only dependency."""

    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project, agents=["codex_cli"])
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))

    provider_repo, _ = make_skill_repo(
        skills_root,
        "provider",
        {
            "csk-skill.json": json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {"exec": "none", "network": "none"},
                    "commands": {
                        "provider-tool": {
                            "type": "script",
                            "unix_path": "scripts/provider-tool",
                        }
                    },
                }
            ),
            "scripts/provider-tool": "#!/bin/sh\necho provider\n",
        },
        tag="v1",
    )
    make_skill_repo(
        skills_root,
        "consumer",
        {
            "csk-skill.json": json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {"exec": "none", "network": "none"},
                    "dependencies": {
                        "skills": {
                            "provider": {
                                "git": str(provider_repo),
                                "ref": {"kind": "tag", "value": "v1"},
                                "mode": "context",
                            }
                        }
                    },
                }
            )
        },
        tag="v1",
    )

    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [{"name": "consumer", "tag": "v1"}],
        },
    )

    result = global_install.install(cfg)
    print("STATUS=", result.status)
    print("ERRORS=", result.errors)
    root = csk_home / "global" / "skills"
    bins = csk_home / "global" / "bin"
    print("installed dirs:", sorted(p.name for p in root.iterdir()) if root.is_dir() else None)
    print("global bins:", sorted(p.name for p in bins.iterdir()) if bins.is_dir() else None)
