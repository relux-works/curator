from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from csk_tests_helpers import make_config, make_project, make_skill_repo
from csk import config, global_install


def _write_global_skillfile(csk_home: Path, data: dict) -> None:
    root = csk_home / "global"
    root.mkdir(parents=True, exist_ok=True)
    (root / "Skillfile.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def test_probe_real_global_install_without_go_on_path(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project, agents=["codex_cli"])
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))

    make_skill_repo(
        skills_root,
        "skill-plain",
        {"csk-skill.json": json.dumps({"schema_version": 2})},
        tag="v1",
    )
    make_skill_repo(
        skills_root,
        "skill-build",
        {
            "agent-skill.json": json.dumps(
                {
                    "schema_version": 6,
                    "build_roots": ["build"],
                    "commands": {
                        "tool": {
                            "type": "build",
                            "driver": "go-v1",
                            "source_dir": "build/cmd/tool",
                        }
                    },
                    "capabilities": {},
                }
            ),
            "build/go.mod": "module example.com/tool\n\ngo 1.23\n",
            "build/cmd/tool/main.go": "package main\n\nfunc main() {}\n",
        },
        tag="v1",
    )
    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [
                {"name": "skill-build", "tag": "v1"},
                {"name": "skill-plain", "tag": "v1"},
            ],
        },
    )

    empty_bin = tmp_path / "empty-bin"
    empty_bin.mkdir()
    for tool in ("git", "sh", "env", "uname"):
        found = shutil.which(tool)
        if found:
            (empty_bin / tool).symlink_to(found)
    monkeypatch.setenv("PATH", str(empty_bin))
    print("go visible after PATH strip:", shutil.which("go"))

    result = global_install.install(cfg)
    print("STATUS=", result.status)
    print("ERRORS=", result.errors)
    root = csk_home / "global" / "skills"
    print("installed dirs:", sorted(p.name for p in root.iterdir()) if root.is_dir() else None)
