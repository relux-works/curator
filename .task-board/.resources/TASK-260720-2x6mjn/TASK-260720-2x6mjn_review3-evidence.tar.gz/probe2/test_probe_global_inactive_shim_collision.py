from __future__ import annotations

import json
from pathlib import Path

import pytest

from csk_tests_helpers import make_config, make_project, make_skill_repo
from csk import config, global_install


def _write_global_skillfile(csk_home: Path, data: dict) -> None:
    root = csk_home / "global"
    root.mkdir(parents=True, exist_ok=True)
    (root / "Skillfile.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _provider(skills_root: Path, name: str, body: str) -> Path:
    repo, _ = make_skill_repo(
        skills_root,
        name,
        {
            "csk-skill.json": json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {"exec": "none", "network": "none"},
                    "commands": {
                        "tool": {
                            "type": "script",
                            "unix_path": "scripts/tool",
                        }
                    },
                }
            ),
            "scripts/tool": f"#!/bin/sh\necho {body}\n",
        },
        tag="v1",
    )
    return repo


def _consumer(skills_root: Path, name: str, provider_name: str, provider_repo: Path) -> None:
    make_skill_repo(
        skills_root,
        name,
        {
            "csk-skill.json": json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {"exec": "none", "network": "none"},
                    "dependencies": {
                        "skills": {
                            provider_name: {
                                "git": str(provider_repo),
                                "ref": {"kind": "tag", "value": "v1"},
                                "mode": "context",
                            }
                        }
                    },
                }
            )
        },
        tag="v1",
    )


def test_probe_two_inactive_provider_commands_collide_in_global_bin(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    """Two context-only providers both export `tool`; neither command is active."""

    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project, agents=["codex_cli"])
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))

    provider_one = _provider(skills_root, "provider-one", "one")
    provider_two = _provider(skills_root, "provider-two", "two")
    _consumer(skills_root, "consumer-one", "provider-one", provider_one)
    _consumer(skills_root, "consumer-two", "provider-two", provider_two)

    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [
                {"name": "consumer-one", "tag": "v1"},
                {"name": "consumer-two", "tag": "v1"},
            ],
        },
    )

    result = global_install.install(cfg)
    print("STATUS=", result.status)
    print("ERRORS=", result.errors)
    root = csk_home / "global" / "skills"
    bins = csk_home / "global" / "bin"
    print("installed dirs:", sorted(p.name for p in root.iterdir()) if root.is_dir() else None)
    print("global bins:", sorted(p.name for p in bins.iterdir()) if bins.is_dir() else None)
    shim = bins / "tool"
    if shim.exists():
        print("global/bin/tool content:", shim.read_text(encoding="utf-8", errors="replace").replace("\n", " ||| "))
