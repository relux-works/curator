from __future__ import annotations

import json
from pathlib import Path

import pytest

from csk_tests_helpers import make_config, make_project, make_skill_repo
from csk import config, global_install


def _write_global_skillfile(csk_home: Path, data: dict) -> None:
    root = csk_home / "global"
    root.mkdir(parents=True, exist_ok=True)
    (root / "Skillfile.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def test_probe_good_skill_still_installs_when_another_skill_has_missing_dep(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project, agents=["codex_cli"])
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))

    make_skill_repo(
        skills_root,
        "skill-build",
        {
            "agent-skill.json": json.dumps(
                {
                    "schema_version": 6,
                    "build_roots": ["build"],
                    "commands": {
                        "tool": {
                            "type": "build",
                            "driver": "go-v1",
                            "source_dir": "build/cmd/tool",
                        }
                    },
                    "capabilities": {},
                }
            ),
            "build/go.mod": "module example.com/tool\n\ngo 1.23\n",
            "build/cmd/tool/main.go": "package main\n\nfunc main() {}\n",
        },
        tag="v1",
    )
    make_skill_repo(
        skills_root,
        "skill-bad",
        {
            "csk-skill.json": json.dumps(
                {
                    "schema_version": 2,
                    "commands": {},
                    "dependencies": {
                        "commands": {
                            "missing-tool": {
                                "type": "system",
                                "command": "__csk_missing_global_dependency__",
                            }
                        }
                    },
                }
            )
        },
        tag="v1",
    )

    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [
                {"name": "skill-build", "tag": "v1"},
                {"name": "skill-bad", "tag": "v1"},
            ],
        },
    )

    result = global_install.install(cfg)
    print("status=", result.status)
    print("errors=", result.errors)
    print("messages=", result.messages)
    installed = csk_home / "global" / "skills" / "skill-build"
    print("skill-build installed:", installed.is_dir())
    assert installed.is_dir(), (
        "regression: healthy skill no longer installs when an unrelated skill "
        "has a missing system dependency"
    )
