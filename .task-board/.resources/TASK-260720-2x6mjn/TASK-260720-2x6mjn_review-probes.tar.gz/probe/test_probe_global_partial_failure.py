from __future__ import annotations

import json
from pathlib import Path

import pytest

from csk_tests_helpers import make_config, make_project, make_skill_repo
from csk import config, global_install


def _write_global_skillfile(csk_home: Path, data: dict) -> None:
    root = csk_home / "global"
    root.mkdir(parents=True, exist_ok=True)
    (root / "Skillfile.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def test_probe_broken_decl_keeps_other_installed_global_skills(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, skills_root: Path, csk_home: Path
) -> None:
    project = make_project(tmp_path)
    cfg = make_config(csk_home, skills_root, project, agents=["codex_cli"])
    config.save_config(cfg)
    monkeypatch.setenv("CSK_CONFIG", str(cfg.path))

    make_skill_repo(
        skills_root,
        "skill-a",
        {
            "csk-skill.json": json.dumps({"schema_version": 2}),
        },
        tag="v1",
    )

    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [{"name": "skill-a", "tag": "v1"}],
        },
    )

    first = global_install.install(cfg)
    print("FIRST status=", first.status, "errors=", first.errors)
    installed = csk_home / "global" / "skills" / "skill-a"
    assert installed.is_dir(), "precondition: skill-a installed"

    # Second run: one declaration cannot resolve at all (no such repo).
    _write_global_skillfile(
        csk_home,
        {
            "schema_version": 1,
            "agents": ["codex_cli"],
            "skills": [
                {"name": "skill-a", "tag": "v1"},
                {"name": "skill-missing", "tag": "v1"},
            ],
        },
    )

    second = global_install.install(cfg)
    print("SECOND status=", second.status, "errors=", second.errors)
    print("SECOND messages=", second.messages)
    print("skill-a still installed:", installed.is_dir())
    assert installed.is_dir(), (
        "regression: a single unresolvable global declaration wiped the "
        "already-installed skill tree"
    )
