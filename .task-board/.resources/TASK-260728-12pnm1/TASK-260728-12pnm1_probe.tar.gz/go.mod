module rustboundaryprobe

go 1.25
