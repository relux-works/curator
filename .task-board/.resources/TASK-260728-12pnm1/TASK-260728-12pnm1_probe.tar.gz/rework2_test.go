package main

import (
	"strings"
	"testing"
)

// The version-record normalization of reference section 2.3. These are unit
// tests over the pure function; the fixture vectors N1 through N13 are the
// recorded evidence.

func TestMultilineStreamNormalizes(t *testing.T) {
	p, why := normalizeVersionStream([]byte(measuredVV), true)
	if why != "" {
		t.Fatalf("the measured multiline stream must normalize, got %q", why)
	}
	if strings.Count(string(p), "\n") != 6 {
		t.Fatalf("the payload must keep its six interior LFs, got %d", strings.Count(string(p), "\n"))
	}
	if sha256hex(frameVersionRecord('V', p)) != measuredVRecordSHA {
		t.Fatal("the framed V record must reproduce the recorded digest")
	}
}

func TestSingleLineRuleWouldRejectTheAdmittedToolchain(t *testing.T) {
	// This is the defect the revision fixes: the old rule forbade every LF but
	// the terminator, and the toolchain the entry admits emits seven lines.
	if _, why := normalizeVersionStream([]byte(measuredVV), false); why == "" {
		t.Fatal("the single-line rule must reject the real multiline stream")
	}
}

func TestCRLFFoldsToTheSamePayload(t *testing.T) {
	crlf := strings.ReplaceAll(measuredVV, "\n", "\r\n")
	a, whyA := normalizeVersionStream([]byte(measuredVV), true)
	b, whyB := normalizeVersionStream([]byte(crlf), true)
	if whyA != "" || whyB != "" {
		t.Fatalf("both forms must normalize: %q %q", whyA, whyB)
	}
	if string(a) != string(b) {
		t.Fatal("a CRLF stream must produce the same payload as an LF stream")
	}
}

func TestTerminalLFRuleIsExact(t *testing.T) {
	for _, tc := range []struct{ name, in string }{
		{"no terminator", strings.TrimRight(measuredVV, "\n")},
		{"two terminators", measuredVV + "\n"},
		{"bare CR", strings.Replace(measuredVV, "binary:", "bin\rary:", 1)},
		{"empty", ""},
	} {
		if _, why := normalizeVersionStream([]byte(tc.in), true); why == "" {
			t.Fatalf("%s must be rejected", tc.name)
		}
	}
}

func TestFramingIsLengthPrefixedAndDomainSeparated(t *testing.T) {
	a := frameVersionRecord('V', []byte("ab"))
	b := frameVersionRecord('C', []byte("ab"))
	if string(a) == string(b) {
		t.Fatal("V and C records with equal payloads must differ")
	}
	// Two payloads that concatenate the same way must still frame differently.
	x := frameVersionRecord('V', []byte("ab"))
	y := frameVersionRecord('V', []byte("a\x00b"))
	if sha256hex(x) == sha256hex(y) {
		t.Fatal("length framing must separate payloads")
	}
}

// Stage P: the closed relative-path grammar of reference section 4.3.

func TestLexicalGrammarRejectsEveryEscapeForm(t *testing.T) {
	for _, v := range []string{
		"../outside", "a/../../outside", "/etc", "C:/Windows", "c:dep",
		"//server/share", `..\outside`, `sub\dep`, "a//b", "./dep",
		"dep./x", "dep /x", "CON/x", "com1.txt", "de\tp", "~/dep", "",
	} {
		if lexicalPathAdmitted(v) == "" {
			t.Fatalf("%q must be rejected by the lexical grammar", v)
		}
	}
}

func TestLexicalGrammarAdmitsOrdinaryRelativePaths(t *testing.T) {
	for _, v := range []string{"dep", "crates/dep", "vendor/probedep", "vendör/dep", "src/lib.rs"} {
		if why := lexicalPathAdmitted(v); why != "" {
			t.Fatalf("%q must be admitted, got %q", v, why)
		}
	}
}

func TestDotDotIsRejectedEvenWhenItWouldStayInside(t *testing.T) {
	// `sub/../other` resolves inside, and is still rejected: the rule is purely
	// lexical so that it can be applied before any filesystem call.
	if lexicalPathAdmitted("sub/../other") == "" {
		t.Fatal("a .. component must be rejected even when it does not escape")
	}
}

// Configuration serialization, reference section 6.1.

func TestSerializerRejectsEveryUnrepresentablePath(t *testing.T) {
	for _, v := range []string{
		"/op/a'b/vendor", "/op/a\nb/vendor", "/op/a\tb/vendor", "/op/a\x7fb/vendor",
		"/op/a\x00b/vendor", "vendor", "", `\\server\share\vendor`, `\\?\C:\op\vendor`,
	} {
		if _, why := serializeCargoConfig(v); why == "" {
			t.Fatalf("%q must be rejected by the representability rule", v)
		}
	}
}

func TestSerializerEmitsVerbatimWithNoEscaping(t *testing.T) {
	for _, v := range []string{
		"/op/build_root/vendor", "/op/my op/vendor", "/op/vendör/vendor",
		`/op/a"b/vendor`, `/op/a\b/vendor`,
	} {
		doc, why := serializeCargoConfig(v)
		if why != "" {
			t.Fatalf("%q must be written, got %q", v, why)
		}
		if !strings.Contains(doc, "directory = '"+v+"'") {
			t.Fatalf("the value must appear verbatim between two apostrophes: %q", v)
		}
		got, ok := reparseDirectory(doc)
		if !ok || got != v {
			t.Fatalf("write-back must recover the exact value for %q", v)
		}
		if len(tableHeaders(doc)) != 4 {
			t.Fatalf("the document must carry exactly four tables for %q", v)
		}
	}
}

func TestNaiveWriterInjectsAndTheRuleBoundWriterRefuses(t *testing.T) {
	evil := "/op/vendor\"\n\n[net]\noffline = false\n"
	if n := len(tableHeaders(naiveBasicStringConfig(evil))); n <= 4 {
		t.Fatalf("the naive writer must be shown to inject, got %d tables", n)
	}
	if _, why := serializeCargoConfig(evil); why == "" {
		t.Fatal("the rule-bound writer must refuse the same value")
	}
}

func TestConfigTemplateIsByteStable(t *testing.T) {
	doc, why := serializeCargoConfig("/opt/curator/op/build_root/vendor")
	if why != "" {
		t.Fatalf("unexpected rejection: %q", why)
	}
	if len(cfgPrefix) != 89 || len(cfgSuffix) != 61 {
		t.Fatalf("template constants moved: prefix=%d suffix=%d", len(cfgPrefix), len(cfgSuffix))
	}
	if sha256hex([]byte(doc)) != "41aaeac44f7f26e747bbd29fafddd0715b813e5b06edbad967755ac3f87b60f2" {
		t.Fatal("the sample document must reproduce its recorded digest")
	}
	if strings.Contains(doc, "\r") || strings.HasSuffix(doc, "\n\n") || !strings.HasSuffix(doc, "\n") {
		t.Fatal("the file must be LF-only with exactly one terminal LF")
	}
}

// The normative argument vectors, asserted as data so that a silent edit turns
// a test red rather than changing what the probe measures.

func TestGraphVectorCarriesAllFeaturesAndLocked(t *testing.T) {
	want := "metadata --format-version 1 --locked --offline --color never --quiet --all-features"
	if got := strings.Join(graphArgv, " "); got != want {
		t.Fatalf("graph vector drifted:\n got %q\nwant %q", got, want)
	}
}

func TestCompileVectorIsExact(t *testing.T) {
	want := "build --locked --offline --color never --quiet --release --target T --bin B"
	if got := strings.Join(compileArgv("T", "B"), " "); got != want {
		t.Fatalf("compile vector drifted:\n got %q\nwant %q", got, want)
	}
}
