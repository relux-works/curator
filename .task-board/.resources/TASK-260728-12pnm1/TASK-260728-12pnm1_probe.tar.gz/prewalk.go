package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"unicode/utf8"
)

// ---------------------------------------------------------------------------
// Reference section 4.3: the closed relative-path grammar of Stage P.
//
// The point of this function is *when* it decides, not only what it decides:
// every rejection is computed from the declared string, before any filesystem
// call is made with that string. Measured, cargo opens, parses and reports an
// outside manifest during the graph phase, so a check that reads Cargo's output
// prevents compilation but not the read.
// ---------------------------------------------------------------------------

var windowsReserved = map[string]bool{
	"CON": true, "PRN": true, "AUX": true, "NUL": true,
	"COM1": true, "COM2": true, "COM3": true, "COM4": true, "COM5": true,
	"COM6": true, "COM7": true, "COM8": true, "COM9": true,
	"LPT1": true, "LPT2": true, "LPT3": true, "LPT4": true, "LPT5": true,
	"LPT6": true, "LPT7": true, "LPT8": true, "LPT9": true,
}

// lexicalPathAdmitted returns "" when the declared value satisfies all seven
// rules, and the failing rule otherwise.
func lexicalPathAdmitted(v string) string {
	if v == "" {
		return "rule 1: empty"
	}
	if len(v) > 1024 {
		return "rule 1: over 1024 bytes"
	}
	if !utf8.ValidString(v) {
		return "rule 1: not valid UTF-8"
	}
	for _, r := range v {
		if r == 0x00 {
			return "rule 2: NUL"
		}
		if r < 0x20 || r == 0x7f {
			return "rule 2: control character"
		}
	}
	if strings.Contains(v, `\`) {
		return "rule 3: backslash"
	}
	if strings.HasPrefix(v, "//") {
		return "rule 5: UNC prefix"
	}
	if strings.HasPrefix(v, "/") {
		return "rule 4: absolute"
	}
	if len(v) >= 2 && v[1] == ':' &&
		((v[0] >= 'A' && v[0] <= 'Z') || (v[0] >= 'a' && v[0] <= 'z')) {
		return "rule 5: drive prefix"
	}
	parts := strings.Split(v, "/")
	if parts[0] == "~" {
		return "rule 5: home prefix"
	}
	for _, c := range parts {
		if c == "" {
			return "rule 6: empty component"
		}
		if c == "." || c == ".." {
			return "rule 6: dot component"
		}
		if strings.HasSuffix(c, ".") || strings.HasSuffix(c, " ") {
			return "rule 7: trailing dot or space"
		}
		stem := c
		if i := strings.Index(stem, "."); i >= 0 {
			stem = stem[:i]
		}
		if windowsReserved[strings.ToUpper(stem)] {
			return "rule 7: reserved device name"
		}
	}
	return ""
}

// pathOutcome is the result of the total physical algorithm of reference
// section 4.3. Anchor is the canonical form of the deepest component that
// actually exists; it is always defined, because the build root itself exists.
type pathOutcome struct {
	Reason     string // "" when admitted
	LeafExists bool
	Anchor     string
}

// physicalPathAdmitted is the second half of section 4.3, applied only to a
// value the lexical rule already admitted. isDependency distinguishes a
// dependency path, which cargo must open, from a target path, whose absence is
// not a Stage P failure.
//
// The algorithm is total: it never asks the platform to canonicalize a path
// that does not exist. Measured on macOS 26.5, realpath(3) on an absent leaf
// returns NULL with ENOENT and Go's filepath.EvalSymlinks fails the same way,
// so the superseded rule — "the canonical form of the joined path must remain
// under R", applied to a leaf the same paragraph permits to be absent — had no
// implementation. Worse, canonicalizing an absent leaf below a symbolic link
// reports a path outside the package directory before it fails, which is the
// opposite of a containment check.
//
// Containment therefore rests on two mechanisms that are both total:
//   - the lexical grammar, which already proves the joined path is a descendant
//     of the manifest directory and so of R;
//   - a non-following walk of every component, which rejects any symbolic link
//     or reparse point, so no component can redirect the path at all.
//
// Canonicalization is applied only to the deepest existing ancestor, where it
// is defined, and is a cross-check against platform surprises rather than the
// primary gate.
func physicalPathOutcome(root, manifestDir, rel string, isDependency bool) pathOutcome {
	joined := filepath.Join(manifestDir, filepath.FromSlash(rel))

	canonRoot, err := filepath.EvalSymlinks(root)
	if err != nil {
		return pathOutcome{Reason: "the build root does not canonicalize: " + err.Error()}
	}

	remainder := strings.Trim(filepath.ToSlash(strings.TrimPrefix(joined, root)), "/")
	var comps []string
	for _, c := range strings.Split(remainder, "/") {
		if c != "" {
			comps = append(comps, c)
		}
	}

	cur := root
	anchor := root
	leafExists := true
	for i, c := range comps {
		next := filepath.Join(cur, c)
		st, err := os.Lstat(next)
		if err != nil {
			// The component does not exist, so neither does anything below it.
			// The walk stops here rather than continuing to stat descendants of
			// a path that is already known to be absent.
			leafExists = false
			break
		}
		// A symbolic link or reparse point is rejected wherever it appears,
		// including as the leaf itself, and it is rejected before the leaf is
		// looked at.
		if st.Mode()&os.ModeSymlink != 0 {
			return pathOutcome{Reason: "symbolic link or reparse component: " + c}
		}
		if i < len(comps)-1 && !st.IsDir() {
			// An existing non-directory ancestor means the leaf cannot exist.
			// Nothing further is opened.
			anchor = next
			leafExists = false
			break
		}
		cur = next
		anchor = next
	}

	// The anchor exists by construction, so this canonicalization is always
	// defined. Requiring R as a path-component prefix catches a platform whose
	// canonical form differs from the lexical one — case folding, short names —
	// without ever depending on the leaf.
	canonAnchor, err := filepath.EvalSymlinks(anchor)
	if err != nil {
		return pathOutcome{Reason: "the deepest existing ancestor does not canonicalize: " + err.Error()}
	}
	if canonAnchor != canonRoot && !strings.HasPrefix(canonAnchor, canonRoot+string(os.PathSeparator)) {
		return pathOutcome{Reason: "canonical path escapes the build root"}
	}

	out := pathOutcome{LeafExists: leafExists, Anchor: canonAnchor}
	if isDependency {
		if !leafExists {
			out.Reason = "dependency path does not exist"
			return out
		}
		st, err := os.Lstat(joined)
		if err != nil || !st.IsDir() {
			out.Reason = "dependency path is not a directory"
			return out
		}
		if st, err := os.Lstat(filepath.Join(joined, "Cargo.toml")); err != nil || !st.Mode().IsRegular() {
			out.Reason = "dependency path has no Cargo.toml"
			return out
		}
		return out
	}

	// A non-dependency target path may legitimately be absent: a vendored crate
	// can declare a target whose sources were not vendored, and no admitted
	// compile command builds it. Absence ends the check; nothing is
	// canonicalized for it.
	if !leafExists {
		return out
	}
	st, err := os.Lstat(joined)
	if err != nil {
		out.Reason = "leaf disappeared during the walk"
		return out
	}
	if !st.Mode().IsRegular() && !st.IsDir() {
		out.Reason = "target path is neither a regular file nor a directory"
	}
	return out
}

// physicalPathAdmitted is the reason-only projection of physicalPathOutcome,
// kept because most callers only need the verdict.
func physicalPathAdmitted(root, manifestDir, rel string, isDependency bool) string {
	return physicalPathOutcome(root, manifestDir, rel, isDependency).Reason
}

// buildScriptFileGate is the section 4.2 file rule that closes auto-discovered
// build scripts before any cargo process.
//
// Measured on cargo 1.91.0: with `package.build` absent and a regular file
// named `build.rs` in the manifest's own directory, `cargo metadata` reports a
// `custom-build` target and `cargo build` compiles and *executes* the script.
// The forbidden-key gate never sees it, because there is no key to reject, so
// before this rule the shape was caught only by G2 — after Cargo had already
// read and resolved the tree.
//
// Discovery was measured to key on exactly one thing: a regular file named
// `build.rs` directly in the manifest directory. A different file name, a
// `build.rs` in a subdirectory, and a *directory* named `build.rs` were all
// measured not to be discovered; `build = false` was measured to suppress
// discovery, and edition 2024 behaves as edition 2021.
//
// The rule is nevertheless stated on the mere existence of the name, without
// consulting `package.build` and without distinguishing entry types: one lstat
// per manifest directory, no reasoning about Cargo's discovery semantics at
// all. It over-rejects in two stated directions — a package shipping a
// `build.rs` alongside `build = false`, and a *directory* named `build.rs` —
// both of which Cargo was measured to ignore. Neither arises from `cargo
// vendor` normalization, whose manifests carry `build = false` exactly when no
// build script file was packaged.
func buildScriptFileGate(manifestDir string) string {
	if _, err := os.Lstat(filepath.Join(manifestDir, "build.rs")); err != nil {
		return ""
	}
	return "an entry named build.rs exists in the manifest directory"
}

// ancestorObligation implements reference section 4.6: no `.cargo` directory
// and no `Cargo.toml` in any ancestor of the build root, up to the filesystem
// root. It returns the first offending ancestor, or "".
func ancestorObligation(root string) string {
	dir := filepath.Dir(root)
	for {
		if st, err := os.Lstat(filepath.Join(dir, ".cargo")); err == nil && st.IsDir() {
			return dir + "/.cargo"
		}
		if st, err := os.Lstat(filepath.Join(dir, "Cargo.toml")); err == nil && !st.IsDir() {
			return dir + "/Cargo.toml"
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return ""
		}
		dir = parent
	}
}

func vectorsPrewalk(work string) []Vector {
	var out []Vector
	add := func(id, title, expected, observed, detail string) {
		v := Vector{ID: id, Group: "prewalk", Title: title, Expected: expected, Observed: observed, Detail: detail}
		v.settle()
		out = append(out, v)
	}

	type c struct{ id, in, expect string }
	cases := []c{
		{"P1/plain", "dep", "admitted"},
		{"P2/nested", "crates/dep", "admitted"},
		{"P3/vendored", "vendor/probedep", "admitted"},
		{"P4/non-ascii", "vendör/dep", "admitted"},
		{"P5/parent", "../outside", "rejected"},
		{"P6/parent-deep", "a/../../outside", "rejected"},
		{"P7/absolute", "/etc", "rejected"},
		{"P8/drive", "C:/Windows", "rejected"},
		{"P9/drive-lower", "c:dep", "rejected"},
		{"P10/unc", "//server/share", "rejected"},
		{"P11/backslash", `..\outside`, "rejected"},
		{"P12/backslash-inner", `sub\dep`, "rejected"},
		{"P13/empty-component", "a//b", "rejected"},
		{"P14/dot-component", "./dep", "rejected"},
		{"P15/trailing-dot", "dep./x", "rejected"},
		{"P16/trailing-space", "dep /x", "rejected"},
		{"P17/reserved-con", "CON/x", "rejected"},
		{"P18/reserved-com1-ext", "com1.txt", "rejected"},
		{"P19/control-char", "de\tp", "rejected"},
		{"P20/nul", "de\x00p", "rejected"},
		{"P21/home", "~/dep", "rejected"},
		{"P22/empty", "", "rejected"},
		{"P23/too-long", strings.Repeat("a", 1025), "rejected"},
	}
	for _, tc := range cases {
		why := lexicalPathAdmitted(tc.in)
		obs := "admitted"
		if why != "" {
			obs = "rejected"
		}
		add(tc.id, "lexical path grammar: "+tc.id, tc.expect, obs, why)
	}

	// The physical half: a symlinked component inside the root is rejected even
	// though the declared string is lexically fine.
	rootDir := filepath.Join(work, "prewalk-root")
	_ = os.RemoveAll(rootDir)
	_ = os.MkdirAll(filepath.Join(rootDir, "real", "dep"), 0o755)
	_ = os.WriteFile(filepath.Join(rootDir, "real", "dep", "Cargo.toml"), []byte("[package]\n"), 0o644)
	linkOK := os.Symlink(filepath.Join(rootDir, "real"), filepath.Join(rootDir, "linked")) == nil

	obs := "not run"
	if linkOK {
		obs = "admitted"
		if why := physicalPathAdmitted(rootDir, rootDir, "linked/dep", true); why != "" {
			obs = "rejected"
		}
	}
	expected := "rejected"
	if !linkOK {
		expected = "not run"
	}
	add("P24/symlink-component", "a lexically clean path traversing a symlink", expected, obs, "")

	if why := physicalPathAdmitted(rootDir, rootDir, "real/dep", true); why == "" {
		add("P25/physical-ok", "a real directory with a manifest", "admitted", "admitted", "")
	} else {
		add("P25/physical-ok", "a real directory with a manifest", "admitted", "rejected", why)
	}

	if why := physicalPathAdmitted(rootDir, rootDir, "real/absent", true); why != "" {
		add("P26/missing-dependency", "a dependency path that does not exist", "rejected", "rejected", why)
	} else {
		add("P26/missing-dependency", "a dependency path that does not exist", "rejected", "admitted", "")
	}

	if why := physicalPathAdmitted(rootDir, rootDir, "real/absent.rs", false); why == "" {
		add("P27/missing-target", "a target path that does not exist", "admitted", "admitted",
			"a vendored crate may declare a target whose sources were not vendored")
	} else {
		add("P27/missing-target", "a target path that does not exist", "admitted", "rejected", why)
	}

	// ----------------------------------------------------------------------
	// P31 through P37: the total physical algorithm for absent leaves.
	//
	// The superseded rule permitted a non-dependency target path to be absent
	// and, in the same paragraph, required the canonical form of that path to
	// remain under R. Measured, no such canonical form exists: realpath(3)
	// returns ENOENT and filepath.EvalSymlinks fails. These vectors pin the
	// replacement: a non-following component walk decides containment, and
	// canonicalization is applied only to the deepest existing ancestor.
	// ----------------------------------------------------------------------
	_ = os.MkdirAll(filepath.Join(rootDir, "real", "deep", "deeper"), 0o755)
	_ = os.WriteFile(filepath.Join(rootDir, "real", "afile"), []byte("x"), 0o644)
	_ = os.MkdirAll(filepath.Join(rootDir, "elsewhere"), 0o755)
	linkOutside := os.Symlink(filepath.Join(rootDir, "elsewhere"), filepath.Join(rootDir, "escape")) == nil

	// P31: the platform genuinely cannot canonicalize the permitted absent leaf.
	// This is the measurement that makes the superseded rule unimplementable
	// rather than merely awkward, and it is checked rather than asserted.
	{
		_, err := filepath.EvalSymlinks(filepath.Join(rootDir, "real", "deep", "absent.rs"))
		obs := "canonicalizes"
		if err != nil {
			obs = "cannot be canonicalized"
		}
		add("P31/absent-leaf-has-no-canonical-form",
			"the canonical form of a permitted absent leaf",
			"cannot be canonicalized", obs,
			"this is why the rule anchors on the deepest existing ancestor")
	}

	// P32: an absent leaf with safe existing ancestors is admitted, and the
	// anchor it reports is the deepest existing directory, under R.
	{
		o := physicalPathOutcome(rootDir, rootDir, "real/deep/deeper/absent.rs", false)
		obs := "rejected: " + o.Reason
		if o.Reason == "" {
			anchorOK := strings.HasSuffix(o.Anchor, filepath.Join("real", "deep", "deeper"))
			obs = fmt.Sprintf("admitted, leaf_exists=%v anchor_is_deepest_existing=%v", o.LeafExists, anchorOK)
		}
		add("P32/absent-leaf-safe-ancestors", "an absent target path below real directories",
			"admitted, leaf_exists=false anchor_is_deepest_existing=true", obs, "")
	}

	// P33: an absent leaf below a symbolic-link ancestor is rejected, and it is
	// rejected by the ancestor walk — the leaf is never reached.
	{
		expected, obs := "rejected at the symbolic link component", "not run"
		if linkOutside {
			o := physicalPathOutcome(rootDir, rootDir, "escape/absent.rs", false)
			switch {
			case o.Reason == "":
				obs = "admitted"
			case strings.HasPrefix(o.Reason, "symbolic link or reparse component"):
				obs = "rejected at the symbolic link component"
			default:
				obs = "rejected for another reason: " + o.Reason
			}
		} else {
			expected = "not run"
		}
		add("P33/absent-leaf-symlink-ancestor", "an absent target path below a symbolic-link ancestor",
			expected, obs, "the walk rejects before the leaf is looked at")
	}

	// P34: the same shape as a dependency path. Absence is a failure there, but
	// the symbolic-link ancestor must still be what decides it.
	{
		expected, obs := "rejected at the symbolic link component", "not run"
		if linkOutside {
			o := physicalPathOutcome(rootDir, rootDir, "escape/dep", true)
			switch {
			case o.Reason == "":
				obs = "admitted"
			case strings.HasPrefix(o.Reason, "symbolic link or reparse component"):
				obs = "rejected at the symbolic link component"
			default:
				obs = "rejected for another reason: " + o.Reason
			}
		} else {
			expected = "not run"
		}
		add("P34/dependency-symlink-ancestor", "a dependency path below a symbolic-link ancestor",
			expected, obs, "")
	}

	// P35: an existing non-directory ancestor. The leaf cannot exist, nothing
	// below it is opened, and the two leaf policies differ as specified.
	{
		oT := physicalPathOutcome(rootDir, rootDir, "real/afile/absent.rs", false)
		oD := physicalPathOutcome(rootDir, rootDir, "real/afile/dep", true)
		obs := fmt.Sprintf("target=%s dependency=%s", verdictWord(oT.Reason), verdictWord(oD.Reason))
		exp := "target=admitted dependency=rejected (dependency path does not exist)"
		add("P35/non-directory-ancestor", "a path below an existing regular file", exp, obs, "")
	}

	// P36: a symbolic-link leaf is rejected even when its target is inside R.
	{
		expected, obs := "rejected", "not run"
		if os.Symlink(filepath.Join(rootDir, "real", "afile"), filepath.Join(rootDir, "leaflink.rs")) == nil {
			o := physicalPathOutcome(rootDir, rootDir, "leaflink.rs", false)
			obs = verdictWord(o.Reason)
			if o.Reason != "" {
				obs = "rejected"
			}
		} else {
			expected = "not run"
		}
		add("P36/symlink-leaf", "a target path that is itself a symbolic link", expected, obs,
			"a link inside R is still a redirection the manager did not admit")
	}

	// P37: the auto-discovered build script gate of section 4.2. `package.build`
	// absent plus a `build.rs` file is the shape the forbidden-key gate cannot
	// see, because there is no key to reject.
	{
		bsDir := filepath.Join(rootDir, "bsgate")
		_ = os.MkdirAll(bsDir, 0o755)
		clean := buildScriptFileGate(bsDir)
		_ = os.WriteFile(filepath.Join(bsDir, "build.rs"), []byte("fn main() {}\n"), 0o644)
		dirty := buildScriptFileGate(bsDir)
		obs := fmt.Sprintf("without build.rs=%v with build.rs=%v", clean == "", dirty == "")
		add("P37/auto-discovered-build-script", "the build.rs file gate over a manifest directory",
			"without build.rs=true with build.rs=false", obs, dirty)
	}

	// Ancestor obligations, both directions. The fixture is created under the
	// runner's temporary directory rather than under the probe work directory,
	// because the obligation walks to the filesystem root and a work directory
	// under an operator home would legitimately find the operator's own
	// `~/.cargo`. When the temporary directory itself is not clean the vector
	// reports that as a reason rather than as a divergence.
	anc, mkErr := os.MkdirTemp("", "rustprobe-anc-")
	if mkErr != nil {
		anc = filepath.Join(work, "prewalk-anc")
		_ = os.RemoveAll(anc)
	}
	_ = os.MkdirAll(filepath.Join(anc, "parent", "build_root"), 0o755)
	clean := ancestorObligation(filepath.Join(anc, "parent", "build_root"))
	expClean, obsClean := "clean", "clean"
	if clean != "" {
		expClean = "not run"
		obsClean = "not run"
	}
	add("P28/ancestor-clean", "no ancestor Cargo.toml or .cargo", expClean, obsClean, clean)

	_ = os.WriteFile(filepath.Join(anc, "parent", "Cargo.toml"), []byte("[workspace]\n"), 0o644)
	got := ancestorObligation(filepath.Join(anc, "parent", "build_root"))
	obsDirty := "clean"
	if strings.HasSuffix(got, "/Cargo.toml") {
		obsDirty = "offending ancestor manifest found"
	}
	add("P29/ancestor-manifest", "an ancestor Cargo.toml is detected", "offending ancestor manifest found", obsDirty, got)

	_ = os.RemoveAll(filepath.Join(anc, "parent", "Cargo.toml"))
	_ = os.MkdirAll(filepath.Join(anc, "parent", ".cargo"), 0o755)
	got2 := ancestorObligation(filepath.Join(anc, "parent", "build_root"))
	obsCargo := "clean"
	if strings.HasSuffix(got2, "/.cargo") {
		obsCargo = "offending ancestor config directory found"
	}
	add("P30/ancestor-cargo-dir", "an ancestor .cargo directory is detected",
		"offending ancestor config directory found", obsCargo, got2)

	return out
}
