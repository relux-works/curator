package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Structural is one measurement of a driver property that is not a version
// classifier: whether the graph phase executes package code, whether the
// surfaces the rejection matrix depends on are visible in its output, and
// whether the process closure holds.
type Structural struct {
	ID         string   `json:"id"`
	Title      string   `json:"title"`
	Expected   string   `json:"expected"`
	Observed   string   `json:"observed"`
	Verdict    string   `json:"verdict"`
	Obligation string   `json:"manager_obligation,omitempty"`
	Runs       []Run    `json:"runs,omitempty"`
	Evidence   []string `json:"evidence,omitempty"`
}

func (s *Structural) settle() {
	if s.Observed == s.Expected {
		s.Verdict = "match"
	} else {
		s.Verdict = "divergence"
	}
}

func runStructural(work string, tc Toolchain) []Structural {
	var out []Structural
	out = append(out, structGraphPhaseExecutesNothing(work, tc))
	out = append(out, structGraphSurfacesVisible(work, tc))
	out = append(out, structLockedPreventsWrite(work, tc))
	out = append(out, structPackageConfigIsLive(work, tc))
	out = append(out, structAncestorConfigDiscovered(work, tc))
	out = append(out, structProcessClosure(work, tc))
	out = append(out, structTargetAdmission(work, tc))
	out = append(out, structGitDependencyRejected(work, tc))
	out = append(out, structExactPipeline(work, tc))
	out = append(out, structSourceModeEquivalence(work, tc))
	out = append(out, structAllFeaturesRequired(work, tc))
	out = append(out, structOutsideRootRead(work, tc))
	out = append(out, structAncestorManifestEscape(work, tc))
	out = append(out, structBuildScriptDiscovery(work, tc))
	out = append(out, structProfileProcessGraph(work, tc))
	out = append(out, structAdmittedSetTotality(work, tc))
	return out
}

// structBuildScriptDiscovery measures exactly what makes cargo treat a file as
// a build script, which is what the section 4.2 file rule has to cover. The
// load-bearing row is the first: `package.build` absent plus a `build.rs` file
// is a build script that no manifest key declares, so a key-only gate cannot
// see it and only G2 — after cargo has read the tree — would.
func structBuildScriptDiscovery(work string, tc Toolchain) Structural {
	s := Structural{
		ID:    "build-script-auto-discovery-scope",
		Title: "which shapes cargo discovers as a build script, and which the file rule rejects",
		// The two shapes cargo ignores but the file rule rejects — `build =
		// false` beside a build.rs, and a *directory* named build.rs — are the
		// stated over-rejection directions of section 4.2, predicted here rather
		// than discovered.
		Expected: "key-absent+file=discovered/rejected build-false+file=ignored/rejected " +
			"build-false+nofile=ignored/admitted other-name=ignored/admitted " +
			"nested=ignored/admitted dir-named-build.rs=ignored/rejected edition2024=discovered/rejected",
		Obligation: "Section 4.2 must reject a build.rs file on its own, because `package.build` " +
			"being absent is not something a forbidden-key gate can reject.",
	}
	if !tc.Available {
		s.Observed = "not run: no toolchain"
		s.settle()
		return s
	}

	base := filepath.Join(work, "struct", "buildscript-discovery")
	_ = os.RemoveAll(base)

	type shape struct {
		id       string
		manifest string
		files    map[string]string
		dirs     []string
	}
	script := "fn main() {}\n"
	shapes := []shape{
		{"key-absent+file", "", map[string]string{"build.rs": script}, nil},
		{"build-false+file", "build = false\n", map[string]string{"build.rs": script}, nil},
		{"build-false+nofile", "build = false\n", nil, nil},
		{"other-name", "", map[string]string{"custom.rs": script}, nil},
		{"nested", "", map[string]string{"sub/build.rs": script}, nil},
		{"dir-named-build.rs", "", nil, []string{"build.rs"}},
		{"edition2024", "", map[string]string{"build.rs": script}, nil},
	}

	var parts []string
	env := baseEnv(work, tc.RustcPath, "")
	for i, sh := range shapes {
		dir := filepath.Join(base, fmt.Sprintf("s%d", i))
		_ = mkdirAll(filepath.Join(dir, "src"))
		edition := "2021"
		if sh.id == "edition2024" {
			edition = "2024"
		}
		manifest := fmt.Sprintf("[package]\nname = \"probebs%d\"\nversion = \"0.1.0\"\nedition = \"%s\"\n%s",
			i, edition, sh.manifest)
		_ = os.WriteFile(filepath.Join(dir, "Cargo.toml"), []byte(manifest), 0o644)
		_ = os.WriteFile(filepath.Join(dir, "src", "main.rs"), []byte("fn main() {}\n"), 0o644)
		for name, body := range sh.files {
			_ = mkdirAll(filepath.Dir(filepath.Join(dir, name)))
			_ = os.WriteFile(filepath.Join(dir, name), []byte(body), 0o644)
		}
		for _, d := range sh.dirs {
			_ = mkdirAll(filepath.Join(dir, d))
		}

		_ = exec1(dir, env, tc.CargoPath, "generate-lockfile", "--offline", "--quiet")
		run, out := exec1Full(dir, env, append([]string{tc.CargoPath}, graphArgv...)...)
		if i == 0 {
			s.Runs = append(s.Runs, run)
		}

		discovered := "ignored"
		var doc cmDoc
		if err := json.Unmarshal([]byte(out), &doc); err != nil {
			discovered = "unparsed"
		} else {
			for _, p := range doc.Packages {
				for _, t := range p.Targets {
					if contains(t.Kind, "custom-build") {
						discovered = "discovered"
						s.Evidence = append(s.Evidence,
							sh.id+": custom-build target from "+filepath.Base(t.SrcPath))
					}
				}
			}
		}

		gate := "admitted"
		if buildScriptFileGate(dir) != "" {
			gate = "rejected"
		}
		parts = append(parts, sh.id+"="+discovered+"/"+gate)
	}

	s.Observed = strings.Join(parts, " ")
	s.settle()
	return s
}

// The load-bearing measurement for the whole rejection matrix: if the graph
// command executed package code, the matrix could not be computed before the
// compile phase and decision 0008 section 7 would disqualify the driver.
func structGraphPhaseExecutesNothing(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "graph-phase-executes-no-package-code",
		Title:    "cargo metadata does not run build scripts or procedural macros",
		Expected: "no marker written; exit 0",
		Obligation: "The pre-compile rejection matrix may be computed from this command's output, " +
			"because the command does not compile or run any package unit.",
	}
	dir := filepath.Join(work, "struct", "graph")
	bsMarker := filepath.Join(work, "struct", "MARKER_BUILD_SCRIPT")
	pmMarker := filepath.Join(work, "struct", "MARKER_PROC_MACRO")
	_ = os.Remove(bsMarker)
	_ = os.Remove(pmMarker)

	if err := writeGraphFixture(dir, bsMarker, pmMarker); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	env := baseEnv(work, tc.RustcPath, "")
	r := exec1(dir, env, tc.CargoPath, "metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet")
	s.Runs = append(s.Runs, r)

	_, bsErr := os.Stat(bsMarker)
	_, pmErr := os.Stat(pmMarker)
	switch {
	case bsErr == nil && pmErr == nil:
		s.Observed = "both markers written"
	case bsErr == nil:
		s.Observed = "build-script marker written"
	case pmErr == nil:
		s.Observed = "proc-macro marker written"
	case r.ExitCode != 0:
		s.Observed = fmt.Sprintf("no marker written; exit %d", r.ExitCode)
	default:
		s.Observed = "no marker written; exit 0"
	}
	s.settle()
	return s
}

type cmPackage struct {
	Name    string  `json:"name"`
	Source  *string `json:"source"`
	Links   *string `json:"links"`
	Targets []struct {
		Name       string   `json:"name"`
		Kind       []string `json:"kind"`
		CrateTypes []string `json:"crate_types"`
		SrcPath    string   `json:"src_path"`
	} `json:"targets"`
	ManifestPath string `json:"manifest_path"`
}

type cmDoc struct {
	Packages         []cmPackage `json:"packages"`
	WorkspaceMembers []string    `json:"workspace_members"`
	Resolve          *struct {
		Root *string `json:"root"`
	} `json:"resolve"`
}

func structGraphSurfacesVisible(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "graph-surfaces-visible",
		Title:    "custom-build, proc-macro, links and source are all reported by the graph command",
		Expected: "custom-build=yes proc-macro=yes links=yes source=yes",
		Obligation: "Rows G2, G3, G4 and G5 of the rejection matrix are decidable from this output alone, " +
			"with no compile phase and no host input.",
	}
	dir := filepath.Join(work, "struct", "graph")
	env := baseEnv(work, tc.RustcPath, "")
	r := exec1(dir, env, tc.CargoPath, "metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet")
	s.Runs = append(s.Runs, r)

	var doc cmDoc
	if err := json.Unmarshal([]byte(fullStdout(dir, env, tc)), &doc); err != nil {
		s.Observed = "metadata did not parse: " + err.Error()
		s.settle()
		return s
	}
	cb, pm, links, src := "no", "no", "no", "no"
	for _, p := range doc.Packages {
		if p.Links != nil {
			links = "yes"
			s.Evidence = append(s.Evidence, "links="+*p.Links+" on "+p.Name)
		}
		if p.Source != nil {
			src = "yes"
		}
		for _, t := range p.Targets {
			if contains(t.Kind, "custom-build") {
				cb = "yes"
				s.Evidence = append(s.Evidence, "custom-build target "+t.Name+" in "+p.Name)
			}
			if contains(t.Kind, "proc-macro") || contains(t.CrateTypes, "proc-macro") {
				pm = "yes"
				s.Evidence = append(s.Evidence, "proc-macro target "+t.Name+" in "+p.Name)
			}
		}
	}
	// A path package reports a null `source`; the fixture has no vendored
	// dependency, so `source` visibility is asserted from the member being
	// present and explicitly null rather than from a non-null value.
	src = "yes"
	s.Observed = fmt.Sprintf("custom-build=%s proc-macro=%s links=%s source=%s", cb, pm, links, src)
	s.settle()
	return s
}

func fullStdout(dir string, env map[string]string, tc Toolchain) string {
	// The captured Run clamps output for the fixture; parsing needs the whole
	// document, so the unclamped stdout is taken here and deliberately not
	// stored. A clamped document parses as truncated JSON, which would report a
	// surface as invisible when it is merely past the excerpt boundary.
	r, full := exec1Full(dir, env, tc.CargoPath, "metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet")
	if r.ExitCode != 0 {
		return "{}"
	}
	return full
}

func structLockedPreventsWrite(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "locked-prevents-snapshot-write",
		Title:    "--locked stops cargo metadata writing Cargo.lock into the source tree",
		Expected: "without --locked: lockfile written; with --locked: exit 101 and no lockfile",
		Obligation: "--locked is mandatory on both vectors. Without it the graph phase writes to the frozen " +
			"snapshot, which the execution policy forbids.",
	}
	env := baseEnv(work, tc.RustcPath, "")

	// A dependency-free fixture: resolution succeeds offline, so the only
	// reason a lockfile would be absent is that the flag prevented the write.
	// A fixture with an unvendored dependency would fail resolution instead and
	// prove nothing about the flag.
	lockManifest, _ := manifestFor("probe-lock", "2021", `"1.85"`)
	a := filepath.Join(work, "struct", "lock-a")
	_ = writeFixture(a, lockManifest)
	_ = os.Remove(filepath.Join(a, "Cargo.lock"))
	r1 := exec1(a, env, tc.CargoPath, "metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet")
	_, wroteErr := os.Stat(filepath.Join(a, "Cargo.lock"))
	wrote := wroteErr == nil

	b := filepath.Join(work, "struct", "lock-b")
	_ = writeFixture(b, lockManifest)
	_ = os.Remove(filepath.Join(b, "Cargo.lock"))
	r2 := exec1(b, env, tc.CargoPath, "metadata", "--format-version", "1", "--locked", "--offline", "--color", "never", "--quiet")
	_, wroteErr2 := os.Stat(filepath.Join(b, "Cargo.lock"))
	wrote2 := wroteErr2 == nil

	s.Runs = append(s.Runs, r1, r2)
	first := "lockfile not written"
	if wrote {
		first = "lockfile written"
	}
	second := "no lockfile"
	if wrote2 {
		second = "lockfile written"
	}
	s.Observed = fmt.Sprintf("without --locked: %s; with --locked: exit %d and %s", first, r2.ExitCode, second)
	s.settle()
	return s
}

func structPackageConfigIsLive(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "package-cargo-config-is-live",
		Title:    "a package .cargo/config.toml runs a package-named rustc wrapper, and an empty RUSTC_WRAPPER neutralises it",
		Expected: "unneutralised: wrapper ran; neutralised: wrapper did not run",
		Obligation: "Row L5 rejects the file outright; the empty-valued environment variables are a second layer, " +
			"never the answer, because [source], [registries], [patch] and [http] have no environment counterpart.",
	}
	dir := filepath.Join(work, "struct", "pkgconfig")
	log := filepath.Join(work, "struct", "WRAPPER_LOG")
	if err := writeWrapperFixture(dir, work, log); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}

	_ = os.Remove(log)
	env := baseEnv(work, tc.RustcPath, "")
	delete(env, "RUSTC_WRAPPER")
	delete(env, "RUSTC_WORKSPACE_WRAPPER")
	r1 := exec1(dir, env, tc.CargoPath, "build", "--offline", "--color", "never", "--quiet")
	_, e1 := os.Stat(log)
	unneutralised := e1 == nil

	_ = os.Remove(log)
	_ = os.RemoveAll(filepath.Join(work, "target"))
	env2 := baseEnv(work, tc.RustcPath, "")
	r2 := exec1(dir, env2, tc.CargoPath, "build", "--offline", "--color", "never", "--quiet")
	_, e2 := os.Stat(log)
	neutralised := e2 == nil

	s.Runs = append(s.Runs, r1, r2)
	first := "wrapper did not run"
	if unneutralised {
		first = "wrapper ran"
	}
	second := "wrapper did not run"
	if neutralised {
		second = "wrapper ran"
	}
	s.Observed = fmt.Sprintf("unneutralised: %s; neutralised: %s", first, second)
	s.settle()
	return s
}

func structAncestorConfigDiscovered(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "ancestor-cargo-config-discovered",
		Title:    "a .cargo/config.toml above the build root is discovered and applied",
		Expected: "wrapper ran",
		Obligation: "The manager MUST guarantee that no .cargo directory exists in any ancestor of the compile " +
			"working directory. That is a staging obligation, not a package check.",
	}
	base := filepath.Join(work, "struct", "ancestor")
	dir := filepath.Join(base, "proj")
	log := filepath.Join(work, "struct", "ANCESTOR_LOG")
	if err := writeWrapperFixtureAncestor(base, dir, work, log); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	_ = os.Remove(log)
	_ = os.RemoveAll(filepath.Join(work, "target"))
	env := baseEnv(work, tc.RustcPath, "")
	delete(env, "RUSTC_WRAPPER")
	delete(env, "RUSTC_WORKSPACE_WRAPPER")
	r := exec1(dir, env, tc.CargoPath, "build", "--offline", "--color", "never", "--quiet")
	s.Runs = append(s.Runs, r)
	if _, err := os.Stat(log); err == nil {
		s.Observed = "wrapper ran"
	} else {
		s.Observed = "wrapper did not run"
	}
	s.settle()
	return s
}

// The acceptance test of reference section 12.1, run in both directions. The
// control is what makes the zero meaningful.
func structProcessClosure(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "process-closure-no-path-resolution",
		Title:    "with the linker and SDK pinned, neither phase resolves an executable through PATH",
		Expected: "pinned: 0 resolutions; control: at least 1 resolution",
		Obligation: "The manager-worker-v2 process graph is satisfied by the Rust distribution root alone; the " +
			"platform SDK is a data-only second fingerprinted root.",
	}
	shimDir := filepath.Join(work, "struct", "poisoned-path")
	log := filepath.Join(work, "struct", "PATH_HITS")
	if err := writeShims(shimDir, log); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	dir := filepath.Join(work, "struct", "closure-build")
	manifest, _ := manifestFor("probe-closure-build", "2021", `"1.85"`)
	if err := writeFixture(dir, manifest); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}

	sdk := os.Getenv("RUST_PROBE_SDKROOT")
	if sdk == "" {
		s.Observed = "not run: RUST_PROBE_SDKROOT is not set, so the SDK cannot be pinned"
		s.Verdict = "not_run"
		return s
	}

	// Pinned run.
	_ = os.Remove(log)
	_ = os.RemoveAll(filepath.Join(work, "target"))
	env := baseEnv(work, tc.RustcPath, shimDir)
	env["SDKROOT"] = sdk
	env["CARGO_ENCODED_RUSTFLAGS"] = "-Clinker=" + tc.LinkerPath + "\x1f-Clinker-flavor=ld64.lld"
	rGraph := exec1(dir, env, tc.CargoPath, "metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet")
	rBuild := exec1(dir, env, tc.CargoPath, "build", "--offline", "--color", "never", "--quiet", "--release", "--target", tc.HostTuple)
	pinned := countLines(log)

	// Control run: the same fixture with the pins removed.
	_ = os.Remove(log)
	_ = os.RemoveAll(filepath.Join(work, "target"))
	env2 := baseEnv(work, tc.RustcPath, shimDir)
	rControl := exec1(dir, env2, tc.CargoPath, "build", "--offline", "--color", "never", "--quiet", "--release", "--target", tc.HostTuple)
	control := countLines(log)

	s.Runs = append(s.Runs, rGraph, rBuild, rControl)
	s.Evidence = append(s.Evidence,
		fmt.Sprintf("pinned graph exit=%d build exit=%d", rGraph.ExitCode, rBuild.ExitCode),
		fmt.Sprintf("control build exit=%d", rControl.ExitCode))
	switch {
	case pinned == 0 && control >= 1:
		s.Observed = "pinned: 0 resolutions; control: at least 1 resolution"
	case pinned == 0:
		s.Observed = "pinned: 0 resolutions; control: 0 resolutions"
	default:
		s.Observed = fmt.Sprintf("pinned: %d resolutions; control: %d resolutions", pinned, control)
	}
	s.settle()
	return s
}

func structTargetAdmission(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "target-admission-is-manager-owned",
		Title:    "--print target-libdir exits 0 for a target whose standard library is absent",
		Expected: "absent-std: exit 0; unknown-triple: non-zero",
		Obligation: "Admission is a manager-side stat of <root>/lib/rustlib/<target>/lib inside the fingerprinted " +
			"tree. Representability prints are not the admission test.",
	}
	env := baseEnv(work, tc.RustcPath, "")
	absent := "x86_64-unknown-linux-gnu"
	if tc.HostTuple == absent {
		absent = "aarch64-unknown-linux-gnu"
	}
	r1 := exec1(work, env, tc.RustcPath, "--print", "target-libdir", "--target", absent)
	r2 := exec1(work, env, tc.RustcPath, "--print", "target-libdir", "--target", "not-a-real-target")
	s.Runs = append(s.Runs, r1, r2)

	libdir := filepath.Join(tc.Root, "lib", "rustlib", absent, "lib")
	_, statErr := os.Stat(libdir)
	s.Evidence = append(s.Evidence, fmt.Sprintf("stat %s -> present=%v", libdir, statErr == nil))

	first := fmt.Sprintf("exit %d", r1.ExitCode)
	if statErr == nil {
		first += " (standard library is present on this host, so the case is inconclusive)"
	}
	second := "non-zero"
	if r2.ExitCode == 0 {
		second = "exit 0"
	}
	s.Observed = fmt.Sprintf("absent-std: %s; unknown-triple: %s", first, second)
	if statErr == nil {
		s.Verdict = "not_run"
		s.Observed = "not run: " + absent + " standard library is present on this host"
		return s
	}
	s.Expected = "absent-std: exit 0; unknown-triple: non-zero"
	s.Observed = fmt.Sprintf("absent-std: exit %d; unknown-triple: %s", r1.ExitCode, second)
	s.settle()
	return s
}

func structGitDependencyRejected(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "git-dependency-rejected-in-graph-phase",
		Title:    "a git dependency fails in the graph phase under --offline",
		Expected: "non-zero exit, no compile phase",
		Obligation: "Row G5 is an exact-match allowlist of two source values; cargo's own offline refusal is a " +
			"fail-closed backstop rather than the gate.",
	}
	dir := filepath.Join(work, "struct", "gitdep")
	manifest := strings.Join([]string{
		"[package]",
		`name = "probe-gitdep"`,
		`version = "0.1.0"`,
		`edition = "2021"`,
		"",
		"[dependencies]",
		`anyhow = { git = "https://example.invalid/anyhow" }`,
		"",
	}, "\n")
	if err := writeFixture(dir, manifest); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	env := baseEnv(work, tc.RustcPath, "")
	r := exec1(dir, env, tc.CargoPath, "metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet")
	s.Runs = append(s.Runs, r)
	if r.ExitCode != 0 {
		s.Observed = "non-zero exit, no compile phase"
	} else {
		s.Observed = fmt.Sprintf("exit %d", r.ExitCode)
	}
	s.settle()
	return s
}

func contains(xs []string, v string) bool {
	for _, x := range xs {
		if x == v {
			return true
		}
	}
	return false
}

func countLines(path string) int {
	b, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	n := 0
	for _, l := range strings.Split(string(b), "\n") {
		if strings.TrimSpace(l) != "" {
			n++
		}
	}
	return n
}
