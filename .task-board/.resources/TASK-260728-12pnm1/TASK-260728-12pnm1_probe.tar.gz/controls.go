package main

import (
	"fmt"
	"strings"
)

// Control is a superseded classification, command form, or recognition family
// kept runnable as a check that is **required to fail**. A control that stops
// failing is a regression: it means the defect it guards has been
// reintroduced, or the property that made it fail has been silently dropped.
type Control struct {
	ID       string `json:"id"`
	Guards   string `json:"guards"`
	Failed   bool   `json:"failed"`
	Findings int    `json:"findings"`
	Detail   string `json:"detail"`
}

func runControls(measured []Measured, closure []ClosureCheck, tc Toolchain, work string) []Control {
	return []Control{
		controlOpenClassifier(closure, tc),
		controlLeadOnly(measured, tc),
		controlExitStatusSemantics(measured),
		controlBuildAsIsolated(work, tc),
		controlEditionFoldedIntoGrammar(measured),
		controlSubstringMatching(measured, tc),
		controlOmittedAllFeatures(work, tc),
		controlEscapeFromGraphOnly(work, tc),
		controlNaiveConfigWriter(),
		controlOperatorCargoLeak(work, tc),
		controlRawLimitBeforeFolding(),
		controlKeyOnlyBuildScriptGate(work, tc),
		controlProfileAdmittedWholesale(work, tc),
		controlPackedDenyList(work, tc),
		controlSupersededAdmittedSet(work, tc),
	}
}

// C1. An open classifier with a fall-through verdict. Guards closure in both
// directions: every unrelated real failure becomes a verdict.
func controlOpenClassifier(closure []ClosureCheck, tc Toolchain) Control {
	n := 0
	for _, c := range closure {
		if c.Direction == "acceptance-laundering" && c.Kind == "real-unrelated-failure" {
			// The open variant names a verdict for anything it does not
			// recognise. Every one of these outcomes would become one.
			n++
		}
	}
	return Control{
		ID:       "C1/open-classifier",
		Guards:   "closure in both laundering directions",
		Failed:   n > 0,
		Findings: n,
		Detail: fmt.Sprintf("a fall-through branch would name a verdict for %d measured unrelated failures "+
			"that the closed classifier leaves without one", n),
	}
}

// C2. Lead-only recognition, dropping the caret source line. Guards the three
// grammar classes from collapsing into one: none of the first lines names the
// value under test, so a lead-only classifier recognises a diagnostic produced
// for a different value.
func controlLeadOnly(measured []Measured, tc Toolchain) Control {
	n := 0
	var examples []string
	for _, m := range measured {
		if m.Status != "match" || m.Isolated.Layer != LayerGrammar || len(m.Runs) == 0 {
			continue
		}
		wrong := Predicted{
			Literal: `"1.85"`, LiteralBody: "1.85", Line: 5, Edition: "2021",
			EditionFloor: editionFloors["2021"], HostVersion: tc.RustVersion,
		}
		combined := m.Runs[0].Stdout + "\n" + m.Runs[0].Stderr
		if leadOnlyClassify(wrong, combined) {
			n++
			if len(examples) < 3 {
				examples = append(examples, m.Case.ID)
			}
		}
	}
	return Control{
		ID:       "C2/lead-only-recognition",
		Guards:   "three grammar classes collapsing into one",
		Failed:   n > 0,
		Findings: n,
		Detail: fmt.Sprintf("a lead-only classifier recognised %d diagnostics that were produced for a different "+
			"value under test (examples: %s)", n, strings.Join(examples, ", ")),
	}
}

func leadOnlyClassify(p Predicted, combined string) bool {
	for _, l := range normalizeLines(combined) {
		if l == p.grammarOtherFirstLine() || l == p.grammarPrereleaseFirstLine() || l == p.grammarBuildFirstLine() {
			return true
		}
	}
	return false
}

// C3. Exit status as the semantic measurement. Guards against folding the host
// gate and the edition floor into the grammar layer: a value that is perfectly
// representable but above the resolved toolchain exits non-zero, and an
// exit-status classifier scores it as unrepresentable.
func controlExitStatusSemantics(measured []Measured) Control {
	n := 0
	var examples []string
	for _, m := range measured {
		if m.Status != "match" || len(m.Runs) < 2 {
			continue
		}
		representable := m.Isolated.Layer == LayerAccepted
		exitSaysRepresentable := m.Runs[1].ExitCode == 0
		if representable != exitSaysRepresentable {
			n++
			if len(examples) < 3 {
				examples = append(examples, m.Case.ID)
			}
		}
	}
	return Control{
		ID:       "C3/exit-status-as-semantics",
		Guards:   "the host gate folded into the grammar layer",
		Failed:   n > 0,
		Findings: n,
		Detail: fmt.Sprintf("%d cases where the corroborating command's exit status disagrees with the isolated "+
			"representability measurement (examples: %s)", n, strings.Join(examples, ", ")),
	}
}

// C4. `cargo build` as the isolated representability command. Guards the same
// folding, arrived at by choosing a wider command rather than a wider reading.
// C3 and C4 are not redundant: C3 changes how an outcome is read, C4 changes
// which command produces it, and either alone leaves the other reachable.
func controlBuildAsIsolated(work string, tc Toolchain) Control {
	c := Case{ID: "control-c4", Literal: `"1.99"`, Edition: "2021",
		ExpectLayer: LayerAccepted, CuratorClass: 4, Compared: true}
	m := measureCase(work, tc, c)
	if m.Status == "not_run" {
		return Control{ID: "C4/build-as-isolated", Guards: "the host gate folded in by command choice",
			Failed: false, Detail: "not run: " + m.Reason}
	}
	// The isolated command reports the value; the build command gates on it.
	// Using the build command as the isolated measurement therefore reports a
	// representable value as not representable, which is a P1 violation against
	// a class this contract deliberately keeps as `compared`.
	violates := m.Isolated.Layer == LayerAccepted && m.Corroborating.Layer == LayerHostGate
	return Control{
		ID:       "C4/build-as-isolated",
		Guards:   "the host gate folded in by command choice",
		Failed:   violates,
		Findings: boolToInt(violates),
		Detail: fmt.Sprintf("isolated=%s corroborating=%s for a representable value above the resolved toolchain; "+
			"using the corroborating command as the isolated one yields a P1 violation", m.Isolated.Layer, m.Corroborating.Layer),
	}
}

// C5. The edition floor folded into the grammar classifier. Guards one
// host-independent layer swallowing another: the grammar layer accepts values
// the edition floor rejects, so a merged classifier has no outcome that
// distinguishes them and loses the independence witness.
func controlEditionFoldedIntoGrammar(measured []Measured) Control {
	grammarAccepts := 0
	editionRejects := 0
	for _, m := range measured {
		if m.Status != "match" {
			continue
		}
		if m.Isolated.Layer == LayerEdition {
			editionRejects++
			// The same literal is grammar-representable: `"1"`, `"1.31"` and
			// `"1.56"` all parse. A merged classifier would call them
			// grammar rejections, which contradicts the accepted case that
			// uses the identical literal at a lower edition.
			grammarAccepts++
		}
	}
	return Control{
		ID:       "C5/edition-folded-into-grammar",
		Guards:   "one host-independent layer swallowing another",
		Failed:   editionRejects > 0 && grammarAccepts > 0,
		Findings: editionRejects,
		Detail: fmt.Sprintf("%d measured values are grammar-representable and rejected only by the edition floor; "+
			"a merged classifier would report them as grammar rejections", editionRejects),
	}
}

// C6. Substring matching anywhere in combined output. Guards against
// recognising a family rather than an outcome.
func controlSubstringMatching(measured []Measured, tc Toolchain) Control {
	n := 0
	wrong := Predicted{
		Literal: `"1.85"`, LiteralBody: "1.85", Line: 5, Edition: "2021",
		EditionFloor: editionFloors["2021"], HostVersion: tc.RustVersion,
	}
	needle := `expected a version like "1.32"`
	for _, m := range measured {
		if m.Status != "match" || len(m.Runs) == 0 {
			continue
		}
		combined := m.Runs[0].Stdout + "\n" + m.Runs[0].Stderr
		if strings.Contains(combined, needle) && !strings.Contains(combined, wrong.caretLine()) {
			n++
		}
	}
	return Control{
		ID:       "C6/substring-matching",
		Guards:   "recognising a family rather than an outcome",
		Failed:   n > 0,
		Findings: n,
		Detail:   fmt.Sprintf("a substring matcher recognised %d outcomes that belong to a different value under test", n),
	}
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}
