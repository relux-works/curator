package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
)

// Controls C13, C14 and C15 keep the three superseded cycle-3 behaviours
// runnable as checks that are **required to fail**. Each also re-checks its
// replacement and reports itself as *not* failing if the replacement regressed,
// so a control can never pass by accident once the fix is undone.

// C13. The superseded rule: `[profile]` tables admitted wholesale, on the
// argument that a release toolchain cannot unlock per-profile rustflags. Guards
// the process-closure claim. Measured: `split-debuginfo = "packed"` beside any
// non-zero `debug` level runs a PATH-resolved `dsymutil` under the exact pinned
// pipeline, and cargo exits 0 after the helper returns 127.
func controlProfileAdmittedWholesale(work string, tc Toolchain) Control {
	c := Control{
		ID:     "C13/profile-tables-admitted-wholesale",
		Guards: "an admitted profile table starting a package-selected process",
	}
	if runtime.GOOS == "windows" || !tc.Available {
		c.Detail = "not run: no toolchain, or POSIX shims unavailable"
		return c
	}
	const packed = "[profile.release]\ndebug = 2\nsplit-debuginfo = \"packed\""
	r := runProfileCase(work, tc, "c13-superseded", packed, false)
	b, _ := json.Marshal(r)

	if supersededProfileGate(packed) == "" && r.Hits > 0 {
		c.Failed = true
		c.Findings = r.Hits
		c.Detail = "the superseded gate admitted the table and the pipeline resolved " + r.Names +
			" through PATH: " + string(b)
	} else {
		c.Detail = "the superseded shape recorded no PATH resolution, so the control no longer exercises it: " + string(b)
	}

	// The replacement must reject the same manifest from snapshot bytes.
	if profileGateVerdict(packed) == "" {
		c.Failed = false
		c.Detail += "; the replacement gate admitted the same table, which is a regression"
	}
	return c
}

// C14. The value deny-list that a first reading suggests: reject "packed" and
// admit every other string. Guards the pin and the positive value allowlist.
// Measured: cargo forwards nothing to rustc for an unrecognized value, and
// rustc's own macOS default is "packed", so a deny-list is bypassed by any
// garbage string — and by the empty string.
func controlPackedDenyList(work string, tc Toolchain) Control {
	c := Control{
		ID:     "C14/split-debuginfo-deny-list",
		Guards: "an unrecognized split-debuginfo value falling back to rustc's process-capable default",
	}
	if runtime.GOOS == "windows" || !tc.Available {
		c.Detail = "not run: no toolchain, or POSIX shims unavailable"
		return c
	}
	const unknown = "[profile.release]\ndebug = 2\nsplit-debuginfo = \"wat\""
	// The superseded deny-list: reject only the literal "packed".
	denyList := func(doc string) string {
		if containsString(doc, `split-debuginfo = "packed"`) {
			return "packed rejected"
		}
		return ""
	}
	r := runProfileCase(work, tc, "c14-denylist", unknown, false)
	b, _ := json.Marshal(r)

	if denyList(unknown) == "" && r.Hits > 0 {
		c.Failed = true
		c.Findings = r.Hits
		c.Detail = "a deny-list naming \"packed\" admitted an unrecognized value and the pipeline resolved " +
			r.Names + " through PATH: " + string(b)
	} else {
		c.Detail = "the unrecognized value recorded no PATH resolution: " + string(b)
	}

	if profileGateVerdict(unknown) == "" {
		c.Failed = false
		c.Detail += "; the replacement allowlist admitted the same value, which is a regression"
	}
	// The pin is the second mechanism and must make the same shape inert.
	pinned := runProfileCase(work, tc, "c14-denylist-pinned", unknown, true)
	if pinned.Hits != 0 {
		c.Failed = false
		c.Detail += fmt.Sprintf("; the -Csplit-debuginfo pin left %d PATH resolutions, which is a regression", pinned.Hits)
	}
	return c
}

// C15. The superseded G11 input set: manifests plus declared path-bearing
// values, with no account of Cargo's auto-discovered target sources. Guards the
// definition of A. Required to reject an ordinary `src/main.rs` package, which
// is a false manager fault on a positive build.
func controlSupersededAdmittedSet(work string, tc Toolchain) Control {
	c := Control{
		ID:     "C15/superseded-g11-admitted-set",
		Guards: "G11 rejecting an ordinary package whose bin target is auto-discovered",
	}
	if !tc.Available {
		c.Detail = "not run: no toolchain"
		return c
	}
	root := filepath.Join(work, "struct", "c15", "build_root")
	_ = os.RemoveAll(root)
	_ = mkdirAll(filepath.Join(root, "src"))
	_ = os.WriteFile(filepath.Join(root, "Cargo.toml"),
		[]byte("[package]\nname = \"probec15\"\nversion = \"0.1.0\"\nedition = \"2021\"\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "src", "main.rs"), []byte(profileProbeMain), 0o644)
	_ = os.WriteFile(filepath.Join(root, "Cargo.lock"),
		[]byte("version = 4\n\n[[package]]\nname = \"probec15\"\nversion = \"0.1.0\"\n"), 0o644)

	env := baseEnv(work, tc.RustcPath, "")
	run, out := exec1Full(root, env, append([]string{tc.CargoPath}, graphArgv...)...)
	if run.ExitCode != 0 {
		c.Detail = fmt.Sprintf("not a valid control: the graph command exited %d", run.ExitCode)
		return c
	}
	var doc cmDoc
	if err := json.Unmarshal([]byte(out), &doc); err != nil {
		c.Detail = "not a valid control: metadata did not parse"
		return c
	}
	reported := reportedPaths(doc)
	sup := supersededAdmittedSet(root, []string{filepath.Join(root, "Cargo.toml")}, nil)
	supOutside := g11(sup, reported)

	if len(supOutside) > 0 {
		c.Failed = true
		c.Findings = len(supOutside)
		c.Detail = fmt.Sprintf("the superseded set left %d reported path(s) outside it on an ordinary package, "+
			"including %s, which G11 would report as a manager fault", len(supOutside), relTo(root, supOutside[0]))
	} else {
		c.Detail = "the superseded set covered every reported path, so the control no longer exercises the gap"
	}

	a := buildAdmittedSet(root, nil)
	if bad := g11(a, reported); len(bad) > 0 {
		c.Failed = false
		c.Detail += fmt.Sprintf("; the replacement set still left %d path(s) outside, which is a regression", len(bad))
	}
	return c
}

func containsString(hay, needle string) bool {
	return len(needle) > 0 && len(hay) >= len(needle) && stringIndex(hay, needle) >= 0
}

func stringIndex(hay, needle string) int {
	for i := 0; i+len(needle) <= len(hay); i++ {
		if hay[i:i+len(needle)] == needle {
			return i
		}
	}
	return -1
}
