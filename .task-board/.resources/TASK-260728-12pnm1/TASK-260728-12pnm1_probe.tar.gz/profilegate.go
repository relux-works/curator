package main

import (
	"strconv"
	"strings"
)

// ---------------------------------------------------------------------------
// Reference section 4.7: the Stage P profile grammar.
//
// The revision this file implements exists because an admitted `[profile]`
// table was measured to start a package-selected process. On macOS arm64 with
// Rust 1.91.0, `[profile.release] debug = 2` plus `split-debuginfo = "packed"`
// makes the contract's exact compile vector run a PATH-resolved `dsymutil`,
// under pinned SDKROOT, pinned rust-lld, `ld64.lld` flavour, offline config and
// an isolated CARGO_HOME. Cargo exits 0 even when the helper fails.
//
// Two further measurements decide the shape of the rule.
//
//  1. An unrecognized *string* value is more dangerous than "packed". Cargo
//     silently forwards nothing to rustc, and rustc's own macOS default is
//     `packed`, so `split-debuginfo = "wat"` and `split-debuginfo = ""` both
//     reach `dsymutil` with no warning and no error. A deny-list naming
//     "packed" would therefore be bypassed by any garbage string.
//  2. An unknown profile *key* is accepted by cargo without a diagnostic, so a
//     key deny-list cannot stay closed against a future stabilization.
//
// The gate is therefore a positive allowlist of table shapes, keys and values,
// exactly as row G5 is an exact-match allowlist of two source values rather
// than a deny-list of source kinds.
//
// The manager runs this over its own TOML parser. The reader below is a bounded
// subset sufficient for the conformance vectors: it is a probe instrument, not
// the normative parser.
// ---------------------------------------------------------------------------

// profileEntry is one key/value line inside one `[profile...]` table.
type profileEntry struct {
	Table string
	Key   string
	Value string
}

// profileTables extracts the `[profile...]` tables of a TOML document, in
// document order. Inline tables (`profile = { ... }`) are not a Cargo manifest
// shape for profiles and are reported as an unadmitted table so the gate stays
// fail-closed rather than silently skipping them.
func profileTables(doc string) []profileEntry {
	var out []profileEntry
	table := ""
	for _, raw := range strings.Split(strings.ReplaceAll(doc, "\r\n", "\n"), "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasPrefix(line, "[") {
			arrayOfTables := strings.HasPrefix(line, "[[")
			name := strings.TrimSuffix(strings.TrimPrefix(line, "["), "]")
			name = strings.TrimSuffix(strings.TrimPrefix(name, "["), "]")
			table = strings.TrimSpace(name)
			if arrayOfTables && isProfileTable(table) {
				// `[[profile.x]]` is not a Cargo profile shape. Mark it with a
				// name the shape check cannot admit rather than skipping it.
				table = "profile.\x00array-of-tables"
			}
			if isProfileTable(table) {
				// A table header with no keys still has to be shape-checked.
				out = append(out, profileEntry{Table: table})
			}
			continue
		}
		if !isProfileTable(table) {
			continue
		}
		eq := strings.Index(line, "=")
		if eq < 0 {
			out = append(out, profileEntry{Table: table, Key: line, Value: ""})
			continue
		}
		if i := strings.Index(line, "#"); i > eq {
			line = strings.TrimSpace(line[:i])
		}
		out = append(out, profileEntry{
			Table: table,
			Key:   strings.TrimSpace(line[:eq]),
			Value: strings.TrimSpace(line[eq+1:]),
		})
	}
	return out
}

func isProfileTable(t string) bool {
	return t == "profile" || strings.HasPrefix(t, "profile.")
}

// admittedProfileTable decides the table *shape*. Exactly three nestings exist
// in the stable Cargo model, and anything else is rejected without asking what
// it contains.
//
//	profile.<name>
//	profile.<name>.package.<spec>
//	profile.<name>.build-override
func admittedProfileTable(t string) bool {
	parts := splitTOMLKey(t)
	if len(parts) < 2 || parts[0] != "profile" {
		return false
	}
	if !profileNameOK(parts[1]) {
		return false
	}
	switch len(parts) {
	case 2:
		return true
	case 3:
		return parts[2] == "build-override"
	case 4:
		return parts[2] == "package" && parts[3] != ""
	default:
		return false
	}
}

// splitTOMLKey splits a dotted table header, honouring quoted segments so that
// `profile.release.package."*"` yields four parts and a dot inside quotes does
// not split.
func splitTOMLKey(t string) []string {
	var parts []string
	var cur strings.Builder
	inQuote := byte(0)
	for i := 0; i < len(t); i++ {
		c := t[i]
		switch {
		case inQuote != 0:
			if c == inQuote {
				inQuote = 0
				continue
			}
			cur.WriteByte(c)
		case c == '"' || c == '\'':
			inQuote = c
		case c == '.':
			parts = append(parts, strings.TrimSpace(cur.String()))
			cur.Reset()
		default:
			cur.WriteByte(c)
		}
	}
	parts = append(parts, strings.TrimSpace(cur.String()))
	return parts
}

func profileNameOK(n string) bool {
	if n == "" || len(n) > 64 {
		return false
	}
	for i := 0; i < len(n); i++ {
		c := n[i]
		ok := (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
			(c >= '0' && c <= '9') || c == '_' || c == '-'
		if !ok {
			return false
		}
	}
	return true
}

// profileValueOK is the closed value allowlist. Every admitted key is measured
// to leave the process graph at cargo -> rustc -> rust-lld; `split-debuginfo`
// is absent from the table on purpose and is the one stable key this contract
// rejects outright.
func profileValueOK(key, value string) bool {
	v := normalizeTOMLScalar(strings.TrimSpace(value))
	switch key {
	case "opt-level":
		return oneOf(v, "0", "1", "2", "3", `"s"`, `"z"`)
	case "debug":
		return oneOf(v, "false", "true", "0", "1", "2",
			`"none"`, `"line-directives-only"`, `"line-tables-only"`, `"limited"`, `"full"`)
	case "strip":
		return oneOf(v, "false", "true", `"none"`, `"debuginfo"`, `"symbols"`)
	case "debug-assertions", "overflow-checks", "incremental", "rpath":
		return oneOf(v, "false", "true")
	case "lto":
		return oneOf(v, "false", "true", `"off"`, `"thin"`, `"fat"`)
	case "panic":
		return oneOf(v, `"unwind"`, `"abort"`)
	case "codegen-units":
		n, err := strconv.Atoi(v)
		return err == nil && n >= 1 && n <= 65536
	case "inherits":
		return oneOf(v, `"dev"`, `"release"`, `"test"`, `"bench"`) ||
			(len(v) > 2 && v[0] == '"' && v[len(v)-1] == '"' && profileNameOK(v[1:len(v)-1]))
	default:
		return false
	}
}

// normalizeTOMLScalar rewrites a literal string into its basic-string spelling
// so that `'s'` and `"s"` are the same value, as they are in TOML. It touches
// nothing else: a non-string scalar passes through unchanged, and a basic
// string carrying an escape sequence is left alone and therefore fails the
// allowlist, which is the fail-closed direction.
func normalizeTOMLScalar(v string) string {
	if len(v) >= 2 && v[0] == '\'' && v[len(v)-1] == '\'' {
		return `"` + v[1:len(v)-1] + `"`
	}
	return v
}

func oneOf(v string, xs ...string) bool {
	for _, x := range xs {
		if v == x {
			return true
		}
	}
	return false
}

// profileGateVerdict returns "" when every profile table in the document is
// admitted, and the first failing reason otherwise. The diagnostic the manager
// reports is `build_rust_manifest_key_forbidden`; nothing new is minted.
func profileGateVerdict(doc string) string {
	for _, e := range profileTables(doc) {
		if !admittedProfileTable(e.Table) {
			return "profile table shape not admitted: [" + e.Table + "]"
		}
		if e.Key == "" {
			continue
		}
		key := unquoteKey(e.Key)
		if key == "split-debuginfo" {
			return "profile key rejected outright: " + e.Table + "." + e.Key
		}
		if !profileValueOK(key, e.Value) {
			return "profile key or value not admitted: " + e.Table + "." + e.Key + " = " + e.Value
		}
	}
	return ""
}

// unquoteKey strips the TOML quoting a key may carry, so that `split-debuginfo`
// and `"split-debuginfo"` are the same key.
func unquoteKey(k string) string {
	if len(k) >= 2 && (k[0] == '"' || k[0] == '\'') && k[len(k)-1] == k[0] {
		return k[1 : len(k)-1]
	}
	return k
}

// supersededProfileGate is the rule this revision replaces: `[profile]` tables
// admitted wholesale on the argument that a release toolchain cannot unlock
// per-profile rustflags. Kept runnable for control C13.
func supersededProfileGate(string) string { return "" }
