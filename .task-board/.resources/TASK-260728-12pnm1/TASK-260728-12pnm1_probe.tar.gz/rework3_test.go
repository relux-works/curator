package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// ---------------------------------------------------------------------------
// Cycle-3 blocker 1: the size boundary must be decided after CRLF folding.
// ---------------------------------------------------------------------------

// boundaryStream returns an LF stream whose folded length is exactly n bytes,
// built from ten-byte lines so that its CRLF expansion is far larger than n.
func boundaryStream(n int) string {
	lines := (n - 6) / 10
	body := strings.Repeat(strings.Repeat("x", 9)+"\n", lines)
	rest := n - len(body) - 1
	return body + strings.Repeat("x", rest) + "\n"
}

func TestBoundaryStreamHelperIsExact(t *testing.T) {
	for _, n := range []int{4096, 4097, 100, 4095} {
		if got := len(boundaryStream(n)); got != n {
			t.Fatalf("boundaryStream(%d) produced %d bytes", n, got)
		}
	}
}

func TestLineEndingsNeverChangeAdmission(t *testing.T) {
	for _, n := range []int{2, 100, 4094, 4095, 4096, 4097, 4098, 5000} {
		lf := boundaryStream(n)
		crlf := strings.ReplaceAll(lf, "\n", "\r\n")
		pl, wl := normalizeVersionStream([]byte(lf), true)
		pc, wc := normalizeVersionStream([]byte(crlf), true)
		if (wl == "") != (wc == "") {
			t.Fatalf("folded length %d: LF %q and CRLF %q disagree (raw %d vs %d)",
				n, wl, wc, len(lf), len(crlf))
		}
		if wl == "" && string(pl) != string(pc) {
			t.Fatalf("folded length %d: admitted with different payloads", n)
		}
		if wl == "" && sha256hex(frameVersionRecord('V', pl)) != sha256hex(frameVersionRecord('V', pc)) {
			t.Fatalf("folded length %d: admitted with different digests", n)
		}
	}
}

func TestSemanticBoundIsOnTheFoldedStream(t *testing.T) {
	if _, why := normalizeVersionStream([]byte(boundaryStream(4096)), true); why != "" {
		t.Fatalf("a folded stream of exactly 4096 bytes must be admitted, got %q", why)
	}
	if _, why := normalizeVersionStream([]byte(boundaryStream(4097)), true); why == "" {
		t.Fatal("a folded stream of 4097 bytes must be rejected")
	}
	// The reviewer's exact construction.
	lf := strings.Repeat("x", 4093) + "\nA\n"
	crlf := strings.ReplaceAll(lf, "\n", "\r\n")
	if len(lf) != 4096 || len(crlf) != 4098 {
		t.Fatalf("construction drifted: %d %d", len(lf), len(crlf))
	}
	a, wa := normalizeVersionStream([]byte(lf), true)
	b, wb := normalizeVersionStream([]byte(crlf), true)
	if wa != "" || wb != "" {
		t.Fatalf("both forms must be admitted: %q %q", wa, wb)
	}
	if string(a) != string(b) || len(a) != 4095 {
		t.Fatal("both forms must yield the same 4095-byte payload")
	}
}

func TestRawCaptureBoundIsNonLossy(t *testing.T) {
	// Folding replaces two bytes with one and rewrites nothing else, so
	// len(folded) >= ceil(len(raw)/2). The raw bound must therefore never be
	// able to reject a stream the semantic bound would admit.
	for n := 0; n <= 4*maxVersionStreamRaw; n++ {
		if n > maxVersionStreamRaw && (n+1)/2 <= maxVersionStream {
			t.Fatalf("raw length %d could fold within the semantic bound", n)
		}
	}
	// Reached, not pre-empted: the maximal expansion of an in-bound folded
	// stream passes the raw bound and is decided by a semantic rule.
	raw := strings.Repeat("\r\n", maxVersionStream)
	if len(raw) != maxVersionStreamRaw {
		t.Fatalf("construction drifted: %d", len(raw))
	}
	_, why := normalizeVersionStream([]byte(raw), true)
	if why == "" || strings.Contains(why, "raw bytes") {
		t.Fatalf("the maximal expansion must reach a semantic rule, got %q", why)
	}
	if _, why := normalizeVersionStream([]byte(raw+"\r\n"), true); !strings.Contains(why, "raw bytes") {
		t.Fatalf("one pair beyond the bound must be rejected by the capture limit, got %q", why)
	}
}

func TestMeasuredDigestsSurviveTheReorder(t *testing.T) {
	p, why := normalizeVersionStream([]byte(measuredVV), true)
	if why != "" {
		t.Fatalf("the measured stream must still normalize: %q", why)
	}
	if sha256hex(p) != measuredVPayloadSHA || sha256hex(frameVersionRecord('V', p)) != measuredVRecordSHA {
		t.Fatal("the recorded V digests must be unchanged by the reordering")
	}
	c, whyC := normalizeVersionStream([]byte(measuredCargoVersion), false)
	if whyC != "" {
		t.Fatalf("the measured cargo stream must still normalize: %q", whyC)
	}
	if sha256hex(c) != measuredCPayloadSHA || sha256hex(frameVersionRecord('C', c)) != measuredCRecordSHA {
		t.Fatal("the recorded C digests must be unchanged by the reordering")
	}
}

func TestSupersededOrderIsStillDivergent(t *testing.T) {
	// The control has to keep failing; if this stops being true the control is
	// no longer guarding anything.
	if c := controlRawLimitBeforeFolding(); !c.Failed {
		t.Fatalf("C11 must fail as required: %s", c.Detail)
	}
}

// ---------------------------------------------------------------------------
// Cycle-3 blocker 2: Stage P must be total for absent leaves, and must reject
// an auto-discovered build script from snapshot bytes.
// ---------------------------------------------------------------------------

func stagePFixture(t *testing.T) string {
	t.Helper()
	root := t.TempDir()
	real, err := filepath.EvalSymlinks(root)
	if err != nil {
		t.Fatal(err)
	}
	mk := func(p ...string) string { return filepath.Join(append([]string{real}, p...)...) }
	if err := os.MkdirAll(mk("pkg", "src"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(mk("elsewhere"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(mk("pkg", "src", "lib.rs"), []byte("//\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(mk("pkg", "afile"), []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(mk("elsewhere"), mk("pkg", "linkdir")); err != nil {
		t.Fatal(err)
	}
	return real
}

func TestAbsentLeafIsAdmittedWithoutCanonicalizingIt(t *testing.T) {
	root := stagePFixture(t)
	// The premise: the platform cannot canonicalize the absent leaf at all.
	if _, err := filepath.EvalSymlinks(filepath.Join(root, "pkg", "src", "absent.rs")); err == nil {
		t.Fatal("an absent leaf must not canonicalize; the fixture is wrong")
	}
	o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "src/absent.rs", false)
	if o.Reason != "" {
		t.Fatalf("an absent target path must be admitted, got %q", o.Reason)
	}
	if o.LeafExists {
		t.Fatal("the outcome must report the leaf as absent")
	}
	if o.Anchor != filepath.Join(root, "pkg", "src") {
		t.Fatalf("the anchor must be the deepest existing ancestor, got %q", o.Anchor)
	}
}

func TestAbsentLeafBelowASymlinkAncestorIsRejected(t *testing.T) {
	root := stagePFixture(t)
	for _, isDep := range []bool{false, true} {
		o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "linkdir/absent.rs", isDep)
		if !strings.HasPrefix(o.Reason, "symbolic link or reparse component") {
			t.Fatalf("isDependency=%v: must be rejected at the link component, got %q", isDep, o.Reason)
		}
	}
}

func TestSymlinkLeafIsRejectedEvenWhenItPointsInside(t *testing.T) {
	root := stagePFixture(t)
	if err := os.Symlink(filepath.Join(root, "pkg", "afile"), filepath.Join(root, "pkg", "inside.rs")); err != nil {
		t.Skip("symlinks unavailable")
	}
	if o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "inside.rs", false); o.Reason == "" {
		t.Fatal("a symbolic-link leaf must be rejected even when its target is inside the root")
	}
}

func TestNonDirectoryAncestorEndsTheWalk(t *testing.T) {
	root := stagePFixture(t)
	if o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "afile/absent.rs", false); o.Reason != "" {
		t.Fatalf("a target below a regular file is absent, not a failure, got %q", o.Reason)
	}
	o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "afile/dep", true)
	if o.Reason == "" {
		t.Fatal("a dependency below a regular file must be rejected")
	}
}

func TestExistingLeavesStillDecideAsBefore(t *testing.T) {
	root := stagePFixture(t)
	if o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "src/lib.rs", false); o.Reason != "" || !o.LeafExists {
		t.Fatalf("an existing regular target file must be admitted, got %q", o.Reason)
	}
	if o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "src", true); o.Reason == "" {
		t.Fatal("a dependency directory with no Cargo.toml must be rejected")
	}
	if err := os.WriteFile(filepath.Join(root, "pkg", "src", "Cargo.toml"), []byte("[package]\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	if o := physicalPathOutcome(root, filepath.Join(root, "pkg"), "src", true); o.Reason != "" {
		t.Fatalf("a dependency directory with a Cargo.toml must be admitted, got %q", o.Reason)
	}
}

func TestPhysicalCheckIsTotalOverEveryLexicallyAdmittedShape(t *testing.T) {
	// Totality is the property the review asked for: no admitted string may
	// leave the algorithm without a verdict, whatever exists on disk.
	root := stagePFixture(t)
	for _, rel := range []string{
		"src", "src/lib.rs", "src/absent.rs", "src/a/b/c/absent.rs",
		"afile", "afile/absent.rs", "linkdir", "linkdir/absent.rs",
		"deeply/absent/chain/leaf.rs",
	} {
		if why := lexicalPathAdmitted(rel); why != "" {
			t.Fatalf("fixture path %q must be lexically admitted, got %q", rel, why)
		}
		for _, isDep := range []bool{false, true} {
			o := physicalPathOutcome(root, filepath.Join(root, "pkg"), rel, isDep)
			if o.Reason == "" && o.Anchor == "" {
				t.Fatalf("%q isDependency=%v: admitted with no anchor", rel, isDep)
			}
		}
	}
}

func TestBuildScriptFileGate(t *testing.T) {
	dir := t.TempDir()
	if buildScriptFileGate(dir) != "" {
		t.Fatal("a directory with no build.rs must be admitted")
	}
	if err := os.WriteFile(filepath.Join(dir, "build.rs"), []byte("fn main() {}\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	if buildScriptFileGate(dir) == "" {
		t.Fatal("a build.rs file must be rejected with no manifest key involved")
	}
	// The rule is stated on the name alone, so a nested build.rs belongs to its
	// own manifest directory and not to this one.
	nested := t.TempDir()
	if err := os.MkdirAll(filepath.Join(nested, "sub"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(nested, "sub", "build.rs"), []byte("fn main() {}\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	if buildScriptFileGate(nested) != "" {
		t.Fatal("a build.rs in a subdirectory is not this manifest's build script")
	}
}
