// Command rustboundaryprobe measures the Rust acceptance-layer boundary and the
// structural properties that decision 0009 relies on.
//
// It is the boundary probe decision 0007 requires of every reserved driver
// contract: it measures each acceptance layer separately per value, corroborates
// the isolated measurement with a classified — not exit-status — command
// outcome, checks the P1 and P2 alignment properties, measures closure in both
// laundering directions, and carries six controls that are required to fail.
//
// Nothing it emits is a platform claim. A missing toolchain is reported as
// evidence, never installed.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
)

type Fixture struct {
	FixtureVersion string         `json:"fixture_version"`
	Task           string         `json:"task"`
	Host           Host           `json:"host"`
	Toolchain      Toolchain      `json:"toolchain"`
	Cases          []Measured     `json:"cases"`
	HostGateCases  []Measured     `json:"host_gate_cases"`
	Alignment      Alignment      `json:"alignment"`
	Closure        []ClosureCheck `json:"closure"`
	Controls       []Control      `json:"controls"`
	Structural     []Structural   `json:"structural"`
	Vectors        []Vector       `json:"vectors"`
	Summary        Summary        `json:"summary"`
}

type Host struct {
	OperatingSystem string `json:"operating_system"`
	Architecture    string `json:"architecture"`
	GoVersion       string `json:"probe_go_version"`
}

type Summary struct {
	Cases            int  `json:"cases"`
	Matched          int  `json:"matched"`
	Divergences      int  `json:"divergences"`
	NotRun           int  `json:"not_run"`
	ClosureChecks    int  `json:"closure_checks"`
	ClosureFailures  int  `json:"closure_failures"`
	ControlsTotal    int  `json:"controls_total"`
	ControlsFailing  int  `json:"controls_failing_as_required"`
	StructuralTotal  int  `json:"structural_total"`
	StructuralDiverg int  `json:"structural_divergences"`
	VectorsTotal     int  `json:"vectors_total"`
	VectorsDiverg    int  `json:"vector_divergences"`
	Green            bool `json:"green"`
}

func main() {
	var out, workDir string
	var controlsOnly bool
	flag.StringVar(&out, "out", "fixture.json", "path to write the fixture JSON")
	flag.StringVar(&workDir, "work", "", "working directory for fixtures (default: a directory beside -out)")
	flag.BoolVar(&controlsOnly, "controls", false, "run only the controls and report their findings")
	flag.Parse()

	if workDir == "" {
		workDir = filepath.Join(filepath.Dir(out), "work")
	}
	abs, err := filepath.Abs(workDir)
	if err != nil {
		fatal(err)
	}
	// Resolve symlinks so a predicted manifest path equals the path cargo
	// prints. On macOS /tmp is a symlink to /private/tmp, and an unresolved
	// prefix makes every predicted edition-floor form miss.
	if err := os.MkdirAll(abs, 0o755); err != nil {
		fatal(err)
	}
	if real, err := filepath.EvalSymlinks(abs); err == nil {
		abs = real
	}
	workDir = abs
	if err := os.MkdirAll(workDir, 0o755); err != nil {
		fatal(err)
	}

	f := Fixture{
		FixtureVersion: "rust-boundary-fixture-v1",
		Task:           "TASK-260728-12pnm1",
		Host: Host{
			OperatingSystem: osToken(runtime.GOOS),
			Architecture:    archToken(runtime.GOARCH),
			GoVersion:       runtime.Version(),
		},
	}

	f.Toolchain = resolveToolchain(workDir)

	// The host-independent vectors are pure functions over constructed inputs.
	// They run whether or not a toolchain resolves, so a runner with nothing
	// installed still checks the normalization, the Stage P path grammar and
	// the configuration serializer.
	f.Vectors = append(f.Vectors, vectorsNormalization(f.Toolchain, workDir)...)
	f.Vectors = append(f.Vectors, vectorsPrewalk(workDir)...)
	f.Vectors = append(f.Vectors, vectorsConfig()...)
	f.Vectors = append(f.Vectors, vectorsProfileGate()...)
	f.Vectors = append(f.Vectors, vectorsAdmittedSet(workDir)...)

	if !f.Toolchain.Available {
		// Honest degradation: every case reports not_run with the reason, and
		// nothing is installed.
		for _, c := range canonicalCases {
			f.Cases = append(f.Cases, Measured{Case: c, Status: "not_run", Reason: f.Toolchain.Reason})
		}
		for _, c := range hostGateCases {
			f.HostGateCases = append(f.HostGateCases, Measured{Case: c, Status: "not_run", Reason: f.Toolchain.Reason})
		}
		f.Summary = summarize(f)
		emit(f, out)
		fmt.Printf("no usable Rust toolchain: %s\n", f.Toolchain.Reason)
		fmt.Printf("%d cases not run; nothing was installed\n", len(f.Cases))
		os.Exit(0)
	}

	for _, c := range canonicalCases {
		f.Cases = append(f.Cases, measureCase(workDir, f.Toolchain, c))
	}
	for _, c := range hostGateCases {
		m := measureCase(workDir, f.Toolchain, c)
		// For a host-gate case the corroborating command is the measurement of
		// interest; the isolated command is expected to accept.
		m.MatchedExpect = m.Corroborating.Recognised && m.Corroborating.Layer == c.ExpectLayer
		if m.MatchedExpect && m.Isolated.Recognised {
			m.Status = "match"
			m.Reason = ""
		} else {
			m.Status = "divergence"
		}
		f.HostGateCases = append(f.HostGateCases, m)
	}

	f.Alignment = checkAlignment(f.Cases)
	f.Closure = runClosure(workDir, f.Toolchain, f.Cases)
	f.Controls = runControls(f.Cases, f.Closure, f.Toolchain, workDir)
	if !controlsOnly {
		f.Structural = runStructural(workDir, f.Toolchain)
	}
	f.Summary = summarize(f)

	emit(f, out)
	report(f)
	if !f.Summary.Green {
		os.Exit(1)
	}
}

func summarize(f Fixture) Summary {
	s := Summary{}
	for _, m := range f.Cases {
		s.Cases++
		switch m.Status {
		case "match":
			s.Matched++
		case "not_run":
			s.NotRun++
		default:
			s.Divergences++
		}
	}
	for _, m := range f.HostGateCases {
		s.Cases++
		switch m.Status {
		case "match":
			s.Matched++
		case "not_run":
			s.NotRun++
		default:
			s.Divergences++
		}
	}
	for _, c := range f.Closure {
		s.ClosureChecks++
		if !c.NoVerdict {
			s.ClosureFailures++
		}
	}
	for _, c := range f.Controls {
		s.ControlsTotal++
		if c.Failed {
			s.ControlsFailing++
		}
	}
	for _, st := range f.Structural {
		s.StructuralTotal++
		if st.Verdict == "divergence" {
			s.StructuralDiverg++
		}
	}
	for _, v := range f.Vectors {
		s.VectorsTotal++
		if v.Verdict == "divergence" {
			s.VectorsDiverg++
		}
	}
	s.Green = s.Divergences == 0 &&
		s.ClosureFailures == 0 &&
		s.StructuralDiverg == 0 &&
		s.VectorsDiverg == 0 &&
		f.Alignment.P1Holds && f.Alignment.P2Holds &&
		(s.NotRun == s.Cases || s.ControlsFailing == s.ControlsTotal)
	return s
}

func report(f Fixture) {
	fmt.Printf("toolchain: rust %s, cargo %q, host %s\n", f.Toolchain.RustVersion, f.Toolchain.CargoVersion, f.Toolchain.HostTuple)
	fmt.Printf("cases: %d, matched %d, divergences %d, not run %d\n",
		f.Summary.Cases, f.Summary.Matched, f.Summary.Divergences, f.Summary.NotRun)
	fmt.Printf("alignment: P1 no-widening=%v P2 no-narrowing=%v (security partition empty=%v)\n",
		f.Alignment.P1Holds, f.Alignment.P2Holds, f.Alignment.SecurityPartitionEmpty)
	fmt.Printf("closure: %d checks, %d yielded a verdict (must be 0)\n",
		f.Summary.ClosureChecks, f.Summary.ClosureFailures)
	fmt.Printf("controls: %d of %d failing as required\n", f.Summary.ControlsFailing, f.Summary.ControlsTotal)
	for _, c := range f.Controls {
		mark := "FAILS-AS-REQUIRED"
		if !c.Failed {
			mark = "DID-NOT-FAIL"
		}
		fmt.Printf("  %-32s %-18s %s\n", c.ID, mark, c.Detail)
	}
	fmt.Printf("vectors: %d host-independent checks, %d divergences\n", f.Summary.VectorsTotal, f.Summary.VectorsDiverg)
	for _, v := range f.Vectors {
		if v.Verdict == "divergence" {
			fmt.Printf("  DIVERGENCE %-28s expected %q observed %q %s\n", v.ID, v.Expected, v.Observed, v.Detail)
		}
	}
	if len(f.Structural) > 0 {
		fmt.Printf("structural: %d checks, %d divergences\n", f.Summary.StructuralTotal, f.Summary.StructuralDiverg)
		for _, s := range f.Structural {
			fmt.Printf("  %-42s %-11s %s\n", s.ID, s.Verdict, s.Observed)
		}
	}
	for _, m := range append(append([]Measured{}, f.Cases...), f.HostGateCases...) {
		if m.Status != "match" {
			fmt.Printf("  DIVERGENCE %-32s %s\n", m.Case.ID, m.Reason)
		}
	}
	fmt.Printf("green: %v\n", f.Summary.Green)
}

func emit(f Fixture, out string) {
	b, err := json.MarshalIndent(f, "", " ")
	if err != nil {
		fatal(err)
	}
	b = append(b, '\n')
	if err := os.MkdirAll(filepath.Dir(out), 0o755); err != nil {
		fatal(err)
	}
	if err := os.WriteFile(out, b, 0o644); err != nil {
		fatal(err)
	}
}

func osToken(goos string) string {
	switch goos {
	case "darwin":
		return "macos"
	case "windows":
		return "windows"
	case "linux":
		return "linux"
	default:
		return goos
	}
}

func archToken(goarch string) string {
	switch goarch {
	case "arm64":
		return "arm64"
	case "amd64":
		return "amd64"
	default:
		return goarch
	}
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, "probe:", err)
	os.Exit(2)
}
