package main

import "testing"

func fixture() Predicted {
	return Predicted{
		Literal:      `"1.85.0-beta"`,
		LiteralBody:  "1.85.0-beta",
		Line:         5,
		Edition:      "2021",
		EditionFloor: "1.56.0",
		ManifestPath: "/w/cases/probe-x/Cargo.toml",
		PackageName:  "probe-x", PackageVersion: "0.1.0",
		HostVersion: "1.91.0",
	}
}

func TestRecognisesGrammarOnlyWithBothElements(t *testing.T) {
	p := fixture()
	first := p.grammarPrereleaseFirstLine()
	caret := p.caretLine()

	if v := Classify(p, 101, "", first+"\n"+caret+"\n", "", false); !v.Recognised || v.Layer != LayerGrammar {
		t.Fatalf("both elements present should be recognised as grammar, got %+v", v)
	}
	// The first line alone is a family, not an outcome: three distinct grammar
	// rejections share it and none of them names the value under test.
	if v := Classify(p, 101, "", first+"\n", "", false); v.Recognised {
		t.Fatalf("first line alone must yield no verdict, got %+v", v)
	}
	if v := Classify(p, 101, "", caret+"\n", "", false); v.Recognised {
		t.Fatalf("caret line alone must yield no verdict, got %+v", v)
	}
}

func TestCaretLineMustNameThisValue(t *testing.T) {
	p := fixture()
	other := `5 | rust-version = "9.9.9"`
	out := p.grammarPrereleaseFirstLine() + "\n" + other + "\n"
	if v := Classify(p, 101, "", out, "", false); v.Recognised {
		t.Fatalf("a diagnostic naming a different value must yield no verdict, got %+v", v)
	}
}

func TestCaretLineNumberIsPredicted(t *testing.T) {
	p := fixture()
	renumbered := `6 | rust-version = "1.85.0-beta"`
	out := p.grammarPrereleaseFirstLine() + "\n" + renumbered + "\n"
	if v := Classify(p, 101, "", out, "", false); v.Recognised {
		t.Fatalf("a caret line at an unpredicted line number must yield no verdict, got %+v", v)
	}
}

func TestExtendedDiagnosticYieldsNoVerdict(t *testing.T) {
	p := fixture()
	extended := p.grammarPrereleaseFirstLine() + " (see the Cargo book)"
	out := extended + "\n" + p.caretLine() + "\n"
	if v := Classify(p, 101, "", out, "", false); v.Recognised {
		t.Fatalf("a lead with an unconstrained tail must yield no verdict, got %+v", v)
	}
}

func TestUnrelatedFailureYieldsNoVerdict(t *testing.T) {
	p := fixture()
	out := "error: no such subcommand: `definitely-not-a-subcommand`\n"
	v := Classify(p, 101, "", out, "", false)
	if v.Recognised {
		t.Fatalf("an unrelated real failure must yield no verdict, got %+v", v)
	}
	if v.Layer != LayerUnknown {
		t.Fatalf("the fourth state must be unknown, got %s", v.Layer)
	}
}

func TestExitZeroRequiresTheReportedValue(t *testing.T) {
	p := fixture()
	if v := Classify(p, 0, "", "", "", false); v.Recognised {
		t.Fatalf("exit 0 with no reported value must yield no verdict, got %+v", v)
	}
	if v := Classify(p, 0, "", "", "9.9.9", true); v.Recognised {
		t.Fatalf("exit 0 reporting a different value must yield no verdict, got %+v", v)
	}
	if v := Classify(p, 0, "", "", p.LiteralBody, true); !v.Recognised || v.Layer != LayerAccepted {
		t.Fatalf("exit 0 echoing the value under test is acceptance, got %+v", v)
	}
}

func TestDocumentFormOnlyExistsForNonStringValues(t *testing.T) {
	p := fixture() // a string value: no TOML type phrase
	for _, f := range p.forms() {
		if f.layer == LayerDocument {
			t.Fatal("a string value must not carry a document form")
		}
	}
	p.TOMLTypePhrase = "floating point `1.85`"
	found := false
	for _, f := range p.forms() {
		if f.layer == LayerDocument {
			found = true
		}
	}
	if !found {
		t.Fatal("a non-string value must carry a document form")
	}
}

func TestEditionAndHostGateFormsNameTheValue(t *testing.T) {
	p := fixture()
	if got := p.editionCauseLine(); got != "rust-version 1.85.0-beta is older than first version (1.56.0) required by the specified edition (2021)" {
		t.Fatalf("edition cause line: %q", got)
	}
	if got := p.hostGateCauseLine(); got != "probe-x@0.1.0 requires rustc 1.85.0-beta" {
		t.Fatalf("host gate cause line: %q", got)
	}
}

func TestCorroboratingExitZeroWithRejectionIsUnknown(t *testing.T) {
	p := fixture()
	r := Run{ExitCode: 0, Stderr: p.grammarPrereleaseFirstLine() + "\n" + p.caretLine() + "\n"}
	if v := classifyCorroborating(p, r); v.Recognised {
		t.Fatalf("exit 0 alongside a recognised rejection must yield no verdict, got %+v", v)
	}
}

func TestAlignmentDetectsBothViolations(t *testing.T) {
	widening := []Measured{{
		Case:     Case{ID: "w", Compared: true},
		Status:   "match",
		Isolated: Verdict{Layer: LayerGrammar, Recognised: true},
	}}
	if a := checkAlignment(widening); a.P1Holds {
		t.Fatal("classifying an upstream-rejected value as compared must violate P1")
	}
	narrowing := []Measured{{
		Case:     Case{ID: "n", Compared: false},
		Status:   "match",
		Isolated: Verdict{Layer: LayerAccepted, Recognised: true},
	}}
	if a := checkAlignment(narrowing); a.P2Holds {
		t.Fatal("leaving an upstream-accepted value out of compared must violate P2")
	}
}

func TestNormalizeLinesKeepsWholeLines(t *testing.T) {
	got := normalizeLines("  a  \r\n\n b\n")
	if len(got) != 2 || got[0] != "a" || got[1] != "b" {
		t.Fatalf("normalizeLines: %#v", got)
	}
}

func TestManifestPutsRustVersionOnThePredictedLine(t *testing.T) {
	text, line := manifestFor("p", "2021", `"1.85"`)
	if line != 5 {
		t.Fatalf("line = %d", line)
	}
	lines := normalizeLines(text)
	if lines[line-1] != `rust-version = "1.85"` {
		t.Fatalf("line %d is %q", line, lines[line-1])
	}
}

func TestEveryCanonicalCaseHasAPinnedEditionFloor(t *testing.T) {
	for _, c := range append(append([]Case{}, canonicalCases...), hostGateCases...) {
		if _, ok := editionFloors[c.Edition]; !ok {
			t.Fatalf("case %s uses edition %s with no pinned floor", c.ID, c.Edition)
		}
	}
}

func TestComparedSetMatchesTheOrderedClassifier(t *testing.T) {
	// Classes 4 and 5 are `compared`; classes 1, 2, 3 and 7 are not. The table
	// and the classifier must not drift apart.
	for _, c := range canonicalCases {
		want := c.CuratorClass == 4 || c.CuratorClass == 5
		if c.Compared != want {
			t.Fatalf("case %s: class %d says compared=%v, table says %v", c.ID, c.CuratorClass, want, c.Compared)
		}
	}
}
