package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Controls C11 and C12 are the two superseded behaviours this revision
// replaced, kept runnable as checks that are **required to fail**.

// C11. The superseded normalization order: the byte limit applied to the raw
// stream, before CRLF folding. Guards the cross-platform normalization claim —
// with that order, a Windows-hosted and a Unix-hosted probe of the same
// distribution can disagree about whether the toolchain is admissible at all.
func controlRawLimitBeforeFolding() Control {
	c := Control{
		ID:     "C11/raw-limit-before-folding",
		Guards: "line-ending-equivalent version streams receiving different verdicts",
	}

	// The superseded rule, verbatim in its ordering.
	superseded := func(raw []byte) (string, bool) {
		if len(raw) > maxVersionStream {
			return "over 4096 raw bytes", false
		}
		p, why := normalizeVersionStream(raw, true)
		if why != "" {
			return why, false
		}
		return sha256hex(frameVersionRecord('V', p)), true
	}

	divergences := 0
	var detail []string
	for _, lf := range []string{
		strings.Repeat("x", 4093) + "\nA\n",
		strings.Repeat(strings.Repeat("x", 9)+"\n", 409) + "xxxxx\n",
	} {
		crlf := strings.ReplaceAll(lf, "\n", "\r\n")
		_, okLF := superseded([]byte(lf))
		_, okCRLF := superseded([]byte(crlf))
		if okLF != okCRLF {
			divergences++
			detail = append(detail, fmt.Sprintf("folded=%d LF(raw %d) admitted=%v CRLF(raw %d) admitted=%v",
				len(lf), len(lf), okLF, len(crlf), okCRLF))
		}
	}

	if divergences > 0 {
		c.Failed = true
		c.Findings = divergences
		c.Detail = "the superseded order admitted an LF stream and rejected its CRLF equivalent: " +
			strings.Join(detail, "; ")
	} else {
		c.Detail = "the superseded order produced no divergence, which means the boundary pair no longer exercises it"
	}

	// The replacement must agree on every one of those pairs, or the control is
	// reporting a defect that was not actually fixed.
	for _, lf := range []string{
		strings.Repeat("x", 4093) + "\nA\n",
		strings.Repeat(strings.Repeat("x", 9)+"\n", 409) + "xxxxx\n",
		strings.Repeat("x", 4094) + "\nA\n",
	} {
		crlf := strings.ReplaceAll(lf, "\n", "\r\n")
		pl, wl := normalizeVersionStream([]byte(lf), true)
		pc, wc := normalizeVersionStream([]byte(crlf), true)
		if (wl == "") != (wc == "") || (wl == "" && string(pl) != string(pc)) {
			c.Failed = false
			c.Detail += "; the replacement still diverges on a boundary pair, which is a regression"
		}
	}
	return c
}

// C12. The superseded Stage P: a forbidden-key gate with no build-script file
// rule. Guards the claim that every graph row G2 through G8 has a snapshot-byte
// counterpart. Measured, `package.build` absent plus a `build.rs` file makes
// cargo auto-discover, compile and execute a build script, and a gate that only
// inspects manifest keys has nothing to reject.
func controlKeyOnlyBuildScriptGate(work string, tc Toolchain) Control {
	c := Control{
		ID:     "C12/key-only-build-script-gate",
		Guards: "an auto-discovered build script that no manifest key declares",
	}
	if !tc.Available {
		c.Detail = "not run: no toolchain"
		return c
	}

	root := filepath.Join(work, "struct", "control-autobuild")
	_ = os.RemoveAll(root)
	_ = mkdirAll(filepath.Join(root, "src"))
	manifest := "[package]\nname = \"probeauto\"\nversion = \"0.1.0\"\nedition = \"2021\"\n"
	_ = os.WriteFile(filepath.Join(root, "Cargo.toml"), []byte(manifest), 0o644)
	_ = os.WriteFile(filepath.Join(root, "src", "main.rs"), []byte("fn main() {}\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "build.rs"), []byte("fn main() {}\n"), 0o644)

	// The superseded gate: reject only when a manifest key declares a build
	// script. There is no such key here, so it finds nothing.
	keyGateFired := strings.Contains(manifest, "build =") || strings.Contains(manifest, "build=")

	env := baseEnv(work, tc.RustcPath, "")
	_ = exec1(root, env, tc.CargoPath, "generate-lockfile", "--offline", "--quiet")
	run, out := exec1Full(root, env, append([]string{tc.CargoPath}, graphArgv...)...)
	if run.ExitCode != 0 {
		c.Detail = fmt.Sprintf("not a valid control: the graph command exited %d", run.ExitCode)
		return c
	}

	var doc cmDoc
	if err := json.Unmarshal([]byte(out), &doc); err != nil {
		c.Detail = "not a valid control: metadata did not parse"
		return c
	}
	sawCustomBuild := false
	for _, p := range doc.Packages {
		for _, t := range p.Targets {
			if contains(t.Kind, "custom-build") {
				sawCustomBuild = true
			}
		}
	}

	if !keyGateFired && sawCustomBuild {
		c.Failed = true
		c.Findings = 1
		c.Detail = "no manifest key declares a build script, yet cargo reported a custom-build target; " +
			"before the file rule this shape reached cargo"
	} else {
		c.Detail = fmt.Sprintf("key gate fired=%v, cargo reported custom-build=%v", keyGateFired, sawCustomBuild)
	}

	// The replacement rule must reject the same tree from snapshot bytes alone.
	if buildScriptFileGate(root) == "" {
		c.Failed = false
		c.Detail += "; the file rule did not reject the same tree, which is a regression"
	}
	return c
}
