package main

// Case is one value under test for the Cargo.toml `package.rust-version`
// classifier. `ExpectLayer` is what decision 0009 section 9 and the reference
// document's section 7.2 classify the value as; the probe measures whether
// upstream agrees, and fails on any disagreement.
type Case struct {
	ID string `json:"id"`
	// Literal is written verbatim after `rust-version = ` in the fixture, so a
	// TOML string case carries its own quotes.
	Literal string `json:"literal"`
	Edition string `json:"edition"`
	// TOMLTypePhrase is non-empty only for a non-string TOML value; it is the
	// phrase cargo renders for that type.
	TOMLTypePhrase string `json:"toml_type_phrase,omitempty"`
	ExpectLayer    Layer  `json:"expect_layer"`
	// CuratorClass is the ordered classifier class of reference section 7.2.
	CuratorClass int `json:"curator_class"`
	// Compared records whether Curator classifies the value as `compared`, which
	// is the set `C` in the P1/P2 alignment properties.
	Compared bool   `json:"compared"`
	Note     string `json:"note,omitempty"`
}

// editionFloors are pinned upstream constants. A later cargo release that moves
// any of them turns the probe red rather than quietly changing what it
// measures, which is the correct direction for a check whose purpose is to
// notice upstream moving.
var editionFloors = map[string]string{
	"2015": "1.0.0",
	"2018": "1.31.0",
	"2021": "1.56.0",
	"2024": "1.85.0",
}

// canonicalCases is the single case table. `finish()` re-applies it to every
// emitted case so a declared expectation and an executed expectation can never
// drift apart across hosts.
var canonicalCases = []Case{
	// --- accepted: grammar-representable, at or above the edition floor ---
	{ID: "accept.two-component", Literal: `"1.85"`, Edition: "2021",
		ExpectLayer: LayerAccepted, CuratorClass: 5, Compared: true},
	{ID: "accept.three-component", Literal: `"1.85.0"`, Edition: "2021",
		ExpectLayer: LayerAccepted, CuratorClass: 5, Compared: true},
	{ID: "accept.bare-major-edition-2015", Literal: `"1"`, Edition: "2015",
		ExpectLayer: LayerAccepted, CuratorClass: 5, Compared: true,
		Note: "grammar-representable; edition 2015 has the lowest floor"},
	{ID: "accept.edition-2018-at-floor", Literal: `"1.31"`, Edition: "2018",
		ExpectLayer: LayerAccepted, CuratorClass: 5, Compared: true},
	{ID: "accept.edition-2024-at-floor", Literal: `"1.85"`, Edition: "2024",
		ExpectLayer: LayerAccepted, CuratorClass: 5, Compared: true},
	{ID: "accept.above-host", Literal: `"1.99"`, Edition: "2021",
		ExpectLayer: LayerAccepted, CuratorClass: 4, Compared: true,
		Note: "isolation witness: representable and above the resolved toolchain, so a command that reports it cannot be applying the host gate"},

	// --- document layer: the TOML document parses, the value's type does not ---
	{ID: "document.float", Literal: `1.85`, Edition: "2021",
		TOMLTypePhrase: "floating point `1.85`",
		ExpectLayer:    LayerDocument, CuratorClass: 1, Compared: false},
	{ID: "document.integer", Literal: `1`, Edition: "2021",
		TOMLTypePhrase: "integer `1`",
		ExpectLayer:    LayerDocument, CuratorClass: 1, Compared: false},
	{ID: "document.boolean", Literal: `true`, Edition: "2021",
		TOMLTypePhrase: "boolean `true`",
		ExpectLayer:    LayerDocument, CuratorClass: 1, Compared: false},

	// --- grammar layer: a string the rust-version grammar cannot represent ---
	{ID: "grammar.prerelease", Literal: `"1.85.0-beta"`, Edition: "2021",
		ExpectLayer: LayerGrammar, CuratorClass: 2, Compared: false},
	{ID: "grammar.nonnumeric", Literal: `"not-a-version"`, Edition: "2021",
		ExpectLayer: LayerGrammar, CuratorClass: 2, Compared: false},
	{ID: "grammar.build-metadata", Literal: `"1.85.0+build"`, Edition: "2021",
		ExpectLayer: LayerGrammar, CuratorClass: 2, Compared: false},
	{ID: "grammar.four-components", Literal: `"1.85.0.1"`, Edition: "2021",
		ExpectLayer: LayerGrammar, CuratorClass: 2, Compared: false},
	{ID: "grammar.track-token", Literal: `"stable"`, Edition: "2021",
		ExpectLayer: LayerGrammar, CuratorClass: 2, Compared: false},
	{ID: "grammar.empty", Literal: `""`, Edition: "2021",
		ExpectLayer: LayerGrammar, CuratorClass: 2, Compared: false},

	// --- edition floor: representable, and below the floor the manifest's own
	//     edition requires. Host-independent: no toolchain value participates. ---
	{ID: "edition.bare-major-2018", Literal: `"1"`, Edition: "2018",
		ExpectLayer: LayerEdition, CuratorClass: 3, Compared: false,
		Note: "independence witness: the grammar layer accepts this value, the edition floor does not"},
	{ID: "edition.below-2021", Literal: `"1.31"`, Edition: "2021",
		ExpectLayer: LayerEdition, CuratorClass: 3, Compared: false},
	{ID: "edition.below-2024", Literal: `"1.56"`, Edition: "2024",
		ExpectLayer: LayerEdition, CuratorClass: 3, Compared: false},
}

// hostGateCases are measured only by the corroborating command, and only to
// show where the host gate sits. They are deliberately excluded from the layer
// measurement and from the P1/P2 sets: a gate that depends on the runner cannot
// be part of a value's grammar.
var hostGateCases = []Case{
	{ID: "hostgate.above-resolved", Literal: `"1.99"`, Edition: "2021",
		ExpectLayer: LayerHostGate, CuratorClass: 4, Compared: true,
		Note: "same value as accept.above-host; the isolated command reports it, the corroborating command gates on it"},
}
