package main

import (
	"fmt"
	"path/filepath"
	"strings"
)

// ClosureCheck is one outcome deliberately outside the recognised set, together
// with the laundering direction a fabricated verdict would belong to.
//
// Decision 0007: closure is a claim about outcomes *outside* the recognised
// set, so nothing inside it can witness the claim. Each check must yield no
// verdict.
type ClosureCheck struct {
	ID        string `json:"id"`
	Direction string `json:"direction"`
	Kind      string `json:"kind"`
	Yielded   Layer  `json:"yielded"`
	NoVerdict bool   `json:"no_verdict"`
	Detail    string `json:"detail,omitempty"`
}

// runClosure feeds the classifier three families of outcome that must produce
// no verdict:
//
//	A. acceptance laundering — real unrelated command failures. A classifier
//	   that falls through to acceptance would score these as upstream
//	   acceptance, which is what happened to the Go probe under `go build ./...`.
//	B. rejection laundering — every measured outcome cross-fed under a different
//	   value. A classifier that falls through to rejection agrees with the
//	   isolated measurement for the wrong reason, where the crosscheck cannot
//	   see it.
//	C. rejection laundering — measured diagnostics extended the way a later
//	   release would extend them. These are constructed, and are disclosed as
//	   such: an outcome upstream has not yet written cannot be measured on any
//	   host.
func runClosure(work string, tc Toolchain, measured []Measured) []ClosureCheck {
	var out []ClosureCheck
	env := baseEnv(work, tc.RustcPath, "")

	// --- direction A: real unrelated command failures ---
	base := Predicted{
		Literal: `"1.85"`, LiteralBody: "1.85", Line: 5, Edition: "2021",
		EditionFloor: editionFloors["2021"], ManifestPath: filepath.Join(work, "closure", "Cargo.toml"),
		PackageName: "probe-closure", PackageVersion: "0.1.0", HostVersion: tc.RustVersion,
	}

	empty := filepath.Join(work, "closure-empty")
	_ = writeFixtureDirOnly(empty)
	type realFail struct {
		id   string
		argv []string
		dir  string
	}
	fails := []realFail{
		{"no-manifest", []string{tc.CargoPath, "metadata", "--no-deps", "--format-version", "1", "--offline", "--color", "never", "--quiet"}, empty},
		{"unknown-subcommand", []string{tc.CargoPath, "definitely-not-a-subcommand"}, empty},
		{"locked-without-lockfile", []string{tc.CargoPath, "metadata", "--format-version", "1", "--locked", "--offline", "--color", "never", "--quiet"}, filepath.Join(work, "closure-locked")},
		{"bad-flag", []string{tc.CargoPath, "metadata", "--no-such-flag"}, empty},
	}
	_ = writeFixtureWithDep(filepath.Join(work, "closure-locked"))
	for _, f := range fails {
		r := exec1(f.dir, env, f.argv...)
		rv, ok := reportedRustVersion(r.Stdout)
		v := Classify(base, r.ExitCode, r.Stdout, r.Stderr, rv, ok)
		out = append(out, ClosureCheck{
			ID:        "A/" + f.id,
			Direction: "acceptance-laundering",
			Kind:      "real-unrelated-failure",
			Yielded:   v.Layer,
			NoVerdict: !v.Recognised,
			Detail:    fmt.Sprintf("exit=%d", r.ExitCode),
		})
	}

	// --- direction B: every measured outcome cross-fed under a wrong value ---
	for _, m := range measured {
		if m.Status != "match" || len(m.Runs) == 0 {
			continue
		}
		if m.Isolated.Layer == LayerAccepted {
			continue // an accepted outcome carries no diagnostic to cross-feed
		}
		wrong := base // a different value under test, with its own predicted forms
		wrong.PackageName = "probe-crossfeed"
		r := m.Runs[0]
		rv, ok := reportedRustVersion(r.Stdout)
		v := Classify(wrong, r.ExitCode, r.Stdout, r.Stderr, rv, ok)
		out = append(out, ClosureCheck{
			ID:        "B/crossfeed/" + m.Case.ID,
			Direction: "rejection-laundering",
			Kind:      "measured-outcome-under-wrong-value",
			Yielded:   v.Layer,
			NoVerdict: !v.Recognised,
		})
	}

	// --- direction C: constructed extensions of measured diagnostics ---
	extensions := []struct {
		id    string
		first string
		rest  string
	}{
		{"grammar-lead-extended", `error: expected a version like "1.32" (see the Cargo book)`, base.caretLine()},
		{"grammar-prerelease-retitled", `error: unexpected pre-release field, expected a version like "1.32"`, base.caretLine()},
		{"edition-floor-reworded", base.editionFirstLine(), "rust-version 1.85 is below the minimum (1.56.0) for edition (2021)"},
		{"host-gate-extended", base.hostGateFirstLine() + " (2 packages)", base.hostGateCauseLine()},
		{"caret-line-renumbered", base.grammarOtherFirstLine(), "6 | rust-version = \"1.85\""},
		{"first-line-only", base.grammarOtherFirstLine(), "some unrelated line"},
		{"second-line-only", "some unrelated error", base.caretLine()},
	}
	for _, e := range extensions {
		v := Classify(base, 101, "", e.first+"\n"+e.rest+"\n", "", false)
		out = append(out, ClosureCheck{
			ID:        "C/" + e.id,
			Direction: "rejection-laundering",
			Kind:      "constructed-extension",
			Yielded:   v.Layer,
			NoVerdict: !v.Recognised,
			Detail:    "constructed, not measured: an outcome upstream has not yet written cannot be measured on any host",
		})
	}

	// One acceptance-direction constructed check: exit 0 with a value that is
	// not the one under test must not be scored as acceptance.
	v := Classify(base, 0, `{"packages":[{"rust_version":"9.9.9"}]}`, "", "9.9.9", true)
	out = append(out, ClosureCheck{
		ID:        "C/exit-zero-wrong-value",
		Direction: "acceptance-laundering",
		Kind:      "constructed-extension",
		Yielded:   v.Layer,
		NoVerdict: !v.Recognised,
	})

	return out
}

func writeFixtureDirOnly(dir string) error {
	return mkdirAll(dir)
}

func writeFixtureWithDep(dir string) error {
	if err := mkdirAll(dir); err != nil {
		return err
	}
	manifest := strings.Join([]string{
		"[package]",
		`name = "probe-locked"`,
		`version = "0.1.0"`,
		`edition = "2021"`,
		"",
		"[dependencies]",
		`itoa = "1"`,
		"",
	}, "\n")
	return writeFixture(dir, manifest)
}
