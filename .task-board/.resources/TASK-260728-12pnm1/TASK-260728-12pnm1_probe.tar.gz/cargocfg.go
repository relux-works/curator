package main

import (
	"fmt"
	"path/filepath"
	"regexp"
	"strings"
	"unicode/utf8"
)

// ---------------------------------------------------------------------------
// Reference section 6.1: the manager-written $CARGO_HOME/config.toml.
//
// The directory value is package-influenced — build_root is selected by the
// consuming manifest or by the external descriptor — so the containment is a
// closed representability rule plus a serialization that cannot escape, not a
// claim that no package byte reaches the file. A TOML literal string has no
// escape sequences, so the writer is a concatenation and the one character it
// cannot carry joins the rejection list.
// ---------------------------------------------------------------------------

const cfgPrefix = "[source.crates-io]\nreplace-with = \"curator-vendor\"\n\n[source.curator-vendor]\ndirectory = '"
const cfgSuffix = "'\n\n[net]\noffline = true\n\n[term]\nquiet = true\ncolor = \"never\"\n"

// serializeCargoConfig returns the exact bytes of the file, or the failing rule.
func serializeCargoConfig(vendorAbs string) (string, string) {
	if vendorAbs == "" {
		return "", "rule 1: empty"
	}
	if len(vendorAbs) > 4096 {
		return "", "rule 1: over 4096 bytes"
	}
	if !utf8.ValidString(vendorAbs) {
		return "", "rule 1: not valid UTF-8"
	}
	if !filepath.IsAbs(vendorAbs) {
		return "", "rule 2: not absolute"
	}
	for _, r := range vendorAbs {
		if r == 0x00 {
			return "", "rule 3: NUL"
		}
		if r < 0x20 || r == 0x7f {
			return "", "rule 3: control character"
		}
	}
	if strings.ContainsRune(vendorAbs, '\'') {
		return "", "rule 4: apostrophe"
	}
	if strings.HasPrefix(vendorAbs, `\\?\`) || strings.HasPrefix(vendorAbs, `\\.\`) ||
		strings.HasPrefix(vendorAbs, `\\`) {
		return "", "rule 5: verbatim or UNC prefix"
	}
	return cfgPrefix + vendorAbs + cfgSuffix, ""
}

// naiveBasicStringConfig is control C9's superseded writer: it concatenates the
// path into a TOML basic string with no representability rule at all.
func naiveBasicStringConfig(vendorAbs string) string {
	return "[source.crates-io]\nreplace-with = \"curator-vendor\"\n\n" +
		"[source.curator-vendor]\ndirectory = \"" + vendorAbs + "\"\n\n" +
		"[net]\noffline = true\n\n[term]\nquiet = true\ncolor = \"never\"\n"
}

var tableHeaderRe = regexp.MustCompile(`(?m)^\[[^\]\n]+\]$`)

// tableHeaders is the structural sniff used for the write-back check and for
// C9. It needs no TOML parser: the intended document has exactly four top-level
// table headers, and an injected one shows up as a fifth.
func tableHeaders(doc string) []string {
	return tableHeaderRe.FindAllString(doc, -1)
}

// reparseDirectory recovers the literal-string directory value the way the
// write-back verification of section 6.1 must, without a TOML dependency.
var directoryLine = regexp.MustCompile(`(?m)^directory = '([^'\n]*)'$`)

func reparseDirectory(doc string) (string, bool) {
	m := directoryLine.FindStringSubmatch(doc)
	if m == nil {
		return "", false
	}
	return m[1], true
}

func vectorsConfig() []Vector {
	var out []Vector
	add := func(id, title, expected, observed, detail string) {
		v := Vector{ID: id, Group: "config", Title: title, Expected: expected, Observed: observed, Detail: detail}
		v.settle()
		out = append(out, v)
	}

	type c struct{ id, in, expect string }
	cases := []c{
		{"S1/ascii", "/opt/curator/op/build_root/vendor", "written"},
		{"S2/space", "/opt/curator/my op/build_root/vendor", "written"},
		{"S3/non-ascii", "/opt/curator/vendör/build_root/vendor", "written"},
		{"S4/double-quote", `/opt/curator/a"b/vendor`, "written"},
		{"S5/backslash-unix", `/opt/curator/a\b/vendor`, "written"},
		{"S6/apostrophe", "/opt/curator/a'b/vendor", "rejected"},
		{"S7/newline", "/opt/curator/a\nb/vendor", "rejected"},
		{"S8/tab", "/opt/curator/a\tb/vendor", "rejected"},
		{"S9/del", "/opt/curator/a\x7fb/vendor", "rejected"},
		{"S10/nul", "/opt/curator/a\x00b/vendor", "rejected"},
		{"S11/relative", "vendor", "rejected"},
		{"S12/empty", "", "rejected"},
		{"S13/unc", `\\server\share\vendor`, "rejected"},
		{"S14/verbatim", `\\?\C:\op\vendor`, "rejected"},
	}
	for _, tc := range cases {
		doc, why := serializeCargoConfig(tc.in)
		obs := "written"
		if why != "" {
			obs = "rejected"
		}
		add(tc.id, "directory serialization: "+tc.id, tc.expect, obs, why)

		if why == "" {
			// Every written document must survive its own write-back check.
			got, ok := reparseDirectory(doc)
			exp := "four tables, directory byte-equal"
			obsw := fmt.Sprintf("%d tables, reparse ok=%v equal=%v", len(tableHeaders(doc)), ok, got == tc.in)
			if len(tableHeaders(doc)) == 4 && ok && got == tc.in {
				obsw = exp
			}
			add(tc.id+"/write-back", "the written bytes re-parse to the intended structure", exp, obsw, "")
		}
	}

	// The exact byte template, so an implementation can check its writer against
	// a constant rather than against prose.
	doc, _ := serializeCargoConfig("/opt/curator/op/build_root/vendor")
	add("S15/template-length", "the constant part of the template is 150 bytes",
		"prefix=89 suffix=61 total=183",
		fmt.Sprintf("prefix=%d suffix=%d total=%d", len(cfgPrefix), len(cfgSuffix), len(doc)), "")
	add("S16/template-digest", "the sample document reproduces its recorded digest",
		"41aaeac44f7f26e747bbd29fafddd0715b813e5b06edbad967755ac3f87b60f2",
		sha256hex([]byte(doc)), "")
	add("S17/table-count", "the intended document has exactly four table headers",
		"4", fmt.Sprintf("%d", len(tableHeaders(doc))), strings.Join(tableHeaders(doc), " "))
	add("S18/no-crlf", "the template carries no CR and exactly one terminal LF",
		"true", fmt.Sprintf("%v", !strings.Contains(doc, "\r") &&
			strings.HasSuffix(doc, "\n") && !strings.HasSuffix(doc, "\n\n")), "")

	return out
}
