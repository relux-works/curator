package main

import (
	"fmt"
	"path/filepath"
	"strings"
)

// Measured is one case measured on both commands.
//
// The isolated measurement is `cargo metadata --no-deps`, which was measured to
// report a rust-version above the resolved toolchain with exit 0 and therefore
// structurally cannot be applying the host gate. The corroborating measurement
// is `cargo build`, whose outcome is classified rather than read from an exit
// status. Neither is authoritative alone; the disagreement is the check.
type Measured struct {
	Case          Case    `json:"case"`
	Status        string  `json:"status"`
	Reason        string  `json:"reason,omitempty"`
	Predicted     Forms   `json:"predicted"`
	Isolated      Verdict `json:"isolated"`
	Corroborating Verdict `json:"corroborating"`
	Agreed        bool    `json:"agreed"`
	MatchedExpect bool    `json:"matched_expectation"`
	Runs          []Run   `json:"runs"`
}

// Forms records the exact strings the probe predicted before running anything.
// Emitting them is what lets a reader check that recognition was prediction and
// not pattern-hunting after the fact.
type Forms struct {
	CaretLine     string `json:"caret_line"`
	EditionCause  string `json:"edition_cause_line,omitempty"`
	HostGateCause string `json:"host_gate_cause_line,omitempty"`
	EditionFloor  string `json:"edition_floor"`
}

func measureCase(work string, tc Toolchain, c Case) Measured {
	m := Measured{Case: c}

	floor, ok := editionFloors[c.Edition]
	if !ok {
		m.Status = "not_run"
		m.Reason = "no pinned edition floor for edition " + c.Edition
		return m
	}

	name := "probe-" + strings.NewReplacer(".", "-", "_", "-").Replace(c.ID)
	dir := filepath.Join(work, "cases", name)
	manifest, line := manifestFor(name, c.Edition, c.Literal)
	if err := writeFixture(dir, manifest); err != nil {
		m.Status = "not_run"
		m.Reason = "could not write fixture: " + err.Error()
		return m
	}

	p := Predicted{
		Literal:        c.Literal,
		LiteralBody:    tomlBody(c.Literal),
		TOMLTypePhrase: c.TOMLTypePhrase,
		Line:           line,
		Edition:        c.Edition,
		EditionFloor:   floor,
		ManifestPath:   filepath.Join(dir, "Cargo.toml"),
		PackageName:    name,
		PackageVersion: "0.1.0",
		HostVersion:    tc.RustVersion,
	}
	m.Predicted = Forms{
		CaretLine:     p.caretLine(),
		EditionCause:  p.editionCauseLine(),
		HostGateCause: p.hostGateCauseLine(),
		EditionFloor:  floor,
	}

	env := tc.linkPins(baseEnv(work, tc.RustcPath, ""))

	iso := exec1(dir, env, tc.CargoPath,
		"metadata", "--no-deps", "--format-version", "1", "--offline", "--color", "never", "--quiet")
	m.Runs = append(m.Runs, iso)
	rv, rvOK := reportedRustVersion(iso.Stdout)
	m.Isolated = Classify(p, iso.ExitCode, iso.Stdout, iso.Stderr, rv, rvOK)

	cor := exec1(dir, env, tc.CargoPath,
		"build", "--offline", "--color", "never", "--quiet", "--target", tc.HostTuple)
	m.Runs = append(m.Runs, cor)
	// The corroborating command never reports a rust_version, so acceptance is
	// measured by the absence of any recognised rejection together with exit 0.
	m.Corroborating = classifyCorroborating(p, cor)

	// Agreement rule. On the three host-independent layers the two measurements
	// must agree exactly. Where the isolated measurement says the value is
	// accepted, the corroborating command may additionally report the host
	// gate, because that gate is exactly the layer the isolated command cannot
	// reach.
	switch {
	case !m.Isolated.Recognised || !m.Corroborating.Recognised:
		m.Agreed = false
	case m.Isolated.Layer == m.Corroborating.Layer:
		m.Agreed = true
	case m.Isolated.Layer == LayerAccepted && m.Corroborating.Layer == LayerHostGate:
		m.Agreed = true
	default:
		m.Agreed = false
	}

	m.MatchedExpect = m.Isolated.Recognised && m.Isolated.Layer == c.ExpectLayer
	if m.Agreed && m.MatchedExpect {
		m.Status = "match"
	} else {
		m.Status = "divergence"
		if !m.Isolated.Recognised {
			m.Reason = "isolated: " + m.Isolated.Reason
		} else if !m.Corroborating.Recognised {
			m.Reason = "corroborating: " + m.Corroborating.Reason
		} else if !m.MatchedExpect {
			m.Reason = fmt.Sprintf("expected layer %s, isolated measured %s", c.ExpectLayer, m.Isolated.Layer)
		} else {
			m.Reason = fmt.Sprintf("isolated %s vs corroborating %s", m.Isolated.Layer, m.Corroborating.Layer)
		}
	}
	return m
}

// classifyCorroborating differs from Classify in exactly one respect: `cargo
// build` echoes no value back, so exit 0 cannot be corroborated by a reported
// value. It is therefore accepted only when no recognised rejection form
// matched *and* the exit code is 0, and an exit 0 with a recognised rejection
// present would be unknown rather than accepted.
func classifyCorroborating(p Predicted, r Run) Verdict {
	lines := normalizeLines(r.Stdout + "\n" + r.Stderr)
	index := make(map[string]bool, len(lines))
	for _, l := range lines {
		index[l] = true
	}
	var hit *recognisedForm
	for i := range p.forms() {
		f := p.forms()[i]
		if index[f.first] && index[f.second] {
			hit = &f
			break
		}
	}
	if r.ExitCode == 0 {
		if hit != nil {
			return unknown("exit 0 with a recognised rejection form present: " + hit.id)
		}
		return Verdict{Layer: LayerAccepted, Recognised: true, MatchedBy: "exit-zero-no-rejection"}
	}
	if hit == nil {
		return unknown(fmt.Sprintf("no recognised form matched; exit=%d", r.ExitCode))
	}
	return Verdict{Layer: hit.layer, Recognised: true, MatchedBy: hit.id}
}

// Alignment carries the two properties decision 0007 fixes for a classifier
// that claims to mirror an upstream acceptance set.
//
// For Cargo.toml `rust-version` the security partition F is empty: the field's
// value space is a version and nothing else, so no value is classified as
// package influence. P1 (C subset of Upstream) and P2 (Upstream minus F subset
// of C) therefore collapse to the equality C = Upstream, which — unlike the Go
// case — is satisfiable and is checked as such.
type Alignment struct {
	SecurityPartitionEmpty bool     `json:"security_partition_empty"`
	P1Holds                bool     `json:"p1_no_widening"`
	P2Holds                bool     `json:"p2_no_narrowing"`
	P1Violations           []string `json:"p1_violations,omitempty"`
	P2Violations           []string `json:"p2_violations,omitempty"`
}

func checkAlignment(ms []Measured) Alignment {
	a := Alignment{SecurityPartitionEmpty: true, P1Holds: true, P2Holds: true}
	for _, m := range ms {
		if m.Status != "match" {
			continue
		}
		upstreamAccepts := m.Isolated.Layer == LayerAccepted
		if m.Case.Compared && !upstreamAccepts {
			a.P1Holds = false
			a.P1Violations = append(a.P1Violations,
				fmt.Sprintf("%s: classified compared, upstream rejected at %s", m.Case.ID, m.Isolated.Layer))
		}
		if upstreamAccepts && !m.Case.Compared {
			a.P2Holds = false
			a.P2Violations = append(a.P2Violations,
				fmt.Sprintf("%s: upstream accepted, not classified compared", m.Case.ID))
		}
	}
	return a
}
