package main

import (
	"bytes"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

// Run is one recorded command execution: exact argv, working directory, the
// environment the probe set, the real exit code, and bounded output.
type Run struct {
	Argv     []string `json:"argv"`
	Dir      string   `json:"dir"`
	EnvDelta []string `json:"env_delta,omitempty"`
	ExitCode int      `json:"exit_code"`
	Stdout   string   `json:"stdout"`
	Stderr   string   `json:"stderr"`
	Truncate bool     `json:"truncated,omitempty"`
}

const maxCapture = 4096

func exec1(dir string, env map[string]string, argv ...string) Run {
	r, _ := exec1Full(dir, env, argv...)
	return r
}

// exec1Full additionally returns the unclamped stdout. The recorded Run clamps
// output so a fixture stays bounded; a caller that must parse a whole JSON
// document needs the untruncated bytes and takes them from here.
func exec1Full(dir string, env map[string]string, argv ...string) (Run, string) {
	cmd := exec.Command(argv[0], argv[1:]...)
	cmd.Dir = dir

	keys := make([]string, 0, len(env))
	for k := range env {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	envv := make([]string, 0, len(keys))
	delta := make([]string, 0, len(keys))
	for _, k := range keys {
		envv = append(envv, k+"="+env[k])
		delta = append(delta, k+"="+env[k])
	}
	cmd.Env = envv

	var so, se bytes.Buffer
	cmd.Stdout = &so
	cmd.Stderr = &se
	err := cmd.Run()

	code := 0
	if err != nil {
		var ee *exec.ExitError
		if errors.As(err, &ee) {
			code = ee.ExitCode()
		} else {
			// The command could not be started at all. That is a real outcome
			// and is reported as such rather than as a diagnostic string the
			// classifier might recognise.
			code = -1
			se.WriteString("\nprobe: could not start process: " + err.Error() + "\n")
		}
	}

	r := Run{Argv: argv, Dir: dir, EnvDelta: delta, ExitCode: code}
	full := so.String()
	r.Stdout, r.Truncate = clamp(full)
	s2, t2 := clamp(se.String())
	r.Stderr = s2
	r.Truncate = r.Truncate || t2
	return r, full
}

func clamp(s string) (string, bool) {
	if len(s) <= maxCapture {
		return s, false
	}
	return s[:maxCapture], true
}

// rustVersionRe extracts the reported rust_version from `cargo metadata`
// output. It is anchored on the JSON member rather than searched for anywhere,
// and it is used only for the acceptance direction, where the reported value
// must equal the value under test.
var rustVersionRe = regexp.MustCompile(`"rust_version":(null|"([^"]*)")`)

func reportedRustVersion(stdout string) (string, bool) {
	m := rustVersionRe.FindStringSubmatch(stdout)
	if m == nil {
		return "", false
	}
	if m[1] == "null" {
		return "", false
	}
	return m[2], true
}

func writeFixture(dir, manifest string) error {
	if err := os.MkdirAll(filepath.Join(dir, "src"), 0o755); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(dir, "src", "main.rs"), []byte("fn main() {}\n"), 0o644); err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(dir, "Cargo.toml"), []byte(manifest), 0o644)
}

// manifestFor builds the fixture manifest. The `rust-version` assignment is
// always line 5, which is what makes the caret line a predicted constant rather
// than something read back out of the output.
func manifestFor(name, edition, literal string) (text string, line int) {
	var b strings.Builder
	b.WriteString("[package]\n")                      // 1
	b.WriteString("name = \"" + name + "\"\n")        // 2
	b.WriteString("version = \"0.1.0\"\n")            // 3
	b.WriteString("edition = \"" + edition + "\"\n")  // 4
	b.WriteString("rust-version = " + literal + "\n") // 5
	return b.String(), 5
}

func tomlBody(literal string) string {
	if len(literal) >= 2 && literal[0] == '"' && literal[len(literal)-1] == '"' {
		return literal[1 : len(literal)-1]
	}
	return literal
}
