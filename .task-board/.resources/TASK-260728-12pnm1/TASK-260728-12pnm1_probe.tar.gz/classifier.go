package main

import (
	"fmt"
	"strings"
)

// Layer is one of Rust's host-independent acceptance layers for the
// Cargo.toml `package.rust-version` field, or the host gate that sits on top of
// them, or the absence of any rejection.
type Layer string

const (
	LayerAccepted Layer = "accepted"
	LayerDocument Layer = "document"
	LayerGrammar  Layer = "grammar"
	LayerEdition  Layer = "edition-floor"
	LayerHostGate Layer = "host-gate"

	// LayerUnknown is not a verdict. It is the fourth state decision 0007
	// requires: an outcome the closed recognised set does not cover yields no
	// verdict and fails the probe.
	LayerUnknown Layer = "unknown"
)

// Verdict reports whether a classification produced a usable verdict at all.
// A classifier that maps an unrecognised outcome onto a verdict is exactly the
// laundering decision 0007 rejects, so `Recognised` is carried separately from
// `Layer` and is never inferred from it.
type Verdict struct {
	Layer      Layer  `json:"layer"`
	Recognised bool   `json:"recognised"`
	MatchedBy  string `json:"matched_by,omitempty"`
	Reason     string `json:"reason,omitempty"`
}

func unknown(reason string) Verdict {
	return Verdict{Layer: LayerUnknown, Recognised: false, Reason: reason}
}

// Predicted holds every constant the probe fixes *before* a command runs. A
// recognised outcome is one whole diagnostic line matched exactly against a
// form built from these values and from the value under test. Nothing here is
// read back out of the command's own output.
type Predicted struct {
	// Literal is the value under test exactly as written into Cargo.toml,
	// including its quotes when it is a TOML string.
	Literal string
	// LiteralBody is the value with TOML string quotes removed; cargo echoes
	// this form in the edition-floor and host-gate diagnostics.
	LiteralBody string
	// TOMLTypePhrase is the phrase cargo uses for a non-string TOML type, for
	// example `floating point ` + "`1.85`". Empty when the value is a string.
	TOMLTypePhrase string
	// Line is the 1-based line number of the `rust-version` assignment in the
	// generated fixture. Fixed by the generator, never read from output.
	Line int
	// Edition is the fixture's edition token.
	Edition string
	// EditionFloor is the pinned upstream floor for that edition.
	EditionFloor string
	// ManifestPath is the absolute path of the fixture manifest.
	ManifestPath string
	// PackageName and PackageVersion identify the fixture package for the
	// host-gate form.
	PackageName    string
	PackageVersion string
	// HostVersion is the resolved toolchain's normalized triple, used only by
	// the host-gate form.
	HostVersion string
}

// caretLine is the third line of cargo's caret block. It is the only element of
// a grammar or document diagnostic that names the value under test, which is
// why recognition is a pair rather than a single line: three distinct grammar
// rejections share one first line.
func (p Predicted) caretLine() string {
	return fmt.Sprintf("%d | rust-version = %s", p.Line, p.Literal)
}

func (p Predicted) documentFirstLine() string {
	return fmt.Sprintf("error: invalid type: %s, expected a semver or workspace", p.TOMLTypePhrase)
}

func (p Predicted) grammarPrereleaseFirstLine() string {
	return `error: unexpected prerelease field, expected a version like "1.32"`
}

func (p Predicted) grammarBuildFirstLine() string {
	return `error: unexpected build field, expected a version like "1.32"`
}

func (p Predicted) grammarOtherFirstLine() string {
	return `error: expected a version like "1.32"`
}

func (p Predicted) editionFirstLine() string {
	return fmt.Sprintf("error: failed to parse manifest at `%s`", p.ManifestPath)
}

func (p Predicted) editionCauseLine() string {
	return fmt.Sprintf("rust-version %s is older than first version (%s) required by the specified edition (%s)",
		p.LiteralBody, p.EditionFloor, p.Edition)
}

func (p Predicted) hostGateFirstLine() string {
	return fmt.Sprintf("error: rustc %s is not supported by the following package:", p.HostVersion)
}

func (p Predicted) hostGateCauseLine() string {
	return fmt.Sprintf("%s@%s requires rustc %s", p.PackageName, p.PackageVersion, p.LiteralBody)
}

// recognisedForm is one closed entry: an exact first line and an exact second
// element, both predicted before the command ran.
type recognisedForm struct {
	id     string
	layer  Layer
	first  string
	second string
}

// forms returns the complete closed recognised set for one value under test.
// The set is closed by construction: it is a fixed-length slice built from
// predicted constants, and Classify has no fall-through branch that produces a
// verdict.
func (p Predicted) forms() []recognisedForm {
	out := []recognisedForm{
		{id: "grammar/prerelease", layer: LayerGrammar, first: p.grammarPrereleaseFirstLine(), second: p.caretLine()},
		{id: "grammar/build", layer: LayerGrammar, first: p.grammarBuildFirstLine(), second: p.caretLine()},
		{id: "grammar/other", layer: LayerGrammar, first: p.grammarOtherFirstLine(), second: p.caretLine()},
		{id: "edition-floor", layer: LayerEdition, first: p.editionFirstLine(), second: p.editionCauseLine()},
		{id: "host-gate", layer: LayerHostGate, first: p.hostGateFirstLine(), second: p.hostGateCauseLine()},
	}
	if p.TOMLTypePhrase != "" {
		out = append(out, recognisedForm{
			id: "document", layer: LayerDocument, first: p.documentFirstLine(), second: p.caretLine(),
		})
	}
	return out
}

// normalizeLines splits combined output into whole lines with surrounding
// whitespace trimmed. Trimming is deliberate and bounded: cargo indents the
// `Caused by` body and the caret block, and the indentation is presentation.
// Nothing else about a line is relaxed.
func normalizeLines(s string) []string {
	raw := strings.Split(strings.ReplaceAll(s, "\r\n", "\n"), "\n")
	out := make([]string, 0, len(raw))
	for _, l := range raw {
		t := strings.TrimSpace(l)
		if t != "" {
			out = append(out, t)
		}
	}
	return out
}

// Classify maps one command outcome onto a verdict, or onto no verdict at all.
//
// Rules, each of which decision 0007 states normatively:
//   - a recognised outcome is one whole diagnostic line matched exactly against
//     a predicted form, together with its predicted second element;
//   - an unrecognised outcome is unknown, fails the probe, and yields no verdict;
//   - no branch maps an unrecognised outcome to a verdict, in either direction;
//   - a lead with an unconstrained tail, and a substring found anywhere in the
//     output, are families rather than outcomes and are never recognised.
func Classify(p Predicted, exitCode int, stdout, stderr string, acceptedValue string, acceptedOK bool) Verdict {
	if exitCode == 0 {
		// Acceptance is measured by the value the command echoes back, not by
		// the exit status. A command can exit 0 for reasons that have nothing
		// to do with the layer under test.
		if !acceptedOK {
			return unknown("exit 0 with no rust_version reported")
		}
		if acceptedValue != p.LiteralBody {
			return unknown(fmt.Sprintf("exit 0 but reported rust_version %q != value under test %q", acceptedValue, p.LiteralBody))
		}
		return Verdict{Layer: LayerAccepted, Recognised: true, MatchedBy: "reported-value"}
	}

	lines := normalizeLines(stdout + "\n" + stderr)
	index := make(map[string]bool, len(lines))
	for _, l := range lines {
		index[l] = true
	}

	for _, f := range p.forms() {
		if index[f.first] && index[f.second] {
			return Verdict{Layer: f.layer, Recognised: true, MatchedBy: f.id}
		}
	}
	return unknown(fmt.Sprintf("no recognised form matched; exit=%d", exitCode))
}
