package main

import (
	"os"
	"path/filepath"
	"testing"
)

// The profile gate must be total: every constructed document reaches a verdict,
// and the verdict never depends on how the table is spelled.
func TestProfileGateTotality(t *testing.T) {
	docs := []string{
		"",
		"[package]\nname = \"x\"\n",
		"[profile.release]\n",
		"[profile.release]\nopt-level = 3\n",
		"[profile.release]\nsplit-debuginfo = \"packed\"\n",
		"[profile.release.package.\"*\"]\nopt-level = 1\n",
		"[profile.release.package.'x']\nopt-level = 1\n",
		"[profile.release.build-override]\nopt-level = 0\n",
		"[profile.a.b.c.d.e]\nopt-level = 1\n",
		"[profile]\n",
		"[profile.release]\nlonely-key-with-no-equals\n",
		"[profile.release]\nopt-level = 3 # trailing comment\n",
		"[profile.release]\r\nopt-level = 3\r\n",
	}
	for _, d := range docs {
		// Any panic or hang here is the failure; the verdict itself is checked
		// by the conformance vectors.
		_ = profileGateVerdict(d)
	}
}

func TestProfileGateRejectsEverySplitDebuginfoSpelling(t *testing.T) {
	for _, v := range []string{`"packed"`, `"off"`, `"unpacked"`, `"wat"`, `""`, `3`, `true`} {
		doc := "[profile.release]\nsplit-debuginfo = " + v + "\n"
		if profileGateVerdict(doc) == "" {
			t.Fatalf("split-debuginfo = %s was admitted", v)
		}
	}
}

func TestProfileGateAdmitsEveryKeyMeasuredInTheWild(t *testing.T) {
	// The seven keys measured across 506 cached crate manifests, with the exact
	// values those manifests carry. A gate that rejected any of them would
	// reject ordinary vendored crates.
	doc := "[profile.release]\ndebug = 2\nlto = \"fat\"\nopt-level = 3\ncodegen-units = 1\n" +
		"panic = \"abort\"\nincremental = false\n\n[profile.custom]\ninherits = \"release\"\n"
	if why := profileGateVerdict(doc); why != "" {
		t.Fatalf("the measured in-the-wild key set was rejected: %s", why)
	}
	for _, v := range []string{"true", "2"} {
		if why := profileGateVerdict("[profile.bench]\ndebug = " + v + "\n"); why != "" {
			t.Fatalf("debug = %s rejected: %s", v, why)
		}
	}
	for _, v := range []string{"true", `"thin"`, `"fat"`} {
		if why := profileGateVerdict("[profile.release]\nlto = " + v + "\n"); why != "" {
			t.Fatalf("lto = %s rejected: %s", v, why)
		}
	}
}

func TestSplitTOMLKeyHonoursQuotes(t *testing.T) {
	got := splitTOMLKey(`profile.release.package."a.b"`)
	if len(got) != 4 || got[3] != "a.b" {
		t.Fatalf("quoted segment split: %#v", got)
	}
	if !admittedProfileTable(`profile.release.package."*"`) {
		t.Fatal("a star package override must be an admitted shape")
	}
	if admittedProfileTable("profile.release.package") {
		t.Fatal("a package table with no spec must not be admitted")
	}
}

// The admitted set must contain every ordinary source file without any
// knowledge of Cargo's discovery rules, and must not contain anything reachable
// only through a link.
func TestAdmittedSetCoversDefaultLayout(t *testing.T) {
	root := t.TempDir()
	for _, d := range []string{"src", "src/bin", "examples", "tests", "benches"} {
		if err := os.MkdirAll(filepath.Join(root, d), 0o755); err != nil {
			t.Fatal(err)
		}
	}
	files := []string{
		"Cargo.toml", "src/main.rs", "src/lib.rs", "src/bin/e.rs",
		"examples/x.rs", "tests/t.rs", "benches/b.rs",
	}
	for _, f := range files {
		if err := os.WriteFile(filepath.Join(root, f), []byte("x"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	a := buildAdmittedSet(root, []string{filepath.Join(root, "src", "ghost.rs")})
	if a.WalkErr != "" {
		t.Fatalf("walk error: %s", a.WalkErr)
	}
	for _, f := range files {
		if !a.Has(filepath.Join(root, f)) {
			t.Fatalf("%s is not in A", f)
		}
	}
	if !a.Has(filepath.Join(root, "src", "ghost.rs")) {
		t.Fatal("the declared absent leaf is not in A")
	}
	if a.Has(filepath.Join(root, "src", "never.rs")) {
		t.Fatal("an undeclared absent path is in A")
	}
	if a.Has(filepath.Join(filepath.Dir(root), "outside.rs")) {
		t.Fatal("an outside path is in A")
	}
}

func TestAdmittedSetDoesNotDescendALink(t *testing.T) {
	base := t.TempDir()
	root := filepath.Join(base, "root")
	outside := filepath.Join(base, "outside")
	if err := os.MkdirAll(root, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(outside, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(outside, "hidden.rs"), []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(outside, filepath.Join(root, "linked")); err != nil {
		t.Skip("symlinks unavailable")
	}
	a := buildAdmittedSet(root, nil)
	if a.WalkErr != "" {
		t.Fatalf("walk error: %s", a.WalkErr)
	}
	if a.Has(filepath.Join(root, "linked")) {
		t.Fatal("the link component itself is in A")
	}
	if a.Has(filepath.Join(root, "linked", "hidden.rs")) {
		t.Fatal("a file below a link is in A")
	}
}

func TestSupersededAdmittedSetRejectsOrdinaryMain(t *testing.T) {
	root := t.TempDir()
	sup := supersededAdmittedSet(root, []string{filepath.Join(root, "Cargo.toml")}, nil)
	bad := g11(sup, []string{
		filepath.Join(root, "Cargo.toml"),
		filepath.Join(root, "src", "main.rs"),
	})
	if len(bad) != 1 {
		t.Fatalf("the superseded set must leave src/main.rs outside; got %v", bad)
	}
}

func TestSplitDebuginfoPinIsPlatformResolved(t *testing.T) {
	if splitDebuginfoPin("darwin") != "off" {
		t.Fatal("macOS pin is the measured value 'off'")
	}
	if splitDebuginfoPin("windows") != "" || splitDebuginfoPin("linux") != "" {
		t.Fatal("an unqualified platform must carry no pin claim")
	}
	tc := Toolchain{LinkerPath: "/r/lld", LinkerFlavor: "ld64.lld", DebugInfoPin: "off"}
	env := tc.linkPins(map[string]string{})
	want := "-Clinker=/r/lld\x1f-Clinker-flavor=ld64.lld\x1f-Csplit-debuginfo=off"
	if env["CARGO_ENCODED_RUSTFLAGS"] != want {
		t.Fatalf("rustflags = %q", env["CARGO_ENCODED_RUSTFLAGS"])
	}
}

func TestProfileGateQuotingAndArrayOfTables(t *testing.T) {
	if profileGateVerdict("[profile.release]\nopt-level = 's'\n") != "" {
		t.Fatal("a TOML literal string must be the same value as its basic-string spelling")
	}
	if profileGateVerdict(`[profile.release]`+"\n"+`"split-debuginfo" = "packed"`+"\n") == "" {
		t.Fatal("a quoted split-debuginfo key was admitted")
	}
	if profileGateVerdict("[[profile.release]]\nopt-level = 3\n") == "" {
		t.Fatal("an array-of-tables profile header was admitted")
	}
	if profileGateVerdict("[profile.release]\nopt-level = \"\\u0073\"\n") == "" {
		t.Fatal("an escaped basic string was admitted rather than failing closed")
	}
}
