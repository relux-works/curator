#!/usr/bin/env python3
"""Render a rust-boundary-fixture-v1 document as a readable command-evidence log.

Every argument vector, the environment the probe set, the real exit code, and a
bounded output excerpt, in the order the probe ran them.
"""
import json
import sys


def excerpt(s, n=400):
    s = (s or "").strip()
    if not s:
        return "(empty)"
    if len(s) <= n:
        return s
    return s[:n] + " …[truncated]"


def emit_runs(runs, indent="    "):
    for r in runs or []:
        print(f"{indent}$ {' '.join(r['argv'])}")
        print(f"{indent}  cwd      {r['dir']}")
        for e in r.get("env_delta", []):
            print(f"{indent}  env      {e}")
        print(f"{indent}  exit     {r['exit_code']}")
        for name in ("stdout", "stderr"):
            body = excerpt(r.get(name))
            if body != "(empty)":
                print(f"{indent}  {name}:")
                for line in body.splitlines():
                    print(f"{indent}    {line}")
        print()


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "fixture.json"
    f = json.load(open(path))

    print("=" * 78)
    print("Rust driver-pair boundary probe — command evidence")
    print(f"fixture   {f['fixture_version']}")
    print(f"task      {f['task']}")
    h = f["host"]
    print(f"host      {h['operating_system']} {h['architecture']}, probe {h['probe_go_version']}")
    tc = f["toolchain"]
    print(f"toolchain available={tc.get('available')} root={tc.get('root')}")
    if tc.get("reason"):
        print(f"          reason: {tc['reason']}")
    if tc.get("available"):
        print(f"          rustc {tc['rust_version']}  cargo {tc['cargo_version']!r}")
        print(f"          host tuple {tc['host_tuple']}")
        print(f"          launcher   {tc['cargo_path']}")
        print(f"          compiler   {tc['rustc_path']}")
        print(f"          linker     {tc['linker_path']} (flavor {tc.get('linker_flavor')})")
        print(f"          sdk root   {tc.get('sdk_root')}")
    print("=" * 78)
    print()

    print("-" * 78)
    print("SECTION 1 — acceptance-layer cases")
    print("-" * 78)
    for m in f.get("cases", []) + f.get("host_gate_cases", []):
        c = m["case"]
        print(f"[{m['status']:10}] {c['id']}")
        print(f"    literal        {c['literal']}   edition {c['edition']}")
        print(f"    curator class  {c['curator_class']}  compared={c['compared']}  expect={c['expect_layer']}")
        p = m.get("predicted", {})
        print(f"    predicted caret line   {p.get('caret_line')!r}")
        print(f"    predicted edition line {p.get('edition_cause_line')!r}")
        iso, cor = m.get("isolated", {}), m.get("corroborating", {})
        print(f"    isolated       layer={iso.get('layer')} recognised={iso.get('recognised')} by={iso.get('matched_by','')}")
        print(f"    corroborating  layer={cor.get('layer')} recognised={cor.get('recognised')} by={cor.get('matched_by','')}")
        if m.get("reason"):
            print(f"    reason         {m['reason']}")
        if c.get("note"):
            print(f"    note           {c['note']}")
        print()
        emit_runs(m.get("runs"))

    print("-" * 78)
    print("SECTION 2 — alignment properties")
    print("-" * 78)
    a = f["alignment"]
    print(f"security partition empty : {a['security_partition_empty']}")
    print(f"P1 no widening (C subset of Upstream)          : {a['p1_no_widening']}")
    print(f"P2 no narrowing (Upstream minus F subset of C) : {a['p2_no_narrowing']}")
    for v in a.get("p1_violations", []) + a.get("p2_violations", []):
        print(f"  violation: {v}")
    print()

    print("-" * 78)
    print("SECTION 3 — closure: outcomes outside the recognised set")
    print("-" * 78)
    for c in f.get("closure", []):
        ok = "no verdict" if c["no_verdict"] else "FABRICATED A VERDICT"
        print(f"  [{ok:20}] {c['id']:44} direction={c['direction']:22} kind={c['kind']}")
        if c.get("detail"):
            print(f"      {c['detail']}")
    print()

    print("-" * 78)
    print("SECTION 4 — controls, each required to fail")
    print("-" * 78)
    for c in f.get("controls", []):
        mark = "FAILS-AS-REQUIRED" if c["failed"] else "DID-NOT-FAIL"
        print(f"  [{mark:18}] {c['id']}")
        print(f"      guards   {c['guards']}")
        print(f"      findings {c['findings']}")
        print(f"      detail   {c['detail']}")
    print()

    print("-" * 78)
    print("SECTION 5 — structural measurements")
    print("-" * 78)
    for s in f.get("structural", []):
        print(f"  [{s['verdict']:11}] {s['id']}")
        print(f"      {s['title']}")
        print(f"      expected  {s['expected']}")
        print(f"      observed  {s['observed']}")
        if s.get("manager_obligation"):
            print(f"      obligation {s['manager_obligation']}")
        for e in s.get("evidence", []):
            print(f"      evidence  {e}")
        print()
        emit_runs(s.get("runs"), indent="      ")

    print("-" * 78)
    print("SECTION 6 — host-independent vectors")
    print("-" * 78)
    groups = {}
    for v in f.get("vectors", []):
        groups.setdefault(v["group"], []).append(v)
    for g, vs in groups.items():
        print(f"  group {g} ({len(vs)} vectors)")
        for v in vs:
            print(f"    [{v['verdict']:11}] {v['id']:32} expected {v['expected']!r} observed {v['observed']!r}")
            if v.get("detail"):
                print(f"        detail {v['detail']}")
        print()

    print("-" * 78)
    print("SUMMARY")
    print("-" * 78)
    for k, v in f["summary"].items():
        print(f"  {k:34} {v}")


if __name__ == "__main__":
    main()
