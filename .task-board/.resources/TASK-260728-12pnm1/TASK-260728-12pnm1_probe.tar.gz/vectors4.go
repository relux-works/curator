package main

import (
	"os"
	"path/filepath"
	"strings"
)

// vectorsProfileGate are the host-independent conformance vectors of reference
// section 4.7. They are pure functions over constructed manifest documents and
// run whether or not a toolchain resolves.
func vectorsProfileGate() []Vector {
	var out []Vector
	add := func(id, title, expected, doc string) {
		obs := "admitted"
		why := profileGateVerdict(doc)
		if why != "" {
			obs = "rejected"
		}
		v := Vector{ID: id, Group: "profile-gate", Title: title, Expected: expected, Observed: obs, Detail: why}
		v.settle()
		out = append(out, v)
	}
	const head = "[package]\nname = \"x\"\nversion = \"0.1.0\"\nedition = \"2021\"\n\n"

	// Positive: every key and value real published crates were measured to use.
	add("F1/no-profile-table", "a manifest with no profile table", "admitted", head)
	add("F2/opt-level-lto", "the inventory's positive profile vector", "admitted",
		head+"[profile.release]\nopt-level = 3\nlto = \"fat\"\n")
	add("F3/wild-keys", "every key measured across 506 cached crate manifests", "admitted",
		head+"[profile.release]\ndebug = 2\nlto = true\nopt-level = 1\ncodegen-units = 1\npanic = \"abort\"\nincremental = false\n")
	add("F4/custom-inherits", "a custom profile inheriting release", "admitted",
		head+"[profile.myrel]\ninherits = \"release\"\nopt-level = 2\n")
	add("F5/package-override", "a package override carrying admitted keys", "admitted",
		head+"[profile.release.package.\"*\"]\nopt-level = 1\n")
	add("F6/build-override", "a build-override carrying admitted keys", "admitted",
		head+"[profile.release.build-override]\nopt-level = 0\n")
	add("F7/strip-rpath", "strip and rpath, measured to start no process", "admitted",
		head+"[profile.release]\nstrip = \"symbols\"\nrpath = false\ndebug-assertions = true\noverflow-checks = true\n")

	// Negative: the measured process-capable shapes.
	add("F8/split-debuginfo-packed", "the documented process-capable value", "rejected",
		head+"[profile.release]\ndebug = 2\nsplit-debuginfo = \"packed\"\n")
	add("F9/split-debuginfo-off", "the key is rejected outright, not by value", "rejected",
		head+"[profile.release]\nsplit-debuginfo = \"off\"\n")
	add("F10/split-debuginfo-unknown", "an unrecognized value, measured to fall back to rustc's default", "rejected",
		head+"[profile.release]\ndebug = 2\nsplit-debuginfo = \"wat\"\n")
	add("F11/split-debuginfo-empty", "the empty string, same fallback", "rejected",
		head+"[profile.release]\ndebug = 2\nsplit-debuginfo = \"\"\n")
	add("F12/split-debuginfo-override", "the same key inside a package override", "rejected",
		head+"[profile.release.package.x]\nsplit-debuginfo = \"packed\"\n")
	add("F13/split-debuginfo-build-override", "the same key inside a build-override", "rejected",
		head+"[profile.release.build-override]\nsplit-debuginfo = \"packed\"\n")
	add("F14/unknown-key", "a key cargo accepts today without a diagnostic", "rejected",
		head+"[profile.release]\ntotally-unknown-key = 42\n")
	add("F15/unstable-rustflags", "the unstable per-profile rustflags key", "rejected",
		head+"[profile.release]\nrustflags = [\"-Clink-arg=-v\"]\n")
	add("F16/unstable-codegen-backend", "the unstable codegen-backend key", "rejected",
		head+"[profile.release]\ncodegen-backend = \"cranelift\"\n")
	add("F17/unstable-trim-paths", "the trim-paths key, not stable on the measured cargo", "rejected",
		head+"[profile.release]\ntrim-paths = \"all\"\n")
	add("F18/out-of-range-opt-level", "an admitted key with a value outside its set", "rejected",
		head+"[profile.release]\nopt-level = 9\n")
	add("F19/wrong-typed-lto", "an admitted key with a value of the wrong shape", "rejected",
		head+"[profile.release]\nlto = \"aggressive\"\n")
	add("F20/codegen-units-zero", "codegen-units below one", "rejected",
		head+"[profile.release]\ncodegen-units = 0\n")
	add("F21/nesting-too-deep", "a profile table nested past the three stable shapes", "rejected",
		head+"[profile.release.package.x.extra]\nopt-level = 1\n")
	add("F22/unknown-subtable", "a subtable that is neither package nor build-override", "rejected",
		head+"[profile.release.wat]\nopt-level = 1\n")
	add("F23/bare-profile-table", "a bare [profile] table with no profile name", "rejected",
		head+"[profile]\nopt-level = 1\n")
	add("F24/inherits-bad-value", "inherits carrying a non-name value", "rejected",
		head+"[profile.myrel]\ninherits = 3\n")
	add("F25/literal-string-value", "a TOML literal string is the same value as its basic-string spelling", "admitted",
		head+"[profile.release]\nopt-level = 's'\n")
	add("F26/quoted-forbidden-key", "the rejected key spelled as a quoted TOML key", "rejected",
		head+"[profile.release]\n\"split-debuginfo\" = \"packed\"\n")
	add("F27/array-of-tables", "a profile header written as an array of tables", "rejected",
		head+"[[profile.release]]\nopt-level = 3\n")

	return out
}

// vectorsAdmittedSet are the host-independent conformance vectors of reference
// section 4.8. They construct real trees under the probe's working directory
// and never invoke cargo.
func vectorsAdmittedSet(work string) []Vector {
	var out []Vector
	add := func(id, title, expected, observed, detail string) {
		v := Vector{ID: id, Group: "admitted-set", Title: title, Expected: expected, Observed: observed, Detail: detail}
		v.settle()
		out = append(out, v)
	}
	word := func(b bool) string {
		if b {
			return "member"
		}
		return "not-member"
	}

	root := filepath.Join(work, "admitset-vectors")
	_ = os.RemoveAll(root)
	for _, d := range []string{"src", "src/bin", "examples", "tests", "benches", "vendor/dep/src"} {
		_ = mkdirAll(filepath.Join(root, d))
	}
	for _, f := range []string{
		"Cargo.toml", "Cargo.lock", "src/main.rs", "src/lib.rs", "src/bin/extra.rs",
		"examples/e.rs", "tests/t.rs", "benches/b.rs", "vendor/dep/Cargo.toml", "vendor/dep/src/lib.rs",
	} {
		_ = os.WriteFile(filepath.Join(root, f), []byte("x\n"), 0o644)
	}
	absent := filepath.Join(root, "src", "ghost.rs")
	a := buildAdmittedSet(root, []string{absent})

	add("A1/root-manifest", "the build-root manifest", "member",
		word(a.Has(filepath.Join(root, "Cargo.toml"))), "")
	add("A2/auto-main", "an auto-discovered src/main.rs, declared by no key", "member",
		word(a.Has(filepath.Join(root, "src", "main.rs"))), "the ordinary positive shape the superseded text could not decide")
	add("A3/auto-lib", "an auto-discovered src/lib.rs", "member",
		word(a.Has(filepath.Join(root, "src", "lib.rs"))), "")
	add("A4/auto-named-bin", "an auto-discovered src/bin entry", "member",
		word(a.Has(filepath.Join(root, "src", "bin", "extra.rs"))), "")
	add("A5/auto-example", "an auto-discovered example", "member",
		word(a.Has(filepath.Join(root, "examples", "e.rs"))), "")
	add("A6/auto-test", "an auto-discovered integration test", "member",
		word(a.Has(filepath.Join(root, "tests", "t.rs"))), "")
	add("A7/auto-bench", "an auto-discovered bench", "member",
		word(a.Has(filepath.Join(root, "benches", "b.rs"))), "")
	add("A8/vendored-manifest", "a vendored manifest reached by no dependency", "member",
		word(a.Has(filepath.Join(root, "vendor", "dep", "Cargo.toml"))), "unreachable manifests are inventoried and admitted")
	add("A9/vendored-source", "a vendored target source", "member",
		word(a.Has(filepath.Join(root, "vendor", "dep", "src", "lib.rs"))), "")
	add("A10/declared-absent-leaf", "a declared leaf section 4.3 permits to be absent", "member",
		word(a.Has(absent)), "")
	add("A11/undeclared-absent-leaf", "an absent path that no key declares", "not-member",
		word(a.Has(filepath.Join(root, "src", "never.rs"))), "")
	add("A12/outside-root", "a path outside the build root", "not-member",
		word(a.Has(filepath.Join(filepath.Dir(root), "outside.rs"))), "")

	// A symbolic link inside the root is not walked into, so nothing below it
	// enters A even though the link itself is lexically inside R.
	linkTarget := filepath.Join(work, "admitset-outside")
	_ = mkdirAll(linkTarget)
	_ = os.WriteFile(filepath.Join(linkTarget, "hidden.rs"), []byte("x\n"), 0o644)
	link := filepath.Join(root, "linked")
	linkOK := os.Symlink(linkTarget, link) == nil
	if linkOK {
		b := buildAdmittedSet(root, nil)
		add("A13/below-symlink", "a file reachable only through a symbolic link inside the root", "not-member",
			word(b.Has(filepath.Join(link, "hidden.rs"))), "the walk does not descend a link")
		add("A14/symlink-itself", "the symbolic link component itself", "not-member",
			word(b.Has(link)), "")
	} else {
		add("A13/below-symlink", "a file reachable only through a symbolic link inside the root", "not run", "not run", "symlink unavailable")
		add("A14/symlink-itself", "the symbolic link component itself", "not run", "not run", "symlink unavailable")
	}

	// The superseded input set, as a vector rather than only as a control.
	sup := supersededAdmittedSet(root, []string{filepath.Join(root, "Cargo.toml")}, nil)
	add("A15/superseded-set-misses-main", "the superseded input set against src/main.rs", "not-member",
		word(sup.Has(filepath.Join(root, "src", "main.rs"))),
		"the defect blocking finding 2 names: an ordinary positive build had no defined G11 verdict")

	// G11 itself, over a reported list containing one escaping path.
	reported := []string{
		filepath.Join(root, "Cargo.toml"),
		filepath.Join(root, "src", "main.rs"),
		filepath.Join(filepath.Dir(root), "outside", "Cargo.toml"),
	}
	bad := g11(a, reported)
	obs := "1 outside"
	if len(bad) != 1 {
		obs = strings.TrimSpace(strings.Join(bad, " "))
		if len(bad) == 0 {
			obs = "0 outside"
		}
	}
	add("A16/g11-finds-escape", "G11 over a reported list carrying one outside manifest", "1 outside", obs,
		"a non-empty result is build_rust_graph_inconsistent, a manager fault")

	return out
}
