package main

import (
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// ---------------------------------------------------------------------------
// Reference section 4.7: the Stage P admitted path set A, and G11.
//
// The superseded text required every graph `manifest_path` and target
// `src_path` to be "in the Stage P admitted set" while defining only the
// manifest inventory M and the declared path-bearing keys. An ordinary package
// uses `src/main.rs` with no `[[bin]].path` key, so under the written algorithm
// an implementation had to either reject an ordinary positive build at G11 or
// invent an unreviewed copy of Cargo's target auto-discovery inside Stage P.
//
// A is defined instead by the walk Stage P already performs, so it needs no
// discovery semantics at all:
//
//	A = every path the link-free snapshot walk of section 4.1 enumerated
//	    under R, plus every leaf that section 4.3 admitted lexically and
//	    physically and permitted to be absent.
//
// The property that makes this total is measured, not assumed: every path
// `cargo metadata` reports is either an existing file under R — auto-discovered
// targets are found by looking at the filesystem, so they exist — or a path
// declared by a path-bearing key, which section 4.3 has already decided. A
// name-only target with no discoverable file was measured to make cargo exit
// 101 at the graph phase rather than report a phantom `src_path`.
// ---------------------------------------------------------------------------

// admittedSet is A. Membership is by exact cleaned absolute path.
type admittedSet struct {
	walked  map[string]bool
	absent  map[string]bool
	Root    string
	WalkErr string
}

func (a admittedSet) Has(p string) bool {
	c := filepath.Clean(p)
	return a.walked[c] || a.absent[c]
}

func (a admittedSet) Size() int { return len(a.walked) + len(a.absent) }

// Members returns the set sorted, for evidence.
func (a admittedSet) Members() []string {
	out := make([]string, 0, a.Size())
	for p := range a.walked {
		out = append(out, p)
	}
	for p := range a.absent {
		out = append(out, p)
	}
	sort.Strings(out)
	return out
}

// buildAdmittedSet performs the section 4.1 walk and returns A. The walk never
// follows a link and never descends below one: the snapshot is already
// link-free by validation, and a link found here is a validation defect rather
// than a path to resolve.
//
// declaredAbsent carries the leaves section 4.3 admitted and permitted to be
// absent; they are joined against their own manifest directory by the caller.
func buildAdmittedSet(root string, declaredAbsent []string) admittedSet {
	a := admittedSet{
		walked: map[string]bool{},
		absent: map[string]bool{},
		Root:   filepath.Clean(root),
	}
	var walk func(dir string) string
	walk = func(dir string) string {
		entries, err := os.ReadDir(dir)
		if err != nil {
			return "unreadable directory " + dir + ": " + err.Error()
		}
		for _, e := range entries {
			p := filepath.Join(dir, e.Name())
			st, err := os.Lstat(p)
			if err != nil {
				return "unstattable entry " + p + ": " + err.Error()
			}
			if st.Mode()&os.ModeSymlink != 0 {
				// Not admitted, and not descended into. Section 4.3 rejects a
				// link component wherever it appears; here it simply stays out
				// of A, so anything Cargo reaches through it is a G11 finding.
				continue
			}
			a.walked[filepath.Clean(p)] = true
			if st.IsDir() {
				if why := walk(p); why != "" {
					return why
				}
			}
		}
		return ""
	}
	a.walked[a.Root] = true
	a.WalkErr = walk(a.Root)
	for _, p := range declaredAbsent {
		a.absent[filepath.Clean(p)] = true
	}
	return a
}

// g11 is the graph-phase consistency cross-check. It returns the reported paths
// that are not members of A. A non-empty result is
// `build_rust_graph_inconsistent`: a manager fault, never a package rejection.
func g11(a admittedSet, reported []string) []string {
	var bad []string
	for _, p := range reported {
		if p == "" {
			continue
		}
		if !a.Has(p) {
			bad = append(bad, p)
		}
	}
	sort.Strings(bad)
	return bad
}

// supersededAdmittedSet is the set the previous revision's text actually
// defined: manifests plus declared path-bearing values, with no account of
// Cargo's auto-discovered target sources. Kept runnable for control C15, which
// requires it to reject an ordinary `src/main.rs` package.
func supersededAdmittedSet(root string, manifests, declared []string) admittedSet {
	a := admittedSet{walked: map[string]bool{}, absent: map[string]bool{}, Root: filepath.Clean(root)}
	for _, p := range manifests {
		a.walked[filepath.Clean(p)] = true
	}
	for _, p := range declared {
		a.walked[filepath.Clean(p)] = true
	}
	return a
}

// reportedPaths pulls every manifest_path and target src_path out of a
// `cargo metadata` document.
func reportedPaths(doc cmDoc) []string {
	var out []string
	for _, p := range doc.Packages {
		if p.ManifestPath != "" {
			out = append(out, p.ManifestPath)
		}
		for _, t := range p.Targets {
			if t.SrcPath != "" {
				out = append(out, t.SrcPath)
			}
		}
	}
	sort.Strings(out)
	return out
}

// relTo renders a path relative to the root for evidence, without deciding
// anything.
func relTo(root, p string) string {
	if r, err := filepath.Rel(root, p); err == nil && !strings.HasPrefix(r, "..") {
		return r
	}
	return p
}
