package main

import (
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
)

// Toolchain is the resolved Rust distribution root plus everything Stage A
// would normalize from it. Resolution here mirrors the contract's rule that a
// root is named by configuration and never discovered through PATH: the probe
// takes the root from RUST_PROBE_ROOT, or from the single directory under
// RUSTUP_HOME/toolchains when exactly one exists, and never from `which`.
type Toolchain struct {
	Root          string `json:"root"`
	Available     bool   `json:"available"`
	Reason        string `json:"reason,omitempty"`
	CargoPath     string `json:"cargo_path,omitempty"`
	RustcPath     string `json:"rustc_path,omitempty"`
	LinkerPath    string `json:"linker_path,omitempty"`
	RustVersion   string `json:"rust_version,omitempty"`
	CargoVersion  string `json:"cargo_version,omitempty"`
	HostTuple     string `json:"host_tuple,omitempty"`
	Prerelease    bool   `json:"prerelease,omitempty"`
	StdLibPresent bool   `json:"stdlib_present,omitempty"`
	// SDKRoot is the resolved `platform-sdk` link-support root. It is taken
	// from configuration (RUST_PROBE_SDKROOT) and never discovered through
	// `xcrun`, `xcode-select`, PATH, or DEVELOPER_DIR, exactly as the contract
	// requires of a link-support declaration.
	SDKRoot      string `json:"sdk_root,omitempty"`
	LinkerFlavor string `json:"linker_flavor,omitempty"`
	// DebugInfoPin is the platform-resolved `-Csplit-debuginfo` value the
	// manager pins in CARGO_ENCODED_RUSTFLAGS. It is not hygiene. Measured on
	// macOS: when cargo does not pass the flag itself — which happens for every
	// unrecognized profile value — rustc's own default for the target is
	// `packed`, and `packed` runs a PATH-resolved `dsymutil`. The pin makes the
	// whole class inert whatever the package bytes and whatever cargo forwards.
	DebugInfoPin string `json:"split_debuginfo_pin,omitempty"`
}

// splitDebuginfoPin is the manager constant of reference section 6, resolved per
// operating system. macOS is measured; every other value is a qualification
// obligation, never a claim.
func splitDebuginfoPin(goos string) string {
	if goos == "darwin" {
		return "off"
	}
	return ""
}

// linkPins returns the environment settings that keep the link step inside the
// fingerprinted closure. Measured: without the linker and SDK pins, `rustc`
// resolves `xcrun` and `cc` through PATH; without the split-debuginfo pin, an
// admitted profile value reaches a PATH-resolved `dsymutil`.
func (t Toolchain) linkPins(env map[string]string) map[string]string {
	if t.SDKRoot != "" {
		env["SDKROOT"] = t.SDKRoot
	}
	if t.LinkerPath != "" && t.LinkerFlavor != "" {
		flags := "-Clinker=" + t.LinkerPath + "\x1f-Clinker-flavor=" + t.LinkerFlavor
		if t.DebugInfoPin != "" {
			flags += "\x1f-Csplit-debuginfo=" + t.DebugInfoPin
		}
		env["CARGO_ENCODED_RUSTFLAGS"] = flags
	}
	return env
}

var releaseRe = regexp.MustCompile(`^release: (0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?$`)
var cargoVersionRe = regexp.MustCompile(`^cargo (0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)? \([0-9a-f]+ [0-9]{4}-[0-9]{2}-[0-9]{2}\)$`)
var libstdRe = regexp.MustCompile(`^libstd-[0-9a-f]+\.rlib$`)

func discoverRoot() (string, string) {
	if r := os.Getenv("RUST_PROBE_ROOT"); r != "" {
		return r, ""
	}
	home := os.Getenv("RUSTUP_HOME")
	if home == "" {
		if h, err := os.UserHomeDir(); err == nil {
			home = filepath.Join(h, ".rustup")
		}
	}
	if home == "" {
		return "", "no RUST_PROBE_ROOT and no home directory"
	}
	entries, err := os.ReadDir(filepath.Join(home, "toolchains"))
	if err != nil {
		return "", "no toolchains directory under " + home
	}
	var dirs []string
	for _, e := range entries {
		if e.IsDir() {
			dirs = append(dirs, filepath.Join(home, "toolchains", e.Name()))
		}
	}
	switch len(dirs) {
	case 0:
		return "", "no toolchain directory present"
	case 1:
		return dirs[0], ""
	default:
		return "", "more than one toolchain directory present; set RUST_PROBE_ROOT explicitly"
	}
}

func resolveToolchain(work string) Toolchain {
	root, why := discoverRoot()
	if root == "" {
		return Toolchain{Available: false, Reason: why}
	}
	tc := Toolchain{Root: root}
	tc.CargoPath = filepath.Join(root, "bin", "cargo")
	tc.RustcPath = filepath.Join(root, "bin", "rustc")
	for _, p := range []string{tc.CargoPath, tc.RustcPath} {
		if st, err := os.Stat(p); err != nil || st.IsDir() {
			tc.Reason = "missing regular executable " + p
			return tc
		}
	}

	env := baseEnv(work, "", "")
	vv := exec1(work, env, tc.RustcPath, "-vV")
	if vv.ExitCode != 0 {
		tc.Reason = "rustc -vV exited non-zero"
		return tc
	}
	matches := 0
	for _, l := range strings.Split(strings.ReplaceAll(vv.Stdout, "\r\n", "\n"), "\n") {
		if m := releaseRe.FindStringSubmatch(l); m != nil {
			matches++
			tc.RustVersion = m[1] + "." + m[2] + "." + m[3]
			tc.Prerelease = m[4] != ""
		}
	}
	if matches != 1 {
		tc.Reason = "rustc -vV did not yield exactly one release: line"
		return tc
	}

	cv := exec1(work, env, tc.CargoPath, "--version")
	line := strings.TrimRight(strings.ReplaceAll(cv.Stdout, "\r\n", "\n"), "\n")
	if cv.ExitCode != 0 || !cargoVersionRe.MatchString(line) {
		tc.Reason = "cargo --version did not match the anchored rule"
		return tc
	}
	tc.CargoVersion = line
	m := cargoVersionRe.FindStringSubmatch(line)
	if m[1]+"."+m[2]+"."+m[3] != tc.RustVersion || m[4] != "" {
		tc.Reason = "cargo and rustc triples disagree"
		return tc
	}

	ht := exec1(work, env, tc.RustcPath, "--print", "host-tuple")
	if ht.ExitCode != 0 {
		tc.Reason = "rustc --print host-tuple exited non-zero"
		return tc
	}
	tc.HostTuple = strings.TrimSpace(ht.Stdout)
	tc.LinkerPath = filepath.Join(root, "lib", "rustlib", tc.HostTuple, "bin", "rust-lld")

	// Admission, not representability: the standard library must be inside the
	// tree that would be fingerprinted.
	libdir := filepath.Join(root, "lib", "rustlib", tc.HostTuple, "lib")
	if entries, err := os.ReadDir(libdir); err == nil {
		for _, e := range entries {
			if !e.IsDir() && libstdRe.MatchString(e.Name()) {
				tc.StdLibPresent = true
				break
			}
		}
	}
	if !tc.StdLibPresent {
		tc.Reason = "no libstd-*.rlib under " + libdir
		return tc
	}
	if tc.Prerelease {
		tc.Reason = "resolved toolchain is a prerelease, which the contract never resolves"
		return tc
	}

	// The link-support declaration. On macOS the contract requires exactly one
	// role, `platform-sdk`, and it is a hard requirement rather than a
	// convenience: without it the link step resolves `xcrun` and `cc` through
	// PATH. Its absence is reported as evidence and nothing is installed.
	tc.SDKRoot = os.Getenv("RUST_PROBE_SDKROOT")
	tc.DebugInfoPin = splitDebuginfoPin(runtime.GOOS)
	if runtime.GOOS == "darwin" {
		tc.LinkerFlavor = "ld64.lld"
		if tc.SDKRoot == "" {
			tc.Reason = "RUST_PROBE_SDKROOT is not set, so the macOS platform-sdk link-support root cannot be declared"
			return tc
		}
		if st, err := os.Stat(tc.SDKRoot); err != nil || !st.IsDir() {
			tc.Reason = "declared platform-sdk root is not a directory: " + tc.SDKRoot
			return tc
		}
	}
	if st, err := os.Stat(tc.LinkerPath); err != nil || st.IsDir() {
		tc.Reason = "missing regular executable " + tc.LinkerPath
		return tc
	}

	tc.Available = true
	return tc
}

// baseEnv is the operation-private environment shape of reference section 5,
// reduced to what the probe needs. It never inherits: the map is the whole
// environment. `PATH` names a manager-owned empty directory unless the caller
// supplies a poisoned one.
func baseEnv(work, rustc, pathDir string) map[string]string {
	if pathDir == "" {
		pathDir = filepath.Join(work, "empty-path")
		_ = os.MkdirAll(pathDir, 0o755)
	}
	env := map[string]string{
		"PATH":                         pathDir,
		"HOME":                         filepath.Join(work, "home"),
		"TMPDIR":                       filepath.Join(work, "tmp"),
		"XDG_CONFIG_HOME":              filepath.Join(work, "xdg-config"),
		"XDG_CACHE_HOME":               filepath.Join(work, "xdg-cache"),
		"LC_ALL":                       "C",
		"LANG":                         "C",
		"CARGO_HOME":                   filepath.Join(work, "cargo-home"),
		"CARGO_TARGET_DIR":             filepath.Join(work, "target"),
		"CARGO_INCREMENTAL":            "0",
		"CARGO_NET_OFFLINE":            "true",
		"CARGO_NET_RETRY":              "0",
		"CARGO_NET_GIT_FETCH_WITH_CLI": "false",
		"CARGO_TERM_COLOR":             "never",
		"RUSTC_WRAPPER":                "",
		"RUSTC_WORKSPACE_WRAPPER":      "",
		"CARGO_ENCODED_RUSTDOCFLAGS":   "",
	}
	if rustc != "" {
		env["RUSTC"] = rustc
	}
	for _, d := range []string{"home", "tmp", "xdg-config", "xdg-cache", "cargo-home", "target"} {
		_ = os.MkdirAll(filepath.Join(work, d), 0o755)
	}
	return env
}
