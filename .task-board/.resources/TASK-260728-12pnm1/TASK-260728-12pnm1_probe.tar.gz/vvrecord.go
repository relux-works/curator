package main

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"unicode/utf8"
)

// Vector is one host-independent unit measurement: a pure function applied to a
// constructed input, with the outcome predicted before it runs. Unlike a
// Structural check it needs no toolchain, so it runs even on a host where
// nothing is installed.
type Vector struct {
	ID       string `json:"id"`
	Group    string `json:"group"`
	Title    string `json:"title"`
	Expected string `json:"expected"`
	Observed string `json:"observed"`
	Verdict  string `json:"verdict"`
	Detail   string `json:"detail,omitempty"`
}

func (v *Vector) settle() {
	if v.Observed == v.Expected {
		v.Verdict = "match"
	} else {
		v.Verdict = "divergence"
	}
}

// ---------------------------------------------------------------------------
// Reference section 2.3: normalization of the V and C version records.
//
// `rustc -vV` stdout is multiline — measured, seven lines — so the rule is
// defined over a multiline stream. A single-line rule would reject the exact
// toolchain the registry entry admits, which is the defect this implements the
// fix for.
// ---------------------------------------------------------------------------

// The semantic bound is applied to the *folded* stream; the raw bound is a
// capture limit only. Folding replaces a two-byte CRLF with one byte and
// rewrites nothing else, so for any stream
//
//	len(folded) >= ceil(len(raw)/2)
//
// and therefore len(raw) > 2*maxVersionStream implies len(folded) > 4096. The
// raw bound consequently rejects only streams the semantic bound would reject
// anyway: it is a resource limit, never an admission decision.
//
// Ordering the raw bound before the fold — which is what the superseded rule
// did — makes admission depend on line endings. Measured: an LF stream of 4093
// 'x', LF, 'A', LF is 4096 raw bytes and was accepted, while its CRLF form is
// 4098 raw bytes and was rejected, even though folding the second produces the
// first byte for byte. Control C11 keeps that divergence runnable.
const (
	maxVersionStream    = 4096
	maxVersionStreamRaw = 2 * maxVersionStream
)

var errStream = errors.New("version stream rejected")

// normalizeVersionStream applies the ordered steps of reference section 2.3.
// interiorLF reports whether the payload may contain interior LF bytes: true
// for the V record, false for the single-line C record.
func normalizeVersionStream(raw []byte, interiorLF bool) ([]byte, string) {
	if len(raw) > maxVersionStreamRaw {
		return nil, "over 8192 raw bytes"
	}
	if !utf8.Valid(raw) {
		return nil, "not valid UTF-8"
	}
	for _, b := range raw {
		if b == 0x00 {
			return nil, "contains NUL"
		}
	}
	// CRLF -> LF. This is the only rewriting step and it is what makes a
	// Windows-hosted and a Unix-hosted probe of the same distribution agree.
	// It precedes the semantic bound so that two streams differing only in
	// line endings cannot receive different verdicts.
	folded := []byte(strings.ReplaceAll(string(raw), "\r\n", "\n"))
	if len(folded) > maxVersionStream {
		return nil, "over 4096 bytes after folding"
	}
	for _, b := range folded {
		if b == '\r' {
			return nil, "contains a bare CR"
		}
	}
	if len(folded) < 2 {
		return nil, "shorter than two bytes"
	}
	if folded[len(folded)-1] != '\n' {
		return nil, "does not end with LF"
	}
	if folded[len(folded)-2] == '\n' {
		return nil, "ends with more than one LF"
	}
	payload := folded[:len(folded)-1]
	if len(payload) == 0 {
		return nil, "empty payload"
	}
	for _, r := range string(payload) {
		if r == '\n' {
			if !interiorLF {
				return nil, "single-line record carries an interior LF"
			}
			continue
		}
		if r < 0x20 || r == 0x7f {
			return nil, "carries a control character"
		}
	}
	return payload, ""
}

// frameVersionRecord is the record framing of reference section 2.2 with an
// empty path: kind || uint64be(0) || uint64be(len) || payload.
func frameVersionRecord(kind byte, payload []byte) []byte {
	out := make([]byte, 0, 1+8+8+len(payload))
	out = append(out, kind)
	var n [8]byte
	binary.BigEndian.PutUint64(n[:], 0)
	out = append(out, n[:]...)
	binary.BigEndian.PutUint64(n[:], uint64(len(payload)))
	out = append(out, n[:]...)
	return append(out, payload...)
}

func sha256hex(b []byte) string {
	s := sha256.Sum256(b)
	return hex.EncodeToString(s[:])
}

// The measured stdout of the resolved root on the qualifying host, embedded so
// that N2 through N13 need no toolchain at all. A different Rust release
// produces different bytes; N1 states that relationship explicitly instead of
// pretending the constant is universal.
const measuredVV = "rustc 1.91.0 (f8297e351 2025-10-28)\n" +
	"binary: rustc\n" +
	"commit-hash: f8297e351a40c1439a467bbbb6879088047f50b3\n" +
	"commit-date: 2025-10-28\n" +
	"host: aarch64-apple-darwin\n" +
	"release: 1.91.0\n" +
	"LLVM version: 21.1.2\n"

const measuredCargoVersion = "cargo 1.91.0 (ea2d97820 2025-10-10)\n"

const (
	measuredVPayloadSHA = "7d8e08339e557ede5a9e565773c4cf17f83dea27f7d0c6591869f184bd1b81b5"
	measuredVRecordSHA  = "7fc35c11acae420849418f9c9f9b5681651beedc6d68f00bf1e4db022cd5f06b"
	measuredCPayloadSHA = "8d712854de14f22840767bc824c5ac08098f35ddaa44437256e31b53cb546165"
	measuredCRecordSHA  = "d677e668d65108419fd197d147f31f2dda30a1364233440f3b0138d5185c2f78"
)

func vectorsNormalization(tc Toolchain, work string) []Vector {
	var out []Vector

	add := func(id, title, expected, observed, detail string) {
		v := Vector{ID: id, Group: "normalization", Title: title, Expected: expected, Observed: observed, Detail: detail}
		v.settle()
		out = append(out, v)
	}

	// The embedded sample is itself checked against the recorded constants
	// before anything is derived from it, so a typo in the constant is a
	// divergence rather than a silent baseline.
	base := []byte(measuredVV)
	pay, why := normalizeVersionStream(base, true)
	if why != "" {
		add("N0/embedded-sample", "the embedded measured stream normalizes",
			"accepted", "rejected: "+why, "")
		return out
	}
	rec := frameVersionRecord('V', pay)
	add("N0/embedded-sample", "the embedded measured stream reproduces the recorded digests",
		fmt.Sprintf("payload=191 sha=%s record=208 sha=%s", measuredVPayloadSHA, measuredVRecordSHA),
		fmt.Sprintf("payload=%d sha=%s record=%d sha=%s", len(pay), sha256hex(pay), len(rec), sha256hex(rec)), "")

	cpay, cwhy := normalizeVersionStream([]byte(measuredCargoVersion), false)
	cobs := "rejected: " + cwhy
	if cwhy == "" {
		crec := frameVersionRecord('C', cpay)
		cobs = fmt.Sprintf("payload=%d sha=%s record=%d sha=%s", len(cpay), sha256hex(cpay), len(crec), sha256hex(crec))
	}
	add("N0/embedded-cargo", "the embedded cargo --version stream reproduces the recorded digests",
		fmt.Sprintf("payload=35 sha=%s record=52 sha=%s", measuredCPayloadSHA, measuredCRecordSHA), cobs, "")

	// N1 is the only host-dependent vector. It never asserts the constant on a
	// host running a different release; it asserts the relationship.
	{
		exp, obs := "normalizes; digest equals the constant when the bytes equal the sample", ""
		if !tc.Available {
			exp = "not run"
			obs = "not run"
		} else {
			env := baseEnv(work, "", "")
			_, raw := exec1Full(work, env, tc.RustcPath, "-vV")
			p, w := normalizeVersionStream([]byte(raw), true)
			switch {
			case w != "":
				obs = "rejected: " + w
			case raw == measuredVV && sha256hex(frameVersionRecord('V', p)) == measuredVRecordSHA:
				obs = exp
			case raw == measuredVV:
				obs = "bytes equal the sample but the digest differs"
			default:
				// A different release. Idempotence and framing are still
				// checkable and are what the vector asserts here.
				p2, w2 := normalizeVersionStream([]byte(string(p)+"\n"), true)
				if w2 == "" && string(p2) == string(p) {
					obs = exp
				} else {
					obs = "renormalization is not idempotent"
				}
			}
		}
		add("N1/live-stream", "live rustc -vV stdout normalizes and frames deterministically", exp, obs,
			"host-dependent by construction")
	}

	type mut struct {
		id, title, expect string
		in                []byte
	}
	crlf := []byte(strings.ReplaceAll(measuredVV, "\n", "\r\n"))
	noInterior := []byte(strings.Replace(measuredVV, "binary: rustc\n", "", 1))
	oneByte := []byte(strings.Replace(measuredVV, "LLVM version: 21.1.2", "LLVM version: 21.1.3", 1))
	lines := strings.Split(strings.TrimRight(measuredVV, "\n"), "\n")
	lines[1], lines[2] = lines[2], lines[1]
	transposed := []byte(strings.Join(lines, "\n") + "\n")

	muts := []mut{
		{"N2/crlf-folds", "CRLF line endings fold to the same payload", "same digest", crlf},
		{"N3/line-removed", "one interior line removed", "different digest", noInterior},
		{"N4/byte-changed", "one payload byte changed", "different digest", oneByte},
		{"N5/lines-transposed", "two whole lines transposed", "different digest", transposed},
		{"N6/bare-cr", "a bare CR inserted", "rejected", []byte(strings.Replace(measuredVV, "binary:", "bin\rary:", 1))},
		{"N7/no-terminal-lf", "no terminal LF", "rejected", []byte(strings.TrimRight(measuredVV, "\n"))},
		{"N8/two-terminal-lf", "two terminal LFs", "rejected", []byte(measuredVV + "\n")},
		{"N9/nul", "a NUL inserted", "rejected", append([]byte(measuredVV[:10]+"\x00"), measuredVV[10:]...)},
		{"N10/invalid-utf8", "invalid UTF-8 inserted", "rejected", append([]byte{0xff, 0xfe}, measuredVV...)},
		{"N11/empty", "empty stdout", "rejected", []byte("")},
		{"N12/too-long", "a folded stream of 4097 bytes", "rejected", append([]byte(strings.Repeat("x", 4096)), '\n')},
	}
	for _, m := range muts {
		p, w := normalizeVersionStream(m.in, true)
		obs := "rejected"
		if w == "" {
			if sha256hex(frameVersionRecord('V', p)) == measuredVRecordSHA {
				obs = "same digest"
			} else {
				obs = "different digest"
			}
		}
		add(m.id, m.title, m.expect, obs, w)
	}

	// N13 is the single-line constraint on the C record.
	_, w13 := normalizeVersionStream([]byte("cargo 1.91.0 (ea2d97820 2025-10-10)\nextra\n"), false)
	obs13 := "accepted"
	if w13 != "" {
		obs13 = "rejected"
	}
	add("N13/c-record-multiline", "a C payload carrying an interior LF", "rejected", obs13, w13)

	// ----------------------------------------------------------------------
	// N14 through N19: the size boundary, in LF/CRLF pairs.
	//
	// The property under test is not "4096 is the limit" but "line endings do
	// not change the verdict". Each pair is one LF stream and its CRLF
	// expansion; both must be admitted or both rejected, and when admitted the
	// payload and the framed digest must be identical. The superseded order
	// applied the byte limit to the raw stream, so the first pair diverged.
	// ----------------------------------------------------------------------
	pairVector := func(id, title, lf string, wantAdmitted bool) {
		crlf := strings.ReplaceAll(lf, "\n", "\r\n")
		pl, wl := normalizeVersionStream([]byte(lf), true)
		pc, wc := normalizeVersionStream([]byte(crlf), true)

		expected := "both rejected"
		if wantAdmitted {
			expected = "both admitted, identical payload and digest"
		}
		var observed string
		switch {
		case (wl == "") != (wc == ""):
			observed = fmt.Sprintf("divergent verdicts: LF %s, CRLF %s",
				verdictWord(wl), verdictWord(wc))
		case wl != "":
			observed = "both rejected"
		case string(pl) != string(pc):
			observed = fmt.Sprintf("both admitted but payloads differ: %d vs %d bytes", len(pl), len(pc))
		case sha256hex(frameVersionRecord('V', pl)) != sha256hex(frameVersionRecord('V', pc)):
			observed = "both admitted but the framed digests differ"
		default:
			observed = "both admitted, identical payload and digest"
		}
		detail := fmt.Sprintf("folded=%d raw LF=%d raw CRLF=%d", len(lf), len(lf), len(crlf))
		if wl == "" {
			detail += fmt.Sprintf(" payload=%d sha=%s", len(pl), sha256hex(frameVersionRecord('V', pl))[:16])
		} else {
			detail += " reason=" + wl
		}
		add(id, title, expected, observed, detail)
	}

	// The exact stream the reviewer constructed: 4096 raw LF bytes, whose CRLF
	// form is 4098 raw bytes and folds back to the same 4096.
	pairVector("N14/boundary-4096-two-line", "folded stream of exactly 4096 bytes, two lines",
		strings.Repeat("x", 4093)+"\nA\n", true)
	pairVector("N15/boundary-4097-two-line", "folded stream of exactly 4097 bytes, two lines",
		strings.Repeat("x", 4094)+"\nA\n", false)

	// A many-line shape, where the CRLF expansion is far larger than two bytes:
	// 410 terminators, so the raw CRLF form is 4506 bytes against a 4096-byte
	// folded stream. This is the shape a real multiline version stream has.
	manyLines := strings.Repeat(strings.Repeat("x", 9)+"\n", 409)
	pairVector("N16/boundary-4096-many-line", "folded stream of exactly 4096 bytes over 410 lines",
		manyLines+"xxxxx\n", true)
	pairVector("N17/boundary-4097-many-line", "folded stream of exactly 4097 bytes over 410 lines",
		manyLines+"xxxxxx\n", false)

	// N18: the raw capture bound is reached, not pre-empted. 4096 CRLF pairs is
	// exactly 8192 raw bytes and folds to exactly 4096 bytes, so it passes both
	// bounds and is decided by the terminal-LF rule — which is the semantic
	// decision, not the resource limit.
	{
		_, w := normalizeVersionStream([]byte(strings.Repeat("\r\n", maxVersionStream)), true)
		add("N18/raw-bound-not-preemptive",
			"the maximal CRLF expansion of an in-bound folded stream reaches the semantic rules",
			"rejected for a semantic reason", classifyRejection(w),
			fmt.Sprintf("raw=%d folded=%d reason=%q", 2*maxVersionStream, maxVersionStream, w))
	}

	// N19: the raw bound is non-lossy. Folding can at most halve a stream, so a
	// raw stream longer than 8192 bytes always folds to more than 4096 bytes.
	// Checked over every raw length the bound can see rather than argued.
	{
		bad := 0
		for n := 0; n <= 4*maxVersionStreamRaw; n++ {
			minFolded := (n + 1) / 2 // ceil(n/2)
			if n > maxVersionStreamRaw && minFolded <= maxVersionStream {
				bad++
			}
		}
		add("N19/raw-bound-is-non-lossy",
			"no raw length above the capture bound can fold within the semantic bound",
			"0 such lengths", fmt.Sprintf("%d such lengths", bad),
			fmt.Sprintf("checked raw lengths 0..%d", 4*maxVersionStreamRaw))
	}

	return out
}

func verdictWord(why string) string {
	if why == "" {
		return "admitted"
	}
	return "rejected (" + why + ")"
}

// classifyRejection separates a rejection made by the raw capture limit from
// one made by a semantic rule. Only the second is an admission decision.
func classifyRejection(why string) string {
	switch {
	case why == "":
		return "admitted"
	case strings.Contains(why, "raw bytes"):
		return "rejected by the raw capture limit"
	default:
		return "rejected for a semantic reason"
	}
}
