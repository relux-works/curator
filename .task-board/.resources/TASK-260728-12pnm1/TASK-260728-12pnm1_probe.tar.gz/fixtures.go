package main

import (
	"os"
	"path/filepath"
	"strings"
)

func mkdirAll(p string) error { return os.MkdirAll(p, 0o755) }

// writeGraphFixture builds the build-script and procedural-macro fixture. Both
// dependencies are path dependencies, so nothing is fetched, and both write a
// marker file when they execute. The measurement is the absence of the markers.
func writeGraphFixture(dir, bsMarker, pmMarker string) error {
	for _, d := range []string{
		filepath.Join(dir, "src"),
		filepath.Join(dir, "bs", "src"),
		filepath.Join(dir, "pm", "src"),
	} {
		if err := mkdirAll(d); err != nil {
			return err
		}
	}
	root := strings.Join([]string{
		"[package]",
		`name = "probe-graph"`,
		`version = "0.1.0"`,
		`edition = "2021"`,
		"",
		"[dependencies]",
		`probe-bs = { path = "bs" }`,
		`probe-pm = { path = "pm" }`,
		"",
	}, "\n")
	if err := os.WriteFile(filepath.Join(dir, "Cargo.toml"), []byte(root), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(dir, "src", "main.rs"), []byte("fn main() {}\n"), 0o644); err != nil {
		return err
	}

	bs := strings.Join([]string{
		"[package]",
		`name = "probe-bs"`,
		`version = "0.1.0"`,
		`edition = "2021"`,
		`links = "probelib"`,
		`build = "build.rs"`,
		"",
	}, "\n")
	if err := os.WriteFile(filepath.Join(dir, "bs", "Cargo.toml"), []byte(bs), 0o644); err != nil {
		return err
	}
	buildRS := "fn main() {\n    let _ = std::fs::write(" + quoteRust(bsMarker) + ", b\"executed\");\n}\n"
	if err := os.WriteFile(filepath.Join(dir, "bs", "build.rs"), []byte(buildRS), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(dir, "bs", "src", "lib.rs"), []byte("pub fn f() {}\n"), 0o644); err != nil {
		return err
	}

	pm := strings.Join([]string{
		"[package]",
		`name = "probe-pm"`,
		`version = "0.1.0"`,
		`edition = "2021"`,
		"",
		"[lib]",
		"proc-macro = true",
		"",
	}, "\n")
	if err := os.WriteFile(filepath.Join(dir, "pm", "Cargo.toml"), []byte(pm), 0o644); err != nil {
		return err
	}
	pmSrc := "use proc_macro::TokenStream;\n" +
		"#[proc_macro]\n" +
		"pub fn nothing(_: TokenStream) -> TokenStream {\n" +
		"    let _ = std::fs::write(" + quoteRust(pmMarker) + ", b\"executed\");\n" +
		"    TokenStream::new()\n" +
		"}\n"
	return os.WriteFile(filepath.Join(dir, "pm", "src", "lib.rs"), []byte(pmSrc), 0o644)
}

func quoteRust(s string) string {
	return `"` + strings.ReplaceAll(strings.ReplaceAll(s, `\`, `\\`), `"`, `\"`) + `"`
}

func writeWrapperScript(path, log string) error {
	if err := mkdirAll(filepath.Dir(path)); err != nil {
		return err
	}
	body := "#!/bin/sh\nprintf 'WRAPPER %s\\n' \"$1\" >> " + shQuote(log) + "\nexec \"$@\"\n"
	return os.WriteFile(path, []byte(body), 0o755)
}

func shQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func writeWrapperFixture(dir, work, log string) error {
	wrapper := filepath.Join(work, "struct", "wrapper.sh")
	if err := writeWrapperScript(wrapper, log); err != nil {
		return err
	}
	manifest, _ := manifestFor("probe-pkgconfig", "2021", `"1.85"`)
	if err := writeFixture(dir, manifest); err != nil {
		return err
	}
	if err := mkdirAll(filepath.Join(dir, ".cargo")); err != nil {
		return err
	}
	cfg := "[build]\nrustc-wrapper = " + quoteRust(wrapper) + "\n"
	return os.WriteFile(filepath.Join(dir, ".cargo", "config.toml"), []byte(cfg), 0o644)
}

func writeWrapperFixtureAncestor(base, dir, work, log string) error {
	wrapper := filepath.Join(work, "struct", "wrapper-ancestor.sh")
	if err := writeWrapperScript(wrapper, log); err != nil {
		return err
	}
	if err := mkdirAll(filepath.Join(base, ".cargo")); err != nil {
		return err
	}
	cfg := "[build]\nrustc-wrapper = " + quoteRust(wrapper) + "\n"
	if err := os.WriteFile(filepath.Join(base, ".cargo", "config.toml"), []byte(cfg), 0o644); err != nil {
		return err
	}
	manifest, _ := manifestFor("probe-ancestor", "2021", `"1.85"`)
	return writeFixture(dir, manifest)
}

// shimNames is the acceptance test's shim list from reference section 12.1.
var shimNames = []string{
	"cc", "c++", "clang", "clang++", "ld", "ld64", "xcrun", "ar", "ranlib",
	"dsymutil", "strip", "sh", "bash", "env", "lld", "ld.lld", "ld64.lld",
	"gcc", "install_name_tool", "codesign", "link", "cl", "lib", "vswhere", "cmd",
}

func writeShims(dir, log string) error {
	if err := mkdirAll(dir); err != nil {
		return err
	}
	for _, n := range shimNames {
		body := "#!/bin/sh\nprintf 'PATH-RESOLVED: %s\\n' " + shQuote(n) + " >> " + shQuote(log) + "\nexit 127\n"
		if err := os.WriteFile(filepath.Join(dir, n), []byte(body), 0o755); err != nil {
			return err
		}
	}
	return nil
}
