package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
)

// ---------------------------------------------------------------------------
// The exact normative pipeline: the two argument vectors of reference section
// 5, run with the manager-written configuration of section 6.1, a vendored
// crates.io dependency, an operation-private CARGO_HOME and HOME, and both
// source-mode mappings.
//
// The vendored dependency is constructed rather than downloaded. A directory
// source is exactly a directory of crate directories each carrying
// `.cargo-checksum.json`, so a constructed one exercises the same Cargo code
// path as a `cargo vendor` output, needs no network, and needs no operator
// registry cache. That is stated here rather than implied: the probe measures
// the vendored *pipeline*, not crates.io availability.
// ---------------------------------------------------------------------------

const probeDepManifest = `[package]
name = "probedep"
version = "0.1.0"
edition = "2018"
build = false
`

const probeDepSource = "pub fn answer() -> u32 { 42 }\n"

const probeRootLock = `version = 4

[[package]]
name = "probedep"
version = "0.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0000000000000000000000000000000000000000000000000000000000000000"

[[package]]
name = "probemain"
version = "0.1.0"
dependencies = [
 "probedep",
]
`

const probeRootManifest = `[package]
name = "probemain"
version = "0.1.0"
edition = "2021"

[dependencies]
probedep = "0.1.0"
`

// writeVendoredBuildRoot lays out a build root that satisfies L1 through L7 and
// Stage P, with one vendored crates.io dependency.
func writeVendoredBuildRoot(root string) error {
	if err := mkdirAll(filepath.Join(root, "src")); err != nil {
		return err
	}
	dep := filepath.Join(root, "vendor", "probedep")
	if err := mkdirAll(filepath.Join(dep, "src")); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(root, "Cargo.toml"), []byte(probeRootManifest), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(root, "Cargo.lock"), []byte(probeRootLock), 0o644); err != nil {
		return err
	}
	main := "fn main() { println!(\"{}\", probedep::answer()); }\n"
	if err := os.WriteFile(filepath.Join(root, "src", "main.rs"), []byte(main), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(dep, "Cargo.toml"), []byte(probeDepManifest), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(dep, "src", "lib.rs"), []byte(probeDepSource), 0o644); err != nil {
		return err
	}
	return writeCargoChecksum(dep)
}

func writeCargoChecksum(dir string) error {
	files := map[string]string{}
	err := filepath.Walk(dir, func(p string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return err
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(dir, p)
		if err != nil {
			return err
		}
		s := sha256.Sum256(b)
		files[filepath.ToSlash(rel)] = hex.EncodeToString(s[:])
		return nil
	})
	if err != nil {
		return err
	}
	doc, err := json.Marshal(map[string]any{"files": files, "package": strings.Repeat("0", 64)})
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(dir, ".cargo-checksum.json"), doc, 0o644)
}

// opEnv is the operation-private environment of reference section 6, complete
// rather than reduced: a private CARGO_HOME holding only the manager-written
// config, a private HOME, and the link pins.
func opEnv(work string, tc Toolchain, cargoHome, targetDir, pathDir string) map[string]string {
	env := baseEnv(work, tc.RustcPath, pathDir)
	env["CARGO_HOME"] = cargoHome
	env["CARGO_TARGET_DIR"] = targetDir
	env["HOME"] = filepath.Join(cargoHome, "..", "home")
	env["RUSTDOC"] = filepath.Join(tc.Root, "bin", "rustdoc")
	_ = mkdirAll(cargoHome)
	_ = mkdirAll(targetDir)
	_ = mkdirAll(env["HOME"])
	return tc.linkPins(env)
}

var graphArgv = []string{"metadata", "--format-version", "1", "--locked", "--offline",
	"--color", "never", "--quiet", "--all-features"}

func compileArgv(tuple, bin string) []string {
	return []string{"build", "--locked", "--offline", "--color", "never", "--quiet",
		"--release", "--target", tuple, "--bin", bin}
}

// structExactPipeline is the check the previous revision did not have: the
// exact two argument vectors, the exact manager-written config, a vendored
// dependency, isolated Cargo state, and a poisoned PATH, in one run.
func structExactPipeline(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "exact-pipeline-vendored-isolated",
		Title:    "the exact graph and compile vectors over a vendored dependency with the manager-written config",
		Expected: "graph 0, build 0, 0 PATH resolutions, artifact runs",
		Obligation: "Every element is normative: --all-features on the graph vector, --locked, the literal-string " +
			"directory value, an operation-private CARGO_HOME and HOME, and an empty PATH.",
	}
	if runtime.GOOS == "windows" {
		s.Observed = "not run: the poisoned-PATH shims are POSIX shell scripts"
		s.Verdict = "not_run"
		return s
	}
	base := filepath.Join(work, "struct", "exact")
	_ = os.RemoveAll(base)
	root := filepath.Join(base, "build_root")
	if err := writeVendoredBuildRoot(root); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	shimDir := filepath.Join(base, "poisoned-path")
	log := filepath.Join(base, "PATH_HITS")
	if err := writeShims(shimDir, log); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	cargoHome := filepath.Join(base, "cargo-home")
	target := filepath.Join(base, "target")
	if err := mkdirAll(cargoHome); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	doc, why := serializeCargoConfig(filepath.Join(root, "vendor"))
	if why != "" {
		s.Observed = "config rejected: " + why
		s.settle()
		return s
	}
	if err := os.WriteFile(filepath.Join(cargoHome, "config.toml"), []byte(doc), 0o644); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	// Write-back verification, exactly as section 6.1 requires of a manager.
	back, rerr := os.ReadFile(filepath.Join(cargoHome, "config.toml"))
	got, ok := reparseDirectory(string(back))
	if rerr != nil || !ok || got != filepath.Join(root, "vendor") || len(tableHeaders(string(back))) != 4 {
		s.Observed = "write-back verification failed"
		s.settle()
		return s
	}

	env := opEnv(work, tc, cargoHome, target, shimDir)
	_ = os.Remove(log)
	rGraph, graphOut := exec1Full(root, env, append([]string{tc.CargoPath}, graphArgv...)...)
	rBuild := exec1(root, env, append([]string{tc.CargoPath}, compileArgv(tc.HostTuple, "probemain")...)...)
	hits := countLines(log)

	artifact := filepath.Join(target, tc.HostTuple, "release", "probemain")
	rRun := exec1(base, map[string]string{"PATH": shimDir}, artifact)

	s.Runs = append(s.Runs, rGraph, rBuild, rRun)
	s.Evidence = append(s.Evidence,
		fmt.Sprintf("graph exit=%d build exit=%d artifact exit=%d", rGraph.ExitCode, rBuild.ExitCode, rRun.ExitCode),
		fmt.Sprintf("PATH resolutions=%d", hits),
		fmt.Sprintf("graph packages=%s", strings.Join(packageNames(graphOut), ",")),
		"config bytes="+fmt.Sprintf("%d", len(doc)))

	switch {
	case rGraph.ExitCode == 0 && rBuild.ExitCode == 0 && hits == 0 && strings.TrimSpace(rRun.Stdout) == "42":
		s.Observed = "graph 0, build 0, 0 PATH resolutions, artifact runs"
	default:
		s.Observed = fmt.Sprintf("graph %d, build %d, %d PATH resolutions, artifact stdout %q",
			rGraph.ExitCode, rBuild.ExitCode, hits, strings.TrimSpace(rRun.Stdout))
	}
	s.settle()
	return s
}

// structSourceModeEquivalence maps byte-identical build-root bytes through both
// source modes: a local build root at the snapshot top, and a nested build root
// inside a larger repository snapshot that also carries files the compiler must
// never see. Git acquisition is out of the probe's scope and is measured
// separately; what is checked here is the mapping and the resulting graph.
func structSourceModeEquivalence(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "local-and-external-source-mapping-equivalence",
		Title:    "byte-identical build roots in local and nested-external layouts produce the same graph",
		Expected: "identical build-root digest, identical graph after substitution",
		Obligation: "Only the selected build root is compiler-visible; the surrounding external snapshot " +
			"contributes no input.",
	}
	base := filepath.Join(work, "struct", "modes")
	_ = os.RemoveAll(base)
	localRoot := filepath.Join(base, "local", "build_root")
	extRoot := filepath.Join(base, "external", "repo", "crates", "tool")
	for _, r := range []string{localRoot, extRoot} {
		if err := writeVendoredBuildRoot(r); err != nil {
			s.Observed = "fixture error: " + err.Error()
			s.settle()
			return s
		}
	}
	// Files that exist in the external snapshot and must not reach the graph.
	_ = mkdirAll(filepath.Join(base, "external", "repo", "docs"))
	_ = os.WriteFile(filepath.Join(base, "external", "repo", "docs", "README.md"), []byte("outside\n"), 0o644)
	_ = os.WriteFile(filepath.Join(base, "external", "repo", "OUTSIDE.txt"), []byte("outside\n"), 0o644)

	dLocal := treeDigest(localRoot)
	dExt := treeDigest(extRoot)

	var graphs []string
	for i, r := range []string{localRoot, extRoot} {
		cargoHome := filepath.Join(base, fmt.Sprintf("cargo-home-%d", i))
		target := filepath.Join(base, fmt.Sprintf("target-%d", i))
		_ = mkdirAll(cargoHome)
		doc, why := serializeCargoConfig(filepath.Join(r, "vendor"))
		if why != "" {
			s.Observed = "config rejected: " + why
			s.settle()
			return s
		}
		_ = os.WriteFile(filepath.Join(cargoHome, "config.toml"), []byte(doc), 0o644)
		env := opEnv(work, tc, cargoHome, target, "")
		run, out := exec1Full(r, env, append([]string{tc.CargoPath}, graphArgv...)...)
		s.Runs = append(s.Runs, run)
		if run.ExitCode != 0 {
			s.Observed = fmt.Sprintf("graph exit %d in mode %d", run.ExitCode, i)
			s.settle()
			return s
		}
		norm := strings.ReplaceAll(out, r, "<BUILD_ROOT>")
		norm = strings.ReplaceAll(norm, target, "<STAGING>")
		graphs = append(graphs, norm)
	}

	leaked := strings.Contains(graphs[1], "OUTSIDE.txt") || strings.Contains(graphs[1], "docs/README.md")
	switch {
	case dLocal == dExt && graphs[0] == graphs[1] && !leaked:
		s.Observed = "identical build-root digest, identical graph after substitution"
	case dLocal != dExt:
		s.Observed = "build-root digests differ"
	case leaked:
		s.Observed = "the external graph names a file outside the build root"
	default:
		s.Observed = "graphs differ after substitution"
	}
	s.Evidence = append(s.Evidence, "local digest="+dLocal, "external digest="+dExt)
	s.settle()
	return s
}

// structAllFeaturesRequired is the positive half of control C7: with the flag,
// a proc macro reachable only through a non-default feature is in the graph.
func structAllFeaturesRequired(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "all-features-exposes-optional-proc-macro",
		Title:    "a proc macro behind a non-default feature is in the graph only with --all-features",
		Expected: "with: proc-macro present; without: absent",
		Obligation: "Conformance vector 23 depends on this; without the flag the rejection matrix cannot see " +
			"the surface at all.",
	}
	root := filepath.Join(work, "struct", "featgate")
	if err := writeFeatureGateFixture(root); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	env := baseEnv(work, tc.RustcPath, "")
	withRun, withOut := exec1Full(root, env, append([]string{tc.CargoPath}, graphArgv...)...)
	plain := []string{"metadata", "--format-version", "1", "--locked", "--offline", "--color", "never", "--quiet"}
	withoutRun, withoutOut := exec1Full(root, env, append([]string{tc.CargoPath}, plain...)...)
	s.Runs = append(s.Runs, withRun, withoutRun)

	inWith := contains(packageNames(withOut), "probepm")
	inWithout := contains(packageNames(withoutOut), "probepm")
	s.Evidence = append(s.Evidence,
		"with --all-features: "+strings.Join(packageNames(withOut), ","),
		"without: "+strings.Join(packageNames(withoutOut), ","))
	switch {
	case inWith && !inWithout:
		s.Observed = "with: proc-macro present; without: absent"
	default:
		s.Observed = fmt.Sprintf("with: present=%v; without: present=%v", inWith, inWithout)
	}
	s.settle()
	return s
}

func writeFeatureGateFixture(root string) error {
	_ = os.RemoveAll(root)
	if err := mkdirAll(filepath.Join(root, "src")); err != nil {
		return err
	}
	if err := mkdirAll(filepath.Join(root, "probepm", "src")); err != nil {
		return err
	}
	manifest := `[package]
name = "probefeat"
version = "0.1.0"
edition = "2021"

[dependencies]
probepm = { path = "probepm", optional = true }

[features]
extra = ["dep:probepm"]
`
	if err := os.WriteFile(filepath.Join(root, "Cargo.toml"), []byte(manifest), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(root, "src", "main.rs"), []byte("fn main() {}\n"), 0o644); err != nil {
		return err
	}
	// The lock file is written by hand because the fixture has only path
	// dependencies and the normative graph vector passes --locked.
	lock := `version = 4

[[package]]
name = "probefeat"
version = "0.1.0"
dependencies = [
 "probepm",
]

[[package]]
name = "probepm"
version = "0.1.0"
`
	if err := os.WriteFile(filepath.Join(root, "Cargo.lock"), []byte(lock), 0o644); err != nil {
		return err
	}
	pm := `[package]
name = "probepm"
version = "0.1.0"
edition = "2021"

[lib]
proc-macro = true
`
	if err := os.WriteFile(filepath.Join(root, "probepm", "Cargo.toml"), []byte(pm), 0o644); err != nil {
		return err
	}
	src := "use proc_macro::TokenStream;\n#[proc_macro]\npub fn nothing(_: TokenStream) -> TokenStream { TokenStream::new() }\n"
	return os.WriteFile(filepath.Join(root, "probepm", "src", "lib.rs"), []byte(src), 0o644)
}

// structOutsideRootRead is the measurement that justifies Stage P: cargo reads,
// parses and reports a manifest outside the build root during the graph phase,
// and the lexical rule rejects the same declaration before any filesystem call.
func structOutsideRootRead(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "graph-phase-reads-outside-build-root",
		Title:    "cargo reports an outside manifest, and the Stage P grammar rejects it first",
		Expected: "cargo reads the outside manifest; the lexical rule rejects the declaration",
		Obligation: "A post-resolution check prevents compilation, not the read. Stage P decides on the declared " +
			"string.",
	}
	base := filepath.Join(work, "struct", "escape")
	_ = os.RemoveAll(base)
	root := filepath.Join(base, "build_root")
	outside := filepath.Join(base, "outside")
	if err := mkdirAll(filepath.Join(root, "src")); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	if err := mkdirAll(filepath.Join(outside, "src")); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	_ = os.WriteFile(filepath.Join(outside, "Cargo.toml"),
		[]byte("[package]\nname = \"probeoutside\"\nversion = \"0.1.0\"\nedition = \"2021\"\n"), 0o644)
	_ = os.WriteFile(filepath.Join(outside, "src", "lib.rs"), []byte("pub fn f() {}\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "Cargo.toml"),
		[]byte("[package]\nname = \"probeesc\"\nversion = \"0.1.0\"\nedition = \"2021\"\n\n"+
			"[dependencies]\nprobeoutside = { path = \"../outside\" }\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "src", "main.rs"), []byte("fn main() {}\n"), 0o644)

	env := baseEnv(work, tc.RustcPath, "")
	plain := []string{"metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet", "--all-features"}
	run, out := exec1Full(root, env, append([]string{tc.CargoPath}, plain...)...)
	s.Runs = append(s.Runs, run)

	cargoRead := run.ExitCode == 0 && contains(packageNames(out), "probeoutside")
	lexical := lexicalPathAdmitted("../outside") != ""
	s.Evidence = append(s.Evidence,
		fmt.Sprintf("graph exit=%d packages=%s", run.ExitCode, strings.Join(packageNames(out), ",")),
		"lexical verdict: "+lexicalPathAdmitted("../outside"))
	if cargoRead && lexical {
		s.Observed = "cargo reads the outside manifest; the lexical rule rejects the declaration"
	} else {
		s.Observed = fmt.Sprintf("cargo read=%v, lexical rejected=%v", cargoRead, lexical)
	}
	s.settle()
	return s
}

// structAncestorManifestEscape is the measurement that forced the second
// staging obligation: an ancestor workspace manifest satisfies every previous
// graph row while redirecting a dependency outside the build root.
func structAncestorManifestEscape(work string, tc Toolchain) Structural {
	s := Structural{
		ID:       "ancestor-workspace-manifest-escapes-old-rows",
		Title:    "an ancestor Cargo.toml moves workspace_root while workspace_members stays length one",
		Expected: "workspace_root above the build root, one member, that member is the build root package",
		Obligation: "Manager staging must guarantee no ancestor Cargo.toml; the graph must additionally require " +
			"workspace_root to equal the build root.",
	}
	base := filepath.Join(work, "struct", "ancman")
	_ = os.RemoveAll(base)
	parent := filepath.Join(base, "parent")
	root := filepath.Join(parent, "build_root")
	if err := mkdirAll(filepath.Join(root, "src")); err != nil {
		s.Observed = "fixture error: " + err.Error()
		s.settle()
		return s
	}
	_ = os.WriteFile(filepath.Join(parent, "Cargo.toml"), []byte("[workspace]\nmembers = [\"build_root\"]\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "Cargo.toml"),
		[]byte("[package]\nname = \"probeanc\"\nversion = \"0.1.0\"\nedition = \"2021\"\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "src", "main.rs"), []byte("fn main() {}\n"), 0o644)

	env := baseEnv(work, tc.RustcPath, "")
	plain := []string{"metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet", "--all-features"}
	run, out := exec1Full(root, env, append([]string{tc.CargoPath}, plain...)...)
	s.Runs = append(s.Runs, run)

	var doc struct {
		WorkspaceRoot    string   `json:"workspace_root"`
		WorkspaceMembers []string `json:"workspace_members"`
	}
	_ = json.Unmarshal([]byte(out), &doc)
	above := doc.WorkspaceRoot != "" && doc.WorkspaceRoot != root
	oneMember := len(doc.WorkspaceMembers) == 1 && strings.Contains(doc.WorkspaceMembers[0], "probeanc")
	detected := ancestorObligation(root) != ""
	s.Evidence = append(s.Evidence,
		"workspace_root="+doc.WorkspaceRoot,
		fmt.Sprintf("workspace_members=%d", len(doc.WorkspaceMembers)),
		fmt.Sprintf("staging obligation detects it=%v", detected))
	if above && oneMember && detected {
		s.Observed = "workspace_root above the build root, one member, that member is the build root package"
	} else {
		s.Observed = fmt.Sprintf("above=%v oneMember=%v detected=%v", above, oneMember, detected)
	}
	s.settle()
	return s
}

// packageNames pulls the package name list out of a cargo metadata document.
func packageNames(doc string) []string {
	var d struct {
		Packages []struct {
			Name string `json:"name"`
		} `json:"packages"`
	}
	if err := json.Unmarshal([]byte(doc), &d); err != nil {
		return nil
	}
	var out []string
	for _, p := range d.Packages {
		out = append(out, p.Name)
	}
	sort.Strings(out)
	return out
}

// treeDigest is a stable content digest over a directory: sorted relative paths
// with their content digests. It is the probe's own equivalence measure and is
// not curator-build-source-v1.
func treeDigest(root string) string {
	type ent struct{ path, sum string }
	var ents []ent
	_ = filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return err
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(root, p)
		s := sha256.Sum256(b)
		ents = append(ents, ent{filepath.ToSlash(rel), hex.EncodeToString(s[:])})
		return nil
	})
	sort.Slice(ents, func(i, j int) bool { return ents[i].path < ents[j].path })
	h := sha256.New()
	for _, e := range ents {
		h.Write([]byte(e.path))
		h.Write([]byte{0})
		h.Write([]byte(e.sum))
		h.Write([]byte{0})
	}
	return hex.EncodeToString(h.Sum(nil))
}
