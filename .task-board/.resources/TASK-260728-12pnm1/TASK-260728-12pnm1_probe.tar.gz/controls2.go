package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Controls C7 through C10 are the superseded behaviours this revision replaced.
// Each MUST fail. A control that stops failing means the defect it guards has
// been reintroduced, or the property that made it fail has been dropped.

// C7. The graph vector without --all-features. Guards the rejection matrix
// against a package surface it cannot see: measured, an optional proc-macro
// dependency behind a non-default feature is absent from packages[] entirely.
func controlOmittedAllFeatures(work string, tc Toolchain) Control {
	c := Control{
		ID:     "C7/graph-without-all-features",
		Guards: "a proc macro reachable only through a non-default feature, invisible to the matrix",
	}
	if !tc.Available {
		c.Detail = "not run: no toolchain"
		return c
	}
	root := filepath.Join(work, "struct", "control-featgate")
	if err := writeFeatureGateFixture(root); err != nil {
		c.Detail = "fixture error: " + err.Error()
		return c
	}
	env := baseEnv(work, tc.RustcPath, "")
	plain := []string{"metadata", "--format-version", "1", "--locked", "--offline", "--color", "never", "--quiet"}
	run, out := exec1Full(root, env, append([]string{tc.CargoPath}, plain...)...)
	names := packageNames(out)
	if run.ExitCode != 0 {
		c.Detail = fmt.Sprintf("not a valid control: the graph command exited %d", run.ExitCode)
		return c
	}
	// The superseded classifier decides G3 from this graph. It finds nothing,
	// which is exactly the failure.
	if !contains(names, "probepm") {
		c.Failed = true
		c.Findings = 1
		c.Detail = "the proc-macro package is absent from packages[]: " + strings.Join(names, ",")
	} else {
		c.Detail = "the proc-macro package was visible without the flag: " + strings.Join(names, ",")
	}
	return c
}

// C8. Deciding escape from graph output alone, with no Stage P. Guards against
// treating a post-resolution verdict as if it prevented the read.
func controlEscapeFromGraphOnly(work string, tc Toolchain) Control {
	c := Control{
		ID:     "C8/escape-decided-after-cargo-read",
		Guards: "cargo opening, parsing and reporting a manifest outside the build root",
	}
	if !tc.Available {
		c.Detail = "not run: no toolchain"
		return c
	}
	base := filepath.Join(work, "struct", "control-escape")
	_ = os.RemoveAll(base)
	root := filepath.Join(base, "build_root")
	outside := filepath.Join(base, "outside")
	_ = mkdirAll(filepath.Join(root, "src"))
	_ = mkdirAll(filepath.Join(outside, "src"))
	// The outside manifest is malformed, so any diagnostic quoting it is proof
	// that its bytes were read rather than merely named.
	_ = os.WriteFile(filepath.Join(outside, "Cargo.toml"), []byte("[package\nname = \"x\"\n"), 0o644)
	_ = os.WriteFile(filepath.Join(outside, "src", "lib.rs"), []byte("pub fn f() {}\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "Cargo.toml"),
		[]byte("[package]\nname = \"probeesc2\"\nversion = \"0.1.0\"\nedition = \"2021\"\n\n"+
			"[dependencies]\nprobeoutside = { path = \"../outside\" }\n"), 0o644)
	_ = os.WriteFile(filepath.Join(root, "src", "main.rs"), []byte("fn main() {}\n"), 0o644)

	env := baseEnv(work, tc.RustcPath, "")
	plain := []string{"metadata", "--format-version", "1", "--offline", "--color", "never", "--quiet", "--all-features"}
	run := exec1(root, env, append([]string{tc.CargoPath}, plain...)...)
	combined := run.Stdout + run.Stderr
	if strings.Contains(combined, "../outside/Cargo.toml") || strings.Contains(combined, "unclosed table") {
		c.Failed = true
		c.Findings = 1
		c.Detail = "cargo quoted the outside manifest before any verdict could be computed"
	} else {
		c.Detail = "no evidence that the outside manifest was read: " + firstLine(combined)
	}
	return c
}

// C9. The superseded configuration writer: concatenate the directory value into
// a TOML basic string with no representability rule. Guards against a
// package-influenced path changing the parsed configuration.
func controlNaiveConfigWriter() Control {
	c := Control{
		ID:     "C9/naive-basic-string-config",
		Guards: "a package-influenced vendor path injecting tables into the manager-written config",
	}
	evil := "/op/build_root/vendor\"\n\n[net]\noffline = false\nretry = 9\n\n[junk]\nk = \""
	doc := naiveBasicStringConfig(evil)
	headers := tableHeaders(doc)
	if len(headers) > 4 || strings.Contains(doc, "offline = false") {
		c.Failed = true
		c.Findings = len(headers)
		c.Detail = fmt.Sprintf("the written document carries %d table headers and an injected offline=false", len(headers))
	} else {
		c.Detail = fmt.Sprintf("the naive writer produced %d headers with no injection", len(headers))
	}
	// The rule-bound writer must reject the same value rather than escape it.
	if _, why := serializeCargoConfig(evil); why == "" {
		c.Failed = false
		c.Detail += "; the rule-bound writer accepted the same value, which is a regression"
	}
	return c
}

// C10. Operator Cargo state inherited instead of isolated. Guards the claim
// that the vendor directory is the only admitted source: measured, an operator
// configuration satisfies a dependency for a build root that has no vendor
// directory at all.
func controlOperatorCargoLeak(work string, tc Toolchain) Control {
	c := Control{
		ID:     "C10/operator-cargo-state-inherited",
		Guards: "the operator's Cargo configuration and cache supplying package bytes",
	}
	if !tc.Available {
		c.Detail = "not run: no toolchain"
		return c
	}
	base := filepath.Join(work, "struct", "control-leak")
	_ = os.RemoveAll(base)

	// A build root with no vendor directory of its own.
	root := filepath.Join(base, "build_root")
	if err := writeVendoredBuildRoot(root); err != nil {
		c.Detail = "fixture error: " + err.Error()
		return c
	}
	opVendor := filepath.Join(base, "operator-vendor")
	if err := os.Rename(filepath.Join(root, "vendor"), opVendor); err != nil {
		c.Detail = "fixture error: " + err.Error()
		return c
	}

	// A simulated operator home whose .cargo/config.toml replaces crates.io
	// with that directory. This is the operator state a manager must not
	// inherit, constructed rather than assumed to exist on the runner.
	opHome := filepath.Join(base, "operator-home")
	_ = mkdirAll(filepath.Join(opHome, ".cargo"))
	doc, why := serializeCargoConfig(opVendor)
	if why != "" {
		c.Detail = "config rejected: " + why
		return c
	}
	_ = os.WriteFile(filepath.Join(opHome, ".cargo", "config.toml"), []byte(doc), 0o644)

	target := filepath.Join(base, "target")
	inherited := baseEnv(work, tc.RustcPath, "")
	delete(inherited, "CARGO_HOME")
	inherited["HOME"] = opHome
	inherited["CARGO_TARGET_DIR"] = target
	leakRun := exec1(root, inherited, append([]string{tc.CargoPath}, graphArgv...)...)

	isolated := opEnv(work, tc, filepath.Join(base, "private-cargo-home"), target, "")
	isoRun := exec1(root, isolated, append([]string{tc.CargoPath}, graphArgv...)...)

	if leakRun.ExitCode == 0 && isoRun.ExitCode != 0 {
		c.Failed = true
		c.Findings = 1
		c.Detail = fmt.Sprintf("inherited operator state resolved the dependency (exit 0) where isolation failed (exit %d)",
			isoRun.ExitCode)
	} else {
		c.Detail = fmt.Sprintf("inherited exit=%d isolated exit=%d", leakRun.ExitCode, isoRun.ExitCode)
	}
	return c
}

func firstLine(s string) string {
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return s[:i]
	}
	return s
}
